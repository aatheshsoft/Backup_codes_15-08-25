import React from 'react';
import { useNavigate } from 'react-router-dom';
import selectedImage from '../Assets/mft-ordernow.png';

const Sticker = () => {
  const navigate = useNavigate();

  const handleClick = () => {
    navigate('/quick'); // 🔁 Replace with your actual route
  };

  return (
    <div className="Sticker" onClick={handleClick} style={{ cursor: 'pointer' }}>
      <img
        src={selectedImage}
        alt="Selected"
        style={{ width: "100%", height: "auto" }}
      />
    </div>
  );
};

export default Sticker;
