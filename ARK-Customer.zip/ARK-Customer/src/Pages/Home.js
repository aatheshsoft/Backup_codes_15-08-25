import React, { useState, useEffect } from "react";
import axios from "axios";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faWhatsapp } from "@fortawesome/free-brands-svg-icons";
import "@fortawesome/fontawesome-free/css/all.min.css";
import { IoSendSharp } from "react-icons/io5";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap-icons/font/bootstrap-icons.css";
import Carousel from "react-bootstrap/Carousel";
import Footer from "./Footer";
import Header from "./Header";
import Scroll from "./Scroll";
import Card from "react-bootstrap/Card";
import image from "../Assets/profile-banner.jpg";
// import image1 from "../Assets/home_shasti.png";
// import image2 from "../Assets/safety.jpg";
import Stats from "./Stats";
import { Button } from "react-bootstrap";
import { Link, useNavigate } from "react-router-dom";
import CrackersLoader from './CrackersLoader';
import Animation from "./Animation"
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay } from "swiper/modules";
import Adbanner from '../Assets/middle-banner.jpg';
// import Adbanner1 from '../Assets/mft-banner-22.jpeg';
// import Adbanner2 from '../Assets/mft-banner1.jpg';
// Swiper styles
import "swiper/css";
import "swiper/css/autoplay";
import Sticker from "./Sticker";
import img from '../Assets/ark-banner-1.jpg'
import img1 from '../Assets/ark-banner-2.jpg'


const Home = () => {
  const [isChatBoxVisible, setChatBoxVisible] = useState(false);
  const [showDos, setShowDos] = useState(true);
  const [categories, setCategories] = useState([]);
  const [carouselImages, setCarouselImages] = useState([]);
  const [marqueeText, setMarqueeText] = useState([]);
  const [message, setMessage] = useState("");
  const [homeData, setHomeData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [whatsappNumber, setWhatsappNumber] = useState("");
  const [gallery, setGallery] = useState([]);
  const [clientlogo, setClientLogo] = useState([]);
      const navigate = useNavigate();


  const toggleChatBox = () => {
    setChatBoxVisible(!isChatBoxVisible);
  };
  
  const handleMessageChange = (e) => {
    setMessage(e.target.value);
  };

  const sendMessage = () => {
    if (!whatsappNumber) {
      console.log("WhatsApp number is not available yet");
      return;
    }

    const whatsappUrl = `https://wa.me/${whatsappNumber.replace(
      "+",
      ""
    )}?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, "_blank");
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.post(
          "https://arkcrackers.com/customer_api/home.php"
        );
        const { body } = response.data;
        setCategories(body?.category_front || []);
        setCarouselImages(body?.banner || []);
        setMarqueeText(body?.scrollnew?.map(item => item.msg) || []);
        setGallery(body?.gallery || []);
        setClientLogo(body?.client_logo || []);
      } catch (error) {
        console.error("There was an error fetching the data!", error);
      } finally{                                                      
        setIsLoading(false); // Stop loading after data is fetched
      }
    };
    fetchData();   
  }, []);


  useEffect(() => {
    const fetchHomeData = async () =>  {
      try {
        const response = await axios.get(" https://arkcrackers.com/customer_api/content.php");
        const { body } = response.data;
        const { whatsapp_number } = response.data.body.contact;
        setHomeData(body.home);
        setWhatsappNumber(whatsapp_number);
      } catch (error) {
        console.error("Error fetching the about data", error);
      }
    };
    fetchHomeData();
  }, []);

  if (isLoading) {
    return <CrackersLoader />;
  }

  if (!homeData) {
    return <p> </p>; 
  }


const handleCategoryClick = (category) => {
    navigate('/quick', { state: { selectedCategory: category.category_name } });
  };



  return (
    <div className="main-homepage">
      <Header />

      {/* Carousel Section */}
      <div
        className="carousel-container"
        style={{ position: "relative", overflow: "hidden" }}
      >
        <Carousel interval={3000}>
          {carouselImages.map(({ id, image }) => (
            <Carousel.Item key={id}>
              <img
                className="d-block w-100 "
                src={image}
                alt="Carousel slide"
                // onClick={() => handleImageClick(image)}
              />
            </Carousel.Item>
          ))}
          
           {/* <Carousel.Item>
    <img
      className="d-block w-100"
      src={img}
       alt="Carousel slide"
    />
  </Carousel.Item>

  <Carousel.Item>
    <img
      className="d-block w-100"
      src={img1}
  alt="Carousel slide"    
  />
  </Carousel.Item> */}

        </Carousel>
        {/* <Animation /> */}
      </div>

      {/* Marquee Section */}
      <div className="marquee-container">
        <div className="marquee">
          <p>{marqueeText}</p>
        </div>
      </div>

      {/*   content  Section */}
      {/* <div class="banner-wrapper">
  <img src={Adbanner1} alt="Ad Banner 1" class="banner-img1" />
  <img src={Adbanner2} alt="Ad Banner 2" class="banner-img1" />
</div> */}


      <div
        className="content-section"
        style={{ backgroundImage: `url(${image})` }}
      >
        {/* Top Image */}
        <div className="topimg">
          <img src="" alt="" />
        </div>
        {/* Content aligned to the right */}
        <div className="content-text">
          <h5 style={{color:"white"}}><b>Welcome to</b></h5>
         
          <h3 style={{ letterSpacing: "2px", color: "yellow" }}>
            ARK CRACKERS
          </h3>
          <h4 style={{color:"white"}}> 
            WHOLESALE & RETAIL SHOP IN{" "}
            <span style={{ color: "yellow" }}>SIVAKASI</span>
          </h4>
          <br />
          <p
              style={{ fontFamily: " Arial, Helvetica, sans-serif",color:"white"
               }}
              dangerouslySetInnerHTML={{ __html: homeData.value }}
            />
          <br />
          <hr />
          <div className="adlist">
            <div className="adlist2">
              <p>
                <i class="bi bi-check tick"> </i>
                <span>  Best Quality</span>
              </p>
              <p>
                <i class="bi bi-check tick"></i>
                <span> Best price</span>
              </p>
              
            </div>
            <div className="adlist1">
              <p>
                <i class="bi bi-check tick"> </i>
                <span> Safe to Use</span>
                
              </p>
              {/* <p>
                <i class="bi bi-check tick"></i>
                <span> Our Crackers are Organic</span>
              </p> */}
              
            </div>
          </div>
        </div>
      </div>
 <Sticker /> 
      {/*categories section */}

      <div style={{ height: "auto" }}>
        <div>
          <div className="newarr">
            <div className="horizontal-line-text-container">
              <hr className="line" />
              <h4 className="text123">Our Top Categories </h4>  
              
              <hr className="line" />
            </div>

            <div className="newarrival">
              {categories.map((category) => (
                <div key={category.category_id}
                  className="card-container"
                  onClick={() => handleCategoryClick(category)}
                  style={{ cursor: 'pointer' }}
                 >
                  {/* <Link to="/quick"> */}
                  <Card
                    // style={{ width: "14rem" }}
                    className="sub-banner custom-shadow "
                  >
                    <img
                      src={category.image}
                      alt={category.category_name}
                      className="d-block   img12"
                    />
                    <Card.Body>
                      <Card.Title className="imgname">
                        {category.category_name}
                      </Card.Title>
                    </Card.Body>
                  </Card>
                  {/* </Link> */}
                </div>
              ))}
            </div>

            <br />
          </div>
        </div>
      </div>
      <div className="ad-banner-wrapper">
      <img src={Adbanner} alt="Advertisement Banner" className="ad-banner-img" />
    </div>

    <div className="horizontal-line-text-container">
              <hr className="line" />
              <h4 className="text123">Gallery </h4>  
              
              <hr className="line" />
            </div>

            <div className="gallery-slider-container">
         
            <Swiper
              slidesPerView={4} 
              spaceBetween={10} 
              breakpoints={{
                320: { slidesPerView: 2, spaceBetween: 10 }, 
                480: { slidesPerView: 2, spaceBetween: 10 }, 
                768: { slidesPerView: 3, spaceBetween: 10 },
                1024: { slidesPerView: 4, spaceBetween: 10 },
              }}
              loop={true}
              autoplay={{ delay: 2000, disableOnInteraction: false }}
              modules={[Autoplay]}
              className="gallery-swiper"
            >
              {gallery.map((logo, index) => (
                <SwiperSlide key={index} className="gallery-slide">
                  <div className="gallery-card">
                    <img src={logo.image} alt={`Client ${index}`} className="gallery-image" />
                  </div>
                </SwiperSlide>
              ))}
            </Swiper>
          </div>


          <div className="horizontal-line-text-container">
              <hr className="line" />
              <h4 className="text123">Brands </h4>  
              
              <hr className="line" />
            </div>
      <div className="client-logo-section">
      <Swiper
        slidesPerView={6} 
        spaceBetween={20}
        breakpoints={{
          320: { slidesPerView: 2 },
          480: { slidesPerView: 3 }, 
          768: { slidesPerView: 4 }, 
          1024: { slidesPerView: 6 }, 
        }}
        loop={true}
        autoplay={{ delay: 2000, disableOnInteraction: false }}
        modules={[Autoplay]}
      >
        {clientlogo.map((logo, index) => (
          <SwiperSlide key={index} className="client-logo-slide">
            <img src={logo.image} alt={`Client ${index}`} className="client-logo-img" />
          </SwiperSlide>
        ))}
      </Swiper>
    </div>

      {/* <div className="content-section1">
        
        <div className="content-text">
          
          <br />
          <h3 style={{ letterSpacing: "2px", color: "#c43004" }}>
            SAFETY TIPS
          </h3>
          <div className="dos">
            <Button
              as="input"
              type="button"
              value="DO'S"
              className="doss"
              onClick={() => setShowDos(true)}
            />
            <Button
              as="input"
              type="button"
              value="DON'TS"
              className="donts"
              onClick={() => setShowDos(false)}
            />
          </div>
          <br />
          {showDos ? (
            <div className="dos-content">
              <p >
                Here are some important safety tips you should follow when using
                our products:
              </p>
              <ul>
                <li>
                  If you have to buy fireworks, be sure to buy them from a
                  licensed dealer
                </li>
                <li>Keep a bucket of sand or a fire extinguisher handy.</li>
                <li>
                  Ensure there are no inflammable and combustible materials
                  around the fire-cracking area
                </li>
                <li>Follow all safety precautions issued with the fireworks</li>
                <li>Discard used fireworks in a bucket of water</li>
                <li>Burst crackers in safe places that are not crowded</li>
                
              </ul>
            </div>
          ) : (
            <div className="donts-content">
              <p>
                Avoid these actions to ensure safety:
              </p>
              <ul>
                <li>Don't let children play alone with firecrackers</li>
                <li>
                  Don't keep the firecrackers near burning diyas or agarbattis.
                </li>
                <li>
                  Don't wear synthetic or loose garments; thick cotton clothes
                  are ideal.
                </li>
                <li>
                  Don't light crackers while holding them in your hand; you
                  should always light them in open grounds pointing straight up
                </li>
               
              </ul>
            </div>
          )}
         
        </div>
        <div className="topimg">
          <img src={image2} alt="Top" />
        </div>
      </div> */}
      {/* <Stats /> */}

      <div className="minifooter1">
      <div className="minimenu">
          
            <Link to="/">
            <div style={{display:"flex", flexDirection:"column",color:"white"}}>
          <i class="bi bi-house-door" style={{marginLeft:"12px",fontSize:"1.4rem"}}></i>
             Home
             </div>
             </Link>
         
             <Link to="/about">
          <div style={{display:"flex", flexDirection:"column",color:"white"}}>
          <i class="bi bi-journal-text officon" style={{marginLeft:"20px",fontSize:"1.4rem",color:"white"}}></i>
             About Us
             </div>
             </Link>


          <Link to="/quick">
          <div style={{display:"flex", flexDirection:"column",color:"white"}}>
          <i class="bi bi-bag" style={{marginLeft:"18px",fontSize:"1.4rem"}}></i>
             Enquiry
             </div>
             </Link>

             
         
          <Link to="/contact">
          <div style={{display:"flex", flexDirection:"column",color:"white"}}>
          <i class="bi bi-telephone" style={{marginLeft:"12px",fontSize:"1.4rem"}}></i>
             Contact
             </div>
             </Link>
          
        </div>
      </div>

      {/* Floating WhatsApp Icon */}
      {/* WhatsApp Icon */}
      <div className="floating-whatsapp-container">
        <div className="floating-whatsapp" onClick={toggleChatBox}>
          <FontAwesomeIcon icon={faWhatsapp} />
        </div>
        {isChatBoxVisible && (
          <div className="chat-box">
            <div className="wats-header">
              <p>ARK Crackers</p>
              <button className="close-button" onClick={toggleChatBox}>
                X
              </button>
            </div>
            <div className="wats-content">
              <p>Welcome To ARK Crackers</p>
            </div>
            <div className="chat-content">
            <textarea
              placeholder="Type your message here..."
              value={message}
              onChange={handleMessageChange}
            ></textarea>
            <button onClick={sendMessage}>
              <IoSendSharp />
            </button>
          </div>
          </div>
        )}
      </div>
      <Scroll />
      <Footer />
    </div>
    
  );
};

export default Home;
