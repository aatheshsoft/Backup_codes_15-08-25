import React, { useState, useEffect } from "react";
import Header from "../Components/Header";
import { Link, useNavigate, useParams, useLocation } from "react-router-dom";
import axios from "axios";

const EditProducts = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const subcategory_id = location.state?.subcategory_id; // Get category_id from state
  const category_id = location.state?.category_id;
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

  const { product_id } = useParams();

  const [products, setProducts] = useState({
    product_code: "",
    product_name: "",
    sku_no: "",
    hsn_code: "",
    brand: "",
    stock: "",
    qty_per_box:"",
    
    mrp_rate: "",
    stock:"",
    description: "",
    age:"",
    tax: "",
    image1: "",
   
   
  });

  console.log(products);



  const imageFields = [ "image1"];

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await axios.post(
           `${API_BASE_URL}product_detail.php`,
          { product_id }
        );

        console.log("API Response:", response.data);

        if (response.data && response.data.body) {
          setProducts((prev) => ({
            ...prev,
            ...response.data.body, // Update state with API response
          }));
        } else {
          setError("No data found");
        }
      } catch (error) {
        console.error("Error fetching data:", error);
        setError("Failed to fetch data");
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, [product_id]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setProducts((prev) => ({ ...prev, [name]: value }));
  };

  const handleImageChange = (e, field) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setProducts((prev) => ({
          ...prev,
          [field]: reader.result, // Store Base64 image
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleUpdate = async (event) => {
    event.preventDefault();

    try {
      const response = await axios.post(
        `${API_BASE_URL}product_detail_update.php`,
        { product_id, ...products }
      );

      console.log("Update Response:", response.data);

      if (response.data.head.code === 200) {
        alert("Product updated successfully!");
        navigate(`/products/${category_id}`);
      } else {
        alert("Update failed: " + response.data.head.msg);
      }
    } catch (error) {
      console.error("Error updating product:", error);
      alert("Failed to update product.");
    }
  };

  if (loading) return <p>Loading...</p>;
  if (error) return <p className="text-danger">{error}</p>;

  return (
    <>
      <Header />
      <div className="page-wrapper compact-wrapper" id="pageWrapper">
        <div className="page-body-wrapper">
          <div className="page-body">
            <div className="container-fluid">
              <div className="row">
                <div className="col-12">
                  <div className="card">
                    <div className="card-body">
                      <div className="title-header option-title d-sm-flex d-block">
                        <h5>Edit Product</h5>
                        <div className="right-options">
                          <ul>
                            <li>
                              <Link
                                className="btn btn-solid"
                                onClick={() => window.history.back()}
                              >
                                Back
                              </Link>
                            </li>
                          </ul>
                        </div>
                      </div>

                      <form
                        className="theme-form theme-form-2 mega-form"
                        onSubmit={handleUpdate}
                      >
                        <div className="container">
                        
                          <div className="row mb-3">
                                  <label className="col-sm-3 col-form-label">Product Name</label>
                                  <div className="col-sm-9">
                              <input
                                required
                                className="form-control"
                                type="text"
                                name="product_name"
                                placeholder="Enter Product Name"
                                value={products.product_name || ""}
                                onChange={handleInputChange}
                              />
                            </div>
                          </div>
                        <div className="row mb-3">
                                  <label className="col-sm-3 col-form-label"> Rate</label>
                                  <div className="col-sm-9">
                                    <input
                                      className="form-control"
                                      type="text"
                                      name="mrp_rate"
                                      placeholder="Enter MRP Rate"
                                      value={products.mrp_rate || ""}
                                      onChange={handleInputChange}
                                    />
                                  </div>
                                </div>
{/* 
                                <div className="row mb-3">
                                  <label className="col-sm-3 col-form-label">Online Rate</label>
                                  <div className="col-sm-9">
                                    <input
                                      className="form-control"
                                      type="text"
                                      name="online_rate"
                                      placeholder="Enter Online Rate"
                                      value={products.online_rate || ""}
                                      onChange={handleInputChange}
                                    />
                                  </div>
                                </div> */}
                                <div className="row mb-3">
                                  <label className="col-sm-3 col-form-label">Qty Per Box</label>
                                  <div className="col-sm-9">
                                    <input
                                      className="form-control"
                                      type="text"
                                      name="qty_per_box"
                                      placeholder="Enter Qty Per Box"
                                      value={products.qty_per_box || ""}
                                        onChange={handleInputChange}
                                    />
                                  </div>
                                </div>

                                <div className="row mb-3">
                                  <label className="col-sm-3 col-form-label">Stock</label>
                                  <div className="col-sm-9">
                                    <input
                                      className="form-control"
                                      type="text"
                                      name="stock"
                                      placeholder="Enter Stock"
                                      value={products.stock || ""}
                                        onChange={handleInputChange}
                                    />
                                  </div>
                                </div>

                                <div className="row mb-3">
                                  <label className="col-sm-3 col-form-label">Youtube URL</label>
                                  <div className="col-sm-9">
                                    <input
                                      className="form-control"
                                      type="text"
                                      name="youtube_url"
                                      placeholder="Enter Youtube URL"
                                      value={products.youtube_url || ""}
                                      onChange={handleInputChange}
                                    />
                                  </div> 
                                </div>

                                <div className="row mb-3">
                                  <label className="col-sm-3 col-form-label">Age</label>
                                  <div className="col-sm-9">
                                  <input
                                    className="form-control"
                                    type="text"
                                    name="age"
                                    value={products.age || ""}
                                    onChange={handleInputChange}
                                  />
                                </div>
                                </div>

                              <div className="row mb-3">
                                  <label className="col-sm-3 col-form-label">Description</label>
                                  <div className="col-sm-9">
                                  <textarea
                                    className="form-control"
                                    type="text"
                                    name="description"
                                    value={products.description || ""}
                                    onChange={handleInputChange}
                                  />
                                </div>
                                </div>
                        

                                {imageFields.map((field, index) => (
  <div className="row mb-4 align-items-center" key={index}>
    {/* Label on the Left */}
    <label className="col-sm-3 col-form-label">Upload Image</label>

    {/* Input/Image on the Right */}
    <div className="col-sm-9">
      {products[field] ? (
        <div>
          <img
            src={products[field]}
            alt={`Product ${index + 1}`}
            style={{
              width: "100px",
              height: "100px",
              objectFit: "contain",
              borderRadius: "5px",
            }}
          />
          
          <button
            className="btn btn-danger mt-2"
            type="button"
            onClick={() =>
              setProducts((prev) => ({
                ...prev,
                [field]: "",
              }))
            }
          >
            Delete Image
          </button>
        </div>
      ) : (
        <div>
          <input
            type="file"
            className="form-control"
            onChange={(e) => handleImageChange(e, field)}
          />
          <p>Width 500px x 500px</p>
        </div>
      )}
    </div>
  </div>
))}
                        </div>
                        <div className="d-flex justify-content-end">
                          <button
                            className="btn btn-primary me-3"
                            type="submit"
                          >
                            Submit
                          </button>
                          <button
                            className="btn btn-outline"
                            type="button"
                            onClick={() => window.history.back()}
                          >
                            Cancel
                          </button>
                        </div>
                      </form>
                      {/* End Form Section */}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default EditProducts;
