import React, { useState } from "react";
import Header from "../Components/Header";
import { Link,useLocation,useNavigate } from "react-router-dom";
import axios from "axios";

const AddProducts = () => {
  const location = useLocation();
  const category_id = location.state?.category_id; 
  // const subcategory_id = location.state?.subcategory_id; 
  const navigate = useNavigate();
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

  const [formData, setFormData] = useState({
    cid: category_id,
    product_name: "",
    image1: "",
    image2: "",
    youtube_url:"",
    qty_per_box:"",
    // online_rate: "",
    mrp_rate: "",
    description: "",
    age:"",
    stock:""
  })


  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevState) => ({ ...prevState, [name]: value }));
  };

  const handleFileChange = (e) => {
    const { name, files } = e.target;
    if (files && files[0]) {
      setFormData((prev) => ({
        ...prev,
        [name]: files[0],
      }));
    }
  };
  

  
const handleSubmit = async (e) => {
  e.preventDefault();

  const convertToBase64 = (file) =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result);
      reader.onerror = (error) => reject(error);
    });

  try {
    const updatedFormData = { ...formData };
    const imageFields = ["image1", "image2"];

    for (const field of imageFields) {
      if (formData[field] instanceof File) {
        updatedFormData[field] = await convertToBase64(formData[field]);
      }
    }

    console.log("Sending data:", updatedFormData);

    const response = await axios.post(
      `${API_BASE_URL}product_add.php`,
      updatedFormData,
      { headers: { "Content-Type": "application/json" } }
    );

    console.log("Full response:", response);

    if (response.data?.head?.code === 200) {
      alert("Product added successfully!");
      navigate(`/products/${category_id}`);
    } else {
      console.error("API error:", response.data);
      alert(response.data?.head?.msg || "Unexpected server response");
    }
  } catch (error) {
    if (error.response) {
      console.error("Server responded with error:", error.response.data);
      alert(`Server Error: ${error.response.data.head?.msg || 'Unknown error'}`);
    } else if (error.request) {
      console.error("No response received:", error.request);
      alert("No response from server");
    } else {
      console.error("Error during setup:", error.message);
      alert("Error adding product: " + error.message);
    }
  }
};

  

  return (
    <>
      <Header />
      <div class="page-wrapper compact-wrapper" id="pageWrapper">
        <div class="page-body-wrapper">
        <div class="page-body">
        <div class="container-fluid">
          <div class="row">
            <div class="col-12">
                <div class="row">
                    <div class="col-sm-12 m-auto">
                        <div class="card">
                            <div class="card-body">
                               {/*  <!-- Header Section --> */}
                                <div class="title-header option-title d-sm-flex d-block">
                                    <h5>Add Product</h5>
                                    <div class="right-options">
                                        <ul>
                                        <li>
                                            <button className="btn btn-solid" onClick={() => window.history.back()}>
                                            Back
                                            </button>
                                        </li>
                                        </ul>
                                    </div>
                                </div>

                               {/*  <!-- Form Section --> */}
                               <form className="theme-form theme-form-2 mega-form" onSubmit={handleSubmit}>
                                        {/* Product Name */}
                                        <div className="row">
                                        <div className="col-md-12">
                                        <div className="mb-4 row align-items-center">
                                            <label className="col-md-4 col-sm-4 form-label-title">Product Name</label>
                                            <div className="col-md-8 col-sm-8">
                                            <input required className="form-control" type="text" name="product_name" placeholder="Enter Product Name" onChange={handleChange} />
                                            </div>
                                        </div>
                                        </div>
                                    </div>

                                        {/* Image Upload */}
                                        {[1].map((index) => (
  <div className="row" key={index}>
    <div className="col-md-12">
      <div className="mb-4 row align-items-center">
        <label className="col-md-4 col-sm-4 form-label-title">
           Image 
        </label>
        <div className="col-md-8 col-sm-8">
          <input
            type="file"
            className="form-control"
            name={`image${index}`} // name will be image1, image2
            accept="image/*"
            onChange={handleFileChange}
          />
          <p>Width 500px x 500px</p>
        </div>
      </div>
    </div>
  </div>
))}


                                    {/* HSN Code */}
                                    <div className="row">
                                        <div className="col-md-12">
                                        <div className="mb-4 row align-items-center">
                                            <label className="col-md-4 col-sm-4 form-label-title"> Rate</label>
                                            <div className="col-md-8 col-sm-8">
                                            <input className="form-control" type="text" name="mrp_rate" placeholder="Enter MRP Rate" onChange={handleChange} />
                                            </div>
                                        </div>
                                        </div>
                                     </div>
                                     {/* <div className="row">
                                        <div className="col-md-12">
                                        <div className="mb-4 row align-items-center">
                                            <label className="col-md-4 col-sm-4 form-label-title">Online Rate</label>
                                            <div className="col-md-8 col-sm-8">
                                            <input className="form-control" type="text" name="online_rate" placeholder="Enter Online Rate" onChange={handleChange} />
                                            </div>
                                        </div>
                                        </div>
                                     </div> */}
                                     <div className="row">
                                        <div className="col-md-12">
                                        <div className="mb-4 row align-items-center">
                                            <label className="col-md-4 col-sm-4 form-label-title">Qty Per Box</label>
                                            <div className="col-md-8 col-sm-8">
                                            <input className="form-control" type="text" name="qty_per_box" placeholder="Enter Qty Per Box" onChange={handleChange} />
                                            </div>
                                        </div>
                                        </div>
                                     </div>
                                     <div className="row">
                                        <div className="col-md-12">
                                        <div className="mb-4 row align-items-center">
                                            <label className="col-md-4 col-sm-4 form-label-title">Youtube URL</label>
                                            <div className="col-md-8 col-sm-8">
                                            <input className="form-control" type="text" name="youtube_url" placeholder="Enter Youtube URL" onChange={handleChange} />
                                            </div>
                                        </div>
                                        </div>
                                     </div>
                                 {/* Short Description */}
                                     <div className="row">
                                        <div className="col-md-12">
                                        <div className="mb-4 row align-items-center">
                                            <label className="col-md-4 col-sm-4 form-label-title"> Description</label>
                                            <div className="col-md-8 col-sm-8">
                                            <textarea className="form-control" type="text" name="description" placeholder="Enter  Description" onChange={handleChange} />
                                            </div>
                                        </div>
                                        </div>
                                    </div> 

 <div className="row">
                                        <div className="col-md-12">
                                        <div className="mb-4 row align-items-center">
                                            <label className="col-md-4 col-sm-4 form-label-title"> Age</label>
                                            <div className="col-md-8 col-sm-8">
                                            <input className="form-control" type="text" name="age" placeholder="Enter  Age" onChange={handleChange} />
                                            </div>
                                        </div>
                                        </div>
                                    </div> 
                                    <div className="row">
                                        <div className="col-md-12">
                                        <div className="mb-4 row align-items-center">
                                            <label className="col-md-4 col-sm-4 form-label-title"> Stock</label>
                                            <div className="col-md-8 col-sm-8">
                                            <input className="form-control" type="text" name="stock" placeholder="Enter  Stock" onChange={handleChange} />
                                            </div>
                                        </div>
                                        </div>
                                    </div>

                                  {/* Buttons */}
                                    <div className="card-footer border-0 pb-0 d-flex justify-content-end">
                                        <button className="btn btn-primary me-3" type="submit" name="save" value="save">
                                        Submit
                                        </button>
                                        <button className="btn btn-outline" onClick={() => window.history.back()}>
                                        Cancel
                                        </button>
                                    </div>
                                    </form>

                                {/* <!-- End Form Section --> */}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

        </div>
      </div>
    </>
  )
}

export default AddProducts