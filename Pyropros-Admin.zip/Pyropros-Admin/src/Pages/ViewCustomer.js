import React, { useState, useEffect } from "react";
import { Link, useParams } from "react-router-dom";
import Header from "../Components/Header";
import axios from "axios";

const ViewCustomer = () => {
  const { user_id } = useParams(); // Get user_id from URL params
  const [customer, setCustomer] = useState(null);
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

  useEffect(() => {
    const fetchCustomer = async () => {
      try {
        const response = await axios.post(`${API_BASE_URL}customer_detail.php`, { user_id });
        if (response.data.head.code === 200) {
          setCustomer(response.data.body);
        } else {
          console.error("Error fetching customer details:", response.data.head.msg);
        }
      } catch (error) {
        console.error("API Error:", error);
      }
    };

    fetchCustomer();
  }, [user_id]);

  if (!customer) {
    return <p>Loading customer details...</p>;
  }

  return (
    <>
      <Header />
      <div className="page-wrapper compact-wrapper" id="pageWrapper">
        <div className="page-body-wrapper">
          <div className="page-body">
            <div className="container-fluid">
              <div className="row">
                <div className="col-12">
                  <div className="row">
                    <div className="col-sm-12 m-auto">
                      <div className="card">
                        <div className="card-body">
                          <div className="title-header option-title d-sm-flex d-block">
                            <h5>View Customer</h5>
                            <div className="right-options">
                              <ul>
                                <li>
                                  <Link className="btn btn-solid" to="/customerlist">Back</Link>
                                </li>
                              </ul>
                            </div>
                          </div>

                          <form className="theme-form theme-form-2 mega-form">
                            <div className="mb-4 row align-items-center">
                              <label className="form-label-title col-sm-3 mb-0">Name</label>
                              <div className="col-sm-9">
                                <input readOnly className="form-control" type="text" value={customer.name || ""} />
                              </div>
                            </div>
                            <div className="mb-4 row align-items-center">
                              <label className="form-label-title col-sm-3 mb-0">Address</label>
                              <div className="col-sm-9">
                                <textarea readOnly rows="3" className="form-control" value={customer.address || ""}></textarea>
                              </div>
                            </div>
                            <div className="mb-4 row align-items-center">
                              <label className="form-label-title col-sm-3 mb-0">Email</label>
                              <div className="col-sm-9">
                                <input readOnly className="form-control" type="email" value={customer.email || ""} />
                              </div>
                            </div>
                            <div className="mb-4 row align-items-center">
                              <label className="form-label-title col-sm-3 mb-0">Phone Number</label>
                              <div className="col-sm-9">
                                <input readOnly className="form-control" type="text" value={customer.mobile || ""} />
                              </div>
                            </div>
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ViewCustomer;
