// src/context/CartContext.js
import React, { createContext, useContext, useState, useEffect } from 'react';

// Create context
const CartContext = createContext();

// Custom hook for easy access
export const useCart = () => useContext(CartContext);

// Provider component
export const CartProvider = ({ children }) => {
  const [cartItems, setCartItems] = useState(() => {
    const stored = localStorage.getItem("cartItems");
    return stored ? JSON.parse(stored) : [];
  });

const [messages, setMessages] = useState({});
  const [userId, setUserId] = useState(() => localStorage.getItem("user_id"));

const clearCart = () => {
  setCartItems([]);
};


  useEffect(() => {
    localStorage.setItem("cartItems", JSON.stringify(cartItems));
  }, [cartItems]);

  const addToCart = (product) => {
  setCartItems(prev => {
    const existing = prev.find(item =>
      item.id === product.id &&
      item.weight === product.weight &&
      item.unit === product.unit
    );

    // Show message based on existence
    setMessages(prevMessages => ({
      ...prevMessages,
      [product.id + '-' + product.weight + '-' + product.unit]: existing
        ? "This variant is already in your cart."
        : "Item added to cart!"
    }));

    // Clear after 2 seconds
    setTimeout(() => {
      setMessages(prevMessages => {
        const updated = { ...prevMessages };
        delete updated[product.id + '-' + product.weight + '-' + product.unit];
        return updated;
      });
    }, 2000);

    // Don't add if it already exists
    if (existing) return prev;

    // Add with default quantity if not present
    return [...prev, {
      ...product,
      quantity: product.quantity || 1,
    }];
  });
};



const updateQuantity = (productId, weight, amount) => {
  setCartItems(prevItems =>
    prevItems.map(item => {
      if (item.id === productId && item.weight === weight) {
        const newQty = Math.max(1, item.quantity + amount);
        return { ...item, quantity: newQty };
      }
      return item;
    })
  );
};



const removeFromCart = (productId, weight) => {
  setCartItems(prev =>
    prev.filter(item => !(item.id === productId && item.weight === weight))
  );
};





  const handleLogout = () => {
    localStorage.removeItem("user_id");
    localStorage.removeItem("username");
    console.log(localStorage.removeItem("user_id"))
    localStorage.removeItem(`cartItems_${userId}`); // Clear cart for this user
    setUserId(null); // Reset user ID
    setCartItems([]); // Clear cart items in state
    window.location.href = '/template';

  };
  return (
    <CartContext.Provider value={{ cartItems, addToCart, updateQuantity, removeFromCart, clearCart, messages,handleLogout }}>
      {children}
    </CartContext.Provider>
  );
};
