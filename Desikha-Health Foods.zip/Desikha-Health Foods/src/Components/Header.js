import React, { useEffect, useState,useRef } from 'react';
import { Link } from 'react-router-dom';
import Logo from '../Assets/desikha-logo.png';
import { useCart } from '../Context/CartContext';
import { post } from 'jquery';
import { useNavigate } from "react-router-dom";
import axios from 'axios';
import { Offcanvas } from 'bootstrap';
import usericon from '../Assets/img-icon.jpg'
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';

const Header = () => {
    const { cartItems, messages,removeFromCart,handleLogout,updateQuantity  } = useCart(); 
    const [menuItems, setMenuItems] = useState([]);
    const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
    const [query, setQuery] = useState("");
    const navigate = useNavigate();
    const [categories, setCategories] = useState([]);
    const [contactData, setContactData] = useState(null);
    const [show, setShow] = useState(false);
    const offcanvasRef = useRef(null);
    const [showAll, setShowAll] = useState(false);
    const [showDropdown, setShowDropdown] = useState(false);
    const inputRef = useRef(null);
    const isMobile = window.innerWidth <= 992;
    const isLoggedIn = localStorage.getItem('user_id') !== null;
    const [showHeader, setShowHeader] = useState(true);
    const [lastScrollY, setLastScrollY] = useState(window.scrollY);


    const toggleDropdown = () => {
  if (isMobile) {
    setShowDropdown((prev) => !prev);
  }
};

  const visibleCategories = showAll ? categories : categories.slice(0, 12);

  const userName = JSON.parse(localStorage.getItem('username'));

  // console.log(userName); 
 const handleScroll = () => {
    const currentScrollY = window.scrollY;
    if (currentScrollY > lastScrollY) {
      // Scrolling down
      setShowHeader(false);
    } else {
      // Scrolling up
      setShowHeader(true);
    }
    setLastScrollY(currentScrollY);
  };

  useEffect(() => {
    window.addEventListener('scroll', handleScroll);

    return () => window.removeEventListener('scroll', handleScroll);
  }, [lastScrollY]);

  const openOffcanvas = () => setShow(true);

  const handleCheckout = () => {
    setShow(false);
    setTimeout(() => {
      navigate('/checkout');
    }, 100)
  };


const handleSearch = () => {
  if (query.trim() !== "") {
    navigate(`/searchproducts?query=${encodeURIComponent(query)}`);
    setQuery("");
  }
};

  // Calculate total price and savings
  const cartTotal = cartItems.reduce((total, item) => {
    // Ensure values are numbers and handle possible NaN values
    const price = Number(item.price) || 0;
    const quantity = Number(item.quantity) || 0;
    return total + price * quantity;
  }, 0);

  const cartSaving = cartItems.reduce((total, item) => {
    const oldPrice = Number(item.oldPrice) || 0;
    const price = Number(item.price) || 0;
    const quantity = Number(item.quantity) || 0;
    return total + (oldPrice - price) * quantity;
  }, 0);


// console.log("cartitems" , cartItems);
// console.log("cartTotal" , cartTotal);
// console.log("cartSaving" , cartSaving);


useEffect(() => {
  fetch(`${API_BASE_URL}menu_list.php`,{
    method: "POST",
    header:{
    "Content-Type":"application/json"
    },
  })
 .then((res) => res.json())
    .then((data) => {
      if (data.head?.code === 200) {
        setMenuItems(data.body);
      } else {
        console.error("Menu fetch failed:", data.head?.msg);
      }
    })
    .catch((err) => {
      console.error("Fetch error:", err);
    });

},[])

useEffect(() => {
  axios.post(`${API_BASE_URL}menu_dropdown.php`)
    .then(res => {
      if (res.data.head.code === 200 && res.data.body) {
        setCategories(res.data.body);
        console.log(res.data.body);
      } else {
        console.warn("Unexpected response format:", res.data);
      }
    })
    .catch(err => {
      console.error("Error fetching categories:", err);
    });
}, []);


const handleCategoryClick = (cat) => {
  console.log("line 114",cat.category_id)
  navigate(`/shopbycategory/${cat.category_id}`);
};

 useEffect(() => {
	const fetchContactData = async() => {
		try{
			const response = await axios.post(`${API_BASE_URL}content.php`)
			 const {body} = response.data;
			 setContactData(body.contact) 
		} catch(error){
			alert("Error fetching the contact data", error)
		    console.error("Error fetching the contact data", error);
		}
	}
	fetchContactData();
  },[])

// menu offcanvas when click menu after close

const closeOffcanvas = () => {
  const offcanvasEl = document.getElementById("offcanvasNavbar");

  let bsOffcanvas = Offcanvas.getInstance(offcanvasEl);
  if (!bsOffcanvas) {
    bsOffcanvas = new Offcanvas(offcanvasEl);
  }

  bsOffcanvas.hide();

  // 💡 Clean up backdrop and enable scroll after closing
  setTimeout(() => {
    // Remove overflow style from body
    document.body.style.overflow = '';
    document.body.style.position = '';
    document.body.classList.remove('modal-open', 'offcanvas-backdrop');

    // Remove leftover backdrop if exists
    document.querySelector('.offcanvas-backdrop')?.remove();
  }, 300);
};
 useEffect(() => {
    const handleClickOutside = (event) => {
      if (offcanvasRef.current && !offcanvasRef.current.contains(event.target)) {
        setShow(false); // Close the offcanvas
      }
    };

    if (show) {
      document.addEventListener("mousedown", handleClickOutside);
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [show]);

    return (
        <>
            {/* Category Modal */}
            <div className="header-cate-model main-gambo-model modal fade" id="category_model" tabIndex="-1" role="dialog" aria-modal="false" >
                <div className="modal-dialog category-area" role="document">
                    <div className="category-area-inner">
                        <div className="modal-header">
                            <button type="button" className="close btn-close" data-dismiss="modal" aria-label="Close">
                                <i className="uil uil-multiply"></i>
                            </button>
                        </div>
                         <div className="custom-category-modal modal-content">
                          <div className="custom-category-header">
                            <h4>Select Category</h4>
                          </div>

                          <ul className="custom-category-grid">
                            {visibleCategories.map(cat => (
                              <li
                                key={cat.cid}
                                className="custom-category-item"
                                data-bs-dismiss="modal"
                                onClick={() => handleCategoryClick(cat)}
                              >
                                <div className="custom-category-box">
                                  <div className="custom-category-icon">
                                    <img src={cat.image} alt={cat.name} />
                                  </div>
                                  {/* <div className="custom-category-name">
                                    {cat.name.length > 15 ? cat.name.slice(0, 13) + '...' : cat.name}
                                  </div> */}
                                </div>
                              </li>
                            ))}
                          </ul>

                          {categories.length > 9 && (
                            <button
                              className="custom-more-category-btn"
                              onClick={() => setShowAll(!showAll)}
                            >
                              <i className="uil uil-apps"></i> {showAll ? 'Less Categories' : 'More Categories'}
                            </button>
                          )}
                        </div>
                    </div>
                </div>
            </div>
            {/* End Category Modal */}

            {/* Cart Sidebar Offcanvas */}
    {/* Trigger (optional) */}
      {/* <button className="btn btn-primary">Open Cart</button> */}

      {/* Offcanvas Overlay */}
      {show && <div className="offcanvas-backdrop fade show"></div>}

      {/* Offcanvas */}
      <div
        className={`offcanvas offcanvas-end ${show ? 'show' : ''}`}
        tabIndex="-1"
        ref={offcanvasRef}
        style={{ visibility: show ? 'visible' : 'hidden' }}
        aria-labelledby="offcanvasRightLabel"
      >
        <div className="offcanvas-header bs-canvas-header side-cart-header p-3">
          <div className="d-inline-block main-cart-title" id="offcanvasRightLabel">
            My Cart <span>({cartItems.length} Items)</span>
          </div>
          <button type="button" className="close-btn" onClick={() => setShow(false)} aria-label="Close">
            <i className="uil uil-multiply"></i>
          </button>
        </div>

        <div className="offcanvas-body p-0">
          <div className="side-cart-items">
            {cartItems.length === 0 ? (
              <div>&nbsp;&nbsp;&nbsp;<b>No items in the cart</b></div>
            ) : (
              cartItems.map((item, index) => (
                <div key={item.id} className="cart-item">
                  <div className="cart-product-img">
                    <img src={item.image} alt={item.name} />
                  </div>

                  <div className="cart-text">
                    <h4>{item.name}</h4>

                    <div className="cart-radio">
                      <ul className="kggrm-now">
                        {(item.kgOptions || []).map((kg, idx) => (
                          <li key={idx}>
                            <input
                              type="radio"
                              id={`a${index}-${idx}`}
                              name={`cart${index}`}
                            />
                            <label htmlFor={`a${index}-${idx}`}>{kg}</label>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="qty-group">
                      <div className="quantity buttons_added">
                        <input
                          type="button"
                          value="-"
                          className="minus minus-btn"
                          onClick={() => updateQuantity(item.id,item.weight, -1)}
                        />
                        <input
                          type="number"
                          value={item.quantity}
                          readOnly
                          className="input-text qty text"
                        />
                        <input
                          type="button"
                          value="+"
                          className="plus plus-btn"
                          onClick={() => updateQuantity(item.id,item.weight, 1)}
                        />
                      </div>

                      <div className="cart-item-price">
                        <i className="bi bi-currency-rupee"></i>
                        {item.price}
                        <span>
                          <i className="bi bi-currency-rupee"></i>
                          {item.oldPrice}
                        </span>
                      </div>
                    </div>

                    <button
                      type="button"
                      className="cart-close-btn"
                      onClick={() => removeFromCart(item.id, item.weight)}
                    >
                      <i className="uil uil-multiply"></i>
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        <div className="offcanvas-footer">
          {/* <div className="main-total-cart">
            <h2>Sub-Total</h2>
            <span><i className="bi bi-currency-rupee"></i>{cartSaving}</span>
          </div> */}
          <div className="main-total-cart">
            <h2>Total</h2>
            <span><i className="bi bi-currency-rupee"></i>{cartTotal}</span>
          </div>
          <div className="checkout-cart">
            <button
              className="cart-checkout-btn hover-btn"
              onClick={handleCheckout}
              style={{border:"none"}}
            >
              Proceed to Checkout
            </button>
          </div>
        </div>
      </div>
    
          {/* End Cart Sidebar Offcanvas */}

            {/* Header */}
    <header className={`header clearfix ${showHeader ? 'show' : 'hide'}`}>
		<div class="top-header-group">
			<div class="top-header">
				<div class="main_logo" id="logo">
					{/* <Link to="/"><img src={Logo} alt="" /></Link> */}
				</div>
				
        <ul>
						<li>
						 <div className="search120">
              <div className="header_search position-relative">
               <input
                    ref={inputRef}
                    className="prompt srch10"
                    type="text"
                    placeholder="Search for products.."
                    value={query}
                    onChange={(e) => {
                      setQuery(e.target.value);
                      // Ensure focus is maintained
                      setTimeout(() => {
                        inputRef.current?.focus();
                      }, 0);
                    }}
                    onKeyDown={(e) => {
                      console.log("Key pressed:", e.key);
                      if (e.key === "Enter") handleSearch();
                    }}
                    onFocus={() => console.log("Input focused")}
                    onBlur={() => {
                      console.log("Input lost focus");
                      // Optional: keep focus if needed
                      setTimeout(() => {
                        if (document.activeElement !== inputRef.current) {
                          inputRef.current?.focus();
                        }
                      }, 100);
                    }}
                  />


                <i className="uil uil-search s-icon"  style={{ cursor: "pointer" }} onClick={handleSearch}></i>
              </div>
            </div>
						</li>
            </ul>
				<div class="header_right">
					
					<ul>
						<li>
							<a  class="offer-link"><i class="uil uil-phone-alt"></i><b>{contactData?.phonenumber}</b></a>
						</li>
						 <li>
							<Link to="/offers" class="offer-link"><i class="uil uil-gift"></i>Offers</Link>
						</li> 
						 <li>
							<Link to="/" class="offer-link"><i class="uil uil-question-circle"></i>Help</Link>
						</li> 
					 {/* <li>
							<Link to="/wishlist" class="option_links" title="Wishlist"><i class='uil uil-heart icon_wishlist'></i><span class="noti_count1">3</span></Link>
						</li>	  */}
						<li class="dropdown account-dropdown">
							<a href="#" class="opts_account" role="button" id="accountClick" data-bs-auto-close="outside" data-bs-toggle="dropdown" aria-expanded="false">
								<img src={usericon} alt="" />
								<span class="user__name">{userName}</span>
								<i class="uil uil-angle-down"></i>
							</a>
							<div class="dropdown-menu dropdown-menu-account dropdown-menu-end" aria-labelledby="accountClick" data-bs-popper="none">
								<div class="night_mode_switch__btn">
									<a href="#" id="night-mode" class="btn-night-mode">
									
									</a>
								</div>	
								<Link to="/orderhistory" class="channel_item"><i class="uil uil-box icon__1"></i>My Orders</Link>
								{/* <Link to="/myaccount" class="channel_item"><i class="uil uil-location-point icon__1"></i>My Address</Link> */}
                {!isLoggedIn && (
                  <Link to="/signin" className="channel_item">
                    <i className="uil uil-signin icon__1"></i>Sign In
                  </Link>
                )}                
              <Link to="/offers" class="channel_item"><i class="uil uil-gift icon__1"></i>Offers</Link>

                {isLoggedIn && (
                  <a className="channel_item" onClick={handleLogout}>
                    <i className="uil uil-lock-alt icon__1"></i>Sign out
                  </a>
                )}
							</div>
						</li>
					</ul>
				</div>
			</div>
		</div>
		<div class="sub-header-group">
			<div class="sub-header">
				<nav class="navbar navbar-expand-lg bg-gambo gambo-head navbar justify-content-lg-start pt-0 pb-0">
					<button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar">
						<span class="navbar-toggler-icon">
							<i class="uil uil-bars"></i>
						</span>
					</button>
          <div class="main_logo" id="logo">
					<Link to="/"><img src={Logo} alt="" /></Link>
				</div>
					{/* <a href="#" class="category_drop hover-btn" data-bs-toggle="modal" data-bs-target="#category_model" title="Categories"><i class="uil uil-apps"></i><span class="cate__icon">Select Category</span></a> */}
					<div class="offcanvas offcanvas-start" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
						<div class="offcanvas-header">
							<div class="offcanvas-logo" id="offcanvasNavbarLabel">
								<img src={Logo} alt="" />
							</div>
							<button type="button" class="close-btn" data-bs-dismiss="offcanvas" aria-label="Close">
								<i class="uil uil-multiply"></i>
							</button>
						</div>
						<div class="offcanvas-body">
							<div class="offcanvas-category mb-4 d-block d-lg-none">
								<div class="offcanvas-search position-relative">
									<input
                      className="canvas_search"
                      type="text"
                      placeholder="Search for products.."
                      value={query}
                      onChange={(e) => setQuery(e.target.value)}
                      onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                    />

                    <i
                      className="uil uil-search hover-btn canvas-icon"
                      style={{ cursor: "pointer" }}
                      onClick={handleSearch}
                    />
                  </div>
								{/* <button class="category_drop_canvas hover-btn mt-4" data-bs-toggle="modal" data-bs-target="#category_model" title="Categories"><i class="uil uil-apps"></i><span class="cate__icon" onClick={closeOffcanvas}>Select Category</span></button> */}
							  </div>
							<ul class="navbar-nav justify-content-start flex-grow-1 pe_5">
								<li class="nav-item">
									<Link class="nav-link active" aria-current="page" to="/" onClick={closeOffcanvas}>Home</Link>
								</li>
						    {menuItems.map((item) => (
                <li className="nav-item" key={item.id}>
                  <Link className="nav-link" to={`/product/${item.id}`} onClick={closeOffcanvas}>{item.name}</Link>
                </li>
              ))} 
            
              <li
                className={`nav-item dropdown ${showDropdown ? 'show' : ''}`}
                onMouseEnter={() => !isMobile && setShowDropdown(true)}
                onMouseLeave={() => !isMobile && setShowDropdown(false)}
              >
                <span
                  className="nav-link dropdown-toggle"
                  style={{ cursor: 'pointer' }}
                  onClick={toggleDropdown}
                >
                  Health Food Products
                </span>

                {showDropdown && (
                  <ul className="dropdown-menu show" style={{ display: 'block' }}>
                    {categories.map((cat) => (
                      <li key={cat.category_id}>
                      <a
                        className="dropdown-item"
                        onClick={() => {
                          handleCategoryClick(cat);  
                          setShowDropdown(false);    
                          closeOffcanvas();           
                        }}
                      >
                        {cat.category_name}
                      </a>


                      </li>
                    ))}
                  </ul>
                )}
              </li>
                <li class="nav-item">
									<Link class="nav-link" to="/wholesaleproduct" onClick={closeOffcanvas}>Wholesale Cashews</Link>
								</li>
                <li class="nav-item">
									<Link class="nav-link" to="/about" onClick={closeOffcanvas}>About Us</Link>
								</li>
								<li class="nav-item">
									<Link class="nav-link" to="/contactus" onClick={closeOffcanvas}>Contact Us</Link>
								</li>
							</ul>
							{/* <div class="d-block d-lg-none">
								<ul class="offcanvas-help-links">
									<li><a href="#" class="offer-link"><i class="uil uil-phone-alt"></i>1800-000-000</a></li>
									<li><a href="offers.html" class="offer-link"><i class="uil uil-gift"></i>Offers</a></li>
									<li><a href="faq.html" class="offer-link"><i class="uil uil-question-circle"></i>Help</a></li>
								</ul>
								<div class="offcanvas-copyright">
									<i class="uil uil-copyright"></i>Copyright 2022 <b>Gambolthemes</b> . All rights reserved
								</div>
							</div> */}
						</div>
					</div>
					<div class="sub_header_right">
						<div class="header_cart">
                    <a
                      href="#"
                      className="cart__btn hover-btn"
                      onClick={(e) => {
                        e.preventDefault();
                        openOffcanvas(); // your React function to toggle state
                      }}
                    >
                      <i className="bi bi-cart3"></i>&nbsp;
                      <span>Cart</span>
                      <ins>{cartItems.length}</ins>
                      <i className="uil uil-angle-down"></i>
                    </a>
						</div>
					</div>
				</nav>
			</div>
		</div>
	</header>
        </>
    );
};

export default Header;
