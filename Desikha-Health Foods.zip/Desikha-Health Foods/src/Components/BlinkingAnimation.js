import React from 'react';
import { useNavigate } from 'react-router-dom';
import selectedImage from '../Assets/ordernow.png';

const BlinkingAnimaion = () => {
  const navigate = useNavigate();

  const handleClick = () => {
    navigate('/quickpurchase'); 
  };

  return (
    <div className="Sticker" onClick={handleClick} style={{ cursor: 'pointer' }}>
      <img
        src={selectedImage}
        alt="Selected"
        style={{ width: "100%", height: "auto" }}
      />
    </div>
  );
};

export default BlinkingAnimaion;
