import React,{useState,useEffect} from 'react'
import { Link } from 'react-router-dom'
import axios from 'axios';

const Footer = () => {

     const [contactData, setContactData] = useState(null);
     const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
     const [visitorcount, setVisitorCount] = useState();
     
    useEffect(() => {
	const fetchContactData = async() => {
		try{
			const response = await axios.post(`${API_BASE_URL}content.php`)
			 const {body} = response.data;
			 setContactData(body.contact);
             setVisitorCount(body.visitor_count);
		} catch(error){
			alert("Error fetching the contact data", error)
		    console.error("Error fetching the contact data", error);
		}
	}  
	fetchContactData();
  },[])



  return (
    <footer class="footer">
    <div class="footer-first-row">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-6 ">
                    <ul class="call-email-alt">
                        <li><a href="#" class="callemail"><i class="bi bi-telephone"></i>{contactData?.phonenumber}</a></li>
                        {/* <li><a href="#" class="callemail"><i class="uil uil-envelope-alt"></i>{contactData?.email}</a></li> */}
                        <li><a href="#" class="callemail"><i class="uil uil-envelope-alt"></i>desikhahealthfoods@gmail.com</a></li> 
                    </ul>
                </div>
                <div class="col-md-6 col-12">
                    <div class="social-links-footer">
                        <ul>
                            <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                        </ul>
                    </div>
                </div>				
            </div>
        </div>
    </div>
    <div class="footer-second-row">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-6 col-6">
                    <div class="second-row-item">
                        <h4>Address</h4>
                        <ul>
                            <li><p style={{color:"white"}}>{contactData?.address}</p></li>
                            <li><h2 style={{color:"white"}}>Visitor Count : {visitorcount?.visitor_count}</h2></li>

                        </ul>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6 col-6">
                    <div class="second-row-item">
                       <h4>Quick links</h4>
                        <ul>
                            <li><Link to="/about"><i class="bi bi-arrow-right"></i> About Us</Link></li>
                                <li><Link to="/contactus"><i class="bi bi-arrow-right"></i> Contact Us</Link></li>
                                <li><Link to="/privacy">  <i class="bi bi-arrow-right"></i> Privacy Policy</Link></li>
                                <li><Link to="/terms"><i class="bi bi-arrow-right"></i> Term & Conditions</Link></li>
                                <li><Link to="/shippingpolicy"><i class="bi bi-arrow-right"></i> Shipping Policy</Link></li>

                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-6">
                    <div class="second-row-item">
                       <h4>Pages</h4>
                        <ul>
                            <li><Link to="/orderhistory"><i class="bi bi-arrow-right"></i> Order History</Link></li>
                                <li><Link to="/signin"><i class="bi bi-arrow-right"></i> Sign In </Link></li>
                                <li><Link to="/signup">  <i class="bi bi-arrow-right"></i> Sign Up</Link></li>
                                <li><Link to="/offers"><i class="bi bi-arrow-right"></i> Offers</Link></li>
                                {/* <li><Link to="/shippingpolicy"><i class="bi bi-arrow-right"></i> Shipping Policy</Link></li> */}

                        </ul>
                    </div>
                </div>
              
                <div class="col-lg-3 col-md-6 col-6">
                
                    <div class="second-row-item-payment">
                          <h4>Cashew Grades</h4>
                          <ul>
                            <li style={{color:"white"}}>
                                <span>W180</span>
                            </li>
                             <li style={{color:"white"}}>
                                <span>W240</span>
                            </li>
                           <li style={{color:"white"}}>
                                <span>W320</span>
                            </li>
                            <li style={{color:"white"}}>
                                <span>JH</span>
                            </li>
                            <li style={{color:"white"}}>
                                <span>S320</span>
                            </li>
                            <li style={{color:"white"}}>
                                <span>JK</span>
                            </li>
                            <li style={{color:"white"}}>
                                <span>JB</span>
                            </li>
                            <li style={{color:"white"}}>
                                <span>SWP</span>
                            </li>


                          </ul> 
                    </div>
                   
                </div>
            </div>
        </div>
    </div>
    <div class="footer-last-row">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="">
                       
                        <div class="copyright-text">
                            <i class="uil uil-copyright"></i>Copyright {new Date().getFullYear()}  <b>Desikha Health Products</b> . All rights reserved. Developed by <b>Aathesh Soft Solutions</b>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
  )
}

export default Footer