import React, { useState } from 'react';
import Logo from '../Assets/desikha-logo.png';
import { Link,useNavigate } from 'react-router-dom';
import axios from 'axios';

const Signup = () => {
  const navigate = useNavigate();
  const [Errors, setErrors] = useState({});
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    mobile: '',
    password: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };
const validateForm = () => {
    const newErrors = {};
    const emailRegex = /^[a-zA-Z0-9._%+-]+@(gmail|yahoo)\.com$/;
    const mobileRegex = /^\d{10}$/;

    if (!formData.name.trim()) {
      newErrors.name = "Name is required.";
    }

    if (!formData.email.trim()) {
      newErrors.email = "Email is required.";
    } else if (!emailRegex.test(formData.email)) {
      newErrors.email = "Email must be a valid Gmail address.";
    }

    if (!formData.mobile.trim()) {
      newErrors.phno = "Mobile number is required.";
    } else if (!mobileRegex.test(formData.mobile)) {
      newErrors.mobile = "Mobile number must be 10 digits.";
    }

    if (!formData.password.trim()) {
      newErrors.password = "Password is required.";
    } else if (formData.password.length < 6) {
      newErrors.password = "Password must be at least 6 characters.";
    }

    if (!formData.confirm.trim()) {
      newErrors.confirm = "Password confirmation is required.";
    } else if (formData.password !== formData.confirm) {
      newErrors.confirm = "Passwords do not match.";
    }
   

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

// sign up api connection

  const handleSubmit = async (e) => {
  e.preventDefault();
  try {
    const response = await axios.post(
      `${API_BASE_URL}register.php`,
      JSON.stringify({ ...formData }),
      {
        headers: { "Content-Type": "application/json" }
      }
    );

    if (response.data.head && response.data.head.code  === 200) {
      setFormData({
        name: "",
        email: "",
        mobile: "",
        password: "",
        confirm: "",
      });
      alert("Registered successfully");
      navigate('/signin');
    } else {
      // If response message is not success
      setErrors({ apiError: response.data.head.msg || "Registration failed." });
    }
  } catch (error) {
    console.error("Registration error:", error);
    setErrors({ apiError: "Registration failed." });
  }
};



  return (
    <div className="wrapper">
      <div className="sign-inup">
        <div className="container">
          <div className="row justify-content-center">
            <div className="col-lg-5">
              <div className="sign-form">
                <div className="sign-inner">
                  <div className="form-dt">
                    <div className="form-inpts checout-address-step">
                      <form onSubmit={handleSubmit}>
                        <div className="form-title">
                          <h6>Sign Up</h6>
                        </div>

                        <div className="form-group pos_rel mb-3">
                          <input
                            name="name"
                            type="text"
                            placeholder="Full Name"
                            className="form-control lgn_input"
                            required
                            value={formData.name}
                            onChange={handleChange}
                          />
                          <i className="uil uil-user-circle lgn_icon"></i>
                        </div>

                        <div className="form-group pos_rel mb-3">
                          <input
                            name="mobile"
                            type="tel"
                            placeholder="Phone Number"
                            className="form-control lgn_input"
                            required
                            value={formData.mobile}
                            onChange={handleChange}
                          />
                          <i className="uil uil-phone lgn_icon"></i>
                        </div>

                        <div className="form-group pos_rel mb-3">
                          <input
                            name="email"
                            type="email"
                            placeholder="Email Address"
                            className="form-control lgn_input"
                            required
                            value={formData.email}
                            onChange={handleChange}
                          />
                          <i className="uil uil-envelope lgn_icon"></i>
                        </div>

                        <div className="form-group pos_rel mb-3">
                          <input
                            name="password"
                            type="password"
                            placeholder="Password"
                            className="form-control lgn_input"
                            required
                            value={formData.password}
                            onChange={handleChange}
                          />
                          <i className="uil uil-padlock lgn_icon"></i>
                        </div>
                        {Errors.apiError && <div className="error-message">{Errors.apiError}</div>}

                        <button className="login-btn hover-btn" type="submit">
                          Sign Up Now
                        </button>
                      </form>
                    </div>

                    <div className="signup-link">
                      <p>
                        I have an account? - <Link to="/signin">Sign In Now</Link>
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="copyright-text text-center mt-4">
                <i className="uil uil-copyright"></i> Copyright{' '}
                {new Date().getFullYear()} <b>Desikha health foods</b>. All rights reserved
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Signup;
