import React, { useEffect, useState,useRef } from "react";
import Slider from "react-slick";
import Skeleton from "react-loading-skeleton";
import "react-loading-skeleton/dist/skeleton.css";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
// import Image1 from '../Assets/banner-new1.jpg';
// import Image2 from '../Assets/banner-new2.jpg';
// import Image3 from '../Assets/banner-new3.jpg';

const Banner = () => {
  const [banners, setBanners] = useState([]);
  const [loading, setLoading] = useState(true);

  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

  useEffect(() => {
    const fetchBanners = async () => {
      try {
        const response = await fetch(`${API_BASE_URL}home.php`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
        });

        const data = await response.json();

        if (data.head.code === 200 ) {
          const bannerList = Array.isArray(data?.body?.banner) ? data.body.banner : [];
          setBanners(bannerList);
        } else {
          console.error("Invalid banner response", data);
        }
      } catch (error) {
        console.error("Error fetching banners:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchBanners();
  }, []);

const sliderRef = useRef();


const settings = {
  dots: false,
  speed: 500,
  infinite: banners.length > 3,
  slidesToShow: 3,
  slidesToScroll: 1,
  autoplay: true,
  autoplayTimeout:3000,  
  smartSpeed: 500,
  arrows: true,
  pauseOnHover: false,
  beforeChange: () => {
    
    if (document.activeElement) {
      document.activeElement.blur();
    }
  },
  responsive: [
    { breakpoint: 1000, settings: { slidesToShow: 3 } },
    { breakpoint: 600, settings: { slidesToShow: 2 } },
    { breakpoint: 480, settings: { slidesToShow: 1 } },
  ],
};

  // const banners = [Image1, Image2, Image3];


  return (
    
    <div className="main-banner-slider">
      <div className="container-fluid">
        <div className="row">
          <div className="col-md-12">
            <Slider {...settings} className="offers-banner owl-theme">
              {loading
                ? Array.from({ length: 3 }).map((_, index) => (
                    <div className="item" key={index}>
                      <div className="offer-item">
                        <Skeleton
                          height={200}
                          width="100%"
                          baseColor="#e0e0e0"
                          highlightColor="#f5f5f5"
                        />
                      </div>
                    </div>
                  ))
                : Array.isArray(banners) &&
                  banners.map((banner, index) => (
                    <div className="item" key={index}>
                      <div className="offer-item">
                        <div className="offer-item-img">
                          <div className="gambo-overlay"></div>
                          <img
                            src={banner.image}
                            alt={`Banner ${index + 1}`}
                            loading="lazy"
                            style={{ width: "100%", height: "auto" }}
                          />
                        </div>
                      </div>
                    </div>
                  ))}
            </Slider>


          </div>
        </div>
      </div>
    </div>
  );
};

export default Banner;
