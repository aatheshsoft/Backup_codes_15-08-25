import React, { useState } from 'react';
import { Link,useNavigate,useLocation } from 'react-router-dom';
import axios from 'axios';
import Logo from '../Assets/desikha-logo.png';

const Signin = () => {
  const [formData, setFormData] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const navigate = useNavigate()
  const handleChange = (e) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

const location = useLocation();

const from = location.state?.from?.pathname || '/'; // fallback to home if no previous page
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

 const handleSubmit = async (e) => {
  e.preventDefault();
  setError('');

  try {
    const response = await axios.post(`${API_BASE_URL}login.php`,
      JSON.stringify(formData),
      {
        headers: { 'Content-Type': 'application/json' }
      }
    );

    if (response.data.head && response.data.head.msg === 'success') {
      localStorage.setItem('user_id', JSON.stringify(response.data.body.user_id));
      localStorage.setItem('username', JSON.stringify(response.data.body.name));
      alert('Login successful!');
      
      navigate(from, { replace: true }); // 👈 Go back to originally intended page
    } else {
      setError(response.data.head.msg || 'Login failed');
    }
  } catch (err) {
    console.error(err);
    setError('Something went wrong. Please try again.');
  }
};


  return (
    <div className="wrapper">
      <div className="sign-inup">
        <div className="container">
          <div className="row justify-content-center">
            <div className="col-lg-5">
              <div className="sign-form">
                <div className="sign-inner">
                  <div className="form-dt">
                    <div className="form-inpts checout-address-step">
                      <form onSubmit={handleSubmit}>
                        <div className="form-title"><h6>Sign In</h6></div>

                        <div className="form-group pos_rel mb-3">
                          <input
                            name="email"
                            type="text"
                            placeholder="Enter Email"
                            className="form-control lgn_input"
                            value={formData.email}
                            onChange={handleChange}
                            required
                          />
                          <i className="uil uil-mobile-android-alt lgn_icon"></i> 
                        </div>

                        <div className="form-group pos_rel mb-3">
                          <input
                            name="password"
                            type="password"
                            placeholder="Enter Password"
                            className="form-control lgn_input"
                            value={formData.password}
                            onChange={handleChange}
                            required
                          />
                          <i className="uil uil-padlock lgn_icon"></i>
                        </div>

                        {error && <p className="text-danger mb-2">{error}</p>}

                        <button className="login-btn hover-btn h_50" type="submit">Sign In Now</button>
                      </form>
                    </div>

                    <div className="signup-link mt-2">
                      <p>Don't have an account? - <Link to="/signup">Sign Up Now</Link></p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="copyright-text text-center mt-4">
                <i className="uil uil-copyright"></i> Copyright {new Date().getFullYear()} 
                <b> Desikha health foods </b>. All rights reserved
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Signin;
