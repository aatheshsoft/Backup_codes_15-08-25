import React from 'react';
import './Loader.css'; // Import the loader styles
import image from '../Assets/desikha-logo.png'

const Loader = () => {
  return (
    <>
    {/*Logo loader */}
  <div className="loader-container12">
      
      <div class="navbar-logo col-md-3 col-sm-12 col-xs-12">
				<img src={image} title="Desikha" alt="Desikha" />
			</div>
        <div className="loader12">
          <span></span>
          <span></span>
          <span></span>
        </div>
    </div>
    </>
  );
};

export default Loader;
