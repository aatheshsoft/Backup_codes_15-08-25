import React,{useEffect,useState } from 'react'
import OwlCarousel from 'react-owl-carousel';
import 'owl.carousel/dist/assets/owl.carousel.css';
import 'owl.carousel/dist/assets/owl.theme.default.css';
import Banner from '../Components/Banner';
import Footer from '../Components/Footer';
import 'bootstrap-icons/font/bootstrap-icons.css';
import { Link, Links } from 'react-router-dom';
import { useCart } from '../Context/CartContext';
import { FaShoppingCart } from 'react-icons/fa';
import axios from "axios";
import {  useNavigate } from "react-router-dom";
import { Swiper, SwiperSlide } from 'swiper/react';
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/autoplay';
import { Navigation, Autoplay } from 'swiper/modules';
import $ from 'jquery';
import { faWhatsapp } from "@fortawesome/free-brands-svg-icons";
import { IoSendSharp } from "react-icons/io5";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
// import BlinkingAnimaion from '../Components/BlinkingAnimation';
import image1 from '../Assets/kidney-bean_7516939.png';
import image2 from '../Assets/almonds_8887990.png'
import image3 from '../Assets/food_13831884.png';
import bgimage from '../Assets/video-bg-1.jpeg'
import 'font-awesome/css/font-awesome.min.css';
import catimg1 from "../Assets/cashew-cat1.jpg";
import catimg2 from '../Assets/cashew-cat2.jpg';
import pimage from '../Assets/2148774962.jpg';
import pimage1 from '../Assets/cashew-butter-dark-background (1).jpg';
import pimage2 from '../Assets/combo-image.jpg';
import pimage3 from '../Assets/cashew-powder.jpg';
import pimage4 from '../Assets/raw-cashew.jpg';
import pimage5 from '../Assets/roasted cashew.jpg';
import banner from '../Assets/banner-new1.jpg'
import banner1 from '../Assets/banner-new2.jpg'
import banner2 from '../Assets/banner-new3.jpg'
import Loader from '../Components/Loader';




const Home = () => { 
	const { addToCart, messages } = useCart();
    const [categories, setCategories] = useState([]);
    const navigate = useNavigate();
    const[hotproducts,setHotProducts] = useState([]);
    const[feature,setFeature] = useState([]);
    const[newproducts, setNewProducts] = useState([]);
  	const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
  	const [message, setMessage] = useState("");
  	const [isChatBoxVisible, setChatBoxVisible] = useState(false);
    const [shopgallery, setShopGallery]= useState([]);
    const [clientlogo, setClientLogo] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [youtubeurl, setYouTubeUrl] = useState();
    const [showModal, setShowModal] = useState(false);

  const handleOpenModal = () => setShowModal(true);
  const handleCloseModal = () => setShowModal(false);


	const toggleChatBox = () => {
    setChatBoxVisible(!isChatBoxVisible);
  };
  
  const handleMessageChange = (e) => {
    setMessage(e.target.value);
  };

  const sendMessage = () => {
    // if (aa) {
    //   console.log("WhatsApp number is not available yet");
    //   return;
    // }

    const whatsappUrl = `https://wa.me/$.replace(
	 
      "+",
      ""
    )}?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, "_blank");
  };

useEffect(() => {
  axios.post(`${API_BASE_URL}home.php`)
    .then(res => {
      if (res.data.head.code === 200 && res.data.body.category) {

        const fetchedhotProducts = res.data.body.hot_list.map(product => {
  const defaultPrice = product.price?.[0] || {};
      // setSelectedPrice(defaultPrice)
          return {
            id: product.id, 
            name: product.name,
            priceOptions: product.price || [], // store all weights
            price: parseFloat(defaultPrice.online_rate) || 0,
            oldPrice: parseFloat(defaultPrice.mrp_rate) || 0,
            weight: defaultPrice.weight || '',
            unit: defaultPrice.unit || '',
            image: product.image || " ",
            inStock: parseInt(product.stock) > 0,
            category_id: product.category_id,
          };
        

        });
        const fetchednewProducts = res.data.body.new_list.map(product => {
          const defaultPrice = product.price?.[0] || {};
      // setSelectedPrice(defaultPrice)
          return {
              id: product.id, 
            name: product.name,
            priceOptions: product.price || [], // store all weights
            price: parseFloat(defaultPrice.online_rate) || 0,
            oldPrice: parseFloat(defaultPrice.mrp_rate) || 0,
            weight: defaultPrice.weight || '',
            unit: defaultPrice.unit || '',
            image: product.image || " ",
            inStock: parseInt(product.stock) > 0,
            category_id: product.category_id,
          };
        

        });
        setCategories(res.data.body.category);

		    setHotProducts(fetchedhotProducts);
        
		    setFeature(res.data.body.feature_list);
		    setNewProducts(fetchednewProducts);
		    setShopGallery(res.data.body.gallery);
		    setClientLogo(res.data.body.client_logo);
       const rawYoutubeUrl = res.data.body.youtube_url; // e.g. https://youtu.be/YoXxoTDkQdo?si=abc123
          const videoId = rawYoutubeUrl.split("youtu.be/")[1]?.split("?")[0]; // extract "YoXxoTDkQdo"
          const embedUrl = `https://www.youtube.com/embed/${videoId}`;
          setYouTubeUrl(embedUrl);
      }
    })
    .catch(err => {
      console.error("Error fetching categories:", err);
    });
}, []);


useEffect(() => {
    // Initialize Owl Carousel after component mounts
    window.$('.owl-carousel').owlCarousel({
      loop: true,
      margin: 10,
      nav: true,
      autoplay: true,
      autoplayTimeout: 5000,
      responsive: {
        0: {
          items: 1
        },
        600: {
          items: 2
        },
        1000: {
          items: 5
        }
      }
    });
  }, []);

const handleCategoryClick = (cat) => {
  navigate(`/shopbycategory/${cat.category_id}`);
};

  
  useEffect(() => {
			window.scrollTo(0, 0); 
		}, []);


useEffect(() => {
  // Simulate a network request or loading process
  const timer = setTimeout(() => setIsLoading(false), 500);
  return () => clearTimeout(timer);
}, []);

  return (
	<>
  {isLoading ? (
        <Loader />
      ) : (
        <>
    <div class="wrapper">
		{/* <!-- banner Start --> */}
		<Banner />
	{/* 	<!-- banner End --> */}
	<section>
      <div className="best-point-container"  
        style={{ background: 'linear-gradient(to right,rgb(233, 200, 218),rgb(246, 231, 210))' }}
      >
        <div className="container">
          <div className="row">

            <div className="col-xs-12 best-point col-sm-6 col-md-3">
              <div className="icon" style={{ background: '#fff' }}>
                <img className="icon-broccoli" src={image1} style={{ color: '#88c000' }}></img>
              </div>
              <h4 className="upper" style={{ color: '#333333' }}>100% ORGANIC</h4>
              <p style={{ color: '#696969' }}>
                We care about what you eat. We want to produce food which nourishes your body and tastes delicious
              </p>
            </div>

            <div className="col-xs-12 best-point col-sm-6 col-md-3">
              <div className="icon" style={{ background: '#fff' }}>
                <img className="icon-lettuce" src={image2} style={{ color: '#88c000' }}></img>
              </div>
              <h4 className="upper" style={{ color: '#333333' }}>ALWAYS FRESH</h4>
              <p style={{ color: '#696969' }}>
                We care about what you eat. We want to produce food which nourishes your body and tastes delicious
              </p>
            </div>

            <div className="col-xs-12 best-point col-sm-6 col-md-3">
              <div className="icon" style={{ background: '#fff' }}>
                <img className="icon-coconut" src={image3} style={{ color: '#88c000' }}></img>
              </div>
              <h4 className="upper" style={{ color: '#333333' }}>HEALTHY COOKING</h4>
              <p style={{ color: '#696969' }}>
                We care about what you eat. We want to produce food which nourishes your body and tastes delicious
              </p>
            </div>

            <div className="col-xs-12 best-point col-sm-6 col-md-3">
              <div className="icon" style={{ background: '#fff' }}>
                <img className="icon-smoothie" src={image2} style={{ color: '#88c000' }}></img>
              </div>
              <h4 className="upper" style={{ color: '#333333' }}>BEST QUALITY</h4>
              <p style={{ color: '#696969' }}>
                We care about what you eat. We want to produce food which nourishes your body and tastes delicious
              </p>
            </div>

          </div>
        </div>
      </div>
    </section>
		{/* <!-- Categories Start -->  */}
		<>
			{messages && Object.entries(messages).map(([id, message]) => (
			<div key={id} className="message-popup">
				<FaShoppingCart className="cart-icon-addtocart" />
				<div className="message">{message}</div>
			</div>
			))}
		</>
		<div class="section145">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="main-title-tt">
							<div class="main-title-left"> 
      								<span>Shop By</span>
								<h2>Categories</h2>
							</div>
						</div>
					</div>
					
            <div className="col-md-12">
              {Array.isArray(categories) && categories.length > 0 && (
              <OwlCarousel
                className="owl-theme cate-slider"
                      // loop={true}
                      margin={10}
                      nav
                      autoplay={true}
                      autoplayTimeout={3000}
                      autoplayHoverPause={true}
                      smartSpeed={500}
                      responsive={{
                        0: { items: 2 },
                        600: { items: 4 },
                        1000: { items:4  },
                }}
              >
                {categories.map((cat) => (
                  <div
                    className="item"
                    key={cat.category_id}
                    onClick={() => handleCategoryClick(cat)}
                  >
                    <Link className="best-offer-item">
                      {/* <div className="cate-img"> */}
                        <img
                          src={cat.image}
                          alt={cat.category_name}
                           loading="lazy"
                        />
                      {/* </div> */}
                      {/* <h4>
                        {cat.category_name.length > 15
                          ? cat.category_name.slice(0, 15) + "..."
                          : cat.category_name}
                      </h4> */}
                    </Link>
                  </div>
                ))}
              </OwlCarousel>
                )}
            </div>
        
        </div>
			</div>
		</div>

		{/* <!-- Categories End --> */}

 
		<div class="section145">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="main-title-tt">
							<div class="main-title-left">
								<span>For You</span>
								<h2> New Products</h2>
							</div>
							{/* <a href="shop_grid.html" class="see-more-btn">See All</a> */}
						</div>
					</div>
					<div class="col-md-12">
						{newproducts.length > 0 && (
            		<OwlCarousel
						    className="owl-theme cate-slider"
								// loop={true}
								margin={10}
								nav={true}
								dots={true}
								autoplay={true}
								autoplayTimeout={3000}
								responsive={{
									0: { items: 1 },
									600: { items: 4 },
									1000: { items: 4},
								}}
								>
							{newproducts.map((product) => (
								<div className="item" key={product.id}>
								<div className="product-item">
									<Link to={`/productdetails/${product.id}`} className="product-img">
									{/* <Link to='/productdetails' className="product-img"> */}
									<img src={product.image} alt={product.name} loading="lazy" />
									{/* <div className="product-absolute-options">
										<span className="offer-badge-1">{product.offer}</span>
									</div> */}
									</Link>
									<div className="product-text-dt">
									{/* <p>
										Available<span>({product.inStock ? 'In Stock' : 'Out of Stock'})</span>
									</p> */}
									<h4>{product.name}</h4>
									<div className="product-price">
										<i className="bi bi-currency-rupee"></i>{product.price} <span><i className="bi bi-currency-rupee"></i>{product.oldPrice}</span>
									</div>
									<div className="qty-cart">
										<button
										className="add-to-cart-btn hover-btn"
										 onClick={() => {
                                                const defaultVariant = product.priceOptions[0];

                                                addToCart({
                                                  ...product,
                                                  price: defaultVariant.online_rate,
                                                  oldPrice: defaultVariant.mrp_rate,
                                                  weight: defaultVariant.weight,
                                                  unit: defaultVariant.unit,
                                                  quantity: 1, // 👈 Ensure quantity is passed
                                                });
                                              }}
										>
										<span>Add to Cart</span>
										<i className="bi bi-cart3"></i>
										</button>
									</div>
									{/* {messages[product.id] && <div className="cart-message">{messages[product.id]}</div>} */}
									</div>
								</div>
								</div>
								))}
								</OwlCarousel>

							)}
					</div>
				</div>
			</div>
		</div>
		{/* <!-- Featured Products End -->
		<!-- Best Values Offers Start --> */}
		<div class="section145">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="main-title-tt">
							<div class="main-title-left">
								{/* <span>Offers</span> */}
								{/* <h2>Gallery</h2> */}
							</div>
						</div>
					</div>
					{shopgallery.map((product) => (
					<div class="col-lg-4 col-md-6">
						<a href="#" class="best-offer-item" key={product.id}>
							<img 
                src={product.image} 
                loading="lazy"
              />
						</a>
					</div>
					))}
					{/* <div class="col-md-12">
						<a href="#" class="code-offer-item">
							<img src={adbanner} alt="" />
						</a>
					</div> */}
				</div>
			</div>
		</div>
		{/* <!-- Best Values Offers End -->
		<!-- Vegetables and Fruits Start --> */}
		<div class="section145">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="main-title-tt">
							<div class="main-title-left">
								<span>For You</span>
								<h2>Hot Sales</h2>
							</div>
							{/* <a href="shop_grid.html" class="see-more-btn">See All</a> */}
						</div>
					</div>
					<div class="col-md-12">
						{hotproducts.length > 0 && (
            <OwlCarousel
						className="owl-theme cate-slider"
								// loop={true}
								margin={10}
								nav={true}
								dots={true}
								autoplay={true}
								autoplayTimeout={3000}
								responsive={{
									0: { items: 1 },
									600: { items: 4 },
									1000: { items: 4},
								}}
								>
							{hotproducts.map((product) => (
								<div className="item" key={product.id}>
								<div className="product-item">
									<Link to={`/productdetails/${product.id}`} className="product-img">
									{/* <Link to='/productdetails' className="product-img"> */}
									<img src={product.image} alt={product.name} loading="lazy" />
									{/* <div className="product-absolute-options">
										<span className="offer-badge-1">{product.offer}</span>
									</div> */}
									</Link>
									<div className="product-text-dt">
									{/* <p>
										Available<span>({product.inStock ? 'In Stock' : 'Out of Stock'})</span>
									</p> */}
									<h4>{product.name}</h4>
									<div className="product-price">
										<i className="bi bi-currency-rupee"></i>{product.price} <span><i className="bi bi-currency-rupee"></i>{product.oldPrice}</span>
									</div>
									<div className="qty-cart">
										<button
										className="add-to-cart-btn hover-btn"
										 onClick={() => {
                                                const defaultVariant = product.priceOptions[0];

                                                addToCart({
                                                  ...product,
                                                  price: defaultVariant.online_rate,
                                                  oldPrice: defaultVariant.mrp_rate,
                                                  weight: defaultVariant.weight,
                                                  unit: defaultVariant.unit,
                                                  quantity: 1, // 👈 Ensure quantity is passed
                                                });
                                              }}
										>
										<span>Add to Cart</span>
										<i className="bi bi-cart3"></i>
										</button>
									</div>
									{/* {messages[product.id] && <div className="cart-message">{messages[product.id]}</div>} */}
									</div>
								</div>
								</div>
							))} 
								</OwlCarousel>

							)}
					</div>
				</div>
			</div>
		</div>
	{/* 	<!-- Vegetables and Fruits Products End -->
		<!-- New Products Start --> */}

		{/* <div className="section145">
      <div className="container">
        <div className="row"> */}
          {/* <div className="col-md-12">
            <div className="main-title-tt">
              <div className="main-title-left">
                <span>For You</span>
                <h2>Client logo</h2>
              </div>
              <a href="shop_grid.html" className="see-more-btn">
                See All
              </a>
            </div>
          </div>
          <div className="col-md-12">
			{clientlogo.length > 0 && (
            <OwlCarousel
			className="owl-theme cate-slider"
			 loop={true}
				infinite= {true}
				speed= {500}
			margin={10}
			nav
			responsive={{
			0: { items: 1 },
			600: { items: 4 },
			1000: { items: 5 },
			}}
		>
			{clientlogo.map((product) => (
				<div className="item" key={product.id}>
				<div className="product-item">
					<Link to={`/productdetails/${product.id}`} className="product-img">
					<img src={product.image} alt={product.name} loading="lazy"/>
					
					</Link>
					
				</div>
				</div>
			))}
			</OwlCarousel>

			)}
          </div> */}
	<br />
	<section className="full-width-video">
        <div className="video-wrap">
          {/* Background Image */}
          <div className="video-bg">
            <img src={bgimage} alt="Background" />
          </div>

          {/* Optional video tag (can be removed if not used) */}
          <video id="bg-video" preload="auto" muted>
            <source src="" type="video/mp4" />
            Your browser doesn't support HTML5 video.
            <a href="">Download Video</a>
          </video>

          {/* Play Button Overlay */}
          <div className="video-text text-center video-controls">
            <button
              className="play-btn"
              onClick={handleOpenModal}
              style={{ background: 'none', border: 'none' }}
            >
              <i
                className="fa fa-play-circle"
                style={{ fontSize: '80px', color: '#fff' }}
              ></i>
            </button>
            <h2 className="text-lt text-sp">SEE HOW WE PREPARE YOUR MEAL</h2>
          </div>
        </div>
      </section>

      {/* Bootstrap Modal */}
      {showModal && (
        <div
          className="modal fade show"
          style={{ display: 'block', backgroundColor: 'rgba(0,0,0,0.8)' }}
          tabIndex="-1"
          role="dialog"
          onClick={(e) => {
              // ✅ Close modal if clicked outside the modal-dialog
              if (e.target.classList.contains('modal')) {
              handleCloseModal();
              }
          }}
        >
        
          <div className="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div className="modal-content">
              <div className="modal-body p-0 position-relative">
               <button
                  type="button"
                  className="btn-close position-absolute top-0 end-0 m-2"
                  aria-label="Close"
                  onClick={handleCloseModal}
                  style={{
                    background: 'transparent',
                    border: 'none',
                    fontSize: '2rem',
                    color: '#fff',
                    zIndex: 10,
                  }}
                >
                  &times;
                </button>
                <div className="ratio ratio-16x9">
                <iframe
                  width="100%"
                  height="100%"
                  src={youtubeurl}
                  title="YouTube video"
                  frameBorder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                ></iframe>
              </div>

              </div>
            </div>
          </div>
        </div>
      )}
        {/* </div>
      </div>
    </div> */}
		{/* WhatsApp Icon */}
      <div className="floating-whatsapp-container">
        <div className="floating-whatsapp" onClick={toggleChatBox}>
          <FontAwesomeIcon icon={faWhatsapp} />
        </div>
        {isChatBoxVisible && (
          <div className="chat-box">
            <div className="wats-header">
              <p>Desikha health foods</p>
              <button className="close-button" onClick={toggleChatBox}>
                X
              </button>
            </div>
            <div className="wats-content">
              <p>Welcome To Desikha health foods</p>
            </div>
            <div className="chat-content">
            <textarea
              placeholder="Type your message here..."
              value={message}
              onChange={handleMessageChange}
            >
			</textarea>
            <button onClick={sendMessage}>
              <IoSendSharp />
            </button>
          </div>
          </div>
        )}
      </div>
		{/* <!-- New Products End --> */}
	</div>
	<section>
      <div className="fancy-box-container template-1" style={{ background: '#88c000' }}>
        <div className="container">
          <div className="row">

            <div className="col-xs-12 fancy col-sm-6 col-md-3">
              <div className="content clear-all">
                <div className="content-icon">
                  <i className="fa fa-car"></i>
                </div>
                <div className="content-text">
                  <span className="upper title">FREE SHIPPING</span>
                  <p className="text">All order over $100</p>
                </div>
              </div>
            </div>

            <div className="col-xs-12 fancy col-sm-6 col-md-3">
              <div className="content clear-all">
                <div className="content-icon">
                  <i className="fa fa-life-ring"></i>
                </div>
                <div className="content-text">
                  <span className="upper title"><nobr>CUSTOMER SUPPORT</nobr></span>
                  <p className="text">Support 24/7</p>
                </div>
              </div>
            </div>

            <div className="col-xs-12 fancy col-sm-6 col-md-3">
              <div className="content clear-all">
                <div className="content-icon">
                  <i className="fab fa-cc-visa"></i>
                </div>
                <div className="content-text">
                  <span className="upper title">SECURE PAYMENTS</span> 
                  <p className="text">Confirmed</p>
                </div>
              </div>
            </div>

            <div className="col-xs-12 fancy col-sm-6 col-md-3">
              <div className="content clear-all">
                <div className="content-icon">
						<i className="fa fa-heart-o"></i>
                </div>
                <div className="content-text">
                  <span className="upper title">MADE WITH LOVE</span>
                  <p className="text">Best Services</p>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </section>
	<Footer />
  </>
      )}
	</>
      
  )
}

export default Home