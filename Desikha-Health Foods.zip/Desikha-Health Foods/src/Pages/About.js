import React,{useEffect, useState} from 'react'
import Footer from '../Components/Footer'
import axios from 'axios'
import { Link} from 'react-router-dom';

const About = () => {
 const [aboutData, setAboutData] = useState(null);
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
 const[loading,setLoading] = useState(true);
 
  useEffect(() => {
	const fetchAboutData = async() => {
		try{
			const response = await axios.post(`${API_BASE_URL}content.php`)
			 const {body} = response.data;
			 setAboutData(body.about) 
		} catch(error){
			alert("Error fetching the contact data", error)
		    console.error("Error fetching the contact data", error);
		}finally{
			setLoading(false);
		}
	}
	fetchAboutData();
  },[])


useEffect(() => {
			window.scrollTo(0, 0); 
		}, []);

	
  return (
<>
{loading ? (
      <div style={{ height: '100vh', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
        <div className="loader"></div>
      </div>
    ) : (
    <div class="wrapper">
		<div class="gambo-Breadcrumb">
					<div class="container">
						<div class="row">
							<div class="col-md-12">
								<nav aria-label="breadcrumb">
									<ol class="breadcrumb">
										<li class="breadcrumb-item"><Link to="/">Home</Link></li>
										<li class="breadcrumb-item active" aria-current="page">About Us</li>
									</ol>
								</nav>
							</div>
						</div>
					</div>
				</div>
		<div class="life-gambo">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="default-title left-text">
							<h2>About </h2>
							{/* <p>Customers Deserve Better</p>
							<img src="images/line.svg" alt="" /> */}
						</div>
						<div class="about-content">
							  <p dangerouslySetInnerHTML={{ __html: aboutData?.value }} />
							   {/* <p>Welcome to <strong>[Your Brand Name]</strong>, your trusted destination for natural, nutritious, 
							       and wholesome health mix products!</p>

									<p>At <strong>[Your Brand Name]</strong>, we believe that good health starts with good food. 
									That’s why we’ve created a range of traditional and time-tested health mixes made from premium quality 
									grains, pulses, millets, nuts, and herbs — all carefully selected, hygienically processed, and packed 
									with love.</p>

									<h3>Our Mission</h3>
									<p>To bring back the goodness of ancient Indian nutrition in every home by offering <strong>
									100% natural, chemical-free, and preservative-free</strong> health mix products that support a 
									healthy lifestyle for people of all ages.</p>

									<h3>Why Choose Us?</h3>
									<ul>
									<li><strong>100% Natural Ingredients</strong> – No preservatives, no artificial flavors.</li>
									<li><strong>Traditional Recipes</strong> – Inspired by age-old Indian formulations.</li>
									<li><strong>Nutrient-Rich Blends</strong> – Packed with proteins, fibers, and essential vitamins.</li>
									<li><strong>Hygienic Processing</strong> – State-of-the-art equipment with strict quality control.</li>
									<li><strong>Suitable for All Ages</strong> – From toddlers to elders, everyone can enjoy our mixes.</li>
									</ul>

									<h3>Join the Health Revolution</h3>
									<p>We’re more than just a brand — we’re a movement toward healthy living. Thousands of families have 
									already embraced our products as part of their daily routine. Are you ready to start your journey to 
									wellness?</p>
									 */}
						</div> 
					</div>
					{/* <div class="col-lg-6">
						<div class="about-img">
							<img src="images/about.svg" alt="" />
						</div>
					</div> */}
				</div>
			</div>
		</div>
		
	</div>
	)}
	<Footer />
</>
  )
}

export default About