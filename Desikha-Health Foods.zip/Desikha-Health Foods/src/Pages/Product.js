import React,{useEffect,useState} from 'react'
import { Link, Links } from 'react-router-dom';
import Footer from '../Components/Footer';
import { Dropdown } from "react-bootstrap";
import { useCart } from '../Context/CartContext';
import { FaShoppingCart } from 'react-icons/fa';
import axios from "axios";
import { useParams } from "react-router-dom";
import { Offcanvas } from 'bootstrap';
import pimage from '../Assets/45357.jpg';
import pimage1 from '../Assets/45357.jpg';
import pimage2 from '../Assets/45357.jpg';
import Slider from 'rc-slider';
import 'rc-slider/assets/index.css';


const Product = () => {
    const { addToCart, messages } = useCart();
	const [showAll, setShowAll] = useState(false);
    const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
    const [Products, setProducts] = useState([]);
	const [loading, setLoading] = useState(false);
	const { id:menu_id } = useParams(); 
	const [selectedAges, setSelectedAges] = useState([]);
	const [categories, setCategories] = useState([]);
	const [selectedCategories, setSelectedCategories] = useState([]);

 const [range, setRange] = useState([0, 50000]);

	  const handleSliderChange = (value) => {
		setRange(value);
	  };


useEffect(() => {
	setLoading(true)
	if(menu_id){
		axios.post(`${API_BASE_URL}menu_product_list.php`,{
			menu_id:menu_id
		})
		
		.then(res => {
			if(res.data.head.code === 200){
		 const fetchedProducts = res.data.body.map(product => {
  const defaultPrice = product.price?.[0] || {};
      // setSelectedPrice(defaultPrice)
          return {
            id: product.product_id, 
            name: product.product_name,
            priceOptions: product.price || [], // store all weights
            price: parseFloat(defaultPrice.online_rate) || 0,
            oldPrice: parseFloat(defaultPrice.mrp_rate) || 0,
            weight: defaultPrice.weight || '',
            unit: defaultPrice.unit || '',
            image: product.product_image || " ",
            inStock: parseInt(product.stock) > 0,
            category_id: product.category_id,
          };
        

        });
        setProducts(fetchedProducts);
		
		console.log(fetchedProducts);
        setLoading(false);
		}
		})
		 .catch(error => {
      console.error("Error fetching products:", error);
    });
	}
},[menu_id])


// 1. Extract unique ages
const uniqueAges = Array.from(
  new Set(
    Products
      .map((product) => {
        const ageStr = product.age; // e.g. "10+"
        const ageNum = parseInt(ageStr); // get number part like 10
        return !isNaN(ageNum) ? ageStr : null; // only include valid ages
      })
      .filter((age) => age !== null) // remove nulls
  )
).sort((a, b) => parseInt(a) - parseInt(b)); // sort by numeric value



const handleAgeFilterChange = (e) => {
  const age = e.target.value;
  const isChecked = e.target.checked;

  setSelectedAges((prevSelected) => {
    const updated = isChecked
      ? [...prevSelected, age]
      : prevSelected.filter((a) => a !== age);

    // Close the offcanvas
    const offcanvasEl = document.getElementById('offcanvasFilter');
    let offcanvasInstance = Offcanvas.getInstance(offcanvasEl);
    if (!offcanvasInstance) {
      offcanvasInstance = new Offcanvas(offcanvasEl);
    }
    offcanvasInstance.hide();

    // Remove backdrop manually after a slight delay (give Bootstrap time to animate)
    setTimeout(() => {
      const backdrop = document.querySelector('.offcanvas-backdrop');
      if (backdrop) {
        backdrop.remove(); // 🔥 manually remove it
        document.body.classList.remove('offcanvas-backdrop', 'show', 'modal-open');
        document.body.style.overflow = 'auto'; // reset scroll
      }
    }, 100); // delay to let Bootstrap finish animatio

    return updated;
  });
};

const handleCategoryFilterChange = (e, categoryId) => {
  const isChecked = e.target.checked;

  const updatedCategories = isChecked
    ? [...selectedCategories, categoryId]
    : selectedCategories.filter((id) => id !== categoryId);

  setSelectedCategories(updatedCategories);
   // Close the offcanvas
	  const offcanvasEl = document.getElementById('offcanvasFilter');
	  let offcanvasInstance = Offcanvas.getInstance(offcanvasEl);
	  if (!offcanvasInstance) {
		offcanvasInstance = new Offcanvas(offcanvasEl);
	  }
	  offcanvasInstance.hide();
  
	  // Remove backdrop manually after a slight delay (give Bootstrap time to animate)
	  setTimeout(() => {
		const backdrop = document.querySelector('.offcanvas-backdrop');
		if (backdrop) {
		  backdrop.remove(); // 🔥 manually remove it
		  document.body.classList.remove('offcanvas-backdrop', 'show', 'modal-open');
		  document.body.style.overflow = 'auto'; // reset scroll
		}
	  }, 100); 
};

const handleFilter = () => {
  const [minPrice, maxPrice] = range;

  const filtered = Products.filter((product) => {
    const productPrice = parseFloat(product.price);
    return productPrice >= minPrice && productPrice <= maxPrice;
  });

  setProducts(filtered);
  setShowAll(true); // Optional: show all filtered items
};

const filteredProducts = Products.filter((product) => {

//   const ageMatch =
//     selectedAges.length === 0 || selectedAges.includes(product.age);
  const categoryMatch =
    selectedCategories.length === 0 || selectedCategories.includes(product.category_id);

  return  categoryMatch;
});

// const filteredProducts = selectedAges.length === 0
//   ? Products
//   : Products.filter((product) => selectedAges.includes(product.age));


const visibleProducts = showAll ? filteredProducts : filteredProducts.slice(0, 8);


useEffect(() => {
  const offcanvasEl = document.getElementById('offcanvasFilter');

  const handleHidden = () => {
    const backdrop = document.querySelector('.offcanvas-backdrop');
    if (backdrop) {
      backdrop.remove();
    }
    document.body.classList.remove('offcanvas-backdrop', 'show', 'modal-open');
    document.body.style.overflow = 'auto'; // restore scroll
  };

  if (offcanvasEl) {
    offcanvasEl.addEventListener('hidden.bs.offcanvas', handleHidden);
  }

  // Cleanup on unmount
  return () => {
    if (offcanvasEl) {
      offcanvasEl.removeEventListener('hidden.bs.offcanvas', handleHidden);
    }
  };

}, []);
 
// category api ----> category display in side filter

	useEffect(() => {
	axios.post(`${API_BASE_URL}menu_dropdown.php`)
		.then(res => {
		if (res.data.head.code === 200 && res.data.body) {
			setCategories(res.data.body);
	
		}
		})
		.catch(err => {
		console.error("Error fetching categories:", err);
		});
	}, []);


	useEffect(() => {
		window.scrollTo(0, 0); 
	}, []);


  return (
	<>
	{/* offcanvas filter start */}
	
	<div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasFilter" aria-labelledby="offcanvasFilterLabel" data-bs-backdrop="true">
		<div class="offcanvas-header bs-canvas-header side-cart-header p-3">
			
			<div class="d-inline-block main-cart-title" id="offcanvasFilterLabel">Filter</div>
			<button type="button" class="close-btn" data-bs-dismiss="offcanvas" aria-label="Close">
				<i class="uil uil-multiply"></i>
			</button>
		</div>
		<div class="offcanvas-body p-0">
			
			<div class="filter-items">
				<div class="filtr-cate-title">
					<h4> Filter</h4>
				</div>
				<div class="other-item-body scrollstyle_4">
					<div class="brand-list">
						{/* <div class="search-by-catgory">
							<div class="ui search">
							  <div class="ui left icon input swdh10 position-relative">
								<input class="prompt srch10" type="text" placeholder="Search by brand.." />
								<i class="uil uil-search icon icon1"></i>
							  </div>
							</div>
						</div> */}
						{/* {uniqueAges.map((age, index) => {
				          const productCount = Products.filter((product) => product.age === age).length;

				return (
					<div className="form-check mb-2 d-flex justify-content-between align-items-center" key={index}>
					<div>
						<input
						className="form-check-input me-2"
						type="checkbox"
						id={`age-${index}`}
						value={age}
						onChange={handleAgeFilterChange}
						/>
						<label className="form-check-label" htmlFor={`age-${index}`}>
						{age}
						</label> &nbsp; &nbsp; &nbsp; &nbsp; 
						<span className=" ">({productCount} Products)</span>
					</div>
					
					</div>
					
				);
				})} */}

					<div className="price-filter"
						style={{
							width: "100%",
							display: "flex",
							alignItems: "center",
							justifyContent: "center",
							gap: "10px",
							padding: "0 10px"
						}}
						>
						<div style={{ flex: 1 }}>
							<p style={{ textAlign: "center", marginBottom: "10px" }}>
							Min: <i className="bi bi-currency-rupee"></i>{range[0]} - 
							Max: <i className="bi bi-currency-rupee"></i>{range[1]}
							</p>
							<Slider
							range
							min={0}
							max={50000}
							step={10}
							defaultValue={[0, 50000]}
							value={range}
							onChange={handleSliderChange}
							trackStyle={[{ backgroundColor: "#f55d2c" }]}
							handleStyle={[
								{ backgroundColor: "#f55d2c", border: "none" },
								{ backgroundColor: "#f55d2c", border: "none" },
							]}
							/>
						</div>&nbsp;
						<button
							onClick={handleFilter}
							style={{
							height: "40px",
							backgroundColor: "#f55d2c",
							color: "#fff",
							border: "none",
							padding: "0 20px",
							borderRadius: "4px",
							cursor: "pointer",
							whiteSpace: "nowrap",
							marginTop:"25px"
							}}
							data-bs-dismiss="offcanvas" aria-label="Close"
						>
							Go
						</button>
						</div>

					</div>
				</div>
				<hr />
				<div class="filtr-cate-title">
					<h4>Categories</h4>
				</div>
			
					{categories.map((cat, index) => (
					<div
						className="form-check mb-2 d-flex justify-content-between align-items-center"
						key={cat.category_id} // category_id as cid
					>
						<div>
						<input
							className="form-check-input me-2"
							type="checkbox"
							id={`category-${index}`}
							value={cat.category_id}
							onChange={(e) => handleCategoryFilterChange(e, cat.category_id)} // category_id as cid
						/>
						<label className="form-check-label" htmlFor={`category-${index}`}>
							{cat.category_name}
						</label>
						</div>
					</div>
					))}

			</div>
			
		</div>
	</div>

	{/* offcanvas filter end */}

	{loading ? (
      <div style={{ height: '100vh', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
    <div className="loader"></div>
  </div>

    ):(

   <>
    <div class="wrapper">
		<div class="gambo-Breadcrumb">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><Link to="/">Home</Link></li>
								<li class="breadcrumb-item active" aria-current="page">Products</li>
							</ol>
						</nav>
					</div>
				</div>
			</div>
		</div>
		{messages && Object.entries(messages).map(([id, message]) => (
			<div key={id} className="message-popup">
				<FaShoppingCart className="cart-icon-addtocart" />
				<div className="message">{message}</div>
			</div>
		))}

		<div class="all-product-grid">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="product-top-dt">
							{/* <div class="product-left-title">
								<h2>New Products</h2>
							</div> */}
							<a href="#" class="filter-btn" data-bs-toggle="offcanvas" data-bs-target="#offcanvasFilter" 
							aria-controls="offcanvasFilter">Filters <span style={{fontSize:"14px"}}><i class="bi bi-filter"></i></span></a>
						
							
							
						</div>
					</div>
				</div>
				<div class="product-list-view">
					<div class="row">
						 {visibleProducts.map(product => (
						<div class="col-lg-3 col-md-6" key={product.id}>
						<div class="product-item mb-30">
						<a class="product-img">
							<div class="product-absolute-options ">
								
								</div>
								</a>
							<Link to={`/productdetails/${product.id}`} class="product-img">
								<img src={product.image} alt={product.name} />
								
							</Link>
							
							<div class="product-text-dt">
								<h4>{product.name}</h4>
								<div class="product-price"><i class="bi bi-currency-rupee"></i>{product.price} <span><i class="bi bi-currency-rupee"></i>{product.oldPrice}</span></div>
								<div class="qty-cart">
									 <button
											className="add-to-cart-btn hover-btn"
											 onClick={() => {
                                                const defaultVariant = product.priceOptions[0];

                                                addToCart({
                                                  ...product,
                                                  price: defaultVariant.online_rate,
                                                  oldPrice: defaultVariant.mrp_rate,
                                                  weight: defaultVariant.weight,
                                                  unit: defaultVariant.unit,
                                                  quantity: 1, // 👈 Ensure quantity is passed
                                                });
                                              }}
											>
											<span>Add to Cart</span>
											<i className="bi bi-cart3"></i>
											</button>
								</div>
								 
							</div>
						</div>
					</div>
						))}



						{/* <div class="col-lg-3 col-md-6" >
						<div class="product-item mb-30">
						<a class="product-img">
							<div class="product-absolute-options ">
								
								</div>
								</a>
							<Link to={`/productdetails/${product.id}`} class="product-img">
									<Link to={'/productdetails'} class="product-img">

								<img src={pimage} alt='' />
								
							</Link>
							
							<div class="product-text-dt">
								<h4>{product.name}</h4>
								<h4>Cashew </h4>
								<div class="product-price"><i class="bi bi-currency-rupee"></i>{product.price} <span><i class="bi bi-currency-rupee"></i>{product.oldPrice}</span></div>
								<div class="product-price"><i class="bi bi-currency-rupee"></i>1500 <span><i class="bi bi-currency-rupee"></i>1800</span></div>
								<div class="qty-cart">
									 <button
											className="add-to-cart-btn hover-btn"
											// onClick={() => addToCart(product)}
											>
											<span>Add to Cart</span>
											<i className="bi bi-cart3"></i>
											</button>
								</div>
								 
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-6" >
						<div class="product-item mb-30">
						<a class="product-img">
							<div class="product-absolute-options ">
								
								</div>
								</a>
							<Link to={`/productdetails/${product.id}`} class="product-img">
									<Link to={'/productdetails'} class="product-img">

								<img src={pimage1} alt='' />
								
							</Link>
							
							<div class="product-text-dt">
								<h4>{product.name}</h4>
								<h4>Health Mix </h4>
								<div class="product-price"><i class="bi bi-currency-rupee"></i>{product.price} <span><i class="bi bi-currency-rupee"></i>{product.oldPrice}</span></div>
								<div class="product-price"><i class="bi bi-currency-rupee"></i>2500 <span><i class="bi bi-currency-rupee"></i>2800</span></div>
								<div class="qty-cart">
									 <button
											className="add-to-cart-btn hover-btn"
											// onClick={() => addToCart(product)}
											>
											<span>Add to Cart</span>
											<i className="bi bi-cart3"></i>
											</button>
								</div>
								 
							</div>
						</div>
					</div> */}
					{/* <div class="col-lg-3 col-md-6" >
						<div class="product-item mb-30">
						<a class="product-img">
							<div class="product-absolute-options ">
								
								</div>
								</a>
							<Link to={`/productdetails/${product.id}`} class="product-img">
									<Link to={'/productdetails'} class="product-img">

								<img src={pimage2} alt='' />
								
							</Link>
							
							<div class="product-text-dt">
								<h4>{product.name}</h4>
								<h4>All in one (Combo) </h4>
								<div class="product-price"><i class="bi bi-currency-rupee"></i>{product.price} <span><i class="bi bi-currency-rupee"></i>{product.oldPrice}</span></div>
								<div class="product-price"><i class="bi bi-currency-rupee"></i>1099 <span><i class="bi bi-currency-rupee"></i>1299</span></div>
								<div class="qty-cart">
									 <button
											className="add-to-cart-btn hover-btn"
											// onClick={() => addToCart(product)}
											>
											<span>Add to Cart</span>
											<i className="bi bi-cart3"></i>
											</button>
								</div>
								 
							</div>
						</div>
					</div> */}
					
						
						{filteredProducts.length > 8 && (
							<div className="col-md-12">
								<div className="more-product-btn text-center">
								<button className="show-more-btn hover-btn" onClick={() => setShowAll(!showAll)}>
									{showAll ? 'Show Less' : 'Show More'}
								</button>
								</div>
							</div>
						)}
  
					</div>
				</div>
			</div>
		</div>
	</div>
	 </>
       )}
	<Footer />
	</>
  )
}

export default Product