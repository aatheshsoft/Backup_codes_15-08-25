import React,{useEffect,useState} from 'react'
import { Link } from 'react-router-dom';
import pimage from '../Assets/cashew-butter-dark-background (1).jpg';
import pimage1 from '../Assets/2148774962.jpg';
import Footer from '../Components/Footer';
import axios from 'axios';



const OrderHistory = () => {
const UserName = JSON.parse(localStorage.getItem('username'));
 const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const memberId = JSON.parse(localStorage.getItem('user_id')); // or use JSON.parse if needed
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

  useEffect(() => {
    const fetchOrderHistory = async () => {
      try {
        const res = await axios.post(`${API_BASE_URL}orderhistory.php`, {
          member_id: memberId
        });

        if (res.data?.head?.code === 200) {
          setOrders(res.data.body || []);
        } else {
        //   alert('No orders found or failed to fetch order history.');
        }
      } catch (error) {
        console.error('Failed to fetch order history:', error);
        alert('Something went wrong while fetching order history.');
      } finally {
        setLoading(false);
      }
    };

    if (memberId) {
      fetchOrderHistory();
    } else {
      alert("User ID not found. Please login again.");
    }
  }, [memberId]);

  console.log(orders)
 

	useEffect(() => {
		window.scrollTo(0, 0); 
	}, []);
	const handleCancelOrder = async (orderNo) => {
  try {
    const res = await axios.post(`${API_BASE_URL}cancel_order.php`, {
      order_no: orderNo
    });

    if (res.data?.head?.code === 200) {
      alert("Order cancelled successfully.");
		window.location.reload();
      // Optional: Refresh order history or update UI state
      setOrders(prevOrders =>
        prevOrders.map(order =>
          order.order_no === orderNo
            ? { ...order, cancel: "1" } // Mark as cancelled
            : order
        )
      );
    } else {
      alert("Failed to cancel order. Try again later.");
    }
  } catch (error) {
    console.error("Cancel order error:", error);
    alert("Something went wrong while cancelling the order.");
  }
};


	 if (loading) return <p>Loading orders...</p>;



	 
  return (
	<>
    <div class="wrapper">
		<div class="gambo-Breadcrumb">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><Link to="/">Home</Link></li>
								<li class="breadcrumb-item active" aria-current="page">My Orders</li>
							</ol>
						</nav>
					</div>
				</div>
			</div>
		</div>
		<div class="dashboard-group">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="user-dt">
							<div class="user-img">
                                <img src="images/img-icon.jpg" alt="" />
								{/* <div class="img-add">													
									<input type="file" id="file" />
									<label for="file"><i class="uil uil-camera-plus"></i></label>
								</div> */}
							</div>
							<h4>{UserName}</h4>
							{/* <p>+91999999999<a href="#"><i class="uil uil-edit"></i></a></p>
							<div class="earn-points"><img src="images/Dollar.svg" alt="" />Points : <span>20</span></div> */}
						</div>
					</div>
				</div>
			</div>
		</div>	
		<div class="">
			<div class="container">
				<div class="row">
					{/* // page side menu
					 <div class="col-xl-3 col-lg-4 col-md-12">
						<div class="left-side-tabs">
							<div class="dashboard-left-links">
								<a href="dashboard_overview.html" class="user-item"><i class="uil uil-apps"></i>Overview</a>
								<a href="dashboard_my_orders.html" class="user-item active"><i class="uil uil-box"></i>My Orders</a>
								<a href="dashboard_my_rewards.html" class="user-item"><i class="uil uil-gift"></i>My Rewards</a>
								<a href="dashboard_my_wallet.html" class="user-item"><i class="uil uil-wallet"></i>My Wallet</a>
								<a href="dashboard_my_wishlist.html" class="user-item"><i class="uil uil-heart"></i>Shopping Wishlist</a>
								<a href="dashboard_my_addresses.html" class="user-item"><i class="uil uil-location-point"></i>My Address</a>
								<a href="sign_in.html" class="user-item"><i class="uil uil-exit"></i>Logout</a>
							</div>
						</div>
					</div> */}
					<div class="col-xl-12 col-lg-8 col-md-12">
						<div class="dashboard-right">
							<div class="row">
								<div class="col-md-12">
									<div class="main-title-tab">
										<h4><i class="uil uil-box"></i>My Orders</h4>
									</div>
								</div>
								<div class="col-lg-12 col-md-12">
									{orders.map((order, index) => (
											<div className="pdpt-bg" key={index}>
												<div className="pdpt-title">
												<h6>Order Date :  {order.orderdate}</h6>
												</div>
												<div className="order-body10">
												<ul className="order-dtsll d-flex justify-content-between align-items-center">
													<li className="d-flex">
													<div className="order-dt-img">
														<img src={order.image} alt={order.product_name || "Product"} />
													</div>
													<div className="order-dt47 ms-3">
														<h4>{order.product_name || "Unnamed Product"}</h4>
														<p>{order.cancel === "0" ? "Delivered" : "Cancelled"}</p>
														<div className="order-title">{order.qty} Items</div>
													</div>
													</li>

													<li>
														{order.cancel === "0" ? (
															<button
															className="cancel-btn"
															onClick={() => handleCancelOrder(order.order_no)}
															>
															Cancel Order
															</button>
														) : (
															<span className="text-danger fw-bold">Order Cancelled</span>
														)}
														</li>


												</ul>

												<div className="total-dt">
													<div className="total-checkout-group">
													<div className="cart-total-dil">
														<h4>Sub Total</h4>
														<span><i className="bi bi-currency-rupee"></i>{order.amount}</span>
													</div>
													<div className="cart-total-dil pt-3">
														<h4>Delivery Charges</h4>
														<span>Free</span>
													</div>
													</div>
													<div className="main-total-cart">
													<h2>Total</h2>
													<span><i className="bi bi-currency-rupee"></i>{order.totalamount}</span>
													</div>
												</div>

												<div className="track-order">
													<h4>Track Order</h4>
													<div className="bs-wizard" style={{ borderBottom: "0" }}>
													<div className="bs-wizard-step complete">
														<div className="text-center bs-wizard-stepnum">Placed</div>
														<div className="progress"><div className="progress-bar"></div></div>
														<p className="bs-wizard-dot"></p>
													</div>
													<div className="bs-wizard-step complete">
														<div className="text-center bs-wizard-stepnum">Packed</div>
														<div className="progress"><div className="progress-bar"></div></div>
														<p className="bs-wizard-dot"></p>
													</div>
													<div className="bs-wizard-step active">
														<div className="text-center bs-wizard-stepnum">On the way</div>
														<div className="progress"><div className="progress-bar"></div></div>
														<p className="bs-wizard-dot"></p>
													</div>
													<div className="bs-wizard-step disabled">
														<div className="text-center bs-wizard-stepnum">Delivered</div>
														<div className="progress"><div className="progress-bar"></div></div>
														<p className="bs-wizard-dot"></p>
													</div>
													</div>
												</div>
												</div>
											</div>
											))}

									<hr />
									{/* <div class="pdpt-bg">
										<div class="pdpt-title">
											<h6>Delivery Timing 10 May, 3.00PM - 6.00PM</h6>
										</div> 
										<div class="order-body10">
											<ul class="order-dtsll">
												<li>
													<div class="order-dt-img">
														<img src={pimage1} alt="" />
													</div>
												</li>
												<li>
													<div class="order-dt47">
														<h4>Cashew Health Mix Powder</h4>
														<p>Delivered</p>
														<div class="order-title">2 Items </div>
													</div>
												</li>
											</ul>
											<div class="total-dt">
												<div class="total-checkout-group">
													<div class="cart-total-dil">
														<h4>Sub Total</h4>
														<span><i class="bi bi-currency-rupee"></i>25</span>
													</div>
													<div class="cart-total-dil pt-3">
														<h4>Delivery Charges</h4>
														<span>Free</span>
													</div>
												</div>
												<div class="main-total-cart">
													<h2>Total</h2>
													<span><i class="bi bi-currency-rupee"></i>25</span>
												</div>
											</div>
											<div class="track-order">
												<h4>Track Order</h4>
												<div class="bs-wizard" style={{borderBottom:"0"}}>   
													<div class="bs-wizard-step complete">
														<div class="text-center bs-wizard-stepnum">Placed</div>
														<div class="progress"><div class="progress-bar"></div></div>
														<p class="bs-wizard-dot"></p>
													</div>
													<div class="bs-wizard-step complete">
														<div class="text-center bs-wizard-stepnum">Packed</div>
														<div class="progress"><div class="progress-bar"></div></div>
														<p class="bs-wizard-dot"></p>
													</div>
													<div class="bs-wizard-step complete">
														<div class="text-center bs-wizard-stepnum">Arrived</div>
														<div class="progress"><div class="progress-bar"></div></div>
														<p class="bs-wizard-dot"></p>
													</div>
													<div class="bs-wizard-step complete">
														<div class="text-center bs-wizard-stepnum">Delivered</div>
														<div class="progress"><div class="progress-bar"></div></div>
														<p class="bs-wizard-dot"></p>
													</div>
												</div>
											</div>
											<hr />
											
										</div>
									</div> */}
								</div>								
							</div>
						</div>
					</div>
				</div>	
			</div>	
		</div>	
	</div>
	<Footer />
	</>
  )
}

export default OrderHistory