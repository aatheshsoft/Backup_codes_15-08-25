import React, { useRef,useEffect, useState } from 'react'
import OwlCarousel from "react-owl-carousel";
import "owl.carousel/dist/assets/owl.carousel.css";
import "owl.carousel/dist/assets/owl.theme.default.css";
import Footer from '../Components/Footer';
import { Link,useParams } from 'react-router-dom';
import { useCart } from '../Context/CartContext';
import axios from 'axios';
import InnerImageZoom from "react-inner-image-zoom";
import "react-inner-image-zoom/lib/InnerImageZoom/styles.min.css";
import { FaShoppingCart } from 'react-icons/fa';
import pimage from '../Assets/45357.jpg';
import { useNavigate, useLocation  } from 'react-router-dom';



const WholesaleProductDetails = () => {
  const sync1Ref = useRef(null);
  const sync2Ref = useRef(null);
  const { id } = useParams();
  const [activeIndex, setActiveIndex] = useState(0); 
  const navigate = useNavigate();
  const location = useLocation();

  const UserID = JSON.parse(localStorage.getItem("user_id"));

 useEffect(() => {
    if (!UserID) {
      navigate('/signin', {
        state: { from: location }, // 👈 Pass current location to login
        replace: true,
      });
    }
  }, []);


const handleSync = (event) => {
    if (!sync2Ref.current) return; 
    let index = event.item.index;
    sync2Ref.current.to(index, 300, true);
  	};

    const { addToCart, updateQuantity, removeFromCart,cartItems,messages } = useCart();
  	const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
	const[products, setProducts] =  useState([])
	const [loading, setLoading] = useState(false);

	const [counts, setCounts] = useState({});
    const [quantity, setQuantity] = useState ({});
	const [showModal, setShowModal] = useState(false);
	const [selectedProduct, setSelectedProduct] = useState(null);
    const [formData, setFormData] = useState({
		name: '',
		email: '',
		mobileNumber: '',
		address: '',
		city: '',
		state: '',
		pincode: '',
	    message:'',
	})

/* featured product carousel  settings */
  useEffect(() => {
      // Initialize Owl Carousel after component mounts
      window.$('.owl-carousel').owlCarousel({
        loop: true,
        margin: 10,
        nav: true,
        autoplay: true,
        autoplayTimeout: 5000,
        responsive: {
          0: {
            items: 1
          },
          600: {
            items: 2
          },
          1000: {
            items: 5
          }
        }
      });
    }, []);

    
		useEffect(() => {
				window.scrollTo(0, 0); 
			}, []);




		useEffect(() => {
			axios.post(`${API_BASE_URL}product_details.php`, {
			product_id: id
			})
			.then(res => {
			if (res.data.head.code === 200 && res.data.body.product_detail) {
				setProducts(res.data.body.product_detail.map(item => ({
		...item,
		id: item.product_id, // change product_id to id for cart context purpose                                                  
		name:item.product_name
		})));
 
		//console.log(res.data.body.product_detail[0])
      }
    })
    .catch(err => {
      console.error("Error fetching product details:", err);
    });
  }, [id]);

const images = products[0]?.image || [];

  // Optional reset on new product id only (not on every product render)
  useEffect(() => {
	setActiveIndex(0);
	sync1Ref.current?.to(0, 0);
  }, [id]);



 const [tempQuantities, setTempQuantities] = useState({});

  const isInCart = (productId) =>
    cartItems.some(item => item.id === productId);

  const getCartQuantity = (productId) => {
    const item = cartItems.find(item => item.id === productId);
    return item ? item.quantity : null;
  };

  const handleQuantityChange = (productId, amount) => {
    if (isInCart(productId)) {
      const currentQty = getCartQuantity(productId);
      const newQty = Math.max(1, currentQty + amount);
      updateQuantity(productId, amount); // updates from CartContext
    } else {
      setTempQuantities(prev => {
        const currentQty = prev[productId] || 1;
        const newQty = Math.max(1, currentQty + amount);
        return { ...prev, [productId]: newQty };
      });
    }
  };

  const getQuantityToDisplay = (productId) => {
    return getCartQuantity(productId) ?? (tempQuantities[productId] || 1);
  };



	  

// const handleIncrement = (productId) => {
//   setCounts((prev) => ({
//     ...prev,
//     [productId]: prev[productId] + 1,
//   }));
//   updateQuantity(productId, 1);
// console.log("qty : " , updateQuantity)
// };

 // const handleDecrement = (productId) => {
//   setCounts((prev) => {
//     const updated = Math.max(1, prev[productId] - 1);
//     return { ...prev, [productId]: updated };
//   });
//   updateQuantity(productId, -1);   
  
// 	console.log("qty : ", updateQuantity)

// };


const handleSubmit = async (e) => {
  e.preventDefault();

  if (!formData.name || !formData.mobile || !formData.address) {
    alert("Please fill all required fields");
    return;
  }
const minimumQuantities = products.map((item, index) => 
  `Minimum order quantity ${item.minimum_qty} ${item.unit} (Per ${item.unit} contains ${item.box_contains} ${item.box_unit})`
);
const productcode = products.map((item) => item.product_code);

  const orderData = {
    name: formData.name,
    email: formData.email,
    mobile: formData.mobile,
    address: formData.address,
    city: formData.city,
    state: formData.state,
    pincode: formData.pincode,
    product_id: selectedProduct?.id,
    product_name: selectedProduct?.product_name,
    qty: selectedProduct?.quantity,
    message: formData.message,
	minimum_qty: minimumQuantities.join(', '),
  	product_code: productcode.join(', ')
  };

  console.log("Sending order:", orderData);

  try {
    setLoading(true);
    const response = await axios.post(`${API_BASE_URL}enquiry.php`, orderData);
    console.log("API Response:", response.data);
    alert("Enquiry placed successfully!");
	window.location.reload();
	setShowModal(false)
    // navigate("/orderplaced");
  } catch (error) {
    console.error("Enquiry submission failed:", error);
    alert("Something went wrong while placing your Enquiry.");
  } 
  finally {
    setLoading(false);
  }
};




  return (
	<>
    <div class="wrapper">
		<div class="gambo-Breadcrumb">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><Link to ="/">Home</Link></li>
								<li class="breadcrumb-item"><Link >Wholesale Product details</Link></li>
								{/* <li class="breadcrumb-item active" aria-current="page">Product Title</li> */}
							</ol>
						</nav>
					</div>
				</div>
			</div>
		</div>
		<>
			{messages && Object.entries(messages).map(([id, message]) => (
			<div key={id} className="message-popup">
				<FaShoppingCart className="cart-icon-addtocart"/>
				<div className="message">{message}</div>
			</div>
			))}
		</>
		<div class="all-product-grid">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="product-dt-view">
							<div class="row">
								<div class="col-lg-5 col-md-4">
                                <div className="owl-container">
										
										{images.length > 0 && (
												<>
												{/* Large Image Carousel */}
												<InnerImageZoom
												src={images[activeIndex]}
												zoomSrc={images[activeIndex]}
												zoomType="hover"
												zoomScale={2.5}
												zoomPreload={true}
												hideHint={false}
												alt={`Product Zoom ${activeIndex}`}
												width="100%"
											/>

												<br />

												{/* Thumbnails Carousel */}
												<OwlCarousel
													ref={sync2Ref}
													items={4}
													loop={false}
													margin={10}
													nav={false}
													dots={false}
													autoplay={false}
													smartSpeed={1000}
													className="owl-theme"
												>
													{images.map((img, index) => (
													<div
														className="item"
														key={`thumb-${index}`}
														onClick={() => {
														setActiveIndex(index);
														sync1Ref.current?.to(index, 300, true);
														}}
													>
														<img
														src={img}
														alt={`Thumb ${index}`}
														style={{
															border:
															"1px solid #ccc",
															padding: "2px",
															// width: "100px",
															height: "80px",
															objectFit: "cover",
															cursor: "pointer",
														}}
														/>
													</div>
													))}
												</OwlCarousel>
												</>
											)}

										</div>
								</div>
								
								<div class="col-lg-7 col-md-8">  
                                    
									<div class="product-dt-right">

										
										<div className="product-radio">
												{products.length === 0 ? (
													
													<div> </div>
												) : (
													products.map((item, index) => (
														 
													<div key={item.id}>
														<h2>{item.product_name}</h2>

														<div className="no-stock">
														<p className="pd-no">
															Product No.<span>{item.product_code}</span>
														</p>
														{/* <p className="stock-qty">
															Available<span>{item.stock ? '(In Stock)' : '(Out of Stock)'} - {item.stock}</span>
														</p> */}
														</div>
													
 															<p style={{color:"darkgreen",fontSize:"16px"}}>
															  Minimum order quantity {item.minimum_qty} {item.unit} ( Per {item.unit} contain {item.box_contains} {item.box_unit})
															</p>
														<div className="product-group-dt">
														<ul>
															<li>
															<div className="main-price color-discount">
																<span style={{color:"darkblue"}}>Price </span> :<span style={{color:"orangered"}}> <i className="bi bi-currency-rupee"></i>{item.mrp_rate} / {item.rate_per}</span>
															</div>
															</li>
															{/* <li>
															<div className="main-price mrp-price">
																MRP Price<span><i className="bi bi-currency-rupee"></i>{item.mrp_rate}</span>
															</div>
															</li> */}
														</ul>

														<ul className="gty-wish-share">
																<li>
																<div className="qty-product">
																	<div className="quantity buttons_added">
																	<input
																		type="button"
																		value="-"
																		className="minus minus-btn"
																		onClick={() => handleQuantityChange(item.id, -1)}
																	/>
																	<input
																		type="number"
																		value={getQuantityToDisplay(item.id)}
																		readOnly
																		className="input-text qty text"
																	/>
																	<input
																		type="button"
																		value="+"
																		className="plus plus-btn"
																		onClick={() => handleQuantityChange(item.id, 1)}
																	/>
																	</div>
																</div>
																</li>
															</ul>
																&nbsp; &nbsp; &nbsp;
                                                            <table>
																<tbody>
																	<tr>
																		<td style={{ border: "1px solid #ddd", padding: "8px" }}>
                                                                          Product	
																		</td>
																			<td style={{ border: "1px solid #ddd", padding: "8px" }}>
                                                                          {item.product_name}
																		</td>
																		
																	</tr>
																	<tr>
																		<td style={{ border: "1px solid #ddd", padding: "8px" }}>
                                                                          Grade		
																		</td>
																			<td style={{ border: "1px solid #ddd", padding: "8px"}}>
                                                                          	{item.grade}	
																		</td>
																		
																	</tr>
																	<tr>
																		<td style={{ border: "1px solid #ddd", padding: "8px" }}>
                                                                          Type		
																		</td>
																			<td style={{ border: "1px solid #ddd", padding: "8px"}}>
                                                                          	{item.type}	
																		</td>
																		
																	</tr>
																	<tr>
																		<td style={{ border: "1px solid #ddd", padding: "8px" }}>
                                                                          Color	
																		</td>
																			<td style={{ border: "1px solid #ddd", padding: "8px" }}>
                                                                          {item.colour}
																		</td>
																	</tr>
																	<tr>
																		<td style={{ border: "1px solid #ddd", padding: "8px" }}>
                                                                          Shelf Life		
																		</td>
																			<td style={{ border: "1px solid #ddd", padding: "8px" }}>
                                                                          {item.self_life}
																		</td>
																	</tr>
																	<tr>
																		<td style={{ border: "1px solid #ddd", padding: "8px" }}>
                                                                        Processing Type		
																		</td>
																			<td style={{ border: "1px solid #ddd", padding: "8px" }}>
                                                                          {item.processing_type}
																		</td>
																	</tr>

																</tbody>
															</table>
														<ul className="ordr-crt-share">
															{/* <li>
															<button className="add-cart-btn hover-btn" 
															onClick={() => {
																const finalQty = getQuantityToDisplay(item.id); 

																addToCart({
																	...item,
																	price: item.online_rate,
																	oldPrice: item.mrp_rate,
																	quantity: finalQty,
																});

																// Clear temp quantity
																setTempQuantities(prev => {
																	const updated = { ...prev };
																	delete updated[item.id];
																	return updated;
																});
																}}
																>
																<i className="bi bi-cart3"></i>Add to Cart
															</button>
															</li> */}
															<li>
																<button
																className="add-cart-btn hover-btn"
																// onClick={() => {
																// 	const finalQty = getQuantityToDisplay(item.id);

																// 	addToCart({
																// 	...item,
																// 	price: item.online_rate,
																// 	oldPrice: item.mrp_rate,
																// 	quantity: finalQty,
																// 	});

																// 	setTempQuantities(prev => {
																// 	const updated = { ...prev };
																// 	delete updated[item.id];
																// 	return updated;
																// 	});
																// }}
															
																onClick={() => {
																const finalQty = getQuantityToDisplay(item.id);
																setSelectedProduct({ ...item, quantity: finalQty });
																setShowModal(true);
															}}
																>
																Enquiry
																</button>
															</li>
														</ul>
														</div>
													</div>
													))
												)}
												
											</div>
										</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				{/* desciptionn start */}
				<div class="row">
					
					<div class="col-lg-12 col-md-12">
						<div class="pdpt-bg">
							<div class="pdpt-title">
								<h4>Product Details</h4>
							</div>

							<div class="pdpt-body scrollstyle_4">
								<div class="pdct-dts-1">
									<div class="pdct-dt-step">
										<h4>Description</h4>
										{products.length === 0 ? (
													
													<div></div>
												) : (
													products.map((item, index) => (
														<p>{item.full_description}</p>
													)))}
													
												</div>
									
											</div>			
										</div>					
									</div>
								</div>
							</div>
						</div>
					</div>
			{/*<!-- Featured Products Start --> */}		
 	

          {/*   <!-- Featured Products End -->    */}	

 	</div>
		{showModal && (
			<div className="enquiry-modal-container">
				<div className="enquiry-modal-content">
					<div className="d-flex justify-content-between align-items-center">
			<h4 className="enquiry-title mb-0">Product Enquiry</h4>
			<i
				className="bi bi-x-square"
				style={{ fontSize: '1.5rem', cursor: 'pointer' }}
				onClick={() => setShowModal(false)}
			></i>
			</div>

	
		<hr />
		<br />
		<form onSubmit={handleSubmit}>
			<div className="row">
			<div className="col-lg-6 mb-3">
				<label className="form-label">Name</label>
				<input 
					type="text" 
					className="form-control"
					name="name"
					value={formData.name}
					onChange={(e) => setFormData({ ...formData, name: e.target.value })}
					required 
				/>
			</div>
			<div className="col-lg-6 mb-3">
				<label className="form-label">Email</label>
				<input 
					type="email" 
					className="form-control" 
					name="email"
					value={formData.email}
					onChange={(e) => setFormData({ ...formData, email: e.target.value })}
					required 
				/>
			</div>

			<div className="col-lg-6 mb-3">
				<label className="form-label">Mobile</label>
				<input 
					type="tel" 
					className="form-control" 
					name="mobile"
					value={formData.mobile}
					onChange={(e) => setFormData({ ...formData, mobile: e.target.value })}
					required 
				    maxLength={10}
				/>
			</div>
			
			<div className="col-lg-6 ">
				<label className="form-label">Address</label>
				<textarea 
					type="text" 
					className="form-control" 
					name="address"
					value={formData.address}
					onChange={(e) => setFormData({ ...formData, address: e.target.value })}
				/>
			</div> 
			<div className="col-lg-6 mb-3">
				<label className="form-label">City</label>
				<input 
					type="text" 
					className="form-control"
					name="city"
					value={formData.city}
					onChange={(e) => setFormData({ ...formData, city: e.target.value })} 
				/>
			</div>

			<div className="col-lg-6 mb-3">
				<label className="form-label">State</label>
				<input 
					type="text" 
					className="form-control"
					name="state"
					value={formData.state}
					onChange={(e) => setFormData({ ...formData, state: e.target.value })}
				 />
			</div>

			<div className="col-lg-6 mb-3">
				<label className="form-label">Pincode</label>
				<input 
					type="text" 
					className="form-control" 
					name="pincode"
					value={formData.pincode}
					onChange={(e) => setFormData({ ...formData, pincode: e.target.value })}
					maxLength={6}

				/>
			</div>

			

			<div className="col-lg-6 mb-3">
				<label className="form-label">Product Name</label>
				<input
				type="text"
				className="form-control"
				value={selectedProduct?.product_name || ''}
				readOnly
				/>
			</div>
		<div className="col-lg-6 mb-3">
			<label className="form-label">Quantity</label>
			<input
				type="number"
				className="form-control"
				value={selectedProduct?.quantity || 0}
				readOnly
			/>

			<small className="text-muted d-block mt-1">
				Minimum order quantity: {selectedProduct?.minimum_qty} {selectedProduct?.unit} (Per {selectedProduct?.unit} contains {selectedProduct?.box_contains} {selectedProduct?.box_unit})
			</small>
			</div>

			
			<div className="col-12 mb-3">
				<label className="form-label">Message</label>
				<textarea 
					className="form-control" 
					rows="3" 
					name="message"
					value={formData.message}
					onChange={(e) => setFormData({ ...formData, message: e.target.value })}
				/>
			</div>
			</div>

			<div className="d-flex justify-content-between mt-4">
			<button type="submit" className="btn btn-success">{loading ? "Submitting..." : "Submit"}</button>
			<button
				type="button"
				className="btn btn-secondary"
				onClick={() => setShowModal(false)}
			>
				Close
			</button>
			</div>
		</form>
		</div>
	</div>
	)}
<Footer />
  </>
  )
}

export default WholesaleProductDetails;