import React,{useEffect,useState} from 'react'
import { Link, Links } from 'react-router-dom';
import Footer from '../Components/Footer';
import { Dropdown } from "react-bootstrap";
import { useCart } from '../Context/CartContext';
import { FaShoppingCart } from 'react-icons/fa';
import { useParams } from "react-router-dom"; // if using URL param
import axios from "axios";
import { Offcanvas } from 'bootstrap';
import Slider from 'rc-slider';
import 'rc-slider/assets/index.css';



const ShopbyCategory = () => {
    const { addToCart, messages,cartItems } = useCart();
    const [showAll, setShowAll] = useState(false);
    const { category_id: categoryId } = useParams(); 
    const [Products, setProducts] = useState([]);
    const [loading, setLoading] = useState(false);
    const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
    const [selectedAges, setSelectedAges] = useState([]);
    const [range, setRange] = useState([0, 50000]);
   const[selectedprice,setSelectedPrice] = useState({})
      const handleSliderChange = (value) => {
        setRange(value);
      };

       /*-- auto scroll to top code -- */
    
    useEffect(() => {
        window.scrollTo(0, 0); 
    }, []);

 console.log("cartitems" , cartItems);

//     useEffect(() => {
//     setLoading(true);
//     if (categoryId) {
//     axios.post(`${API_BASE_URL}product_list.php`, {
//       category_id: categoryId
//     })
//     .then(res => {
//       if (res.data.head.code === 200) {
//         const fetchedProducts = res.data.body.map(product => ({
//           id: product.product_id,
//           name: product.product_name,
//           price: parseFloat(product.online_rate) || 0,
//           oldPrice: parseFloat(product.mrp_rate) || 0,
//           image: product.product_image || " ", // Fallback if no image
//           inStock: parseInt(product.stock) > 0,
//           category_id: categoryId,
//           age: product.age || null
//         }));
//         setProducts(fetchedProducts);
//         console.log(fetchedProducts);
//          setLoading(false);
//       }
//     })
//     .catch(error => {
//       console.error("Error fetching products:", error);
//     });
//   }
// }, [categoryId]);

useEffect(() => {
  setLoading(true);

  if (categoryId) {
    axios.post(`${API_BASE_URL}product_list.php`, {
      category_id: categoryId
    })
    .then(res => {
      if (res.data.head.code === 200) {
        const fetchedProducts = res.data.body.map(product => {
  const defaultPrice = product.price?.[0] || {};
      // setSelectedPrice(defaultPrice)
          return {
            id: product.product_id, 
            name: product.product_name,
            priceOptions: product.price || [], // store all weights
            price: parseFloat(defaultPrice.online_rate) || 0,
            oldPrice: parseFloat(defaultPrice.mrp_rate) || 0,
            weight: defaultPrice.weight || '',
            unit: defaultPrice.unit || '',
            image: product.product_image || " ",
            inStock: parseInt(product.stock) > 0,
            category_id: categoryId,
          };
        

        });
        setProducts(fetchedProducts);
      } else {
        // API returned valid response but no products
        setProducts([]); // clear existing products
      }

      setLoading(false); // ✅ always stop loading
    })
    .catch(error => {
      console.error("Error fetching products:", error);
      setProducts([]);      // ✅ clear products on error too
      setLoading(false);    // ✅ stop loading even on error
    });
  }
}, [categoryId]);



// 1. Extract unique ages
const uniqueAges = Array.from(
  new Set(
    Products
      .map((product) => {
        const ageStr = product.age; 
        const ageNum = parseInt(ageStr); 
        return !isNaN(ageNum) ? ageStr : null; 
      })
      .filter((age) => age !== null) // remove nulls
  )
).sort((a, b) => parseInt(a) - parseInt(b)); // sort by numeric value



const handleAgeFilterChange = (e) => {
  const age = e.target.value;
  const isChecked = e.target.checked;

  setSelectedAges((prevSelected) => {
    const updated = isChecked
      ? [...prevSelected, age]
      : prevSelected.filter((a) => a !== age);

    // Close the offcanvas
    const offcanvasEl = document.getElementById('offcanvasFilter');
    let offcanvasInstance = Offcanvas.getInstance(offcanvasEl);
    if (!offcanvasInstance) {
      offcanvasInstance = new Offcanvas(offcanvasEl);
    }
    offcanvasInstance.hide();

    // Remove backdrop manually after a slight delay 
    setTimeout(() => {
      const backdrop = document.querySelector('.offcanvas-backdrop');
      if (backdrop) {
        backdrop.remove(); 
        document.body.classList.remove('offcanvas-backdrop', 'show', 'modal-open');
        document.body.style.overflow = 'auto'; // reset scroll
      }
    }, 100); 

    return updated;
  });
};

const filteredProducts = selectedAges.length === 0
  ? Products
  : Products.filter((product) => selectedAges.includes(product.age));


const visibleProducts = showAll ? filteredProducts : filteredProducts.slice(0, 8);

const handleFilter = () => {
  const [minPrice, maxPrice] = range;

  const filtered = Products.filter((product) => {
    const productPrice = parseFloat(product.price);
    return productPrice >= minPrice && productPrice <= maxPrice;
  });

  setProducts(filtered);
  setShowAll(true); // Optional: show all filtered items
};

//offcanvas close code 
useEffect(() => {
  const offcanvasEl = document.getElementById('offcanvasFilter');

  const handleHidden = () => {
    const backdrop = document.querySelector('.offcanvas-backdrop');
    if (backdrop) {
      backdrop.remove();
    }
    document.body.classList.remove('offcanvas-backdrop', 'show', 'modal-open');
    document.body.style.overflow = 'auto'; 
  };

  if (offcanvasEl) {
    offcanvasEl.addEventListener('hidden.bs.offcanvas', handleHidden);
  }

  // Cleanup on unmount
  return () => {
    if (offcanvasEl) {
      offcanvasEl.removeEventListener('hidden.bs.offcanvas', handleHidden);
    }
  };
}, []);


  return (
    <>
    {/* offcanvas filter start */}
    
    <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasFilter" aria-labelledby="offcanvasFilterLabel">
        <div class="offcanvas-header bs-canvas-header side-cart-header p-3">
            <div class="d-inline-block main-cart-title" id="offcanvasFilterLabel">Filter</div>
            <button type="button" class="close-btn" data-bs-dismiss="offcanvas" aria-label="Close">
                <i class="uil uil-multiply"></i>
            </button>
        </div>
        <div className="offcanvas-body p-0">
  <div className="filter-items">
    <div className="filtr-cate-title">
      <h4>Price Filter</h4>
    </div>
    <div className="other-item-body scrollstyle_4">
      <div className="brand-list">
        <div className="price-filter"
  style={{
    width: "100%",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    gap: "10px",
    padding: "0 10px"
  }}
>
  <div style={{ flex: 1 }}>
    <p style={{ textAlign: "center", marginBottom: "10px" }}>
      Min: <i className="bi bi-currency-rupee"></i>{range[0]} - 
      Max: <i className="bi bi-currency-rupee"></i>{range[1]}
    </p>
    <Slider
      range
      min={0}
      max={50000}
      step={10}
      defaultValue={[0, 50000]}
      value={range}
      onChange={handleSliderChange}
      trackStyle={[{ backgroundColor: "#f55d2c" }]}
      handleStyle={[
        { backgroundColor: "#f55d2c", border: "none" },
        { backgroundColor: "#f55d2c", border: "none" },
      ]}
    />
  </div>&nbsp;
  <button
    onClick={handleFilter}
    style={{
      height: "40px",
      backgroundColor: "#f55d2c",
      color: "#fff",
      border: "none",
      padding: "0 20px",
      borderRadius: "4px",
      cursor: "pointer",
      whiteSpace: "nowrap",
      marginTop:"25px"
    }}
    data-bs-dismiss="offcanvas" aria-label="Close"
  >
    Go
  </button>
</div>

      </div>
    </div>
  </div>
  <hr />
</div>

    </div>
    {loading ? (
      <div 
        style={{ 
          height: '100vh', 
          display: 'flex', 
          justifyContent: 'center', 
          alignItems: 'center' 
        }}
      >
        <div className="loader"></div>
      </div>
    ) : visibleProducts.length === 0 ? (
      <div 
        style={{ 
          height: '50vh', 
          display: 'flex', 
          justifyContent: 'center', 
          alignItems: 'center' 
        }}
      >
        <h4 style={{marginTop:"150px"}}>No products found</h4>
      </div>
    ) : (
      <>
    {/* offcanvas filter end */}    
    <div class="wrapper">
        <div class="gambo-Breadcrumb">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><Link to="/">Home</Link></li>
                                <li class="breadcrumb-item active" aria-current="page">Products</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        {messages && Object.entries(messages).map(([id, message]) => (
        <div key={id} className="message-popup">
            <FaShoppingCart className="cart-icon-addtocart" />
            <div className="message">{message}</div>
        </div>
        ))}

        <div class="all-product-grid">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="product-top-dt">
                            <div class="product-left-title">
                                {/* <h2>Vegetables & Fruits</h2> */}
                            </div>
                            <a href="#" class="filter-btn" data-bs-toggle="offcanvas" data-bs-target="#offcanvasFilter" 
                            aria-controls="offcanvasFilter">Filters <span style={{fontSize:"14px"}}><i class="bi bi-filter"></i></span></a>
                        </div>
                    </div>
                </div>
                <div class="product-list-view">
                    <div class="row">
                         {visibleProducts.map(product => (
                                <div className="col-lg-3 col-md-6" key={product.id}>
                                    <div className="product-item mb-30">
                                   <Link to={`/productdetails/${product.id}`} className="product-img">
                                    <img src={product.image} alt={product.name} />
                                    </Link>


                                    <div className="product-text-dt">
                                        {/* <p>Available <span>({product.inStock ? 'In Stock' : 'Out of Stock'})</span></p> */}
                                        <h4>{product.name}</h4>
                                        <div className="product-price">
                                        <i className="bi bi-currency-rupee"></i>{product.price} 
                                        <span><i className="bi bi-currency-rupee"></i>{product.oldPrice}</span>
                                        </div>
                                        <div className="qty-cart">
                                        <button
                                            className="add-to-cart-btn hover-btn"
                                             onClick={() => {
                                                const defaultVariant = product.priceOptions[0];

                                                addToCart({
                                                  ...product,
                                                  price: defaultVariant.online_rate,
                                                  oldPrice: defaultVariant.mrp_rate,
                                                  weight: defaultVariant.weight,
                                                  unit: defaultVariant.unit,
                                                  quantity: 1, // 👈 Ensure quantity is passed
                                                });
                                              }}

                                        >
                                            <span>Add to Cart</span>
                                            <i className="bi bi-cart3"></i>
                                        </button>
                                        </div>
                                    </div>
                                    </div>
                                </div>
                                 ))} 
                             {filteredProducts.length > 8 && (
                              <div className="col-md-12">
                                <div className="more-product-btn text-center">
                                  <button className="show-more-btn hover-btn" onClick={() => setShowAll(!showAll)}>
                                    {showAll ? 'Show Less' : 'Show More'}
                                  </button>
                                </div>
                              </div>
                          )}   
                    </div>
                </div>
            </div>
        </div>
    </div>
      </>
       )}
    <Footer />
    </>
  )
}

export default ShopbyCategory