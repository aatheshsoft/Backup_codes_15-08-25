import React,{useEffect, useState} from 'react'
import Footer from '../Components/Footer'
import { Link } from 'react-router-dom';
import axios from 'axios';



const Privacy = () => {
const [privacyData, setPrivacyData] = useState();
const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
const[loading,setLoading] = useState(true);

 useEffect(() => {
	const fetchPrivacydata = async () => {
		
		try{
		const response = await axios.post(`${API_BASE_URL}content.php`)
		const {body} = response.data;
		setPrivacyData(body.privacy)
		}catch(error){
			alert(error)
			console.error(error)
		}finally{
			setLoading(false);
		}
	}
fetchPrivacydata()
},[])

useEffect(() => {
    window.scrollTo(0, 0); 
}, []);

return (
  <>
    {loading ? (
      <div style={{ height: '100vh', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
        <div className="loader"></div>
      </div>
    ) : (
      <div className="wrapper">
        <div className="gambo-Breadcrumb">
          <div className="container">
            <div className="row">
              <div className="col-md-12">
                <nav aria-label="breadcrumb">
                  <ol className="breadcrumb">
                    <li className="breadcrumb-item"><Link to="/">Home</Link></li>
                    <li className="breadcrumb-item active" aria-current="page">Privacy Policy</li>
                  </ol>
                </nav>
              </div>
            </div>
          </div>
        </div>
        <div className="all-product-grid">
          <div className="container">
            <div className="row">
              <div className="col-lg-12 col-md-12">
                <div className="job-main-dt">
                  <h2>Privacy Policy</h2>
                </div>
                <div className="job-des-dt142 policy-des-dt">
                  <p dangerouslySetInnerHTML={{ __html: privacyData?.value }} />
                  {/* <h2>Privacy Policy</h2>

    <p><strong>[Your Brand Name]</strong> is committed to protecting your privacy. This Privacy Policy explains how we collect, use, and safeguard your personal information when you visit our website or make a purchase from us.</p>

    <h3>1. Information We Collect</h3>
    <p>We may collect the following types of information:</p>
    <ul>
      <li>Personal Information (name, email address, phone number, shipping address)</li>
      <li>Payment Information (billing details, transaction data)</li>
      <li>Technical Information (IP address, browser type, device details)</li>
      <li>Usage Data (pages visited, time spent on site, clicks)</li>
    </ul>

    <h3>2. How We Use Your Information</h3>
    <p>We use the collected information to:</p>
    <ul>
      <li>Process and deliver your orders</li>
      <li>Respond to your inquiries and provide customer support</li>
      <li>Improve our website and services</li>
      <li>Send promotional emails (only if you opt-in)</li>
    </ul>

    <h3>3. Data Security</h3>
    <p>We implement appropriate technical and organizational measures to protect your personal information from unauthorized access, misuse, or disclosure.</p>

    <h3>4. Sharing Your Information</h3>
    <p>We do <strong>not</strong> sell, trade, or rent your personal information to third parties. We may share information with trusted third parties only to fulfill services (like payment gateways, courier partners) and only under strict confidentiality agreements.</p>

    <h3>5. Cookies</h3>
    <p>We use cookies to enhance your browsing experience and analyze site traffic. You can choose to disable cookies through your browser settings, though some features may not work properly as a result.</p>

    <h3>6. Your Rights</h3>
    <p>You have the right to access, correct, or delete your personal information stored with us. Please contact us at <a href="mailto:support@yourbrand.com">support@yourbrand.com</a> for any such requests.</p>

    <h3>7. Changes to This Policy</h3>
    <p>We may update this Privacy Policy from time to time. Any changes will be posted on this page with a revised "Last Updated" date.</p>

    <p><strong>Last Updated:</strong> July 2, 2025</p>

    <p>If you have any questions about this policy, please contact us at <a href="mailto:support@yourbrand.com">support@yourbrand.com</a>.</p> */}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    )}
    <Footer />
  </>
);

}

export default Privacy