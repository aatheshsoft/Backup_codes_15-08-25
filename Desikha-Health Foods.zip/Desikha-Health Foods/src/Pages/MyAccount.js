import { Link } from 'react-router-dom';
import Footer from '../Components/Footer';
import React, { useEffect, useState } from 'react';



const MyAccount = () => {
//window  scroll to top when page rendering
    
const [addressList, setAddressList] = useState([
    {
      id: 1,
      type: 'Home',
      name:'Test',
      address: 'Door No. 8 ,Ramasamy nagar',
      city: 'Sivakasi',
      pincode: '123456',
      state: 'Tamilnadu',
      landmark: 'Bus stop',
      phonenumber: '1234567890'
      
    },
  ]);
  
  const [formData, setFormData] = useState({
    type: 'Home',
      name:'',
      address: '',
      city: '',
      pincode: '',
      state: '',
      landmark: '',
      phonenumber: ''
  });
  const [isEdit, setIsEdit] = useState(false);
  const [editId, setEditId] = useState(null);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const openAddModal = () => {
    setIsEdit(false);
    setEditId(null);
    setFormData({
      type: 'Home',
      name:'',
      address: '',
      city: '',
      pincode: '',
      state: '',
      landmark: '',
      phonenumber: ''
    });
  };

  const openEditModal = (address) => {
    setIsEdit(true);
    setEditId(address.id);
    setFormData({
      type: address.type,
      name:address.name || '',
      address: address.address || '',
      city:address.city || '',
      pincode: address.pincode || '',
      state: address.state || '',
      landmark:address.landmark || '',
      phonenumber: address.phonenumber || '',
    });
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  

  const handleSubmit = (e) => {
    e.preventDefault();
    const fullAddress = `${formData.address}`;

    if (isEdit && editId !== null) {
      setAddressList(prev =>
        prev.map(addr =>
          addr.id === editId ? { ...addr, ...formData, address: fullAddress } : addr
        )
      );
    } else {
      const newAddress = {
        id: Date.now(),
        ...formData,
        address: fullAddress,
      };
      setAddressList(prev => [...prev, newAddress]);
    }

    // Close modal manually
    document.querySelector('.btn-close')?.click();
  };

useEffect(() => {
    window.scrollTo(0, 0); 
}, []);




  return (
    <>
    <div id="address_model" className="modal fade" tabIndex="-1">
        <div className="modal-dialog category-area">
          <div className="category-area-inner">
            <div className="modal-header">
              <button type="button" className="close btn-close" data-bs-dismiss="modal" aria-label="Close">
                <i className="uil uil-multiply"></i>
              </button>
            </div>
            <div className="category-model-content modal-content">
              <div className="cate-header">
                <h4 className="mb-0">{isEdit ? 'Edit Address' : 'Add New Address'}</h4>
              </div>
              <div className="add-address-form">
                <form onSubmit={handleSubmit}>
                  <div className="form-group">
                    <div className="product-radio">
                      <ul className="product-now">
                        {['Home', 'Office', 'Other'].map((label, idx) => (
                          <li key={idx}>
                            <input
                              type="radio"
                              id={`ad${idx}`}
                              name="type"
                              value={label}
                              checked={formData.type === label}
                              onChange={handleInputChange}
                            />
                            <label htmlFor={`ad${idx}`}>{label}</label>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  <div className="address-fieldset">
                    <div className="row">
                        <div className="col-lg-12">
                        <div className="form-group mt-4">
                          <label>Name*</label>
                          <input
                            name="name"
                            type="text"
                            className="form-control"
                            value={formData.name}
                            onChange={handleInputChange}
                            required
                          />
                        </div>
                      </div>
                      <div className="col-lg-12">
                        <div className="form-group mt-4">
                          <label>Address*</label>
                          <input
                            name="address"
                            type="text"
                            className="form-control"
                            value={formData.address}
                            onChange={handleInputChange}
                            required
                          />
                        </div>
                      </div>
                      <div className="col-lg-12">
                        <div className="form-group mt-4">
                          <label>City*</label>
                          <input
                            name="city"
                            type="text"
                            className="form-control"
                            value={formData.city}
                            onChange={handleInputChange}
                          />
                        </div>
                      </div>
                      <div className="col-lg-6">
                        <div className="form-group mt-4">
                          <label>Pincode*</label>
                          <input
                            name="pincode"
                            type="text"
                            className="form-control"
                            value={formData.pincode}
                            onChange={handleInputChange}
                            required
                          />
                        </div>
                      </div>
                       <div className="col-lg-6">
                        <div className="form-group mt-4">
                          <label>State*</label>
                          <input
                            name="state"
                            type="text"
                            className="form-control"
                            value={formData.state}
                            onChange={handleInputChange}
                            required
                          />
                        </div>
                      </div>
                      <div className="col-lg-6">
                        <div className="form-group mt-4">
                          <label>Landmark*</label>
                          <input
                            name="landmark"
                            type="text"
                            className="form-control"
                            value={formData.landmark}
                            onChange={handleInputChange}
                            required
                          />
                        </div>
                      </div>
                      <div className="col-lg-6">
                        <div className="form-group mt-4">
                          <label>Phone Number*</label>
                          <input
                            name="phonenumber"
                            type="text"
                            className="form-control"
                            value={formData.phonenumber}
                            onChange={handleInputChange}
                            required
                          />
                        </div>
                      </div>
                      <div className="col-lg-12">
                        <div className="form-group mt-4">
                          <button type="submit" className="save-btn14 w-100 hover-btn"> 
                            Save
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    <div class="wrapper">
    <div class="gambo-Breadcrumb">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><Link to = "/">Home</Link></li>
                            <li class="breadcrumb-item active" aria-current="page">User Dashboard</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <div class="dashboard-group">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="user-dt">
                        <div class="user-img">
                            <img src="images/img-icon.jpg" alt="" />
                            {/* <div class="img-add">													
                                <input type="file" id="file" />
                                <label for="file"><i class="uil uil-camera-plus"></i></label>
                            </div> */}
                        </div>
                        <h4>Aathesh soft</h4>
                    </div>
                </div>
            </div>
        </div>
    </div>	
    <div class="">
        <div class="container">
            <div class="row">
                
                <div class="col-xl-12 col-lg-12 col-md-12">
                    <div class="dashboard-right">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="main-title-tab">
                                    <h4><i class="uil uil-location-point"></i>My Address</h4>
                                </div>
                            </div>
                            <div class="col-lg-12 col-md-12">
                                <div class="pdpt-bg">
                                    {/* <div class="pdpt-title">
                                        <h4>My Address</h4>
                                    </div> */}
                                    <div class="address-body">
                                        <a href="#" class="add-address hover-btn" data-bs-toggle="modal" data-bs-target="#address_model"  onClick={openAddModal}>Add New Address</a>
                                        {addressList.map((addr) => (
                                        <div class="address-item" key={addr.id}>
                                            <div class="address-icon1">
                                                <i class="uil uil-map-marker"></i>
                                            </div>
                                            <div class="address-dt-all">
                                                 <h4>{addr.type}</h4>
                                                <p>{addr.name},</p>
                                                <p>{addr.address},</p>
                                                <p>{addr.city}</p>
                                                 <p>{addr.pincode}</p>
                                                 <p>{addr.state}</p>
                                                <p>{addr.phonenumber}</p>

                                                <ul class="action-btns">
                                                    <li>
                                                        <a href="#" class="action-btn ">
                                                            <i class="uil uil-edit" 
                                                                data-bs-toggle="modal" 
                                                                data-bs-target="#address_model" 
                                                                onClick={(e) => {
                                                                    e.preventDefault();
                                                                    openEditModal(addr);
                                                                }}
                                                            >
                                                            </i>
                                                        </a>
                                                    </li>

                                                    <li>
                                                        <a href="#" class="action-btn">
                                                            <i class="bi bi-trash3" 
                                                               onClick={(e) => {
                                                               e.preventDefault();
                                                                setAddressList(prev => prev.filter(a => a.id !== addr.id));
                                                            }}>
                                                            </i>
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                          ))}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>	
        </div>	
    </div>	
</div>
<Footer />
</>
  )
}

export default MyAccount