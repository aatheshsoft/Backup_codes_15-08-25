import React,{useEffect, useState} from 'react'
import { Link } from 'react-router-dom';
import { useCart } from '../Context/CartContext';
import { useNavigate, useLocation  } from 'react-router-dom';
import axios from 'axios';



const Checkout = () => {
 const { removeFromCart, cartItems, clearCart } = useCart();
  const totalPrice = cartItems.reduce((acc, item) => acc + item.price * item.quantity, 0);
  const grandTotal = totalPrice;
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
const UserID = JSON.parse(localStorage.getItem("user_id"));
  const location = useLocation();

  const [formData, setFormData] = useState({
   
    name: '',
    address: '',
    city: '',
    state: '',
    pincode: '',
    landmark: '',
    phonenumber: '',
  });

  const [addressList, setAddressList] = useState([]);
  const [isEdit, setIsEdit] = useState(false);
  const [editId, setEditId] = useState(null);


useEffect(() => {
  if (!UserID) {
    navigate('/signin', {
      state: { from: location }, // Pass current page info to login
      replace: true,
    });
    return;
  }

  fetchAddressList(); // ✅ Run only if user is logged in
}, []);

  const fetchAddressList = async () => {
  try {
    const res = await axios.post(`${API_BASE_URL}addresslist.php`, {
      user_id: UserID
    });
    
    console.log("API Response:", res.data.body); // 

    // Fix: Always fallback to empty array
    setAddressList(res.data.body || []);
  } catch (error) {
    console.error("Failed to load addresses", error);
    setAddressList([]); // prevent map error
  }
};
console.log("API addressList:",addressList);

  const openAddModal = () => {
    setIsEdit(false);
    setEditId(null);
    setFormData({
     
      name: '',
	  email: '',
      address: '',
      city: '',
      pincode: '',
      state: '',
      landmark: '',
      phonenumber: '',
    });
  };

  const openEditModal = (address) => {
    setIsEdit(true);
    setEditId(address.address_id);
    setFormData({
     
      name: address.name || '',
	  email: address.email || '',
      address: address.address || '',
      city: address.city || '',
      pincode: address.pincode || '',
      state: address.state || '',
      landmark: address.landmark || '',
      phonenumber: address.phonenumber || '',
    });
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleAddressSubmit = async (e) => {
    e.preventDefault();

    const payload = {
      user_id: UserID,
      ...formData
    };

    try {
      setLoading(true);
      if (isEdit) {
        // Update existing address
        await axios.post(`${API_BASE_URL}addresslistupdate.php`, { address_id: editId, ...payload });
        alert('Address updated successfully');
		window.location.reload();
      } else {
        // Add new address
        await axios.post(`${API_BASE_URL}addresslistadd.php`, payload);
        alert('Address added successfully');
		window.location.reload();
      }
      fetchAddressList(); // Refresh list
    } catch (error) {
      console.error('Error saving address:', error);
      alert('Failed to save address.');
    } finally {
      setLoading(false);
    }
  };

 const deleteAddress = async (id) => {
  const confirmDelete = window.confirm("Are you sure you want to delete this address?");
  if (!confirmDelete) return;

  try {
    await axios.post(`${API_BASE_URL}addresslistdelete.php`, {
      address_id: id,
      user_id: UserID // ✅ Include user_id if required by API
    });

    // ✅ Remove the address from the list
    setAddressList(prev => prev.filter(addr => addr.address_id !== id));

    alert("Address deleted successfully.");
	window.location.reload();
  } catch (error) {
    console.error('Failed to delete address:', error);
    alert("Failed to delete address. Please try again.");
  }
};


  const handleOrderSubmit = async (e) => {
  e.preventDefault();

  const selectedAddress = addressList.find(
    (a) => a.address_id === formData.selectedAddressId
  );
  if (!selectedAddress) return alert("Please select an address");

  const orderData = {
    user_id: UserID, // 👈 Include user_id if your order API expects it
    name: selectedAddress.name,
    phonenumber: selectedAddress.phonenumber,
    email: selectedAddress.email,
    address: selectedAddress.address,
    city: selectedAddress.city,
    state: selectedAddress.state,
    pincode: selectedAddress.pincode,
    subtotal: totalPrice,
    discount_percentage: 0.0,
    coupon_discount: 0.0,
    total: totalPrice,
    coupen_code: '',
    product: cartItems.map((item) => ({
      product_id: item.product_id || item.id,
      category_id: item.category_id || '',
      product_name: item.name || item.product_name,
      unit_price: item.price,
      weight:item.weight,
      quantity: item.quantity,
      final_price: item.price * item.quantity,
      discount: 0.0,
    })),
  };

  try {
    setLoading(true);
    const response = await axios.post(`${API_BASE_URL}order.php`, orderData);

    if (response.data?.head?.code === 200) {
      alert(" Order placed successfully!");
      clearCart();
      navigate("/orderplaced");
    } else {
      alert(" Order failed. Please try again.");
      console.error("Order failed response:", response.data);
    }
  } catch (error) {
    console.error("Failed to place order:", error);
    alert("Something went wrong. Please try again later.");
  } finally {
    setLoading(false);
  }
};




  return (
	<>
	<div id="address_model" className="modal fade" tabIndex="-1">
        <div className="modal-dialog category-area">
          <div className="category-area-inner">
            <div className="modal-header">
              <button type="button" className="close btn-close" data-bs-dismiss="modal" aria-label="Close">
                <i className="uil uil-multiply"></i>
              </button>
            </div>
            <div className="category-model-content modal-content">
              <div className="cate-header">
                <h4 className="mb-0">{isEdit ? 'Edit Address' : 'Add New Address'}</h4>
              </div>
              <div className="add-address-form">
                <form onSubmit={handleAddressSubmit}>
                  <div className="form-group">
                    <div className="product-radio">
                      <ul className="product-now">
                        {['Home', 'Office', 'Other'].map((label, idx) => (
                          <li key={idx}>
                            <input
                              type="radio"
                              id={`ad${idx}`}
                              name="type"
                              value={label}
                              checked={formData.type === label}
                              onChange={handleInputChange}
                            />
                            <label htmlFor={`ad${idx}`}>{label}</label>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  <div className="address-fieldset">
                    <div className="row">
                        <div className="col-lg-12">
                        <div className="form-group mt-4">
                          <label>Name*</label>
                          <input
                            name="name"
                            type="text"
                            className="form-control"
                            value={formData.name}
                            onChange={handleInputChange}
                            required
                          />
                        </div>
                      </div>
					  <div className="col-lg-12">
                        <div className="form-group mt-4">
                          <label>Email*</label>
                          <input
                            name="email"
                            type="text"
                            className="form-control"
                            value={formData.email}
                            onChange={handleInputChange}
                            required
                          />
                        </div>
                      </div>
                      <div className="col-lg-12">
                        <div className="form-group mt-4">
                          <label>Address*</label>
                          <input
                            name="address"
                            type="text"
                            className="form-control"
                            value={formData.address}
                            onChange={handleInputChange}
                            required
                          />
                        </div>
                      </div>
                      <div className="col-lg-12">
                        <div className="form-group mt-4">
                          <label>City*</label>
                          <input
                            name="city"
                            type="text"
                            className="form-control"
                            value={formData.city}
                            onChange={handleInputChange}
                          />
                        </div>
                      </div>
                      <div className="col-lg-6">
                        <div className="form-group mt-4">
                          <label>Pincode*</label>
                          <input
                            name="pincode"
                            type="text"
                            className="form-control"
                            value={formData.pincode}
                            onChange={handleInputChange}
                            required
                          />
                        </div>
                      </div>
                       <div className="col-lg-6">
                        <div className="form-group mt-4">
                          <label>State*</label>
                          <input
                            name="state"
                            type="text"
                            className="form-control"
                            value={formData.state}
                            onChange={handleInputChange}
                            required
                          />
                        </div>
                      </div>
                      <div className="col-lg-6">
                        <div className="form-group mt-4">
                          <label>Landmark*</label>
                          <input
                            name="landmark"
                            type="text"
                            className="form-control"
                            value={formData.landmark}
                            onChange={handleInputChange}
                            required
                          />
                        </div>
                      </div>
                      <div className="col-lg-6">
                        <div className="form-group mt-4">
                          <label>Phone Number*</label>
                          <input
                            name="phonenumber"
                            type="text"
                            className="form-control"
                            value={formData.phonenumber}
                            onChange={handleInputChange}
                            required
                          />
                        </div>
                      </div>
                      <div className="col-lg-12">
                        <div className="form-group mt-4">
                          <button type="submit" className="save-btn14 w-100 hover-btn"> 
                            Save
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    <div class="wrapper">
		<div class="gambo-Breadcrumb">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><Link to ='/'>Home</Link></li>
								<li class="breadcrumb-item active" aria-current="page">Checkout</li>
							</ol>
						</nav>
					</div>
				</div>
			</div>
		</div>
		<div class="all-product-grid">
			<div class="container">
				<div class="row">
          <div class="col-lg-8 col-md-6">
						<div class="pdpt-bg mt-0">
							<div class="pdpt-title">
								<h4>Order Summary</h4>
							</div>
							<div class="right-cart-dt-body">
								   {cartItems.map((item) => (
										<div className="cart-item border_radius" key={item.id}>
											<div className="cart-product-img">
											<img src={item.image} alt={item.name} />
											</div>
											<div className="cart-text">
											<h4>{item.name}</h4>
                      <div>
                        <p>Product Code : {item.product_code}</p>
                        </div>
											<div className="cart-item-price">
												<i className="bi bi-currency-rupee"></i>{item.price}
												{item.oldPrice && (
												<span>
													<i className="bi bi-currency-rupee"></i>{item.oldPrice}
												</span>
												)}
											</div>
											<button type="button" className="cart-close-btn" onClick={() => removeFromCart(item.id)}>
												<i className="uil uil-multiply"></i>
											</button>
											</div>
										</div>
										))}

							</div>
							{/* <div className="total-checkout-group">
								<div className="cart-total-dil">
									<h4>Gambo Super Market</h4>
									<span><i className="bi bi-currency-rupee"></i>{totalPrice}</span>
								</div>

								<div className="cart-total-dil pt-3">
									<h4>Delivery Charges</h4>
									<span><i className="bi bi-currency-rupee"></i>{deliveryCharge}</span>
								</div>

							</div>
							<div className="cart-total-dil saving-total">
							<h4>Total Saving</h4>
							<span><i className="bi bi-currency-rupee"></i>{savings}</span>
							</div>	 */}
						

							
						</div>
						<div className="main-total-cart p-4">
						<h2>Total</h2>
						<span><i className="bi bi-currency-rupee"></i>{grandTotal}</span>
						</div>
            <div class="col-lg-12 col-md-12">
														<div class="form-group mt-30">
															<div class="address-btns">
																{/* <button class="save-btn14 hover-btn">Save</button> */}
												<button
                          type="submit"
                          disabled={loading} // ✅ disables the button
                          className="collapsed ms-auto next-btn16 hover-btn"
                          onClick={handleOrderSubmit}
                          style={{ cursor: loading ? 'wait' : 'pointer' }}
                        >
                          {loading ? 'Submitting...' : 'Submit Order'}
                        </button>

																{/* <button type="submit" className="collapsed ms-auto next-btn16 hover-btn" onClick={() => navigate('/orderhistory')}>
																	Order Now
																</button> */}
															</div>
														</div>
													</div>
					</div>

					<div class="col-lg-4 col-md-6">
						<div id="checkout_wizard" class="checkout accordion left-chck145">
							
							<div class="checkout-step">
								<div class="checkout-card" >
									<div className="col-lg-6 col-md-7  ">
											<h4 className="checkout-step-title">
												<h5 className="wizard-btn collapsed">Delivery Address</h5>
											</h4>
											</div> &nbsp;&nbsp;&nbsp;
                       
										
										</div>
								
								<div>
									<div class="checkout-step-body">
										<div class="checout-address-step">
											<div class="row">
                        	<div className="col-lg-12 col-md-12 d-flex justify-content-end">
											<nobr>
                        <a
												href="#"
												className="add-address hover-btn"
												data-bs-toggle="modal"
												data-bs-target="#address_model"
												onClick={openAddModal}
											>
												Add New Address
											</a>
                      </nobr>
											</div>
                      
												<div class="col-lg-12">												
												
													<div class="col-lg-12 col-md-12">
														<div class="pdpt-bg">
															{/* <div class="pdpt-title">
																<h4>My Address</h4>
															</div> */}
															<div className="address-body">
																{addressList.map((addr) => (
																	<div className="address-item" key={addr.address_id}>
																	{/* Replace icon with checkbox */}
																	<div >
																		<input
																			type="checkbox"
																			checked={formData.selectedAddressId === addr.address_id}
																			onChange={(e) => {
																				if (e.target.checked) {
																				setFormData({
																					...formData,
																					selectedAddressId: addr.address_id,
																					name: addr.name,
																					address: addr.address,
																					city: addr.city,
																					pincode: addr.pincode,
																					state: addr.state,
																					phonenumber: addr.phonenumber,
																				});
																				} else {
																				setFormData({ ...formData, selectedAddressId: null });
																				}
																			}}
																			style={{
																				width: '18px',
																				height: '18px',
																				marginRight: '10px',
																				cursor: 'pointer',
																				accentColor: '#28a745' // Optional: green style for checkbox
																			}}
																			/>

																	</div>

																	<div className="address-dt-all">
																		{/* <h4>{addr.type}</h4> */}
																		<p>{addr.name},</p>
																		<p>{addr.email},</p>
																		<p>{addr.address},</p>
																		<p>{addr.city}</p>
																		<p>{addr.pincode}</p>
																		<p>{addr.state}</p>
																		<p>{addr.phonenumber}</p>

																		<ul className="action-btns">
																		<li>
																			<a
																			href="#"
																			className="action-btn"
																			onClick={(e) => {
																				e.preventDefault();
																				openEditModal(addr);
																			}}
																			data-bs-toggle="modal"
																			data-bs-target="#address_model"
																			>
																			<i className="uil uil-edit"></i>
																			</a>
																		</li>
																		<li>
																			<a
																				href="#"
																				className="action-btn"
																				onClick={(e) => {
																				e.preventDefault();
																				deleteAddress(addr.address_id); // ✅ Use correct function
																				}}
																			>
																				<i className="bi bi-trash3"></i>
																			</a>
																			</li>

																		</ul>
																	</div>
																	</div>
																))}
															</div>
														</div>
													</div>
													
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					
				</div>
			</div>
		</div>	
	</div>
	</>
  )
}

export default Checkout;