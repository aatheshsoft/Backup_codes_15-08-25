import React, { useRef,useEffect, useState } from 'react'
import OwlCarousel from "react-owl-carousel";
import "owl.carousel/dist/assets/owl.carousel.css";
import "owl.carousel/dist/assets/owl.theme.default.css";
import Footer from '../Components/Footer';
import { Link, Links,useParams } from 'react-router-dom';
import { useCart } from '../Context/CartContext';
import axios from 'axios';
import InnerImageZoom from "react-inner-image-zoom";
import "react-inner-image-zoom/lib/InnerImageZoom/styles.min.css";
import { FaShoppingCart } from 'react-icons/fa';
import pimage from '../Assets/45357.jpg';



const ProductDetails = () => {
  const sync1Ref = useRef();
  const sync2Ref = useRef();
  const { id } = useParams();
  const [activeIndex, setActiveIndex] = useState(0); // for large image sync
  const { addToCart, updateQuantity, removeFromCart,cartItems,messages } = useCart();
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
  const [products, setProducts] =  useState([])
  const [relatedProducts, setRelatedProducts] = useState([]);
  const [counts, setCounts] = useState({});
  const [quantity, setQuantity] = useState ({});
  const [selectedPrices, setSelectedPrices] = useState({});

/* featured product carousel  settings */
  useEffect(() => {
      // Initialize Owl Carousel after component mounts
      window.$('.owl-carousel').owlCarousel({
        loop: true,
        margin: 10,
        nav: true,
        autoplay: true,
        autoplayTimeout: 5000,
        responsive: {
          0: {
            items: 1
          },
          600: {
            items: 2
          },
          1000: {
            items: 5
          }
        }
      });
    }, []);

    
useEffect(() => {
		window.scrollTo(0, 0); 
	}, []);




	useEffect(() => {
    axios.post(`${API_BASE_URL}product_details.php`, {
      product_id: id,
    })
      .then(res => {
        if (res.data.head.code === 200 && res.data.body.product_detail) {
          const productData = res.data.body.product_detail.map(item => ({
            ...item,
            id: item.product_id,
            name: item.product_name,
          }));

          setProducts(productData);

          // Set default selected prices (first item in price array)
          const defaultPrices = {};
          productData.forEach(prod => {
            defaultPrices[prod.product_id] = prod.price[0];
          });
          setSelectedPrices(defaultPrices);

          const relatedData = res.data.body.related_products.map(item => ({
            ...item,
            id: item.product_id,
            name: item.product_name,
          }));
          setRelatedProducts(relatedData);
        }
      })
      .catch(err => {
        console.error("Error fetching product details:", err);
      });
  }, [id]);

const handleWeightChange = (productId, priceObj) => {
  setSelectedPrices(prev => ({
    ...prev,
    [productId]: priceObj
  }));

  const key = `${productId}_${priceObj.weight}`;
  setTempQuantities(prev => ({
    ...prev,
    [key]: prev[key] || 1 // default to 1 if not already set
  }));
};


 const [tempQuantities, setTempQuantities] = useState({});

const getKey = (productId) => {
  const selectedWeight = selectedPrices[productId]?.weight;
  return selectedWeight ? `${productId}_${selectedWeight}` : productId;
};


 
const isInCart = (key) =>
  cartItems.some(item => `${item.id}_${item.weight}` === key);


const getCartQuantity = (key) => {
  const item = cartItems.find(item => `${item.id}_${item.weight}` === key);
  return item ? item.quantity : null;
};


 const handleQuantityChange = (productId, amount) => {
  const key = getKey(productId);
  const weight = selectedPrices[productId]?.weight;
  if (!weight) return;
  if (isInCart(key)) {
    const currentQty = getCartQuantity(key);
    const newQty = Math.max(1, currentQty + amount);
    updateQuantity(productId, weight, amount); // Update via context
  } else {
    setTempQuantities(prev => {
      const currentQty = prev[key] || 1;
      const newQty = Math.max(1, currentQty + amount);
      return { ...prev, [key]: newQty };
    });
  }
};


 const getQuantityToDisplay = (productId) => {
  const key = getKey(productId);
  return getCartQuantity(key) ?? tempQuantities[key] ?? 1;
};


const images = products[0]?.image || [];

  // Optional reset on new product id only (not on every product render)
  useEffect(() => {
    setActiveIndex(0);
    sync1Ref.current?.to(0, 0);
  }, [id]);

	  

// const handleIncrement = (productId) => {
//   setCounts((prev) => ({
//     ...prev,
//     [productId]: prev[productId] + 1,
//   }));
//   updateQuantity(productId, 1);
// console.log("qty : " , updateQuantity)
// };

 // const handleDecrement = (productId) => {
//   setCounts((prev) => {
//     const updated = Math.max(1, prev[productId] - 1);
//     return { ...prev, [productId]: updated };
//   });
//   updateQuantity(productId, -1);   
  
// 	console.log("qty : ", updateQuantity)

// };





// const staticProducts = [
//   {
//     id: 1,
//     name: "Health Mix Classic",
//     product_code: "HMX001",
//     stock: 25,
//     online_rate: 180,
//     mrp_rate: 250,
// 	image:pimage,
// 	price:350,
// 	oldPrice:550,
//   },
 
// ];





  return (
	<>
    <div class="wrapper">
		<div class="gambo-Breadcrumb">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><Link to ="/">Home</Link></li>
								<li class="breadcrumb-item"><Link >Productdetails</Link></li>
								{/* <li class="breadcrumb-item active" aria-current="page">Product Title</li> */}
							</ol>
						</nav>
					</div>
				</div>
			</div>
		</div>
			<>
			{messages && Object.entries(messages).map(([id, message]) => (
			<div key={id} className="message-popup">
				<FaShoppingCart className="cart-icon-addtocart"/>
				<div className="message">{message}</div>
			</div>
			))}
		</>
		<div class="all-product-grid">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="product-dt-view">
							<div class="row">
								 <div className="col-lg-5 col-md-4">
									<div className="owl-container">
										{images.length > 0 && (
										<>
											{/* Large Image Zoom (Only One at a Time) */}
											<div className="item">
											<InnerImageZoom
												src={images[activeIndex]}
												zoomSrc={images[activeIndex]}
												zoomType="hover"
												zoomScale={2.5}
												zoomPreload={true}
												hideHint={false}
												alt={`Product Zoom ${activeIndex}`}
												width="100%"
											/>
											</div>

											<br />

											{/* Thumbnail Carousel */}
											<OwlCarousel
											ref={sync2Ref}
											items={4}
											loop={false}
											margin={10}
											nav={false}
											dots={false}
											autoplay={false}
											smartSpeed={1000}
											className="owl-theme"
											>
											{images.map((img, index) => (
												<div
												className="item"
												key={`thumb-${index}`}
												onClick={() => {
													setActiveIndex(index);
												}}
												>
												<img
													src={img}
													alt={`Thumb ${index}`}
													style={{
													// border: activeIndex === index ? '2px solid #007bff' : '1px solid #ccc',
													padding: '2px',
													// width: '100px',
													height: '80px',
													objectFit: 'cover',
													cursor: 'pointer',
													}}
												/>
												</div>
											))}
											</OwlCarousel>
										</>
										)}
									</div>
									</div>
								<div class="col-lg-7 col-md-8">  
                                    
									<div class="product-dt-right">

										
										<div className="product-radio">
												{products.length === 0 ? (
													
													<div> </div>
												) : (
													products.map((item, index) => (
														 
													<div key={item.id}>
														<h2>{item.product_name}</h2>

														<div className="no-stock">
														<p className="pd-no">
															Product No.<span>{item.product_code}</span>
														</p>
														<p className="stock-qty">
														<span style={{ color: item.stock ? 'green' : 'red' }}>
														{item.stock ? '(In Stock)' : '(Out of Stock)'}
														</span>
														</p>
														</div>
													<div className="product-radio">
														<ul className="product-now">
															{item.price.map((priceObj, idx) => {
															const labelId = `product-${item.id}-price-${idx}`;
															const isChecked = selectedPrices[item.id]?.weight === priceObj.weight;
															return (
																<li key={idx}>
																<input
																	type="radio"
																	id={labelId}
																	name={`product-${item.id}-weight`}
																	checked={isChecked}
																	onChange={() => handleWeightChange(item.id, priceObj)}
																/>
																<label htmlFor={labelId}>
																<nobr> {parseFloat(priceObj.weight)} - {priceObj.unit}</nobr>
																</label>
																</li>
															);
															})}
														</ul>
														</div>

														<div className="product-group-dt">
														<ul>
															<li>
															<div className="main-price color-discount">
																Price
																<span style={{ color: "darkgreen" }}>
																<i className="bi bi-currency-rupee"></i>
																{selectedPrices[item.id]?.online_rate || item.price[0].online_rate}
																</span>
															</div>
															</li> -
															<li>
															<div className="main-price mrp-price">
																<span style={{ color: "red" }}>
																<i className="bi bi-currency-rupee"></i>
																{selectedPrices[item.id]?.mrp_rate || item.price[0].mrp_rate}
																</span>
															</div>
															</li>
														</ul>


														<ul className="gty-wish-share">
																<li>
																<div className="qty-product">
																	<div className="quantity buttons_added">
																	<input
																		type="button"
																		value="-"
																		className="minus minus-btn"
																		onClick={() => handleQuantityChange(item.id, -1)}
																	/>
																	<input
																		type="number"
																		value={getQuantityToDisplay(item.id)}
																		readOnly
																		className="input-text qty text"
																	/>
																	<input
																		type="button"
																		value="+"
																		className="plus plus-btn"
																		onClick={() => handleQuantityChange(item.id, 1)}
																	/>
																	</div>
																</div>
																</li>
															</ul>

														<ul className="ordr-crt-share">
															<li>
															<button className="add-cart-btn hover-btn" 
																onClick={() => {
																 const finalQty = getQuantityToDisplay(item.id);

																	const selectedVariant = selectedPrices[item.id] || item.price[0];

																	addToCart({
																		...item,
																		price: selectedVariant.online_rate,
																		oldPrice: selectedVariant.mrp_rate,
																		quantity: finalQty,
																		image: images[0],
																		weight: selectedVariant.weight,
																		unit: selectedVariant.unit,
																	});

																// Clear temp quantity
																const key = getKey(item.id);
																setTempQuantities(prev => {
																	const updated = { ...prev };
																	delete updated[key];
																	return updated;
																});
																}}
																>
																<i className="bi bi-cart3"></i>Add to Cart
															</button>
															</li>
														</ul>
														</div>
													</div>
													))
												)}
												
											</div>

										{/* <div class="pdp-details">
											<ul>
												<li>
													<div class="pdp-group-dt">
														<div class="pdp-icon"><i class="uil uil-usd-circle"></i></div>
														<div class="pdp-text-dt">
															<span>Lowest Price Guaranteed</span>
															<p>Get difference refunded if you find it cheaper anywhere else.</p>
														</div>
													</div>
												</li>
												<li>
													<div class="pdp-group-dt">
														<div class="pdp-icon"><i class="uil uil-cloud-redo"></i></div>
														<div class="pdp-text-dt">
															<span>Easy Returns & Refunds</span>
															<p>Return products at doorstep and get refund in seconds.</p>
														</div>
													</div>
												</li>
											</ul>
										</div> */}
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="row">
					
					<div class="col-lg-12 col-md-12">
						<div class="pdpt-bg">
							<div class="pdpt-title">
								<h4>Product Details</h4>
							</div>
							<div class="pdpt-body scrollstyle_4">
								<div class="pdct-dts-1">
									<div class="pdct-dt-step">
										<h4>Description</h4>
										{products.length === 0 ? (
													
													<div></div>
												) : (
													products.map((item, index) => (
														<p>{item.full_description}</p>
													)))}
													
										</div>
									
								</div>			
							</div>					
						</div>
					</div>
				</div>
			</div>
		</div>
{/* 		<!-- Featured Products Start -->
 */}		
 	{/* <div class="section145">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="main-title-tt">
							<div class="main-title-left">
								<span>For You</span>
								<h2>Related Products</h2>
							</div>
							<a href="#" class="see-more-btn">See All</a>
						</div>
					</div>
					<div class="col-md-12">
                        
                            <div class="owl-carousel featured-slider owl-theme" >
                            {relatedProducts.map ((product) => (
							<div class="item" key={product.product_id}>
								<div class="product-item">
									<Link to={`/productdetails/${product.id}`} className="product-img">
										<img src={product.product_image} alt={product.product_name} />
										
									</Link>
									<div class="product-text-dt">
										<p>Available<span>{product.inStock ? "InStock" : "Out of Stock"}</span></p>
										<h4>{product.product_name}</h4>
										<div class="product-price"><i class="bi bi-currency-rupee"></i>{product.online_rate} <span><i class="bi bi-currency-rupee"></i>{product.mrp_rate}</span></div>
										<div className="qty-cart">
											<button
											className="add-to-cart-btn hover-btn"
											onClick={() => {
																

																addToCart({
																	...product,
																	price: product.online_rate,
																	oldPrice: product.mrp_rate,
																	
																    image:product.product_image

																});

																
																}}
											>
											<span>Add to Cart</span>
											<i className="bi bi-cart3"></i>
											</button>
										</div>
									</div>
								</div>
							</div>
                             ))}
                            </div>

                    </div>
				</div>
			</div>
		</div>		 */}
		<div class="section145">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="main-title-tt">
							<div class="main-title-left">
								<span>For You</span>
								<h2> Related Products</h2>
							</div>
							{/* <a href="shop_grid.html" class="see-more-btn">See All</a> */}
						</div>
					</div>
					<div class="col-md-12">
						{relatedProducts.length > 0 && (
            		<OwlCarousel
						    className="owl-theme cate-slider"
								// loop={true}
								margin={10}
								nav={true}
								dots={true}
								autoplay={true}
								autoplayTimeout={3000}
								responsive={{
									0: { items: 1 },
									600: { items: 4 },
									1000: { items: 4},
								}}
								>
							{relatedProducts.map((product) => (
								<div className="item" key={product.id}>
								<div className="product-item">
									<Link to={`/productdetails/${product.id}`} className="product-img">
									{/* <Link to='/productdetails' className="product-img"> */}
									<img src={product.product_image} alt={product.product_name} loading="lazy" />
									{/* <div className="product-absolute-options">
										<span className="offer-badge-1">{product.offer}</span>
									</div> */}
									</Link>
									<div className="product-text-dt">
									{/* <p>
										Available<span>({product.inStock ? 'In Stock' : 'Out of Stock'})</span>
									</p> */}
									<h4>{product.product_name}</h4>
									<div className="product-price">
										<i className="bi bi-currency-rupee"></i>{product.online_rate} <span><i className="bi bi-currency-rupee"></i>{product.mrp_rate}</span>
									</div>
									<div className="qty-cart">
										<button
										className="add-to-cart-btn hover-btn"
										onClick={() => {
																

																addToCart({
																	...product,
																	price: product.online_rate,
																	oldPrice: product.mrp_rate,
																	
																    image:product.product_image

																});

																
																}}
										>
										<span>Add to Cart</span>
										<i className="bi bi-cart3"></i>
										</button>
									</div>
									{/* {messages[product.id] && <div className="cart-message">{messages[product.id]}</div>} */}
									</div>
								</div>
								</div>
								))}
								</OwlCarousel>

							)}
					</div>
				</div>
			</div>
		</div>

          {/*   <!-- Featured Products End -->    */}	

 	</div>
   <Footer />
  </>
  )
}

export default ProductDetails