import React,{useEffect, useState} from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import Footer from '../Components/Footer'


const Terms = () => {
const [termsData, setTermsData] = useState();
const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
const[loading,setLoading] = useState(true);

		useEffect(() => {
			const fetchTermsdata = async () =>{
				try{
				const response = await axios.post(`${API_BASE_URL}content.php`)
				const {body} = response.data;
				setTermsData(body.terms)
				}catch(error){
					alert(error)
					console.error(error)
				}finally{
			setLoading(false);
		}
			}
		fetchTermsdata()
		},[])



        useEffect(() => {
            window.scrollTo(0, 0); 
        }, []);

return (
	<>
	{loading ? (
      <div style={{ height: '100vh', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
        <div className="loader"></div>
      </div>
    ) : (
<div class="wrapper">
		<div class="gambo-Breadcrumb">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><Link to="/">Home</Link></li>
								<li class="breadcrumb-item active" aria-current="page">Term and Conditions</li>
							</ol>
						</nav>
					</div>
				</div>
			</div>
		</div>
		<div class="all-product-grid">
			<div class="container">
				<div class="row">
					<div class="col-lg-12 col-md-12">
						<div class="job-main-dt">
							<h2> Term and Conditions</h2>
							
						</div>
						<div class="job-des-dt142 policy-des-dt">
							<p dangerouslySetInnerHTML={{ __html:termsData?.value }} />
							  {/* <p>Welcome to <strong>[Your Brand Name]</strong>! By accessing or using our website, you agree to comply with and be bound by the following Terms and Conditions. Please read them carefully before using our services.</p>

    <h3>1. Acceptance of Terms</h3>
    <p>By accessing our website and placing an order, you agree to abide by these terms, our Privacy Policy, and any other applicable policies posted on our site.</p>

    <h3>2. Products and Services</h3>
    <p>All products are subject to availability. We reserve the right to limit quantities or discontinue any product at any time. Product descriptions and pricing are subject to change without prior notice.</p>

    <h3>3. Orders and Payments</h3>
    <ul>
      <li>All orders must be placed through our website.</li>
      <li>Prices listed are in INR and inclusive of applicable taxes unless otherwise stated.</li>
      <li>We accept online payments through secure payment gateways.</li>
    </ul>

    <h3>4. Shipping and Delivery</h3>
    <p>We aim to dispatch orders within the specified time frame. However, we are not responsible for delays caused by external factors such as courier issues or natural calamities.</p>

    <h3>5. Returns and Refunds</h3>
    <p>Due to the perishable nature of our products, we do not accept returns once a product is opened. If the product is damaged or incorrect upon delivery, please contact us within 2 days with photographic evidence for resolution.</p>

    <h3>6. User Conduct</h3>
    <p>Users agree not to misuse the site for unlawful purposes. Any fraudulent, abusive, or harmful behavior may result in termination of access to our services.</p>

    <h3>7. Intellectual Property</h3>
    <p>All content on this website, including text, images, logos, and product information, is the property of <strong>[Your Brand Name]</strong> and protected by copyright laws. Unauthorized use is strictly prohibited.</p>

    <h3>8. Limitation of Liability</h3>
    <p>We strive to provide accurate and up-to-date information, but we do not guarantee that the website will be error-free. We are not liable for any damages arising from the use of our products or services.</p>

    <h3>9. Modifications</h3>
    <p>We reserve the right to update or modify these Terms at any time. Changes will be effective immediately upon posting on the website. Continued use of the site indicates acceptance of the revised terms.</p>

    <h3>10. Contact Us</h3>
    <p>If you have any questions regarding these Terms and Conditions, please contact us at <a href="mailto:support@yourbrand.com">support@yourbrand.com</a>.</p> */}

    {/* <p><strong>Last Updated:</strong> July 2, 2025</p> */}
	 {/* <p>if you any  questions regarding these Terms and Conditions,please contact us  at </p> */}
						</div>
						
					</div>
				</div>
			</div>
		</div>	
	</div>  
	)}
	 <Footer />
	</>
	)
}

export default Terms