import React,{useEffect, useState} from 'react'
import Footer from '../Components/Footer'
import { Link } from 'react-router-dom'
import axios from 'axios';




const Contactus = () => {
  const [contactData, setContactData] = useState(null);
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
  const [loading, setLoading] = useState(false);
  
  const [formData, setFormData] = useState({
	name:'',
	email:'',
	mobile:'',
    message:'',
  })

  useEffect(() => {
	const fetchContactData = async() => {
		try{
			const response = await axios.post(`${API_BASE_URL}content.php`)
			 const {body} = response.data;
			 setContactData(body.contact) 
		} catch(error){
			alert("Error fetching the contact data", error)
		    console.error("Error fetching the contact data", error);
		}
	}
	fetchContactData();
  },[])

	useEffect(() => {
		window.scrollTo(0, 0); 
	}, []);

	


const handleSubmit = async (e) => {
  e.preventDefault();

  if (!formData.name || !formData.mobile || !formData.email ) {
    alert("Please fill  required fields");
    return;
  }

  const orderData = {
    name: formData.name,
    email: formData.email,
    mobile: formData.mobile,
    message: formData.message,
  };

  console.log("Sending order:", orderData);

  try {
    setLoading(true);
    const response = await axios.post(`${API_BASE_URL}contact_form.php`, orderData);
    console.log("API Response:", response.data);
    alert("Message sent successfully!");
	window.location.reload();
  } catch (error) {
    console.error("Message sent failed:", error);
    alert("Something went wrong while sent message.");
  } 
  finally {
    setLoading(false);
  }
};


  return (
    <>
    <div class="wrapper">
		<div class="gambo-Breadcrumb">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><Link to="/">Home</Link></li>
								<li class="breadcrumb-item active" aria-current="page">Contact Us</li>
							</ol>
						</nav>
					</div>
				</div>
			</div>
		</div>
		<div class="all-product-grid">
			<div class="container">
				<div class="row">																					
					<div class="col-lg-6 col-md-12">
						<div class="panel-group accordion" id="accordion0">
							<div class="panel panel-default">
								<div class="panel-heading" id="headingOne">
									<div class="panel-title">
										<a class="collapsed" data-bs-toggle="collapse" data-bs-target="#collapseOne" href="#" aria-expanded="false" aria-controls="collapseOne">
											<i class="uil uil-location-point chck_icon"></i>Address
										</a>
									</div>
								</div>
								<div id="collapseOne" class="panel-collapse collapse show" role="tabpanel" aria-labelledby="headingOne" data-bs-parent="#accordion0" >
									<div class="panel-body">
										Shop:<br />
										{contactData?.address}
										<div class="color-pink">Tel:{contactData?.phonenumber}</div>
									</div>
								</div>
							</div>
													
						</div>
					</div>
					<div class="col-lg-6 col-md-12 mt-5">
						<h4>Contact</h4>
						<form onSubmit={handleSubmit}>
							<div className="row">
								<div className="col-lg-12 mb-3">
									<label className="form-label">Name<span style={{color:"red"}}>*</span></label>
									<input 
										type="text" 
										className="form-control" 
										name="name"
										value={formData.name}
										onChange={(e) => setFormData({ ...formData, name: e.target.value })}
										required 
									/>
								</div>
								<div className="col-lg-12 mb-3">
									<label className="form-label">Email<span style={{color:"red"}}>*</span></label>
									<input 
										type="email" 
										className="form-control" 
										name="email"
										value={formData.email}
										onChange={(e) => setFormData({ ...formData, email: e.target.value })}
										required 
									/>
								</div>

								<div className="col-lg-12 mb-3">
									<label className="form-label">Mobile<span style={{color:"red"}}>*</span></label>
									<input 
										type="tel" 
										className="form-control"
										name="mobile"
										value={formData.mobile}
										onChange={(e) => setFormData({ ...formData, mobile: e.target.value })}
										required 
									 />
								</div>
		

								{/* <div className="col-lg-6 mb-3">
									<label className="form-label">City</label>
									<input 
										type="text" 
										className="form-control" 
										name="city"
										value={formData.city}
										onChange={(e) => setFormData({ ...formData, city: e.target.value })}
									/>
								</div>
								<div className="col-lg-6 mb-3">
									<label className="form-label">Pincode</label>
									<input 
										type="text" 
										className="form-control" 
										name="pincode"
										value={formData.pincode}
										onChange={(e) => setFormData({ ...formData, pincode: e.target.value })}
									/>
								</div>

								<div className="col-lg-6 mb-3">
									<label className="form-label">State</label>
									<input 
										type="text" 
										className="form-control" 
										name="state"
										value={formData.state}
										onChange={(e) => setFormData({ ...formData, state: e.target.value })}
									/>
								</div>
								<div className="col-lg-12 mb-3">
									<label className="form-label">Address</label>
									<input 
										type="text" 
										className="form-control" 
										name="address"
										value={formData.address}
										onChange={(e) => setFormData({ ...formData, address: e.target.value })}
									/>
								</div>  */}
								<div className="col-12 mb-8">
									<label className="form-label">Message</label>
									<textarea 
										className="form-control" 
										rows="3" 
										name="message"
										value={formData.message}
										onChange={(e) => setFormData({ ...formData, message: e.target.value })}
									/>
								</div>
							</div>
							<div className="d-flex justify-content-center mt-4">
								<button type="submit" className="btn btn-success ">{loading ? "Submitting...." : "Submit" }</button>
							</div>
						</form>
					</div>	
				</div>
				<br />
					<iframe
					src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14257.61944436964!2d78.0399536!3d27.1750157!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x397471d1d46c6e6f%3A0xa25e1c16f219dedd!2sTaj%20Mahal!5e0!3m2!1sen!2sin!4v1627800000000!5m2!1sen!2sin"
					width="100%"
					height="450"
					style={{ border: "0" }}
					allowFullScreen
					loading="lazy"
					referrerPolicy="no-referrer-when-downgrade"
					/>
			</div>
			
		</div>	
	</div>
   <Footer />
    </>
  )
}

export default Contactus