import React,{useEffect, useState} from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import Footer from '../Components/Footer'


const ShippingPolicy = () => {
const [shippingData, setShippingData] = useState();
const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
 const[loading,setLoading] = useState(true);

        useEffect(() => {
            const fetchTermsdata = async () =>{
                try{
                const response = await axios.post(`${API_BASE_URL}content.php`)
                const {body} = response.data;
                setShippingData(body.shipping)
                }catch(error){
                    alert(error)
                    console.error(error)
                }finally{
			setLoading(false);
		}
            }
        fetchTermsdata()
        },[])



        useEffect(() => {
            window.scrollTo(0, 0); 
        }, []);

return (
    <>
    {loading ? (
      <div style={{ height: '100vh', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
        <div className="loader"></div>
      </div>
    ) : (
<div class="wrapper">
        <div class="gambo-Breadcrumb">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><Link to="/">Home</Link></li>
                                <li class="breadcrumb-item active" aria-current="page">Term and Conditions</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <div class="all-product-grid">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        <div class="job-main-dt">
                            <h2> Shipping and Delivery Policy</h2>
                            
                        </div>
                        <div class="job-des-dt142 policy-des-dt">
                            <p dangerouslySetInnerHTML={{ __html:shippingData?.value }} />
                             {/* <p>At <strong>[Your Brand Name]</strong>, we are committed to delivering your health mix products in a timely, safe, and efficient manner. Please review our shipping policy below for full details on delivery timelines, charges, and more.</p>

                            <h3>1. Order Processing</h3>
                            <p>Orders are processed within <strong>1–2 business days</strong> after receiving full payment. Orders placed on weekends or holidays will be processed on the next working day.</p>

                            <h3>2. Shipping Methods and Delivery Time</h3>
                            <ul>
                            <li><strong>Standard Shipping:</strong> Delivery within <strong>3–7 business days</strong> depending on your location.</li>
                            <li><strong>Express Shipping (if available):</strong> Delivery within <strong>1–3 business days</strong>.</li>
                            </ul>
                            <p>Delivery timelines may vary due to unforeseen factors such as weather conditions, courier delays, or remote location accessibility.</p>

                            <h3>3. Shipping Charges</h3>
                            <p>Shipping charges are calculated based on the order weight and delivery location. Final shipping cost will be displayed at checkout before you confirm your order.</p>
                            <ul>
                            <li><strong>Free Shipping:</strong> Available on orders above ₹<strong>499</strong> (subject to change).</li>
                            </ul>

                            <h3>4. Order Tracking</h3>
                            <p>Once your order is shipped, you will receive an email or SMS with the tracking number and courier partner details. You can use this information to track your shipment in real time.</p>

                            <h3>5. Delivery Address</h3>
                            <p>Please ensure that your delivery address, pincode, and contact details are accurate. We will not be responsible for failed deliveries due to incorrect or incomplete address information.</p>

                            <h3>6. Delays and Issues</h3>
                            <p>In rare cases, delivery may be delayed due to reasons beyond our control. We appreciate your patience and understanding in such circumstances.</p>

                            <h3>7. Damaged or Lost Packages</h3>
                            <p>If your package arrives damaged or does not arrive at all within 10 business days of the estimated delivery date, please contact us at <a href="mailto:support@yourbrand.com">support@yourbrand.com</a> with your order number and details.</p> */}
                         {/* <p>if you any  questions regarding these Terms and Conditions,please contact us  at [company email] </p> */}
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>	
    </div>  
    )}
    <Footer />
    </>
    )
}

export default ShippingPolicy