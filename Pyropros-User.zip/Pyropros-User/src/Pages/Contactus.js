import React,{useEffect, useState} from 'react'
import Footer from '../Components/Footer'
import { Link } from 'react-router-dom'
import axios from 'axios';




const Contactus = () => {
  const [contactData, setContactData] = useState(null);
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
 
  useEffect(() => {
	const fetchContactData = async() => {
		try{
			const response = await axios.post(`${API_BASE_URL}content.php`)
			 const {body} = response.data;
			 setContactData(body.contact) 
		} catch(error){
			alert("Error fetching the contact data", error)
		    console.error("Error fetching the contact data", error);
		}
	}
	fetchContactData();
  },[])

		useEffect(() => {
			window.scrollTo(0, 0); 
		}, []);

  return (
    <>
    <div class="wrapper">
		<div class="gambo-Breadcrumb">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><Link to="/">Home</Link></li>
								<li class="breadcrumb-item active" aria-current="page">Contact Us</li>
							</ol>
						</nav>
					</div>
				</div>
			</div>
		</div>
		<div class="all-product-grid">
			<div class="container">
				<div class="row">																					
					<div class="col-lg-6 col-md-12">
						<div class="panel-group accordion" id="accordion0">
							<div class="panel panel-default">
								<div class="panel-heading" id="headingOne">
									<div class="panel-title">
										<a class="collapsed" data-bs-toggle="collapse" data-bs-target="#collapseOne" href="#" aria-expanded="false" aria-controls="collapseOne">
											<i class="uil uil-location-point chck_icon"></i>Address
										</a>
									</div>
								</div>
								<div id="collapseOne" class="panel-collapse collapse show" role="tabpanel" aria-labelledby="headingOne" data-bs-parent="#accordion0" >
									<div class="panel-body">
										Shop:<br />
										{contactData?.address}
										<div class="color-pink">Tel:{contactData?.phonenumber}</div>
									</div>
								</div>
							</div>
													
						</div>
					</div>
				</div>
			</div>
		</div>	
	</div>
   <Footer />
    </>
  )
}

export default Contactus