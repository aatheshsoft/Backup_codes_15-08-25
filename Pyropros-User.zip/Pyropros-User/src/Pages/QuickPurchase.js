import React,{useState, useEffect, useRef } from 'react';
import Image from '../Assets/Chakkars.jpg'
import Modal from "react-bootstrap/Modal";
import Button from "react-bootstrap/Button";
import Footer from '../Components/Footer';
import { Link,useLocation } from 'react-router-dom';
import { useCart } from '../Context/CartContext';
import Image1 from "../Assets/Sparklers.340273222189be05ee57.jpg"
import axios from 'axios';
import Form from "react-bootstrap/Form";


const QuickPurchase = () => {
    const [isSmallScreen, setIsSmallScreen] = useState(window.innerWidth <= 426);
    const [showModal, setShowModal] = useState(false);
    const [selectedImage, setSelectedImage] = useState(null);
    const [loading, setLoading] = useState(false);
    const [counts, setCounts] = useState({});
    const { addToCart, updateQuantity, removeFromCart,cartItems } = useCart();
    const [products, setProducts] = useState([]);
    const [searchQuery, setSearchQuery] = useState("");
  	const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

   

  const fetchProducts = async () => {
     setLoading(true);
  try {
    const response = await axios.post(`${API_BASE_URL}quick_buy.php`);
    const categoryData = response.data.body.category;

    // Structure: [{ category_name, products: [{ id, name, ... }] }]
    const structuredProducts = categoryData.map((cat) => ({
      category_name: cat.category_name,
      products: cat.product.map((prod) => ({
        ...prod,
        id: prod.product_id,
        name: prod.product_name,
        price: parseFloat(prod.price),
        qty_per_box: prod.qty_per_box,
        image: prod.image,
        oldPrice: prod.oldprice
      })),
    }));

    setProducts(structuredProducts); // Now this is an array of categories with products
     setLoading(false);
  } catch (error) {
    console.error('Error fetching products:', error);
  }
};


      /*-- auto scroll to top code -- */

    useEffect(() => {
        window.scrollTo(0, 0); 
    }, []);


    /*--small screen table content align --  */

    useEffect(() => {
    fetchProducts();

    const handleResize = () => {
      setIsSmallScreen(window.innerWidth <= 426);
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

      /* image large view  */

      const handleImageClick = (imageSrc) => {
        setSelectedImage(imageSrc);
        setShowModal(true);
      };


      // useEffect(() => {
      //   setLoading(true);
      
      //   setTimeout(() => {
      //     setLoading(false);
      //   }, 2000);
      // }, []);


const handleAddClick = (product) => {
  setCounts((prev) => ({ ...prev, [product.id]: 1 }));
  addToCart({ ...product, quantity: 1 });
};




const handleIncrement = (productId) => {
  setCounts((prev) => ({
    ...prev,
    [productId]: prev[productId] + 1,
  }));
  updateQuantity(productId, 1);
};

const handleDecrement = (productId) => {
  setCounts((prev) => {
    const updated = Math.max(1, prev[productId] - 1);
    return { ...prev, [productId]: updated };
  });
  updateQuantity(productId, -1);   
};

const filteredProducts = products
  .map((category) => {
    const filteredItems = category.products.filter((product) =>
      product.name.toLowerCase().includes(searchQuery.toLowerCase())
    );
    return {
      ...category,
      products: filteredItems,
    };
  })
  .filter((category) => category.products.length > 0); // remove categories with no matching products

      
    
  return (
    <>
    {loading ? (
      <div style={{ height: '100vh', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
    <div className="loader"></div>
  </div>

    ):(

   <>
    <div class="wrapper">
		<div class="gambo-Breadcrumb">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><Link to="/">Home</Link></li>
								<li class="breadcrumb-item active" aria-current="page">Quick Purchase</li>
							</ol>
						</nav>
					</div>
				</div>
			</div>
		</div>
	
		<div class="">
			<div class="container">
				<div class="row">
					
					<div class="col-xl-12 col-lg-8 col-md-12">
						<div class="dashboard-right">
							<div class="row">
															
                <div className="search-box-container">
                <div className="search-box">
                  <Form.Control
                    type="text"
                    placeholder="Search Products..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                  <i className="fa fa-search"></i>
                </div>
              </div>
								<div class="col-lg-12 col-md-12">
									<div class="pdpt-bg">
										<div class="pdpt-title">
											<h4>All Products</h4>
										</div>
										<div class="active-offers-body">
											<div class="table-responsive">
												 <table className="table ucp-table earning__table">
                                <thead className="thead-s">
                                  <tr className="quick-table">
                                    <th scope="col" style={{ width: '80px' }}>Image</th>
                                    <th scope="col">Product Name</th>
                                    {!isSmallScreen && <th scope="col">Price</th>}
                                    {!isSmallScreen && <th scope="col">Qty</th>}
                                    {!isSmallScreen && <th scope="col">Qty Per Box</th>}
                                    {!isSmallScreen && <th scope="col">Total</th>}
                                  </tr>
                                </thead>
                                <tbody>
                                  {filteredProducts.map((category) => (
                                      <React.Fragment key={category.category_name}>
                                        <tr className="category-header">
                                          <td colSpan={isSmallScreen ? 4 : 7} className="category-header">
                                            <h5 className="ctgyname">{category.category_name}</h5>
                                          </td>
                                        </tr>

                                        {category.products.map((product) => {
                                          const cartItem = cartItems.find((item) => item.id === product.id);
                                          const quantity = cartItem ? cartItem.quantity : 0;
                                          const total = product.price * quantity;

                                          return (
                                            <tr key={product.id}>
                                              <td className="order-dt-img">
                                                <img
                                                  src={product.image}
                                                  alt={product.name}
                                                  loading="lazy"
                                                  onClick={() => handleImageClick(product.image)}
                                                  style={{ cursor: "pointer" }}
                                                />
                                              </td>
                                              <td className='product-name-quick'>
                                                {product.name}
                                                {isSmallScreen && (
                                                  <div className="table-responsive-price">
                                                    
                                                    <nobr><td className="product-price"><i className="bi bi-currency-rupee"></i>{product.price}<span><nobr><i className="bi bi-currency-rupee"></i>{product.oldprice}</nobr></span></td></nobr>
                                                    
                                                    <td>
                                                      {quantity === 0 ? (
                                                        <Button onClick={() => handleAddClick(product)} className="add-btn">Add</Button>
                                                      ) : (
                                                        <div className="counter-btn">
                                                          <Button className="countadd" onClick={() => handleDecrement(product.id)}>-</Button>
                                                          <div className="counter-display">{quantity}</div>
                                                          <Button className="countadd" onClick={() => handleIncrement(product.id)}>+</Button>
                                                        </div>
                                                      )}
                                                    </td>
                                                  </div>
                                                )}
                                              </td>

                                              {!isSmallScreen && (
                                                <>
                                                  <td className="product-price"><i className="bi bi-currency-rupee"></i>{product.price}<span><i className="bi bi-currency-rupee"></i>{product.oldprice}</span></td>
                                                  <td>
                                                    {quantity === 0 ? (
                                                      <Button onClick={() => handleAddClick(product)} className="add-btn">Add</Button>
                                                    ) : (
                                                      <div className="counter-btn">
                                                        <Button className="countadd" onClick={() => handleDecrement(product.id)}>-</Button>
                                                        <div className="counter-display">{quantity}</div>
                                                        <Button className="countadd" onClick={() => handleIncrement(product.id)}>+</Button>
                                                      </div>
                                                    )}
                                                  </td>
                                                  <td>{product.qty_per_box}</td>
                                                  <td><i class="bi bi-currency-rupee"></i><b>{total.toFixed(2)}</b></td>
                                                </>
                                              )}
                                            </tr>
                                          );
                                        })}
                                      </React.Fragment>
                                    ))}

                                </tbody>
                              </table>


											</div>	
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>	
			</div>	
		</div>	
	</div>
    <Footer />
    <Modal
        show={showModal}
        onHide={() => setShowModal(false)}
        size="md"
        aria-labelledby="contained-modal-title-vcenter"
        centered
      >
        <Modal.Header closeButton>
          <Modal.Title id="contained-modal-title-vcenter">
            Product Image
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <img
            src={selectedImage}
            alt="Selected"
            style={{ width: "100%", height: "400px",objectFit:"contain" }}
          />
        </Modal.Body>
        <Modal.Footer>
          <Button onClick={() => setShowModal(false)}>Close</Button>
        </Modal.Footer>
      </Modal>
      </>
       ) }
</>
  )
}

export default QuickPurchase