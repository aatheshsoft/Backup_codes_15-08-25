import React,{useEffect, useState} from 'react'
import Footer from '../Components/Footer'
import axios from 'axios'

const About = () => {
 const [aboutData, setAboutData] = useState(null);
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
 const[loading,setLoading] = useState(true);
 
  useEffect(() => {
	const fetchAboutData = async() => {
		try{
			const response = await axios.post(`${API_BASE_URL}content.php`)
			 const {body} = response.data;
			 setAboutData(body.about) 
		} catch(error){
			alert("Error fetching the contact data", error)
		    console.error("Error fetching the contact data", error);
		}finally{
			setLoading(false);
		}
	}
	fetchAboutData();
  },[])




	
  return (
<>
{loading ? (
      <div style={{ height: '100vh', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
        <div className="loader"></div>
      </div>
    ) : (
    <div class="wrapper">
		<div class="default-dt">
			<div class="container">
				<div class="row">
					<div class="col-lg-12 col-md-12">
					
						<div class="title129">	
							<h2>About Us</h2>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="life-gambo">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="default-title left-text">
							<h2>About </h2>
							{/* <p>Customers Deserve Better</p>
							<img src="images/line.svg" alt="" /> */}
						</div>
						<div class="about-content">
							  <p dangerouslySetInnerHTML={{ __html: aboutData?.value }} />
							  
						</div>
					</div>
					<div class="col-lg-6">
						<div class="about-img">
							<img src="images/about.svg" alt="" />
						</div>
					</div>
				</div>
			</div>
		</div>
		
	</div>
	)}
	<Footer />
</>
  )
}

export default About