import React,{useEffect, useState} from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import Footer from '../Components/Footer'


const Terms = () => {
const [termsData, setTermsData] = useState();
const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
const[loading,setLoading] = useState(true);

		useEffect(() => {
			const fetchTermsdata = async () =>{
				try{
				const response = await axios.post(`${API_BASE_URL}content.php`)
				const {body} = response.data;
				setTermsData(body.terms)
				}catch(error){
					alert(error)
					console.error(error)
				}finally{
			setLoading(false);
		}
			}
		fetchTermsdata()
		},[])



        useEffect(() => {
            window.scrollTo(0, 0); 
        }, []);

return (
	<>
	{loading ? (
      <div style={{ height: '100vh', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
        <div className="loader"></div>
      </div>
    ) : (
<div class="wrapper">
		<div class="gambo-Breadcrumb">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><Link to="/">Home</Link></li>
								<li class="breadcrumb-item active" aria-current="page">Term and Conditions</li>
							</ol>
						</nav>
					</div>
				</div>
			</div>
		</div>
		<div class="all-product-grid">
			<div class="container">
				<div class="row">
					<div class="col-lg-12 col-md-12">
						<div class="job-main-dt">
							<h2> Term and Conditions</h2>
							
						</div>
						<div class="job-des-dt142 policy-des-dt">
							<p dangerouslySetInnerHTML={{ __html:termsData?.value }} />
						</div>
						
					</div>
				</div>
			</div>
		</div>	
	</div>  
	)}
	 <Footer />
	</>
	)
}

export default Terms