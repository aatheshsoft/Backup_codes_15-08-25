import React,{useEffect,useState } from 'react'
import OwlCarousel from 'react-owl-carousel';
import 'owl.carousel/dist/assets/owl.carousel.css';
import 'owl.carousel/dist/assets/owl.theme.default.css';
import Banner from '../Components/Banner';
import Footer from '../Components/Footer';
import 'bootstrap-icons/font/bootstrap-icons.css';
import { Link, Links } from 'react-router-dom';
import { useCart } from '../Context/CartContext';
import { FaShoppingCart } from 'react-icons/fa';
import axios from "axios";
import {  useNavigate } from "react-router-dom";
import { Swiper, SwiperSlide } from 'swiper/react';
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/autoplay';
import { Navigation, Autoplay } from 'swiper/modules';
import $ from 'jquery';
import { faWhatsapp } from "@fortawesome/free-brands-svg-icons";
import { IoSendSharp } from "react-icons/io5";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import BlinkingAnimaion from '../Components/BlinkingAnimation';
import image1 from '../Assets/Banner1.jpg';
import image2 from '../Assets/banner2.jpeg'
import image3 from '../Assets/banner3.jpeg';
import adbanner from '../Assets/ad-banner.jpg'


const Home = () => { 
	const { addToCart, messages } = useCart();
    const [categories, setCategories] = useState([]);
    const navigate = useNavigate();
	const[hotproducts,setHotProducts] = useState([]);
	const[feature,setFeature] = useState([]);
	const[newproducts, setNewProducts] = useState([]);
  	const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
  	const [message, setMessage] = useState("");
  	const [isChatBoxVisible, setChatBoxVisible] = useState(false);
    const [shopgallery, setShopGallery]= useState([]);
    const [clientlogo, setClientLogo] = useState([]);

	const toggleChatBox = () => {
    setChatBoxVisible(!isChatBoxVisible);
  };
  
  const handleMessageChange = (e) => {
    setMessage(e.target.value);
  };

  const sendMessage = () => {
    // if (aa) {
    //   console.log("WhatsApp number is not available yet");
    //   return;
    // }

    const whatsappUrl = `https://wa.me/$.replace(
	 
      "+",
      ""
    )}?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, "_blank");
  };

useEffect(() => {
  axios.post(`${API_BASE_URL}home.php`)
    .then(res => {
      if (res.data.head.code === 200 && res.data.body.category) {
        setCategories(res.data.body.category);
		setHotProducts(res.data.body.hot_list);
		setFeature(res.data.body.feature_list);
		setNewProducts(res.data.body.new_list);
		setShopGallery(res.data.body.gallery);
		setClientLogo(res.data.body.client_logo)
      }
    })
    .catch(err => {
      console.error("Error fetching categories:", err);
    });
}, []);


useEffect(() => {
    // Initialize Owl Carousel after component mounts
    window.$('.owl-carousel').owlCarousel({
      loop: true,
      margin: 10,
      nav: true,
      autoplay: true,
      autoplayTimeout: 5000,
      responsive: {
        0: {
          items: 1
        },
        600: {
          items: 2
        },
        1000: {
          items: 5
        }
      }
    });
  }, []);

const handleCategoryClick = (cat) => {
  navigate(`/shopbycategory/${cat.cid}`);
};

  
  useEffect(() => {
			window.scrollTo(0, 0); 
		}, []);

  


  return (
	<>
    <div class="wrapper">
		{/* <!-- banner Start --> */}
		<Banner />
	{/* 	<!-- banner End --> */}

		{/* <!-- Categories Start -->  */}
		<>
			{messages && Object.entries(messages).map(([id, message]) => (
			<div key={id} className="message-popup">
				<FaShoppingCart className="cart-icon-addtocart" />
				<div className="message">{message}</div>
			</div>
			))}
		</>
		<div class="section145">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="main-title-tt">
							<div class="main-title-left">
								<span>Shop By</span>
								<h2>Categories</h2>
							</div>
						</div>
					</div>
					 <div className="col-md-12">
								{categories.length > 0 && (
									<OwlCarousel
										className="owl-theme cate-slider"
										loop={true}
										infinite= {true}
    									speed= {500}
										margin={10} 
										nav
										autoplay={true}           
										autoplayTimeout={3000}  
										autoplayHoverPause={true}
										smartSpeed={500}
										responsive={{
										0: { items: 2 },
										600: { items: 4 },
										1000: { items: 5 },
										}}
									>
										{categories.map(cat => (
										<div className="item" key={cat.cid} onClick={() => handleCategoryClick(cat)}>
											<a className="category-item">
											<div className="cate-img">
												<img
												src={cat.image}
												alt={cat.name}
												// style={{ width: "50px", height: "50px", objectFit: "contain" }}
												/>
											</div>
											<h4>{cat.name.length > 15 ? cat.name.slice(0, 15) + '...' : cat.name}</h4>
											</a>
										</div>
										))}
									</OwlCarousel>
									)}

								</div> 
				</div>
			</div>
		</div>
		{/* <!-- Categories End --> */}
		<BlinkingAnimaion />
		{/* <!-- Featured Products Start --> */}
		<div class="section145">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="main-title-tt">
							<div class="main-title-left">
								<span>For You</span>
								<h2>Added New Products</h2>
							</div>
							{/* <a href="shop_grid.html" class="see-more-btn">See All</a> */}
						</div>
					</div>
					<div class="col-md-12">
						{newproducts.length > 0 && (
            		<OwlCarousel
						className="owl-theme cate-slider"
								// loop={true}
								margin={10}
								nav={true}
								dots={true}
								autoplay={true}
								autoplayTimeout={3000}
								responsive={{
									0: { items: 1 },
									600: { items: 4 },
									1000: { items: 5},
								}}
								>
							{newproducts.map((product) => (
								<div className="item" key={product.id}>
								<div className="product-item">
									<Link to={`/productdetails/${product.id}`} className="product-img">
									<img src={product.image} alt={product.name} loading="lazy" />
									{/* <div className="product-absolute-options">
										<span className="offer-badge-1">{product.offer}</span>
									</div> */}
									</Link>
									<div className="product-text-dt">
									<p>
										Available<span>({product.inStock ? 'In Stock' : 'Out of Stock'})</span>
									</p>
									<h4>{product.name}</h4>
									<div className="product-price">
										<i className="bi bi-currency-rupee"></i>{product.price} <span><i className="bi bi-currency-rupee"></i>{product.oldPrice}</span>
									</div>
									<div className="qty-cart">
										<button
										className="add-to-cart-btn hover-btn"
										onClick={() => addToCart(product)}
										>
										<span>Add to Cart</span>
										<i className="bi bi-cart3"></i>
										</button>
									</div>
									{/* {messages[product.id] && <div className="cart-message">{messages[product.id]}</div>} */}
									</div>
								</div>
								</div>
								))}
								</OwlCarousel>

							)}
					</div>
				</div>
			</div>
		</div>
		{/* <!-- Featured Products End -->
		<!-- Best Values Offers Start --> */}
		<div class="section145">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="main-title-tt">
							<div class="main-title-left">
								{/* <span>Offers</span> */}
								<h2>Gallery</h2>
							</div>
						</div>
					</div>
					{shopgallery.map((product) => (
					<div class="col-lg-4 col-md-6">
						<a href="#" class="best-offer-item" key={product.id}>
							<img src={product.image} />
						</a>
					</div>
					))}
					{/* <div class="col-md-12">
						<a href="#" class="code-offer-item">
							<img src={adbanner} alt="" />
						</a>
					</div> */}
				</div>
			</div>
		</div>
		{/* <!-- Best Values Offers End -->
		<!-- Vegetables and Fruits Start --> */}
		<div class="section145">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="main-title-tt">
							<div class="main-title-left">
								<span>For You</span>
								<h2>Hot Sales</h2>
							</div>
							{/* <a href="shop_grid.html" class="see-more-btn">See All</a> */}
						</div>
					</div>
					<div class="col-md-12">
						{hotproducts.length > 0 && (
            			<OwlCarousel
						className="owl-theme cate-slider"
								// loop={true}
								margin={10}
								nav={true}
								dots={true}
								autoplay={true}
								autoplayTimeout={3000}
								responsive={{
									0: { items: 1 },
									600: { items: 4 },
									1000: { items: 5},
								}}
								>
							{hotproducts.map((product) => (
								<div className="item" key={product.id}>
								<div className="product-item">
									<Link to={`/productdetails/${product.id}`} className="product-img">
									<img src={product.image} alt={product.name} loading="lazy" />
									{/* <div className="product-absolute-options">
										<span className="offer-badge-1">{product.offer}</span>
									</div> */}
									</Link>
									<div className="product-text-dt">
									<p>
										Available<span>({product.inStock ? 'In Stock' : 'Out of Stock'})</span>
									</p>
									<h4>{product.name}</h4>
									<div className="product-price">
										<i className="bi bi-currency-rupee"></i>{product.price} <span><i className="bi bi-currency-rupee"></i>{product.oldPrice}</span>
									</div>
									<div className="qty-cart">
										<button
										className="add-to-cart-btn hover-btn"
										onClick={() => addToCart(product)}
										>
										<span>Add to Cart</span>
										<i className="bi bi-cart3"></i>
										</button>
									</div>
									{/* {messages[product.id] && <div className="cart-message">{messages[product.id]}</div>} */}
									</div>
								</div>
								</div>
							))}
								</OwlCarousel>

							)}
					</div>
				</div>
			</div>
		</div>
	{/* 	<!-- Vegetables and Fruits Products End -->
		<!-- New Products Start --> */}

		<div className="section145">
      <div className="container">
        <div className="row">
          <div className="col-md-12">
            <div className="main-title-tt">
              <div className="main-title-left">
                {/* <span>For You</span> */}
                <h2>Client logo</h2>
              </div>
              {/* <a href="shop_grid.html" className="see-more-btn">
                See All
              </a> */}
            </div>
          </div>
          <div className="col-md-12">
			{clientlogo.length > 0 && (
            <OwlCarousel
			className="owl-theme cate-slider"
			// loop={true}
				infinite= {true}
				speed= {500}
			margin={10}
			nav
			responsive={{
			0: { items: 1 },
			600: { items: 4 },
			1000: { items: 5 },
			}}
		>
			{clientlogo.map((product) => (
				<div className="item" key={product.id}>
				<div className="product-item">
					<Link to={`/productdetails/${product.id}`} className="product-img">
					<img src={product.image} alt={product.name} loading="lazy"/>
					
					</Link>
					
				</div>
				</div>
			))}
			</OwlCarousel>

			)}
          </div>
        </div>
      </div>
    </div>
		{/* WhatsApp Icon */}
      <div className="floating-whatsapp-container">
        <div className="floating-whatsapp" onClick={toggleChatBox}>
          <FontAwesomeIcon icon={faWhatsapp} />
        </div>
        {isChatBoxVisible && (
          <div className="chat-box">
            <div className="wats-header">
              <p>Pyropros</p>
              <button className="close-button" onClick={toggleChatBox}>
                X
              </button>
            </div>
            <div className="wats-content">
              <p>Welcome To Pyropros</p>
            </div>
            <div className="chat-content">
            <textarea
              placeholder="Type your message here..."
              value={message}
              onChange={handleMessageChange}
            ></textarea>
            <button onClick={sendMessage}>
              <IoSendSharp />
            </button>
          </div>
          </div>
        )}
      </div>
		{/* <!-- New Products End --> */}
	</div>
	<Footer />
	</>
  )
}

export default Home