import React,{useEffect, useState} from 'react'
import Footer from '../Components/Footer'
import { Link } from 'react-router-dom';
import axios from 'axios';



const Privacy = () => {
const [privacyData, setPrivacyData] = useState();
const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
const[loading,setLoading] = useState(true);

 useEffect(() => {
	const fetchPrivacydata = async () => {
		
		try{
		const response = await axios.post(`${API_BASE_URL}content.php`)
		const {body} = response.data;
		setPrivacyData(body.privacy)
		}catch(error){
			alert(error)
			console.error(error)
		}finally{
			setLoading(false);
		}
	}
fetchPrivacydata()
},[])

useEffect(() => {
    window.scrollTo(0, 0); 
}, []);

return (
  <>
    {loading ? (
      <div style={{ height: '100vh', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
        <div className="loader"></div>
      </div>
    ) : (
      <div className="wrapper">
        <div className="gambo-Breadcrumb">
          <div className="container">
            <div className="row">
              <div className="col-md-12">
                <nav aria-label="breadcrumb">
                  <ol className="breadcrumb">
                    <li className="breadcrumb-item"><Link to="/">Home</Link></li>
                    <li className="breadcrumb-item active" aria-current="page">Privacy Policy</li>
                  </ol>
                </nav>
              </div>
            </div>
          </div>
        </div>
        <div className="all-product-grid">
          <div className="container">
            <div className="row">
              <div className="col-lg-12 col-md-12">
                <div className="job-main-dt">
                  <h2>Privacy Policy</h2>
                </div>
                <div className="job-des-dt142 policy-des-dt">
                  <p dangerouslySetInnerHTML={{ __html: privacyData?.value }} />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    )}
    <Footer />
  </>
);

}

export default Privacy