import React,{useEffect, useState} from 'react'
import { Link } from 'react-router-dom';
import { useCart } from '../Context/CartContext';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';



const Checkout = () => {
const { removeFromCart,cartItems } = useCart();
const totalPrice = cartItems.reduce((acc, item) => acc + item.price * item.quantity, 0);
const grandTotal = totalPrice ;
const navigate = useNavigate();
const [loading, setLoading] = useState(false);
const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
const { clearCart } = useCart();
const [formData , setFormData] = useState({
  name: '',
  email: '',
  mobileNumber: '',
  address: '',
  city: '',
  state: '',
  pincode: '',
})

    useEffect(() => {
        // Ensure that jQuery is loaded and the DOM is ready
        if (window.$) {
          window.$('.owl-carousel').owlCarousel({
            loop: true,
            margin: 10,
            nav: false,        
            dots: false,      
            autoplay: false,    
            autoplayTimeout: 5000,  
            responsive: {
              0: {
                items: 1,      
              },
              600: {
                items: 2,     
              },
              1000: {
                items: 5,       
              },
            },
          });
        }
      }, []);

const handleSubmit = async (e) => {
  e.preventDefault();

  if (!formData.name || !formData.mobileNumber || !formData.address) {
    alert("Please fill all required fields");
    return;
  }

  const orderData = {
    name: formData.name,
    email: formData.email,
    phonenumber: formData.mobileNumber,
    address: formData.address,
    city: formData.city,
    state: formData.state,
    pincode: formData.pincode,
    subtotal: cartItems.reduce((acc, item) => acc + item.price * item.quantity, 0),
    discount_percentage: 0.00,
    coupon_discount: 0.00,
    total: cartItems.reduce((acc, item) => acc + item.price * item.quantity, 0),
    coupen_code: "",
    product: cartItems.map(item => ({
      product_id: item.product_id || item.id,
      category_id: item.category_id || "",
      product_name: item.name || item.product_name,
      unit_price: item.price,
      quantity: item.quantity,
      final_price: item.price * item.quantity,
	  discount: 0.00,
    }))
  };

  console.log("Sending order:", orderData);

  try {
    setLoading(true);
    const response = await axios.post(`${API_BASE_URL}order.php`, orderData);
    console.log("API Response:", response.data);
    alert("Order placed successfully!");
	clearCart();
    navigate("/orderplaced");
  } catch (error) {
    console.error("Order submission failed:", error);
    alert("Something went wrong while placing your order.");
  } finally {
    setLoading(false);
  }
};



  return (
    <div class="wrapper">
		<div class="gambo-Breadcrumb">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><Link to ='/'>Home</Link></li>
								<li class="breadcrumb-item active" aria-current="page">Checkout</li>
							</ol>
						</nav>
					</div>
				</div>
			</div>
		</div>
		<div class="all-product-grid">
			<div class="container">
				<div class="row">
					<div class="col-lg-8 col-md-7">
						<div id="checkout_wizard" class="checkout accordion left-chck145">
							
							<div class="checkout-step">
								<div class="checkout-card" >
									<h4 class="checkout-step-title">
										<button class="wizard-btn collapsed" > Delivery Address</button>
									</h4>
								</div>
								<div>
									<div class="checkout-step-body">
										<div class="checout-address-step">
											<div class="row">
												<div class="col-lg-12">												
													<form onSubmit={handleSubmit}>
														{/* <!-- Multiple Radios (inline) --> */}
														<div class="form-group">
															{/* <div class="product-radio">
																<ul class="product-now">
																	<li>
																		<input type="radio" id="ad1" name="address1" checked />
																		<label for="ad1">Home</label>
																	</li>
																	<li>
																		<input type="radio" id="ad2" name="address1" />
																		<label for="ad2">Office</label>
																	</li>
																	<li>
																		<input type="radio" id="ad3" name="address1" />
																		<label for="ad3">Other</label>
																	</li>
																</ul>
															</div> */}
														</div>
														<div class="address-fieldset">
															<div class="row">
																<div class="col-lg-12 col-md-12">
																	<div class="form-group mt-30">
																		<label class="control-label">Name</label>
																		<input
																		id="name"
																		name="name"
																		type="text"
																		placeholder="Name"
																		className="form-control input-md"
																		required
																		value={formData.name}
																		onChange={(e) => setFormData({ ...formData, name: e.target.value })}
																		/>
																	</div>
																</div>
																<div class="col-lg-6 col-md-12">
																	<div class="form-group mt-30">
																		<label class="control-label">Mobile Number</label>
																		<input 
																		id="mobileNumber" 
																		name="mobileNumber" 
																		type="text" 
																		placeholder="Mobile Number" 
																		class="form-control input-md" 
																		required
																		value={formData.mobileNumber}
																		onChange={(e) => setFormData({ ...formData, mobileNumber: e.target.value })}
																		/>
																	</div>
																</div>
																<div class="col-lg-6 col-md-12">
																	<div class="form-group mt-30">
																		<label class="control-label">Email</label>
																		<input 
																		id="email" 
																		name="email" 
																		type="text" 
																		placeholder="Email" 
																		class="form-control input-md" 
																		required
																		value={formData.email}
																		onChange={(e) => setFormData({ ...formData, email: e.target.value })}
																		/>
																		</div>
																</div>

																<div class="col-lg-12 col-md-12">
																	<div class="form-group mt-30">
																		<label class="control-label">Address</label>
																		<textarea 
																		id="address" 
																		name="address" 
																		type="text" 
																		placeholder="Address" 
																		class="form-control input-md" 
																		required
																		value={formData.address}
																		onChange={(e) => setFormData({ ...formData, address: e.target.value })}
																		/>																	
																	</div>
																</div>
																
																<div class="col-lg-6 col-md-12">
																	<div class="form-group mt-30">
																		<label class="control-label">City</label>
																		<input 
																		id="city" 
																		name="city" 
																		type="text" 
																		placeholder="City" 
																		class="form-control input-md" 
																		required
																		value={formData.city}
																		onChange={(e) => setFormData({ ...formData, city: e.target.value })}
																		/>																	
																	</div>
																</div>
																<div class="col-lg-6 col-md-12">
																	<div class="form-group mt-30">
																		<label class="control-label">State</label>
                                                                        <input
																		id="state" 
																		name="state" 
																		type="text" 
																		placeholder="State" 
																		class="form-control input-md" 
																		required
																		value={formData.state}
																		onChange={(e) => setFormData({ ...formData, state: e.target.value })}
																		/>																																		
																	</div>
																</div>
																<div class="col-lg-6 col-md-12">
																	<div class="form-group mt-30">
																		<label class="control-label">Pincode</label>
																		<input
																		id="pincode" 
																		name="pincode" 
																		type="text" 
																		placeholder="Pincode" 
																		class="form-control input-md" 
																		required
																		value={formData.pincode}
																		onChange={(e) => setFormData({ ...formData, pincode: e.target.value })}
																		/>																		
																	</div>
																</div>
																
																<div class="col-lg-12 col-md-12">
																	<div class="form-group mt-30">
																		<div class="address-btns">
																			{/* <button class="save-btn14 hover-btn">Save</button> */}
																			<button type="submit" className="collapsed ms-auto next-btn16 hover-btn">
																			{loading ? 'Submitting...' : 'Submit Enquiry'}
																			</button>																		
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</form>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-4 col-md-5">
						<div class="pdpt-bg mt-0">
							<div class="pdpt-title">
								<h4>Order Summary</h4>
							</div>
							<div class="right-cart-dt-body">
								{cartItems.map((item) => (
										<div className="cart-item border_radius" key={item.id}>
											<div className="cart-product-img">
											<img src={item.image} alt={item.name} />
											</div>
											<div className="cart-text">
											<h4>{item.name}</h4>
											<div className="cart-item-price">
												<i className="bi bi-currency-rupee"></i>{item.price}
												{item.oldPrice && (
												<span>
													<i className="bi bi-currency-rupee"></i>{item.oldPrice}
												</span>
												)}
											</div>
											<button type="button" className="cart-close-btn" onClick={() => removeFromCart(item.id)}>
												<i className="uil uil-multiply"></i>
											</button>
											</div>
										</div>
										))}

							</div>
							<div className="total-checkout-group">
						{/* <div className="cart-total-dil">
							<h4>Gambo Super Market</h4>
							<span><i className="bi bi-currency-rupee"></i>{totalPrice}</span>
						</div> */}
						{/* <div className="cart-total-dil pt-3">
							<h4>Delivery Charges</h4>
							<span><i className="bi bi-currency-rupee"></i>{deliveryCharge}</span>
						</div> */}
						</div>
						{/* <div className="cart-total-dil saving-total">
						<h4>Total Saving</h4>
						<span><i className="bi bi-currency-rupee"></i>{savings}</span>
						</div> */}
						

							
						</div>
						<div className="main-total-cart p-4">
						<h2>Total</h2>
						<span><i className="bi bi-currency-rupee"></i>{grandTotal}</span>
						</div>
					</div>
				</div>
			</div>
		</div>	
	</div>
  )
}

export default Checkout