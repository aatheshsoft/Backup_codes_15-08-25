import React,{useEffect,useState} from 'react'
import { Link, Links } from 'react-router-dom';
import Footer from '../Components/Footer';
import { Dropdown } from "react-bootstrap";
import { useCart } from '../Context/CartContext';
import { FaShoppingCart } from 'react-icons/fa';
import axios from "axios";
import { useParams } from "react-router-dom";
import { Offcanvas } from 'bootstrap';

const Product = () => {
    const { addToCart, messages } = useCart();
	const [showAll, setShowAll] = useState(false);
    const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
    const [Products, setProducts] = useState([]);
	const [loading, setLoading] = useState(false);
	const { id:menu_id } = useParams(); 
	const [selectedAges, setSelectedAges] = useState([]);
	const [categories, setCategories] = useState([]);
	const [selectedCategories, setSelectedCategories] = useState([]);



useEffect(() => {
	setLoading(true)
	if(menu_id){
		axios.post(`${API_BASE_URL}menu_product_list.php`,{
			menu_id:menu_id
		})
		
		.then(res => {
			if(res.data.head.code === 200){
		  const fetchedProducts = res.data.body.map(product => ({
          id: product.product_id,
          name: product.product_name,
          price: parseFloat(product.online_rate) || 0,
          oldPrice: parseFloat(product.mrp_rate) || 0,
          image: product.product_image || " ", 
          category_id: product.category_id,
          menu_id: menu_id,
		  age: product.age || null
        }));
        setProducts(fetchedProducts);
		
		console.log(fetchedProducts);
        setLoading(false);
		}
		})
		 .catch(error => {
      console.error("Error fetching products:", error);
    });
	}
},[menu_id])


// 1. Extract unique ages
const uniqueAges = Array.from(
  new Set(
    Products
      .map((product) => {
        const ageStr = product.age; // e.g. "10+"
        const ageNum = parseInt(ageStr); // get number part like 10
        return !isNaN(ageNum) ? ageStr : null; // only include valid ages
      })
      .filter((age) => age !== null) // remove nulls
  )
).sort((a, b) => parseInt(a) - parseInt(b)); // sort by numeric value



const handleAgeFilterChange = (e) => {
  const age = e.target.value;
  const isChecked = e.target.checked;

  setSelectedAges((prevSelected) => {
    const updated = isChecked
      ? [...prevSelected, age]
      : prevSelected.filter((a) => a !== age);

    // Close the offcanvas
    const offcanvasEl = document.getElementById('offcanvasFilter');
    let offcanvasInstance = Offcanvas.getInstance(offcanvasEl);
    if (!offcanvasInstance) {
      offcanvasInstance = new Offcanvas(offcanvasEl);
    }
    offcanvasInstance.hide();

    // Remove backdrop manually after a slight delay (give Bootstrap time to animate)
    setTimeout(() => {
      const backdrop = document.querySelector('.offcanvas-backdrop');
      if (backdrop) {
        backdrop.remove(); // 🔥 manually remove it
        document.body.classList.remove('offcanvas-backdrop', 'show', 'modal-open');
        document.body.style.overflow = 'auto'; // reset scroll
      }
    }, 100); // delay to let Bootstrap finish animatio

    return updated;
  });
};

const handleCategoryFilterChange = (e, categoryId) => {
  const isChecked = e.target.checked;

  const updatedCategories = isChecked
    ? [...selectedCategories, categoryId]
    : selectedCategories.filter((id) => id !== categoryId);

  setSelectedCategories(updatedCategories);
   // Close the offcanvas
	  const offcanvasEl = document.getElementById('offcanvasFilter');
	  let offcanvasInstance = Offcanvas.getInstance(offcanvasEl);
	  if (!offcanvasInstance) {
		offcanvasInstance = new Offcanvas(offcanvasEl);
	  }
	  offcanvasInstance.hide();
  
	  // Remove backdrop manually after a slight delay (give Bootstrap time to animate)
	  setTimeout(() => {
		const backdrop = document.querySelector('.offcanvas-backdrop');
		if (backdrop) {
		  backdrop.remove(); // 🔥 manually remove it
		  document.body.classList.remove('offcanvas-backdrop', 'show', 'modal-open');
		  document.body.style.overflow = 'auto'; // reset scroll
		}
	  }, 100); 
};



const filteredProducts = Products.filter((product) => {
  const ageMatch =
    selectedAges.length === 0 || selectedAges.includes(product.age);
  const categoryMatch =
    selectedCategories.length === 0 || selectedCategories.includes(product.category_id);

  return ageMatch && categoryMatch;
});

const visibleProducts = showAll ? filteredProducts : filteredProducts.slice(0, 8);






useEffect(() => {
  const offcanvasEl = document.getElementById('offcanvasFilter');

  const handleHidden = () => {
    const backdrop = document.querySelector('.offcanvas-backdrop');
    if (backdrop) {
      backdrop.remove();
    }
    document.body.classList.remove('offcanvas-backdrop', 'show', 'modal-open');
    document.body.style.overflow = 'auto'; // restore scroll
  };

  if (offcanvasEl) {
    offcanvasEl.addEventListener('hidden.bs.offcanvas', handleHidden);
  }

  // Cleanup on unmount
  return () => {
    if (offcanvasEl) {
      offcanvasEl.removeEventListener('hidden.bs.offcanvas', handleHidden);
    }
  };
}, []);
 
// category api ----> category display in side filter
useEffect(() => {
  axios.post(`${API_BASE_URL}home.php`)
    .then(res => {
      if (res.data.head.code === 200 && res.data.body.category) {
        setCategories(res.data.body.category);
   
      }
    })
    .catch(err => {
      console.error("Error fetching categories:", err);
    });
}, []);



  return (
	<>
	{/* offcanvas filter start */}
	
	<div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasFilter" aria-labelledby="offcanvasFilterLabel" data-bs-backdrop="true">
		<div class="offcanvas-header bs-canvas-header side-cart-header p-3">
			<div class="d-inline-block main-cart-title" id="offcanvasFilterLabel">Filter</div>
			<button type="button" class="close-btn" data-bs-dismiss="offcanvas" aria-label="Close">
				<i class="uil uil-multiply"></i>
			</button>
		</div>
		<div class="offcanvas-body p-0">
			
			<div class="filter-items">
				<div class="filtr-cate-title">
					<h4>Age Filter</h4>
				</div>
				<div class="other-item-body scrollstyle_4">
					<div class="brand-list">
						{/* <div class="search-by-catgory">
							<div class="ui search">
							  <div class="ui left icon input swdh10 position-relative">
								<input class="prompt srch10" type="text" placeholder="Search by brand.." />
								<i class="uil uil-search icon icon1"></i>
							  </div>
							</div>
						</div> */}
						{uniqueAges.map((age, index) => {
				          const productCount = Products.filter((product) => product.age === age).length;

				return (
					<div className="form-check mb-2 d-flex justify-content-between align-items-center" key={index}>
					<div>
						<input
						className="form-check-input me-2"
						type="checkbox"
						id={`age-${index}`}
						value={age}
						onChange={handleAgeFilterChange}
						/>
						<label className="form-check-label" htmlFor={`age-${index}`}>
						{age}
						</label> &nbsp; &nbsp; &nbsp; &nbsp; 
						<span className=" ">({productCount} Products)</span>
					</div>
					
					</div>
				);
				})}


					</div>
				</div>
				<hr />
				<div class="filtr-cate-title">
					<h4>Categories</h4>
				</div>
			
					{categories.map((cat, index) => (
					<div
						className="form-check mb-2 d-flex justify-content-between align-items-center"
						key={cat.cid} // category_id as cid
					>
						<div>
						<input
							className="form-check-input me-2"
							type="checkbox"
							id={`category-${index}`}
							value={cat.cid}
							onChange={(e) => handleCategoryFilterChange(e, cat.cid)} // category_id as cid
						/>
						<label className="form-check-label" htmlFor={`category-${index}`}>
							{cat.name}
						</label>
						</div>
					</div>
					))}

			</div>
			
			
		</div>
	</div>
	{/* offcanvas filter end */}  
	{loading ? (
      <div style={{ height: '100vh', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
    <div className="loader"></div>
  </div>

    ):(

   <>
    <div class="wrapper">
		<div class="gambo-Breadcrumb">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><Link to="/">Home</Link></li>
								<li class="breadcrumb-item active" aria-current="page">Products</li>
							</ol>
						</nav>
					</div>
				</div>
			</div>
		</div>
		{messages && Object.entries(messages).map(([id, message]) => (
  <div key={id} className="message-popup">
    <FaShoppingCart className="cart-icon-addtocart" />
    <div className="message">{message}</div>
  </div>
))}

		<div class="all-product-grid">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="product-top-dt">
							<div class="product-left-title">
								{/* <h2>Vegetables & Fruits</h2> */}
							</div>
							<a href="#" class="filter-btn" data-bs-toggle="offcanvas" data-bs-target="#offcanvasFilter" 
							aria-controls="offcanvasFilter">Filters <span style={{fontSize:"14px"}}><i class="bi bi-filter"></i></span></a>
						
							
							
						</div>
					</div>
				</div>
				<div class="product-list-view">
					<div class="row">
						 {visibleProducts.map(product => (
						<div class="col-lg-3 col-md-6" key={product.id}>
						<div class="product-item mb-30">
						<a class="product-img">
							<div class="product-absolute-options ">
									{/* <span class="offer-badge-1">{product.offer}</span> */}
									{/* <span class="like-icon" title="wishlist"></span> */}
								</div>
								</a>
							<Link to={`/productdetails/${product.id}`} class="product-img">
								<img src={product.image} alt={product.name} />
								
							</Link>
							
							<div class="product-text-dt">
								{/* <p>Available<span>({product.inStock ? 'InStock' : 'Out of Stock'})</span></p> */}
								<h4>{product.name}</h4>
								<div class="product-price"><i class="bi bi-currency-rupee"></i>{product.price} <span><i class="bi bi-currency-rupee"></i>{product.oldPrice}</span></div>
								<div class="qty-cart">
									 <button
											className="add-to-cart-btn hover-btn"
											onClick={() => addToCart(product)}
											>
											<span>Add to Cart</span>
											<i className="bi bi-cart3"></i>
											</button>
								</div>
								 {/* {messages[product.id] && <div className="cart-message">{messages[product.id]}</div>} */}
							</div>
						</div>
					</div>
						))}
						
						
						<div className="col-md-12">
        <div className="more-product-btn text-center">
          <button className="show-more-btn hover-btn" onClick={() => setShowAll(!showAll)}>
            {showAll ? 'Show Less' : 'Show More'}
          </button>
        </div>
      </div>   
					</div>
				</div>
			</div>
		</div>
	</div>
	 </>
       )}
	<Footer />
	</>
  )
}

export default Product