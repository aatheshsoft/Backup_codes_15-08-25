import React, { useRef,useEffect, useState } from 'react'
import OwlCarousel from "react-owl-carousel";
import "owl.carousel/dist/assets/owl.carousel.css";
import "owl.carousel/dist/assets/owl.theme.default.css";
import Footer from '../Components/Footer';
import { Link, Links,useParams } from 'react-router-dom';
import { useCart } from '../Context/CartContext';
import axios from 'axios';
import InnerImageZoom from "react-inner-image-zoom";
import "react-inner-image-zoom/lib/InnerImageZoom/styles.min.css";
import { FaShoppingCart } from 'react-icons/fa';



const ProductDetails = () => {
  const sync1Ref = useRef(null);
  const sync2Ref = useRef(null);
  const { id } = useParams();

  
  const handleSync = (event) => {
    if (!sync2Ref.current) return; // Prevents error if ref is null
    let index = event.item.index;
    sync2Ref.current.to(index, 300, true);
  	};

    const { addToCart, updateQuantity, removeFromCart,cartItems,messages } = useCart();
  	const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
	const[products, setProducts] =  useState([])

	const [counts, setCounts] = useState({});
    const [quantity, setQuantity] = useState ({});


/* featured product carousel  settings */
  useEffect(() => {
      // Initialize Owl Carousel after component mounts
      window.$('.owl-carousel').owlCarousel({
        loop: true,
        margin: 10,
        nav: true,
        autoplay: true,
        autoplayTimeout: 5000,
        responsive: {
          0: {
            items: 1
          },
          600: {
            items: 2
          },
          1000: {
            items: 5
          }
        }
      });
    }, []);

    
		useEffect(() => {
				window.scrollTo(0, 0); 
			}, []);




		useEffect(() => {
			axios.post(`${API_BASE_URL}product_details.php`, {
			product_id: id
			})
			.then(res => {
			if (res.data.head.code === 200 && res.data.body.product_detail) {
				setProducts(res.data.body.product_detail.map(item => ({
		...item,
		id: item.product_id, // change product_id to id for cart context purpose                                                  
		name:item.product_name
		})));
 
		//console.log(res.data.body.product_detail[0])
      }
    })
    .catch(err => {
      console.error("Error fetching product details:", err);
    });
  }, [id]);


 const [tempQuantities, setTempQuantities] = useState({});

  const isInCart = (productId) =>
    cartItems.some(item => item.id === productId);

  const getCartQuantity = (productId) => {
    const item = cartItems.find(item => item.id === productId);
    return item ? item.quantity : null;
  };

  const handleQuantityChange = (productId, amount) => {
    if (isInCart(productId)) {
      const currentQty = getCartQuantity(productId);
      const newQty = Math.max(1, currentQty + amount);
      updateQuantity(productId, amount); // updates from CartContext
    } else {
      setTempQuantities(prev => {
        const currentQty = prev[productId] || 1;
        const newQty = Math.max(1, currentQty + amount);
        return { ...prev, [productId]: newQty };
      });
    }
  };

  const getQuantityToDisplay = (productId) => {
    return getCartQuantity(productId) ?? (tempQuantities[productId] || 1);
  };



	  

// const handleIncrement = (productId) => {
//   setCounts((prev) => ({
//     ...prev,
//     [productId]: prev[productId] + 1,
//   }));
//   updateQuantity(productId, 1);
// console.log("qty : " , updateQuantity)
// };

 // const handleDecrement = (productId) => {
//   setCounts((prev) => {
//     const updated = Math.max(1, prev[productId] - 1);
//     return { ...prev, [productId]: updated };
//   });
//   updateQuantity(productId, -1);   
  
// 	console.log("qty : ", updateQuantity)

// };




  return (
	<>
    <div class="wrapper">
		<div class="gambo-Breadcrumb">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><Link to ="/">Home</Link></li>
								<li class="breadcrumb-item"><Link >Productdetails</Link></li>
								{/* <li class="breadcrumb-item active" aria-current="page">Product Title</li> */}
							</ol>
						</nav>
					</div>
				</div>
			</div>
		</div>
			<>
			{messages && Object.entries(messages).map(([id, message]) => (
			<div key={id} className="message-popup">
				<FaShoppingCart className="cart-icon-addtocart"/>
				<div className="message">{message}</div>
			</div>
			))}
		</>
		<div class="all-product-grid">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="product-dt-view">
							<div class="row">
								<div class="col-lg-4 col-md-4">
                                <div className="owl-container">
										{/* Large Image Carousel */}
										{products.length > 0 && (
												<>
													{/* Large Image Carousel */}
													<OwlCarousel
														ref={(el) => (sync1Ref.current = el)}
														items={1}
														loop
														margin={10}
														dots={false}
														autoplay={false}
														smartSpeed={1000}
														onChanged={handleSync}
														className="owl-theme"
														>
														{products.map((item, index) => (
															<div className="item" key={`large-${index}`}>
																<InnerImageZoom
																	src={item.image}
																	zoomSrc={item.image}            
																	zoomType="hover"                 
																	zoomScale={2.5}                  
																	zoomPreload={true}              
																	alt={`Product Zoom ${index}`}
																	width="100%"
																	hideHint={false} 
																/>
															</div>
														))}
													</OwlCarousel>

                                                     <br />
													{/* Small Thumbnail Carousel */}
													<OwlCarousel
													ref={(el) => (sync2Ref.current = el)}
													items={4}
													loop
													margin={10}
													nav={false}
													dots={false}
													autoplay={false}
													smartSpeed={1000}
													center
													className="owl-theme"
													>
													{products.map((item, index) => (
														<div
														className="item"
														key={`thumb-${index}`}
														onClick={() => sync1Ref.current?.to(index, 300, true)}
														>
														<img src={item.image} alt={`Thumb ${index}`} />
														</div>
													))}
													</OwlCarousel>
												</>
												)}

										</div>
								</div>
								<div class="col-lg-8 col-md-8">  
                                    
									<div class="product-dt-right">

										
										<div className="product-radio">
												{products.length === 0 ? (
													
													<div> </div>
												) : (
													products.map((item, index) => (
														 
													<div key={item.id}>
														<h2>{item.product_name}</h2>

														<div className="no-stock">
														<p className="pd-no">
															Product No.<span>{item.product_code}</span>
														</p>
														<p className="stock-qty">
															Available<span>{item.stock ? '(In Stock)' : '(Out of Stock)'} - {item.stock}</span>
														</p>
														</div>
														{/* <p className="pp-descp">
															{item.shortdescription}</p> */}

														<div className="product-group-dt">
														<ul>
															<li>
															<div className="main-price color-discount">
																Discount Price<span><i className="bi bi-currency-rupee"></i>{item.online_rate}</span>
															</div>
															</li>
															<li>
															<div className="main-price mrp-price">
																MRP Price<span><i className="bi bi-currency-rupee"></i>{item.mrp_rate}</span>
															</div>
															</li>
														</ul>

														<ul className="gty-wish-share">
																<li>
																<div className="qty-product">
																	<div className="quantity buttons_added">
																	<input
																		type="button"
																		value="-"
																		className="minus minus-btn"
																		onClick={() => handleQuantityChange(item.id, -1)}
																	/>
																	<input
																		type="number"
																		value={getQuantityToDisplay(item.id)}
																		readOnly
																		className="input-text qty text"
																	/>
																	<input
																		type="button"
																		value="+"
																		className="plus plus-btn"
																		onClick={() => handleQuantityChange(item.id, 1)}
																	/>
																	</div>
																</div>
																</li>
															</ul>

														<ul className="ordr-crt-share">
															<li>
															<button className="add-cart-btn hover-btn" 
															onClick={() => {
																const finalQty = getQuantityToDisplay(item.id); 

																addToCart({
																	...item,
																	price: item.online_rate,
																	oldPrice: item.mrp_rate,
																	quantity: finalQty,
																});

																// Clear temp quantity
																setTempQuantities(prev => {
																	const updated = { ...prev };
																	delete updated[item.id];
																	return updated;
																});
																}}
																>
																<i className="bi bi-cart3"></i>Add to Cart
															</button>
															</li>
														</ul>
														</div>
													</div>
													))
												)}
											</div>

										{/* <div class="pdp-details">
											<ul>
												<li>
													<div class="pdp-group-dt">
														<div class="pdp-icon"><i class="uil uil-usd-circle"></i></div>
														<div class="pdp-text-dt">
															<span>Lowest Price Guaranteed</span>
															<p>Get difference refunded if you find it cheaper anywhere else.</p>
														</div>
													</div>
												</li>
												<li>
													<div class="pdp-group-dt">
														<div class="pdp-icon"><i class="uil uil-cloud-redo"></i></div>
														<div class="pdp-text-dt">
															<span>Easy Returns & Refunds</span>
															<p>Return products at doorstep and get refund in seconds.</p>
														</div>
													</div>
												</li>
											</ul>
										</div> */}
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="row">
					
					<div class="col-lg-12 col-md-12">
						<div class="pdpt-bg">
							<div class="pdpt-title">
								<h4>Product Details</h4>
							</div>
							<div class="pdpt-body scrollstyle_4">
								<div class="pdct-dts-1">
									<div class="pdct-dt-step">
										<h4>Description</h4>
										{products.length === 0 ? (
													
													<div></div>
												) : (
													products.map((item, index) => (
														<p>{item.description}</p>
													)))}
														</div>
									{/* <div class="pdct-dt-step">
										<h4>Benefits</h4>
										<div class="product_attr">
											Aliquam nec nulla accumsan, accumsan nisl in, rhoncus sapien.<br />
											In mollis lorem a porta congue.<br />
											Sed quis neque sit amet nulla maximus dignissim id mollis urna.<br />
											Cras non libero at lorem laoreet finibus vel et turpis.<br />
											Mauris maximus ligula at sem lobortis congue.<br />
										</div>
									</div>
									<div class="pdct-dt-step">
										<h4>How to Use</h4>
										<div class="product_attr">
											The peeled, orange segments can be added to the daily fruit bowl, and its juice is a refreshing drink.
										</div>
									</div>
									<div class="pdct-dt-step">
										<h4>Seller</h4>
										<div class="product_attr">
											ABCDEFGH
										</div>
									</div>
									<div class="pdct-dt-step">
										<h4>Disclaimer</h4>
										<p>Phasellus efficitur eu ligula consequat ornare. Nam et nisl eget magna aliquam consectetur. Aliquam quis tristique lacus. Donec eget nibh et quam maximus rutrum eget ut ipsum. Nam fringilla metus id dui sollicitudin, sit amet maximus sapien malesuada.</p>
									</div> */}
								</div>			
							</div>					
						</div>
					</div>
				</div>
			</div>
		</div>
{/* 		<!-- Featured Products Start -->
 */}		
 	{/* <div class="section145">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="main-title-tt">
							<div class="main-title-left">
								<span>For You</span>
								<h2>Top Featured Products</h2>
							</div>
							<a href="#" class="see-more-btn">See All</a>
						</div>
					</div>
					<div class="col-md-12">
                        
                            <div class="owl-carousel featured-slider owl-theme" >
                            {Featuredproducts.map ((product) => (
							<div class="item" key={product.id}>
								<div class="product-item">
									<a href="single_product_view.html" class="product-img">
										<img src={product.image} alt={product.title} />
										<div class="product-absolute-options">
											<span class="offer-badge-1">{product.offer}</span>
											<span class="like-icon" title="wishlist"></span>
										</div>
									</a>
									<div class="product-text-dt">
										<p>Available<span>{product.inStock ? "InStock" : "Out of Stock"}</span></p>
										<h4>Product Title Here</h4>
										<div class="product-price"><i class="bi bi-currency-rupee"></i>{product.price} <span><i class="bi bi-currency-rupee"></i>{product.oldPrice}</span></div>
										<div className="qty-cart">
											<button
											className="add-to-cart-btn hover-btn"
											onClick={() => addToCart(product)}
											>
											<span>Add to Cart</span>
											<i className="bi bi-cart3"></i>
											</button>
										</div>
									</div>
								</div>
							</div>
                             ))}
                            </div>

                       
						
					</div>
				</div>
			</div>
		</div>		 */}

          {/*   <!-- Featured Products End -->    */}	

 	</div>
   <Footer />
  </>
  )
}

export default ProductDetails