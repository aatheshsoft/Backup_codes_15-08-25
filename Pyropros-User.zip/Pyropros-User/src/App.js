import React from 'react';
import './App.css';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Header from './Components/Header';
import Home from './Pages/Home';
import Product from './Pages/Product'
import ProductDetails from './Pages/ProductDetails';
import Wishlist from './Pages/Wishlist';
import OrderHistory from './Pages/OrderHistory';
import MyAccount from './Pages/MyAccount';
import Checkout from './Pages/Checkout';
import Signin from './Components/Signin';
import Signup from './Components/Signup';
import About from './Pages/About';
import OrderPlaced from './Pages/OrderPlaced';
import Contactus from './Pages/Contactus';
import QuickPurchase from './Pages/QuickPurchase';
import Privacy from './Pages/Privacy';
import Terms from './Pages/Terms';
import ShopbyCategory from './Pages/ShopbyCategory';
import SearchProducts from './Pages/SearchProducts';
import ShippingPolicy from './Pages/ShippingPolicy';

function App() {
  return (
    <BrowserRouter>
      <Header />
      <Routes>
        
        <Route path="/" element={<Home />} />
        <Route path="/signin" element={<Signin />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/product/:id" element={<Product />} />
        <Route path="/terms" element = {<Terms />} />
        <Route path="/productdetails/:id" element = {<ProductDetails />} />
        <Route path="/shopbycategory/:category_id" element ={<ShopbyCategory />} />
        <Route path="/searchproducts" element = {<SearchProducts />} />
        <Route path="/wishlist" element = {<Wishlist />} />
        <Route path="/orderhistory" element = {<OrderHistory />} />
        <Route path="/myaccount" element = {<MyAccount />} />
        <Route path="/checkout" element = {<Checkout />} />
        <Route path="/orderplaced" element = {<OrderPlaced />} />
        <Route path="/about" element = {<About />} />
        <Route path="/contactus" element = {<Contactus />} />
        <Route path="/quickpurchase" element = {<QuickPurchase />} />
        <Route path="/privacy" element = {<Privacy />} />
        <Route path="/terms" element = {<Terms />} />
        <Route path="/shippingpolicy" element = {<ShippingPolicy />} />
        
      </Routes>
    </BrowserRouter>
  );
}

export default App;
