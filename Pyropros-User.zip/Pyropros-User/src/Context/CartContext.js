// src/context/CartContext.js
import React, { createContext, useContext, useState, useEffect } from 'react';

// Create context
const CartContext = createContext();

// Custom hook for easy access
export const useCart = () => useContext(CartContext);

// Provider component
export const CartProvider = ({ children }) => {
  const [cartItems, setCartItems] = useState(() => {
    const stored = localStorage.getItem("cartItems");
    return stored ? JSON.parse(stored) : [];
  });

const [messages, setMessages] = useState({});

const clearCart = () => {
  setCartItems([]);
};


  useEffect(() => {
    localStorage.setItem("cartItems", JSON.stringify(cartItems));
  }, [cartItems]);

  const addToCart = (product) => {
  setCartItems(prev => {
    const existing = prev.find(item => item.id === product.id);

    // Show appropriate message
    setMessages(prevMessages => ({
      ...prevMessages,
      [product.id]: existing
        ? "This product is already in your cart."
        : "Item added to cart!"
    }));

    // Clear the message after 5 seconds

    setTimeout(() => {
      setMessages(prevMessages => {
        const updatedMessages = { ...prevMessages };
        delete updatedMessages[product.id];
        return updatedMessages;
      });
    }, 2000);

    // If product exists, return existing state
    if (existing) return prev;

    // If new product, add to cart with initial quantity
return [...prev, { ...product, quantity: product.quantity || 1 }];
  });
};


const updateQuantity = (productId, amount) => {
  setCartItems(prev =>
    prev.map(item =>
      item.id === productId
        ? { ...item, quantity: Math.max(1, item.quantity + amount) }
        : item
    )
  );
};

  const removeFromCart = (productId) => {
    setCartItems(prev => prev.filter(item => item.id !== productId));
  };

  return (
    <CartContext.Provider value={{ cartItems, addToCart, updateQuantity, removeFromCart, clearCart, messages }}>
      {children}
    </CartContext.Provider>
  );
};
