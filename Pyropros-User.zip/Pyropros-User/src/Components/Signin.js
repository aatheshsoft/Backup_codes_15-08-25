import React from 'react'
import { Link } from 'react-router-dom'

const Signin = () => {
  return (
    <div class="sign-inup">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-lg-5">
					<div class="sign-form">
						<div class="sign-inner">
							<div class="sign-logo" id="logo">
								<a href="index.html"><img src="images/logo.svg" alt="" /></a>
								<a href="index.html"><img class="logo-inverse" src="images/dark-logo.svg" alt="" /></a>
							</div>
							<div class="form-dt">
								<div class="form-inpts checout-address-step">
									<form>
										<div class="form-title"><h6>Sign In</h6></div>
										<div class="form-group pos_rel mb-3">
											<input id="phone[number]" name="phone" type="text" placeholder="Enter Phone Number" class="form-control lgn_input" required="" />
											<i class="uil uil-mobile-android-alt lgn_icon"></i>
										</div>
										<div class="form-group pos_rel mb-3">
											<input id="password1" name="password1" type="password" placeholder="Enter Password" class="form-control lgn_input" required="" />
											<i class="uil uil-padlock lgn_icon"></i>
										</div>
										<button class="login-btn hover-btn h_50" type="submit">Sign In Now</button>
									</form>
								</div>
								<div class="password-forgor">
									<a href="forgot_password.html">Forgot Password?</a>
								</div>
								<div class="signup-link">
									<p>Don't have an account? - <Link to="/signup">Sign Up Now</Link></p>
								</div>
							</div>
						</div>
					</div>
					<div class="copyright-text text-center mt-4">
						<i class="uil uil-copyright"></i>Copyright 2024 <b>Gambolthemes</b> . All rights reserved
					</div>
				</div>
			</div>
		</div>
	</div>
  )
}

export default Signin