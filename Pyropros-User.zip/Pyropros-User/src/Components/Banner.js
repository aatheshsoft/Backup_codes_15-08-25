import React, { useEffect, useState,useRef } from "react";
import Slider from "react-slick";
import Skeleton from "react-loading-skeleton";
import "react-loading-skeleton/dist/skeleton.css";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

const Banner = () => {
  const [banners, setBanners] = useState([]);
  const [loading, setLoading] = useState(true);

  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

  useEffect(() => {
    const fetchBanners = async () => {
      try {
        const response = await fetch(`${API_BASE_URL}banner.php`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
        });

        const data = await response.json();

        if (data.head.code === 200 && data.head.msg === "success") {
          setBanners(data.body || []);
        } else {
          console.error("Invalid banner response", data);
        }
      } catch (error) {
        console.error("Error fetching banners:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchBanners();
  }, []);

const sliderRef = useRef();


const settings = {
  dots: false,
  infinite: banners.length > 1,
  speed: 500,
  slidesToShow: 3,
  slidesToScroll: 1,
  autoplay: true,
  autoplayTimeout:3000,  
  smartSpeed: 500,// slider speed 
  arrows: true,
  pauseOnHover: false,
  beforeChange: () => {
    // Prevent accessibility warning: blur any focused item before the slide hides
    if (document.activeElement) {
      document.activeElement.blur();
    }
  },
  responsive: [
    { breakpoint: 1000, settings: { slidesToShow: 3 } },
    { breakpoint: 600, settings: { slidesToShow: 2 } },
    { breakpoint: 480, settings: { slidesToShow: 1 } },
  ],
};



  return (
    
    <div className="main-banner-slider">
      <div className="container-fluid">
        <div className="row">
          <div className="col-md-12">
            <Slider ref={sliderRef} {...settings} className="offers-banner owl-theme">
              {loading
                ? Array.from({ length: 3 }).map((_, index) => (
                    <div className="item" key={index}>
                      <div className="offer-item">
                        <Skeleton
                          height={200}
                          width={"100%"}
                          baseColor="#e0e0e0"
                          highlightColor="#f5f5f5"
                        />
                      </div>
                    </div>
                  ))
                : banners.map((banner) => (
                    <div className="item" key={banner.id}>
                      <div className="offer-item">
                        <div className="offer-item-img">
                          <div className="gambo-overlay"></div>
                          <img
                            src={banner.image}
                            alt=""
                            loading="lazy"
                            style={{ width: "100%", height: "auto" }}
                          />
                        </div>
                      </div>
                    </div>
                  ))}
            </Slider>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Banner;
