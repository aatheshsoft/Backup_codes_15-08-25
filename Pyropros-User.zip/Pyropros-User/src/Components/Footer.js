import React,{useState,useEffect} from 'react'
import { Link } from 'react-router-dom'
import axios from 'axios';

const Footer = () => {

     const [contactData, setContactData] = useState(null);
     const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
     const [visitorcount, setVisitorCount] = useState();
     
 useEffect(() => {
	const fetchContactData = async() => {
		try{
			const response = await axios.post(`${API_BASE_URL}content.php`)
			 const {body} = response.data;
			 setContactData(body.contact);
             setVisitorCount(body.visitor_count);
		} catch(error){
			alert("Error fetching the contact data", error)
		    console.error("Error fetching the contact data", error);
		}
	}
	fetchContactData();
  },[])


  return (
    <footer class="footer">
    <div class="footer-first-row">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-6 ">
                    <ul class="call-email-alt">
                        <li><a href="#" class="callemail"><i class="bi bi-telephone"></i>{contactData?.phonenumber}</a></li>
                        <li><a href="#" class="callemail"><i class="uil uil-envelope-alt"></i>{contactData?.email}</a></li>
                    </ul>
                </div>
                <div class="col-md-6 col-6">
                    <div class="social-links-footer">
                        <ul>
                            <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                        </ul>
                    </div>
                </div>				
            </div>
        </div>
    </div>
    <div class="footer-second-row">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 col-md-6 col-6">
                    <div class="second-row-item">
                        <h4>Address</h4>
                        <ul>
                            <li><p style={{color:"white"}}>{contactData?.address}</p></li>
                           
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-6">
                    <div class="second-row-item">
                       <h4>Quick links</h4>
                        <ul>
                            <li><Link to="/about"><i class="bi bi-arrow-right"></i> About</Link></li>
                                <li><Link to="/contactus"><i class="bi bi-arrow-right"></i> Contact</Link></li>
                                <li><Link to="/privacy">  <i class="bi bi-arrow-right"></i> Privacy Policy</Link></li>
                                <li><Link to="/terms"><i class="bi bi-arrow-right"></i> Term & Conditions</Link></li>
                                <li><Link to="/shippingpolicy"><i class="bi bi-arrow-right"></i> Shipping Policy</Link></li>

                        </ul>
                    </div>
                </div>
              
                <div class="col-lg-4 col-md-5  ">
                
                    <div class="second-row-item-payment">
                        <h2 style={{color:"white"}}>VisitorCount : {visitorcount?.visitor_count}</h2> <br />
                        <p style={{color:"white"}}>Please Note: The honorable Supreme Court of India has banned sales of firecrackers from 2018. We obey the order and we don't permit online purchase of crackers. For your convenience, we show our products on the website. We request you to add your products to the Quick Purchase and submit the required crackers through the enquiry button. We will contact you within 24 hrs and confirm the order through WhatsApp or phone call. Please add and submit your enquiries and enjoy your Diwali with ARK Crackers.</p>

                    </div>
                   
                </div>
                
            </div>
        </div>
    </div>
    <div class="footer-last-row">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="">
                       
                        <div class="copyright-text">
                            <i class="uil uil-copyright"></i>Copyright {new Date().getFullYear()}  <b>Pyropros</b> . All rights reserved. Developed by <b>Aathesh soft solutions</b>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
  )
}

export default Footer