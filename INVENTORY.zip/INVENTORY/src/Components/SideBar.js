import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import './Sidebar.css';
import {
  FaTachometerAlt, FaCartPlus, FaBoxOpen, FaChartLine, FaUser,
  FaFileInvoiceDollar, FaWarehouse, FaTh
} from 'react-icons/fa';
import Logo from '../Assets/logo.jpg';
import { GrDocumentUser } from "react-icons/gr";
import { RiBillLine, RiProfileLine } from "react-icons/ri";
import { AiOutlineDeliveredProcedure } from "react-icons/ai";
import { IoClose } from "react-icons/io5";

const Sidebar = ({ isMobileOpen, toggleSidebar }) => {
  const [isOpen, setIsOpen] = useState(false);

  const toggleDropdown = () => setIsOpen(prev => !prev);

  const handleLinkClick = () => {
    setIsOpen(false);         
    toggleSidebar();
  };

  return (
    <aside className={`sidebar ${isMobileOpen ? 'mobile-show' : ''}`}>
      <div className="sidebar-logo">
        <img src={Logo} alt="Logo" />
        {/* Close Button - visible only on mobile */}
        <button className="close-btn" onClick={toggleSidebar}>
          <IoClose size={24} />
        </button>
      </div>

      <ul className="sidebar-menu">
        <li><NavLink to="/" onClick={handleLinkClick}><FaTachometerAlt className="icon" />Dashboard</NavLink></li>
        <li><NavLink to="/" onClick={handleLinkClick}><FaTh className="icon" />Master</NavLink></li>
        <li><NavLink to="/customerlist" onClick={handleLinkClick}><FaUser className="icon" />Customers</NavLink></li>
        <li><NavLink to="/suppliers" onClick={handleLinkClick}><GrDocumentUser className="icon" />Suppliers</NavLink></li>
        <li><NavLink to="/estimate" onClick={handleLinkClick}><RiBillLine className="icon" />Estimate</NavLink></li>
        <li><NavLink to="/invoice" onClick={handleLinkClick}><RiProfileLine className="icon" />Proforma</NavLink></li>
        <li><NavLink to="/invoice" onClick={handleLinkClick}><AiOutlineDeliveredProcedure className="icon" />Delivery Note</NavLink></li>
        <li><NavLink to="/invoice" onClick={handleLinkClick}><FaFileInvoiceDollar className="icon" />Invoice</NavLink></li>
        <li><NavLink to="/purchaselist" onClick={handleLinkClick}><FaBoxOpen className="icon" />Purchase List</NavLink></li>
        <li><NavLink to="/orders" onClick={handleLinkClick}><FaCartPlus className="icon" />Orders</NavLink></li>
        <li><NavLink to="/stock" onClick={handleLinkClick}><FaWarehouse className="icon" />Stock</NavLink></li>
        <li className={`sidebar-dropdown ${isOpen ? 'active' : ''}`}>
          <div
            className="sidebar-link"
            onClick={toggleDropdown}
            style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '5px', cursor: 'pointer' }}
          >
            <span style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
              <FaChartLine className="icon" /> Reports
            </span>
            <i className={`bi ${isOpen ? 'bi-chevron-down' : 'bi-chevron-right'}`}></i>
          </div>

          {isOpen && (
            <ul className="sidebar-submenu">
              <li><NavLink to="/gstreport" onClick={handleLinkClick}>GST Report</NavLink></li>
              <li><NavLink to="/paidreport" onClick={handleLinkClick}>Paid Report</NavLink></li>
              <li><NavLink to="/purchasereport" onClick={handleLinkClick}>Purchase Report</NavLink></li>
            </ul>
          )}
        </li>
      </ul>
    </aside>
  );
};

export default Sidebar;
