import React, { useState, useEffect, useRef } from 'react';
import './Header.css';
import { FaBars, FaUserCircle } from 'react-icons/fa';
import { Link } from 'react-router-dom';

const Header = ({ toggleSidebar }) => {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dropdownRef = useRef();

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <header className="header">
      <div className="left-section">
        <FaBars className="menu-icon" onClick={toggleSidebar} />
      </div>

      <div className="right-section" ref={dropdownRef}>
        <div className="user-box" onClick={() => setDropdownOpen(!dropdownOpen)}>
          <FaUserCircle className="user-icon" />
          <span className="username">Sample</span>
        </div>

        {dropdownOpen && (
          <div className="dropdown-menu">
             <Link to ="/employee"><div className="dropdown-item">Employee</div></Link>
            <div className="dropdown-item">Settings</div>
            <div className="dropdown-item">Logout</div>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
