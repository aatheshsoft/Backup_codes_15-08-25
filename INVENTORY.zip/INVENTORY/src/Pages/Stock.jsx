import React, { useState } from 'react';
import './Stock.css';



const Stock = () => {
    const stockData = [
  { id: 1, name: 'Cracker Box 1', Stcok: '150',code:"F106"  },
  { id: 2, name: 'Rocket Pack' , Stcok: '150',code:"F107" },
  { id: 3, name: 'Flower Pot', Stcok: '150',code:"F108" },
  // Add more dummy data here
];
  const [searchTerm, setSearchTerm] = useState('');

  const filteredData = stockData.filter(item =>
    item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.code.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="stock-container">
      <div className="stock-header">
        <h3>Stock Summary</h3>
        <input
          type="text"
          className="search-bar"
          placeholder="Search by name or code..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>
      <div className="table-responsive">
        <table className="stock-table">
          <thead>
            <tr>
              <th>S.No</th>
              <th>Product Code</th>
              <th>Product Name</th>
              <th>Stock</th>
             
            </tr>
          </thead>
          <tbody>
            {filteredData.map((item, index) => (
              <tr key={item.id}>
                <td>{index + 1}</td>
                <td>{item.code}</td>
                <td>{item.name}</td>
                <td>{item.Stcok}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Stock;
