import React, { useEffect, useState } from "react";
import Logo from "../Assets/p-logo.png";
import Image from "../Assets/p-logo.png";
import './PrintOrder.css'

const PrintOrder = () => {
  const [orderData, setOrderData] = useState(null);
  const [vechicleno, setVehicleNp] = useState("");
  const [transport, setTransport] = useState("");

  useEffect(() => {
    const mockData = {
      order_id: "INV1001",
      order_date: "2025-07-29",
      order_time: "11:30 AM",
      vehicle_no: "TN-00-AB-1234",
      transport: "ABC Transport",
      seller_detail: {
        address: "123 Market Street",
        city: "Test",
        state: "Tamil Nadu",
        pincode: "626123",
        phone: "1234567890",
        gst_no: "33AHEPV6120H1Z2",
      },
      buyer_detail: {
        name: "Test Traders",
        tax_number: "GST123456789",
        address: "45 Gandhi Road, Test",
        telephone: "1122334455",
      },
      bill_detail: [
        {
          product_name: "Sample Product 1",
          hsn_code: "3604",
          amount_with_tax_per_product: "100.00",
          tax_percentage: 12,
          qty: 10,
          unit: "pcs",
          total_with_gst_per_product: "1120.00",
        },
        {
          product_name: "Sample Product 2",
          hsn_code: "3604",
          amount_with_tax_per_product: "50.00",
          tax_percentage: 12,
          qty: 5,
          unit: "pcs",
          total_with_gst_per_product: "280.00",
        },
      ],
      final_billing: [
        {
          tax12: {
            without_gst: 1250,
            gst_amt: 180,
          },
        },
      ],
    };

    setOrderData(mockData);
    setVehicleNp(mockData.vehicle_no);
    setTransport(mockData.transport);
  }, []);

  const bill_detail = orderData?.bill_detail || [];
  const final_billing = orderData?.final_billing || [];

  let totalAmount = 0;
  bill_detail.forEach((item) => {
    totalAmount += parseFloat(item.total_with_gst_per_product) || 0;
  });

  let taxSummary = {};
  final_billing.forEach((item) => {
    Object.keys(item).forEach((taxKey) => {
      if (item[taxKey] && typeof item[taxKey] === "object") {
        const gstRate = parseInt(taxKey.replace("tax", ""), 10);
        if (!taxSummary[gstRate]) {
          taxSummary[gstRate] = {
            taxableValue: 0,
            cgst: 0,
            sgst: 0,
            totalTax: 0,
          };
        }

        taxSummary[gstRate].taxableValue += item[taxKey].without_gst || 0;
        taxSummary[gstRate].cgst += (item[taxKey].gst_amt || 0) / 2;
        taxSummary[gstRate].sgst += (item[taxKey].gst_amt || 0) / 2;
        taxSummary[gstRate].totalTax += item[taxKey].gst_amt || 0;
      }
    });
  });

  const numberToWords = (num) => {
    if (num === 0) return "Zero";
    const ones = [
      "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine",
      "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen",
      "Seventeen", "Eighteen", "Nineteen"
    ];
    const tens = [
      "", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"
    ];
    const convertBelowThousand = (n) => {
      if (n < 20) return ones[n];
      if (n < 100) return tens[Math.floor(n / 10)] + (n % 10 !== 0 ? " " + ones[n % 10] : "");
      return ones[Math.floor(n / 100)] + " Hundred" + (n % 100 !== 0 ? " and " + convertBelowThousand(n % 100) : "");
    };

    let integerPart = Math.floor(num);
    let decimalPart = Math.round((num - integerPart) * 100);

    let result = "";
    if (integerPart > 0) {
      let crores = Math.floor(integerPart / 10000000);
      let lakhs = Math.floor((integerPart % 10000000) / 100000);
      let thousands = Math.floor((integerPart % 100000) / 1000);
      let hundreds = integerPart % 1000;

      if (crores) result += convertBelowThousand(crores) + " Crore ";
      if (lakhs) result += convertBelowThousand(lakhs) + " Lakh ";
      if (thousands) result += convertBelowThousand(thousands) + " Thousand ";
      if (hundreds) result += convertBelowThousand(hundreds);
    } else {
      result = "Zero";
    }

    result = result.trim();
    if (decimalPart > 0) {
      result += " and " + convertBelowThousand(decimalPart) + " Paise";
    }

    return result + " Only";
  };

  useEffect(() => {
    if (!orderData?.buyer_detail) return;
    const buyerName = orderData.buyer_detail.name?.replace(/\s+/g, '_') || 'Invoice';
    const originalTitle = document.title;

    document.title = buyerName;

    const timer = setTimeout(() => {
      window.print();
      setTimeout(() => {
        document.title = originalTitle;
      }, 1000);
    }, 1500);

    return () => {
      clearTimeout(timer);
      document.title = originalTitle;
    };
  }, [orderData]);

  return (
    <div className="invoice-container" style={{
      width: "100%", 
      maxWidth: "100%", 
      margin: "auto", 
      padding: "10px",
      fontFamily: "Arial, sans-serif",
      // overflowX: "auto"
    }}>
      <div className="position-relative mb-3">
              {/* Row for logo + image */}
              <div className="d-flex justify-content-between align-items-start px-2">
                {/* Left Logo */}
                <div>
                  <img
                    src={Logo}
                    alt="Poongodi Traders Logo"
                    style={{ maxWidth: "80px", height: "48px" }}
                  />
                </div>

                {/* Right Image */}
                
              

              {/* Center Text */}
              {orderData && orderData.seller_detail && (
                <>
              <div className="text-center mt-2 px-2" >
                <h5 className="mb-1 fw-bold">Tax Invoice</h5>
                <h5 className="mb-1 fw-bold">Company Name</h5>
                <p className="mb-1">{orderData.seller_detail.address}</p>
                <p className="mb-1">
                  {orderData.seller_detail.city}, {orderData.seller_detail.state} - {orderData.seller_detail.pincode}
                </p>
                <p className="mb-1">Phone: {orderData.seller_detail.phone}</p>
                <p className="mb-1">GST No: {orderData.seller_detail.gst_no}</p>
              </div>
              </>
              )}
              <div>
                  <img
                    src={Image}
                    alt="Lakshmi"
                    style={{ maxWidth: "50px", height: "55px", objectFit: "contain" }}
                  />
                </div>
            </div>
            </div>
<hr />

<div
  style={{
    display: "flex",
    justifyContent: "space-between",
    borderBottom: "1px solid black",
    paddingBottom: "10px",
    flexWrap: "wrap",
  }}
>
  
  {orderData ? (
    <div>
      <strong>Invoice No:</strong> {orderData.order_id}
      <br />
      <strong>Dated:</strong> {orderData?.order_date || ""} & {orderData?.order_time || ""}
      </div>
  ) : (
    <p></p>
  )}
</div>

  <div style={{
          marginTop: "10px",
          borderBottom: "1px solid black",
          paddingBottom: "10px",
          display: "flex",
          justifyContent: "space-between",
        }}>
<div>
      {orderData && orderData.buyer_detail && (
    <>
    <strong>Buyer (Bill to)</strong><br />
    <strong>{orderData?.buyer_detail?.name}</strong>,<br />
    {orderData?.buyer_detail?.tax_number && (
      <>
        {orderData.buyer_detail.tax_number}<br />
      </>
    )}
    {orderData?.buyer_detail?.address}<br />
    {orderData?.buyer_detail?.telephone}
  </>
  
 )}

</div>
    <div>
    <strong>Dated:</strong> {orderData?.order_date || ""} & {orderData?.order_time || ""}<br />
    <strong>Vehicle Number :</strong> <span>{vechicleno}</span><br />
    <strong>Transport :</strong> <span>{transport}</span>
    </div>

      </div>
      
      <table style={{ width: "100%", borderCollapse: "collapse", marginTop: "5px" }}>
        <thead>
          <tr>
            <th style={{ border: "1px solid black", padding: "5px" }}>S No</th>
            <th style={{ border: "1px solid black", padding: "5px" }}>Description of Goods</th>
            <th style={{ border: "1px solid black", padding: "5px",textAlign:"center" }}>HSN/SAC</th>
            <th style={{ border: "1px solid black", padding: "5px",textAlign:"center" }}>Rate </th>
            <th style={{ border: "1px solid black", padding: "5px",textAlign:"center" }}>GST Rate</th>
            <th style={{ border: "1px solid black", padding: "5px",textAlign:"center" }}>Quantity</th>
            
            <th style={{ border: "1px solid black", padding: "5px",textAlign:"right"  }}>Amount</th>
          </tr>
        </thead>
        <tbody>
          {orderData && orderData.bill_detail ? (
            orderData.bill_detail.map((item, index) => (
              <tr key={index}>
                <td style={{ border: "1px solid black", padding: "5px" }}>{index + 1}</td>
                <td style={{ border: "1px solid black", padding: "5px" }}>{item.product_name}</td>
                <td style={{ border: "1px solid black", padding: "5px",textAlign:"center" }}>{item.hsn_code}</td>
                <td style={{ border: "1px solid black", padding: "5px",textAlign:"center" }}>{Number(item.amount_with_tax_per_product || 0).toFixed(2)}</td>

                <td style={{ border: "1px solid black", padding: "5px",textAlign:"center" }}>{item.tax_percentage}%</td>
                <td style={{ border: "1px solid black", padding: "5px",textAlign:"center" }}>{item.qty} - {item.unit}</td>
                <td align="right" style={{ border: "1px solid black", padding: "5px" ,textAlign:"right" }}>
                    {Number(item.total_with_gst_per_product || 0).toFixed(2)}
                  </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="7" style={{ textAlign: "center", padding: "10px" }}>Loading...</td>
            </tr>
          )}
        </tbody>

      </table>
          <div style={{ textAlign: "right", marginTop: "10px" }}>
              <strong>Sub-total : Rs. {Math.round(totalAmount).toFixed(2)} </strong>
            </div>
            <div style={{ textAlign: "right", marginTop: "10px" }}>
              <strong>CGST : Rs. {Object.values(taxSummary).reduce((acc, item) => acc + item.cgst, 0).toFixed(2)} </strong>
            </div>
            <div style={{ textAlign: "right", marginTop: "10px" }}>
              <strong>SGST : Rs. {Object.values(taxSummary).reduce((acc, item) => acc + item.sgst, 0).toFixed(2)} </strong>
            </div>
            <div style={{ textAlign: "right", marginTop: "10px" }}>
              <strong>
                Grand Total : Rs.{" "}
                {Math.round(
                  totalAmount +
                  Object.values(taxSummary).reduce((acc, item) => acc + item.cgst, 0) +
                  Object.values(taxSummary).reduce((acc, item) => acc + item.sgst, 0)
                ).toFixed(2)}
              </strong>
        </div>
      <div style={{ borderTop: "1px solid black", marginTop: "10px", paddingTop: "10px" }}>
  <strong>Amount Chargeable (in words):</strong> Indian Rupees {numberToWords(
               Math.round(   totalAmount +
                  Object.values(taxSummary).reduce((acc, item) => acc + item.cgst, 0) +
                  Object.values(taxSummary).reduce((acc, item) => acc + item.sgst, 0)
               )
                )}
   </div>



      <div style={{ borderTop: "1px solid black", marginTop: "10px", paddingTop: "10px" }}>
        <strong>Tax Details:</strong>
        <table style={{ width: "100%", borderCollapse: "collapse", marginTop: "10px" }}>
  <thead>
    <tr>
      <th style={{ border: "1px solid black", padding: "5px",textAlign:"right" }}>Taxable Value</th>
      <th style={{ border: "1px solid black", padding: "5px" }}>CGST(%)</th>
      <th style={{ border: "1px solid black", padding: "5px",textAlign:"right" }}>CGST</th>
      <th style={{ border: "1px solid black", padding: "5px" }}>SGST(%)</th>
      <th style={{ border: "1px solid black", padding: "5px",textAlign:"right" }}>SGST</th>
      <th style={{ border: "1px solid black", padding: "5px",textAlign:"right" }}>Total Tax</th>
    </tr>
  </thead>
  <tbody>
  {Object.keys(taxSummary).map((taxRate) => (
    <tr key={taxRate}>
      <td style={{ border: "1px solid black", padding: "5px", textAlign: "right" }}>
        {parseFloat(taxSummary[taxRate].taxableValue).toFixed(2)}
      </td>
      <td style={{ border: "1px solid black", padding: "5px" }}>{(taxRate / 2)}%</td>
      <td style={{ border: "1px solid black", padding: "5px", textAlign: "right" }}>
        {parseFloat(taxSummary[taxRate].cgst).toFixed(2)}
      </td>
      <td style={{ border: "1px solid black", padding: "5px" }}>{(taxRate / 2)}%</td>
      <td style={{ border: "1px solid black", padding: "5px", textAlign: "right" }}>
        {parseFloat(taxSummary[taxRate].sgst).toFixed(2)}
      </td>
      <td style={{ border: "1px solid black", padding: "5px", textAlign: "right" }}>
        {parseFloat(taxSummary[taxRate].totalTax).toFixed(2)}
      </td>
    </tr>
  ))}

  {/* Total Row */}
  <tr>
    <th style={{ border: "1px solid black", padding: "5px", textAlign: "right" }}>
    Total :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  {(totalAmount).toFixed(2)}
    </th>
    <th style={{ border: "1px solid black", padding: "5px" }}>-</th>
    <th style={{ border: "1px solid black", padding: "5px", textAlign: "right" }}>
      {Object.values(taxSummary)
        .reduce((acc, item) => acc + parseFloat(item.cgst || 0), 0)
        .toFixed(2)}
    </th>
    <th style={{ border: "1px solid black", padding: "5px" }}>-</th>
    <th style={{ border: "1px solid black", padding: "5px", textAlign: "right" }}>
      {Object.values(taxSummary)
        .reduce((acc, item) => acc + parseFloat(item.sgst || 0), 0)
        .toFixed(2)}
    </th>
    <th style={{ border: "1px solid black", padding: "5px", textAlign: "right" }}>
      {Object.values(taxSummary)
        .reduce((acc, item) => acc + parseFloat(item.totalTax || 0), 0)
        .toFixed(2)}
    </th>
  </tr>
</tbody>

</table>

      </div>
      {/* <div style={{ borderTop: "1px solid black", marginTop: "10px", paddingTop: "10px" }}>
        Tax Amount (in words) : <strong>Indian Rupees Seven Thousand Nine Hundred Twenty Two Only</strong>
      </div> */}
      <div style={{ textAlign: "left"}}>
       Company's PAN :  <strong>AHEPV6120H</strong>
      </div>
      <hr />
      {/* Name : M/s Vijayakumar foodgrains 
Bank of baroda
Ac no :33090500007268
Ifsc : BARB0SIVAKA (Fifth character is zero )
Sivakasi branch */}
      <div  style={{ textAlign: "left"}}>
       Name :  <strong>Company Name</strong>
      </div>
      <div  style={{ textAlign: "left"}}>
       Bank Name :  <strong>Bank Name</strong>
      </div>
      <div  style={{ textAlign: "left"}}>
       Ac.no :  <strong>001122XXXXXX</strong>
      </div>
      <div  style={{ textAlign: "left"}}>
       IFSC :  <strong>TESTXXXXX</strong>
      </div>
      <div  style={{ textAlign: "left"}}>
       Branch :  <strong>XXXXX</strong>
      </div>
      <hr />
      <div style={{ textAlign: "left",width:"50%" }}>
        <strong style={{borderBottom:"1px solid"}}>Declaration</strong><br/>
        <p><b>We declare that this invoice  shows the</b> </p>
         <p style={{marginBottom:"20px"}}> actual price of the goods described and that all particulars are true and correct.</p>
      </div>
      <div style={{ textAlign: "right", marginTop: "-40px" }}>
        <strong >Authorized Signatory</strong>
      </div>
    </div>
  );
};

export default PrintOrder;
