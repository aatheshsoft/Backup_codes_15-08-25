import React from "react";
import { Table, Form, Row, Col, Button } from "react-bootstrap";
import { FaEye, FaEdit, FaTrash } from "react-icons/fa";
import "./PurchaseReport.css";
import { Link } from "react-router-dom";

const PurchaseReport = () => {

const orders = [
  {
    id: 1,
    date: "16-07-2025",
    suppliername:"Test 1",
    productname: "Sample 1",
    rate:"7500",
    tax: "18%",
    gstamount: "₹1400",
    total:"₹8900.00",
    
  },
  {
    id: 2,
    date: "19-07-2025",
    suppliername:"Test 2",
    productname: "Sample 2",
    rate:"12500",
    tax: "18%",
    gstamount: "₹3400",
    total:"₹15900.00",
  },
  
];

  return (
    <div className="purchase-report-container">
      <h4 className="mb-3">List Of Purchase Report </h4>

      <Form className="mb-4">
        <Row className="g-3">
            <Col lg={3} sm={6}>
            <Form.Control type="date" placeholder="From Date" />
            </Col>
            <Col lg={3} sm={6}>
            <Form.Control type="date" placeholder="To Date" />
            </Col>

            
            

            <Col lg={2} sm={4} xs={4}>
            <Button className="w-100 btn-submit-purchase">Submit</Button>
            </Col>

            <Col lg={3} sm={6}>
            <Form.Select>
                <option value="">Select GST</option>
                <option value="order1">18 %</option>
                <option value="order2">5 %</option>
                <option value="order3">12 %</option>
            </Form.Select>
            </Col>
        </Row>
        </Form>

      
      <div className="table-responsive">
        <Table bordered className="purchase-report-table">
          <thead>
            <tr>
              <th>S.No</th>
              <th>Order Date</th>
              <th>Supplier Name</th>
              <th>Product Name</th>
              <th>Rate</th>
              <th>Tax (%)</th>
              <th>GST Amount</th>
              <th>Total</th>
              
            </tr>
          </thead>
          <tbody>
            {orders.map((order) => (
              <tr key={order.id}>
                <td>{order.id}</td>
                <td>{order.date}</td>
                <td>{order.suppliername}</td>
                <td >{order.productname}</td>
                <td>{order.rate}</td>
                <td>{order.tax}</td>
                <td>{order.gstamount}</td>
                <td>{order.total}</td>
                
              </tr>
            ))}
          </tbody>
        </Table>
      </div>
    </div>
  );
};

export default PurchaseReport;
