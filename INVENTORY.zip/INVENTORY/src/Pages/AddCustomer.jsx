import React, { useState } from 'react';
import './AddPurchase.css'; 

const AddPurchase = () => {
  const [formData, setFormData] = useState({
    customername: "",
    phonenumber: "",
    email: "",
    address: "",
    gstnumber: "",
    city:"",
    state:"",
    pincode:"",

  });

  const handleChange = (e) => {
    setFormData({...formData, [e.target.name]: e.target.value});
  };

   
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Purchase Submitted:', formData);
    
  };

  return (
    <div className="container mt-4">
      <div className="d-flex justify-content-between align-items-center mb-3">
        <h4 className="mb-0">Add Customer</h4>
        <button className="btn-top" onClick={() => window.history.back()}>Back</button>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="row g-3">
          
          <div className="col-lg-6">
            <label className="form-label">Customer Name</label>
            <input type="text" className="form-control" name="customername" onChange={handleChange} />
          </div>
          <div className="col-lg-6">
            <label className="form-label">Phone Number</label>
            <input type="text" className="form-control" name="phonenumber" onChange={handleChange} />
          </div>
          <div className="col-lg-6">
            <label className="form-label">Email ID</label>
            <input type="text" className="form-control" name="email" onChange={handleChange} />
          </div>

          <div className="col-lg-6">
            <label className="form-label">GST Number</label>
            <input type="text" className="form-control" name="gstnumber" onChange={handleChange} />
          </div>
          <div className="col-lg-6">
            <label className="form-label">Address</label>
            <input type="text" className="form-control" name="address" onChange={handleChange} />
          </div>
        </div>

        <div className="d-flex justify-content-end mt-4 gap-2">
         <button type="submit" className="btn-submit">Submit</button>
          <button type="button" className="btn-cancel" onClick={() => window.history.back()}>Cancel</button>

        </div>
      </form>
    </div>
  );
};

export default AddPurchase;
