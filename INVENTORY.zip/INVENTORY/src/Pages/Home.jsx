import React from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import "./Home.css";

const data = [
  { name: "Jan", sales: 4000 },
  { name: "Feb", sales: 3000 },
  { name: "Mar", sales: 5000 },
  { name: "Apr", sales: 4000 },
  { name: "May", sales: 6000 },
  { name: "Jun", sales: 7000 },
];

const Home = () => {
  return (
    <div className="dashboard">
      <h2 className="dashboard-title">Dashboard Overview</h2>

      <div className="card-container">
        <div className="card">
          <h4>Total Sales</h4>
          <p><i className="bi bi-currency-rupee"></i>45,000</p>
        </div>
        <div className="card">
          <h4>Orders</h4>
          <p>120</p>
        </div>
        <div className="card">
          <h4>Customers</h4>
          <p>85</p>
        </div>
        <div className="card">
          <h4>Revenue</h4>
          <p><i className="bi bi-currency-rupee"></i>9,500</p>
        </div>
      </div>

      <div className="chart-container">
        <h3 className="chart-title">Monthly Sales Overview</h3>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Line type="monotone" dataKey="sales" stroke="#007bff" strokeWidth={2} />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default Home;
