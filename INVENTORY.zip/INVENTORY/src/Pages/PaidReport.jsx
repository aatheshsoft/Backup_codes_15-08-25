import React from "react";
import { Table, Form, Row, Col, Button } from "react-bootstrap";
import { FaEye, FaEdit, FaTrash } from "react-icons/fa";
import "./PaidReport.css";
import { Link } from "react-router-dom";

const PaidReport = () => {

const orders = [
  {
    id: 51,
    date: "16-07-2025",
    customer: "Sample 1",
    mobile: "--",
    amount: "₹18000.00",
    paid:"₹12000.00",
    balance:"₹6000.00",
  },
  {
    id: 50,
    date: "11-07-2025",
    customer: "Sample 2",
    mobile: "6380410368",
    amount: "₹19000.00",
    paid:"₹10000.00",
    balance:"₹9000.00",
  },
  {
    id: 49,
    date: "08-07-2025",
    customer: "Sample 3",
    mobile: "9750965881",
    amount: "₹18000.00",
    paid:"₹10000.00",
    balance:"₹8000.00",
  },
  {
    id: 48,
    date: "03-07-2025",
    customer: "Sample 4",
    mobile: "9842775343",
    amount: "₹5300.00",
    paid:"₹2000.00",
    balance:"₹3300.00",
  },
  {
    id: 47,
    date: "03-07-2025",
    customer: "Sample 5",
    mobile: "9488820120",
    amount: "₹18000.00",
    paid:"₹12000.00",
    balance:"₹6000.00",
  },
];

  return (
    <div className="Paid-container">
      <h4 className="mb-3">List Of Paid Report</h4>

      <Form className="mb-4">
        <Row className="g-3">
            <Col lg={3} sm={6}>
            <Form.Control type="date" placeholder="From Date" />
            </Col>
            <Col lg={3} sm={6}>
            <Form.Control type="date" placeholder="To Date" />
            </Col>

            
            <Col lg={3} sm={6}>
            <Form.Select>
                <option value="">Select Order</option>
                <option value="order1">Order 1</option>
                <option value="order2">Order 2</option>
                <option value="order3">Order 3</option>
            </Form.Select>
            </Col>

            <Col lg={2} sm={4} xs={4}>
            <Button className="w-100 btn-submit">Submit</Button>
            </Col>
        </Row>
        </Form>

      
      <div className="table-responsive">
        <Table bordered className="paid-table">
          <thead>
            <tr>
              <th>Order ID</th>
              <th>Date</th>
              <th>Customer Name</th>
              <th>Mobile Number</th>
              <th>Amount</th>
              <th>Paid</th>
              <th>Balance</th>
              <th>Print</th>
            </tr>
          </thead>
          <tbody>
            {orders.map((order) => (
              <tr key={order.id}>
                <td>{order.id}</td>
                <td>{order.date}</td>
                <td >{order.customer}</td>
                <td>{order.mobile}</td>
                <td>{order.amount}</td>
                <td>{order.paid}</td>
                <td >{order.balance}</td>
                <td>
                  <i class="bi bi-printer" style={{color:"darkblue",cursor:"pointer"}}></i>
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      </div>
    </div>
  );
};

export default PaidReport;
