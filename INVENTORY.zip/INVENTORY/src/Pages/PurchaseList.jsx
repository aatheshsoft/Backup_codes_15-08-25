import React from "react";
import "./PurchaseList.css";
import { FaEdit, FaTrash } from "react-icons/fa";
import { Link } from "react-router-dom";

const PurchaseList = () => {
  const purchases = [
    {
      id: 1,
      date: "05-05-2025",
      productCode: "SP001",
      productName: "Test Product",
      productRate: 3428.57,
      hsn: "0909",
      gst: 5,
    },
  ];

  return (
    <div className="purchase-container">
      <div className="purchase-header">
        <h3>List Of Purchase</h3>
        <Link to="/addpurchase" className="btn-top">Add Purchase</Link>
      </div>
<div className="purchase-table-wrapper">
      <table className="purchase-table">
        <thead>
          <tr>
            <th>S.No.</th>
            <th>Date</th>
            <th>ProductCode</th>
            <th>Product Name</th>
            <th>Product Rate</th>
            <th>HSN Code</th>
            <th>GST(%)</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {purchases.map((item, index) => (
            <tr key={item.id}>
              <td>{index + 1}</td>
              <td>{item.date}</td>
              <td >
               {item.productCode}
              </td>
              <td>{item.productName}</td>
              <td>{item.productRate}</td>
              <td>{item.hsn}</td>
              <td>{item.gst}</td>
              <td className="action-icons">
                <Link to="/editpurchase"><FaEdit className="edit-icon" /></Link>
                <FaTrash className="delete-icon" />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
</div>
      <div className="pagination">
        <span>Page 1 of 1</span>
        <span className="nav-links">« Previous 1 Next »Last »</span>
      </div>
    </div>
  );
};

export default PurchaseList;
