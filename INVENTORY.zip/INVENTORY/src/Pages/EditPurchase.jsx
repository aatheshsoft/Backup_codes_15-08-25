import React, { useState } from 'react';
import './EditPurchase.css'; // Keep this for button styling or additional spacing if needed

const AddPurchase = () => {
  const [formData, setFormData] = useState({
    productName: '',
    productCode: '',
    category: '',
    brand: '',
    hsnCode: '',
    gst: '',
    qty: '',
    unit: '',
    purchaseRate: '',
    salesRate: '',
    supplierName: '',
    supplierMobile: '',
    gstNumber: '',
    skuNo: '',
    note: ''
  });

  const handleChange = (e) => {
    setFormData({...formData, [e.target.name]: e.target.value});
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Purchase Submitted:', formData);
    // Add your backend API integration here
  };

  return (
    <div className="container mt-4">
      <div className="d-flex justify-content-between align-items-center mb-3">
        <h4 className="mb-0">Edit Purchase</h4>
        <button className="btn-top" onClick={() => window.history.back()}>Back</button>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="row g-3">
          <div className="col-lg-3">
            <label className="form-label">Product Name</label>
            <select className="form-select" name="productName" onChange={handleChange}>
              <option>Select Product</option>
            </select>
          </div>
          <div className="col-lg-3">
            <label className="form-label">Product Code</label>
            <input type="text" className="form-control" name="productCode" onChange={handleChange} />
          </div>
          <div className="col-lg-3">
            <label className="form-label">Category</label>
            <input type="text" className="form-control" name="category" onChange={handleChange} />
          </div>
          <div className="col-lg-3">
            <label className="form-label">Brand</label>
            <input type="text" className="form-control" name="brand" onChange={handleChange} />
          </div>

          <div className="col-lg-3">
            <label className="form-label">HSN Code</label>
            <input type="text" className="form-control" name="hsnCode" onChange={handleChange} />
          </div>
          <div className="col-lg-3">
            <label className="form-label">GST (%)</label>
            <input type="text" className="form-control" name="gst" onChange={handleChange} />
          </div>
          <div className="col-lg-3">
            <label className="form-label">Qty</label>
            <input type="text" className="form-control" name="qty" onChange={handleChange} />
          </div>
          <div className="col-lg-3">
            <label className="form-label">Unit</label>
            <input type="text" className="form-control" name="unit" onChange={handleChange} />
          </div>

          <div className="col-lg-3">
            <label className="form-label">Purchase Rate</label>
            <input type="text" className="form-control" name="purchaseRate" onChange={handleChange} />
          </div>
          <div className="col-lg-3">
            <label className="form-label">Sales Rate</label>
            <input type="text" className="form-control" name="salesRate" onChange={handleChange} />
          </div>

          <div className="col-lg-3">
            <label className="form-label">Supplier Name</label>
            <select className="form-select" name="supplierName" onChange={handleChange}>
              <option>Select Supplier</option>
            </select>
          </div>
          <div className="col-lg-3">
            <label className="form-label">Supplier Mobile</label>
            <input type="text" className="form-control" name="supplierMobile" onChange={handleChange} />
          </div>

          <div className="col-lg-3">
            <label className="form-label">GST Number</label>
            <input type="text" className="form-control" name="gstNumber" onChange={handleChange} />
          </div>
          <div className="col-lg-3">
            <label className="form-label">SKU No</label>
            <input type="text" className="form-control" name="skuNo" onChange={handleChange} />
          </div>

          <div className="col-lg-12">
            <label className="form-label">Note</label>
            <textarea className="form-control" name="note" rows="3" onChange={handleChange}></textarea>
          </div>
        </div>

        <div className="d-flex justify-content-end mt-4 gap-2">
         <button type="submit" className="btn-submit">Submit</button>
          <button type="button" className="btn-cancel" onClick={() => window.history.back()}>Cancel</button>

        </div>
      </form>
    </div>
  );
};

export default AddPurchase;
