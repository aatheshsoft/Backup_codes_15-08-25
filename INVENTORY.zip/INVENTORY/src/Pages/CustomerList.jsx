import React from "react";
import "./CustomerList.css";
import { FaEdit, FaTrash } from "react-icons/fa";
import { Link } from "react-router-dom";

const CustomerList = () => {
  const customers = [
    {
      id: 1,
      name: "John Doe",
      phone: "9876543210",
      email: "john@example.com",
      address: "123 Main Street, City",
    },
  ];

  return (
    <div className="customer-container">
      <div className="customer-header">
        <h3>List of Customers</h3>
        <Link to="/addcustomer" className="btn-top">Add Customer</Link>
      </div>

      <div className="customer-table-wrapper">
        <table className="customer-table">
          <thead>
            <tr>
              <th>S.No.</th>
              <th>Customer Name</th>
              <th>Phone</th>
              <th>Email</th>
              <th>Address</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {customers.map((item, index) => (
              <tr key={item.id}>
                <td>{index + 1}</td>
                <td>{item.name}</td>
                <td>{item.phone}</td>
                <td>{item.email}</td>
                <td>{item.address}</td>
                <td className="action-icons">
                  <Link to="/editcustomer"><FaEdit className="edit-icon" /></Link>
                  <FaTrash className="delete-icon" />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="pagination">
        <span>Page 1 of 1</span>
        <span className="nav-links">« Previous 1 Next » Last »</span>
      </div>
    </div>
  );
};

export default CustomerList;
