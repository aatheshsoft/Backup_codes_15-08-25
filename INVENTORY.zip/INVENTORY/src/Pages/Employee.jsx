import React from "react";
import "./PurchaseList.css";
import { FaEdit, FaTrash } from "react-icons/fa";
import { Link } from "react-router-dom";
import "./Employee.css";

const Employee = () => {
  const employees = [
    {
      id: 1,
      name: "Sample1",
      email: "sample1@gmail.com",
      mobile: "0123456789",
      loginStatus: true, 
    },
    {
      id: 2,
      name: "Sample2",
      email: "sample2@gmail.com",
      mobile: "1234567890",
      loginStatus: true,
    },
  ];

  return (
    <div className="emp-container">
      <div className="emp-header">
        <h3>Employee Management</h3>
        <Link to="/addemployee" className="emp-add-btn">Add Employee</Link>
      </div>

      <div className="emp-table-wrapper">
        <table className="emp-table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Mobile</th>
              <th>Login Status</th>
              <th>Previlage</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {employees.map((emp) => (
              <tr key={emp.id}>
                <td>{emp.name}</td>
                <td>{emp.email}</td>
                <td>{emp.mobile}</td>
                <td>
                    <input type="checkbox" className="checkbox_animated" />
                </td>
                <td>
                    <i className="bi bi-person-badge-fill text-success" style={{cursor:"pointer"}}></i>
                </td>
                <td className="emp-actions">
                  <Link to="">
                    <FaEdit className="emp-edit-icon" />
                  </Link>
                  <FaTrash className="emp-delete-icon" />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>&nbsp;

      <div className="text-end">
        <button className="emp-update-btn">Update</button>
      </div>
    </div>
  );
};

export default Employee;
