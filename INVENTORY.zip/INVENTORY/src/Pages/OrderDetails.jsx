import React from "react";
import { Row, Col, Table, Button } from "react-bootstrap";
import "./OrderDetails.css";
import { Link } from "react-router-dom";

const OrderDetails = () => {
  const order = {
    id: 51,
    date: "16-07-2025",
    customerName: "Sample 1",
    address: "Test",
    vehicleNumber: "",
    transportName: "Lorry",
    products: [
      {
        id: 1,
        name: "Test Product",
        qty: 5,
        price: 3429,
        total: 17145,
      },
    ],
    cgst: 427.5,
    sgst: 427.5,
  };

  const subTotal = order.products.reduce((sum, item) => sum + item.total, 0);

  return (
    <div className="order-detail-container">
      <Row className="mb-3 align-items-center">
        <Col><h4>Order Details</h4></Col>
        <Col className="text-end">
          <Button  className="px-4 btn-top" onClick={() => window.history.back()}>Back</Button>
        </Col>
      </Row>

      <Row className="mb-3">
        <Col md={6}>
          <p><strong>Order ID:</strong> {order.id}</p>
          <p><strong>Order Date:</strong> {order.date}</p>
        </Col>
        <Col  className="text-end">
       <a href="/printorder" target="_blank" rel="noopener noreferrer">
          <i className="bi bi-printer" style={{ color: "darkblue", cursor: "pointer" }}></i>
        </a>

        </Col>
      </Row>

      <Row className="mb-4 border p-3 rounded shadow-sm bg-white">
        <Col md={6}>
          <h6 className="text-secondary">Customer Details</h6>
          <p><strong>Name:</strong> {order.customerName}</p>
          <p><strong>Address:</strong> {order.address}</p>
        </Col>
        <Col md={6}>
          <h6 className="text-secondary">Transport Details</h6>
          <p><strong>Vehicle Number:</strong> {order.vehicleNumber || "-"}</p>
          <p><strong>Transport Name:</strong> {order.transportName}</p>
        </Col>
      </Row>

      <div className="table-responsive">
        <Table bordered className="order-detail-table">
          <thead>
            <tr>
              <th>S.No</th>
              <th>Product Name</th>
              <th>Qty</th>
              <th>Price</th>
              <th>Total</th>
            </tr>
          </thead>
          <tbody>
            {order.products.map((item, index) => (
              <tr key={item.id}>
                <td>{index + 1}</td>
                <td>{item.name}</td>
                <td>{item.qty}</td>
                <td>₹{item.price.toFixed(2)}</td>
                <td>₹{item.total.toFixed(2)}</td>
              </tr>
            ))}
            <tr>
              <td colSpan={4} className="text-end"><strong>Sub-Total</strong></td>
              <td>₹{subTotal.toFixed(2)}</td>
            </tr>
            <tr>
              <td colSpan={4} className="text-end"><strong>CGST</strong></td>
              <td>₹{order.cgst.toFixed(2)}</td>
            </tr>
            <tr>
              <td colSpan={4} className="text-end"><strong>SGST</strong></td>
              <td>₹{order.sgst.toFixed(2)}</td>
            </tr>
          </tbody>
        </Table>
      </div>
    </div>
  );
};

export default OrderDetails;
