import React from "react";
import { Table, Form, Row, Col, Button } from "react-bootstrap";
import "./Orders.css";
import { Link } from "react-router-dom";


const Orders = () => {

const orders = [
  {
    id: 51,
    date: "16-07-2025",
    customer: "Sample 1",
    mobile: "N/A",
    amount: "₹18000.00",
    status: "Pending",
  },
  {
    id: 50,
    date: "11-07-2025",
    customer: "Sample 2",
    mobile: "6380410368",
    amount: "₹19000.00",
    status: "Pending",
  },
  {
    id: 49,
    date: "08-07-2025",
    customer: "Sample 3",
    mobile: "9750965881",
    amount: "₹18000.00",
    status: "Pending",
  },
  {
    id: 48,
    date: "03-07-2025",
    customer: "Sample 4",
    mobile: "9842775343",
    amount: "₹5300.00",
    status: "Pending",
  },
  {
    id: 47,
    date: "03-07-2025",
    customer: "Sample 5",
    mobile: "9488820120",
    amount: "₹18000.00",
    status: "Pending",
  },
];

  return (
    <div className="orders-container">
      <h4 className="mb-3">List Of Sales</h4>

      <Form className="mb-4">
        <Row className="g-3">
          <Col lg={3} sm={6}>
            <Form.Control type="date" placeholder="From Date" />
          </Col>
          <Col lg={3} sm={6}>
            <Form.Control type="date" placeholder="To Date" />
          </Col>
          
          <Col lg={2} sm={4}>
            <Button className="w-100 btn-submit">Submit</Button>
          </Col>
        </Row>
      </Form>

        <Row>
          <Col lg={4} sm={8}>
                  <Form.Control type="text" placeholder="Search Order" />
          </Col>
        </Row>&nbsp;

      <div className="table-responsive">
        <Table bordered className="order-table">
          <thead>
            <tr>
              <th>Order ID</th>
              <th>Date</th>
              <th>Customer Name</th>
              <th>Mobile Number</th>
              <th>Amount</th>
              <th>Payment Status</th>
              <th>View</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {orders.map((order) => (
              <tr key={order.id}>
                <td>{order.id}</td>
                <td>{order.date}</td>
                <td >{order.customer}</td>
                <td>{order.mobile}</td>
                <td>{order.amount}</td>
                <td className="text-danger">{order.status}</td>
                <td>
                 <Link to = '/orderdetails'> <i class="bi bi-eye eye-icon1"></i></Link>
                </td>
                <td>
                  <i class="bi bi-pencil edit-icon1 me-2"></i>
                  <i class="bi bi-trash3 delete-icon1"></i>
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      </div>
    </div>
  );
};

export default Orders;
