import React, { useState } from "react";
import {
  Container,
  Row,
  Col,
  Button,
  Table,
  Form,
  Modal,
} from "react-bootstrap";
import { BiRupee } from "react-icons/bi";
import { RiSave3Line } from "react-icons/ri";
import { FaPlus, FaTrash } from "react-icons/fa";
import './Invoice.css';


const Estimate = () => {
  const [show, setShow] = useState(false);
  const handleShow = () => setShow(true);
  const handleClose = () => setShow(false);

  const [formData, setFormData] = useState({
    customer_name: "",
    mobile: "",
    address: "",
  });

  const [selectedCustomer, setSelectedCustomer] = useState("");
  const [productCode, setProductCode] = useState("");
  const [productName, setProductName] = useState("");
  const [cart, setCart] = useState([]);

  // Static dummy data
  const staticCustomers = [
    { id: 1, name: "Customer A" },
    { id: 2, name: "Customer B" },
  ];

  const staticProducts = [
    { id: 1, code: "P001", name: "Product A", price: 100, box: "10 pcs" },
    { id: 2, code: "P002", name: "Product B", price: 200, box: "5 pcs" },
  ];

  const handleAddToCartByCode = () => {
    if (!productCode) return;
    const product = staticProducts.find((p) => p.code === productCode);
    if (product) {
      const exists = cart.find((item) => item.id === product.id);
      if (exists) {
        setCart(
          cart.map((item) =>
            item.id === product.id ? { ...item, qty: item.qty + 1 } : item
          )
        );
      } else {
        setCart([...cart, { ...product, qty: 1 }]);
      }
    }
    setProductCode("");
    setProductName("");
  };

  const handleAddToCartByName = (selectedName) => {
    const product = staticProducts.find((p) => p.name === selectedName);
    if (product) {
      const exists = cart.find((item) => item.id === product.id);
      if (exists) {
        setCart(
          cart.map((item) =>
            item.id === product.id ? { ...item, qty: item.qty + 1 } : item
          )
        );
      } else {
        setCart([...cart, { ...product, qty: 1 }]);
      }
    }
    setProductName("");
    setProductCode("");
  };

  const handleRemoveItem = (id) => {
    setCart(cart.filter((item) => item.id !== id));
  };

  const handleQtyChange = (e, id) => {
  const value = e.target.value;

  // Allow empty string temporarily (during typing)
  if (value === "") {
    setCart(
      cart.map((item) =>
        item.id === id ? { ...item, qty: "" } : item
      )
    );
    return;
  }

  const qty = Math.max(1, parseInt(value));
  setCart(
    cart.map((item) =>
      item.id === id ? { ...item, qty } : item
    )
  );
};


  const handlePriceChange = (e, id) => {
    const price = parseFloat(e.target.value || 0);
    setCart(
      cart.map((item) =>
        item.id === id ? { ...item, price } : item
      )
    );
  };

  
  const calculateTotal = () => {
    return cart.reduce((acc, item) => acc + item.qty * item.price, 0);
  };

  const handleSave = () => {
    console.log("Saving Invoice:", cart);
    alert("Invoice saved successfully!");
  };

  return (
    <>
    
      <h4>INVOICE</h4>
      <Container className="my-4">
        
        <Row className="mb-3">
          <Col md={6}>
            <Form.Select
              value={selectedCustomer}
              onChange={(e) => setSelectedCustomer(e.target.value)}
            >
              <option value="">Select Customer</option>
              {staticCustomers.map((c) => (
                <option key={c.id} value={c.name}>
                  {c.name}
                </option>
              ))}
            </Form.Select>
          </Col>
          <Col md={3}>
            <Button className="add-customer-btn" onClick={handleShow}>
              <FaPlus /> Add Customer
            </Button>
          </Col>
          <Col md={3}>
            <Form.Control
              placeholder="Enter Esimate No"
              value=""
              
            />
          </Col>
        </Row>

        <Row>
          <Col md={6}>
            <Form.Control
              placeholder="Enter Product Code"
              value={productCode}
              onChange={(e) => setProductCode(e.target.value)}
              onBlur={handleAddToCartByCode}
            />
          </Col>
          <Col md={6}>
            <Form.Select
              value={productName}
              onChange={(e) => {
                const selectedName = e.target.value;
                setProductName(selectedName);
                if (selectedName) handleAddToCartByName(selectedName);
              }}
            >
              <option value="">Select Product</option>
              {staticProducts.map((p) => (
                <option key={p.id} value={p.name}>
                  {p.name}
                </option>
              ))}
            </Form.Select>
          </Col>
        </Row>

        <Table bordered responsive className="my-3 invoice-custom-table">
          <thead>
            <tr>
              <th>S.No</th>
              <th>Item</th>
              <th>Box Contains</th>
              <th>Price</th>
              <th>Qty</th>
              <th>Total</th>
              <th>Del</th>
            </tr>
          </thead>
          <tbody>
            {cart.map((item, i) => (
              <tr key={item.id}>
                <td>{i + 1}</td>
                <td>{item.name}</td>
                <td>{item.box}</td>
                <td>
                  <Form.Control
                    type="number"
                    value={item.price}
                    onChange={(e) => handlePriceChange(e, item.id)}
                  />
                </td>
                <td>
                  <Form.Control
                    type="number"
                    min="1"
                    value={item.qty}
                    onChange={(e) => handleQtyChange(e, item.id)}
                  />
                </td>
                <td>
                  <BiRupee />
                  {(item.price * item.qty).toFixed(2)}
                </td>
                <td>
                  <Button
                    variant="danger"
                    size="sm"
                    onClick={() => handleRemoveItem(item.id)}
                  >
                    <FaTrash />
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </Table>

 



        <div className="d-flex justify-content-between align-items-center bg-light p-3">
          <h5>
            Grand Total: <BiRupee />
            {calculateTotal().toFixed(2)}
          </h5>
          <Button variant="success" onClick={handleSave}>
            <RiSave3Line /> Save Invoice
          </Button>
        </div>
      </Container>

      {/* Modal to Add Customer */}
      <Modal show={show} onHide={handleClose} centered>
        <Modal.Header closeButton>
          <Modal.Title>Add Customer</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group className="mb-3">
              <Form.Label>Customer Name</Form.Label>
              <Form.Control
                type="text"
                name="customer_name"
                value={formData.customer_name}
                onChange={(e) =>
                  setFormData({ ...formData, customer_name: e.target.value })
                }
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Mobile</Form.Label>
              <Form.Control
                type="text"
                name="mobile"
                value={formData.mobile}
                onChange={(e) =>
                  setFormData({ ...formData, mobile: e.target.value })
                }
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Address</Form.Label>
              <Form.Control
                as="textarea"
                rows={2}
                name="address"
                value={formData.address}
                onChange={(e) =>
                  setFormData({ ...formData, address: e.target.value })
                }
              />
            </Form.Group>
            <Button className="esimate-btn" onClick={handleClose}>
              Submit
            </Button>
          </Form>
        </Modal.Body>
      </Modal>
    </>
  );
};

export default Estimate;
