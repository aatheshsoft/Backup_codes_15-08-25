import React, { useState } from "react";
import { Form, Button, Row, Col, Container } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import './AddEmployee.css';


const AddEmployee = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    mobile: "",
    password: "",
  });

  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // TODO: API call logic here
    console.log("Form Submitted:", formData);
  };

 

  return (
    <Container fluid className="mt-4">
      <Row className="mb-4">
        <Col lg={12} className="d-flex justify-content-between align-items-center">
          <h4>Add Employee</h4>
          <Button className="back-button" onClick={() => window.history.back()}>Back</Button>
        </Col>
      </Row>

      <Form onSubmit={handleSubmit}>
            <Form.Group as={Row} className="mb-3">
                <Form.Label column lg={2} className="text-start">Name</Form.Label>
                <Col lg={10}>
                <Form.Control
                    type="text"
                    name="name"
                    placeholder="Enter Name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                />
                </Col>
            </Form.Group>

            <Form.Group as={Row} className="mb-3">
                <Form.Label column lg={2} className="text-start">Email</Form.Label>
                <Col lg={10}>
                <Form.Control
                    type="email"
                    name="email"
                    placeholder="Enter Email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                />
                </Col>
            </Form.Group>

            <Form.Group as={Row} className="mb-3">
                <Form.Label column lg={2} className="text-start">Mobile Number</Form.Label>
                <Col lg={10}>
                <Form.Control
                    type="tel"
                    name="mobile"
                    placeholder="Enter Mobile Number"
                    value={formData.mobile}
                    onChange={handleChange}
                    required
                />
                </Col>
            </Form.Group>

            <Form.Group as={Row} className="mb-4">
                <Form.Label column lg={2} className="text-start">Password</Form.Label>
                <Col lg={10}>
                <Form.Control
                    type="password"
                    name="password"
                    placeholder="Enter Password"
                    value={formData.password}
                    onChange={handleChange}
                    required
                />
                </Col>
            </Form.Group>

            <Row>
                <Col  className="d-flex gap-2 justify-content-end">
                <Button className="button-submit" variant="primary">Submit</Button>
                <Button className="button-cancel" onClick={() => window.history.back()}>Cancel</Button>
                </Col>
            </Row>
            </Form>

    </Container>
  );
};

export default AddEmployee;
