import React from "react";
import { Table, Form, Row, Col, Button } from "react-bootstrap";
import { FaEye, FaEdit, FaTrash } from "react-icons/fa";
import "./GstReport.css";
import { Link } from "react-router-dom";

const GstReport = () => {

const orders = [
  {
    id: 1,
    date: "16-07-2025",
    productname: "Sample 1",
    tax: "18%",
    amount: "₹1400",
    total:"₹12000.00",
    
  },
  {
     id: 2,
    date: "19-07-2025",
    productname: "Sample 2",
    tax: "5%",
    amount: "₹1900",
    total:"₹21000.00",
  },
  
];

  return (
    <div className="Gst-report-container">
      <h4 className="mb-3">List Of GST Report</h4>

      <Form className="mb-4">
        <Row className="g-3">
            <Col lg={3} sm={6}>
            <Form.Control type="date" placeholder="From Date" />
            </Col>
            <Col lg={3} sm={6}>
            <Form.Control type="date" placeholder="To Date" />
            </Col>

            
            

            <Col lg={2} sm={4} xs={4}>
            <Button className="w-100 btn-submit1">Submit</Button>
            </Col>

            <Col lg={3} sm={6}>
            <Form.Select>
                <option value="">Select GST</option>
                <option value="order1">18</option>
                <option value="order2">5</option>
                <option value="order3">9</option>
            </Form.Select>
            </Col>
        </Row>
        </Form>

      
      <div className="table-responsive">
        <Table bordered className="Gst-report-table">
          <thead>
            <tr>
              <th>S.No</th>
              <th>Order Date</th>
              <th>Product Name</th>
              <th>Tax (%)</th>
              <th>GST Amount</th>
              <th>Total</th>
              
            </tr>
          </thead>
          <tbody>
            {orders.map((order) => (
              <tr key={order.id}>
                <td>{order.id}</td>
                <td>{order.date}</td>
                <td >{order.productname}</td>
                <td>{order.tax}</td>
                <td>{order.amount}</td>
                <td>{order.total}</td>
                
              </tr>
            ))}
          </tbody>
        </Table>
      </div>
    </div>
  );
};

export default GstReport;
