import React, { useState } from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import Header from './Components/Header';
import Sidebar from './Components/SideBar';
import './App.css'; // base styling
import Home from './Pages/Home'; 
import PurchaseList from './Pages/PurchaseList'; 
import AddPurchase from './Pages/AddPurchase'; 
import EditPurchase from './Pages/EditPurchase'; 
import Invoice from './Pages/Invoice'; 
import Stock from './Pages/Stock'; 
import Estimate from './Pages/Estimate';
import CustomerList from './Pages/CustomerList';
import AddCustomer from './Pages/AddCustomer'; 
import Orders from './Pages/Orders';
import OrderDetails from './Pages/OrderDetails';
import PaidReport from './Pages/PaidReport';
import GstReport from './Pages/GstReport';
import PurchaseReport from './Pages/PurchaseReport';
import PrintOrder from './Pages/PrintOrder';
import Employee from './Pages/Employee';
import AddEmployee from './Pages/AddEmployee';
import EditCustomer from './Pages/EditCustomer';

const App = () => {
   const [isMobileOpen, setIsMobileOpen] = useState(false);

  const toggleSidebar = () => {
    setIsMobileOpen(prev => !prev);
  };

  const location = useLocation();
  const isPrintOrderPage = location.pathname === "/printorder";

  if (isPrintOrderPage) {
    return (
      <Routes>
        <Route path="/printorder" element={<PrintOrder />} />
      </Routes>
    );
  }

  return (
    <div className="app-container">
      <Header toggleSidebar={toggleSidebar} />
      <Sidebar isMobileOpen={isMobileOpen} toggleSidebar={toggleSidebar} />

      <div className="main-content">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/purchaselist" element={<PurchaseList />} />
          <Route path="/addpurchase" element={<AddPurchase />} />
          <Route path="/editpurchase" element={<EditPurchase />} />
          <Route path="/invoice" element={<Invoice />} />
          <Route path="/stock" element={<Stock />} />
          <Route path="/estimate" element={<Estimate />} />
          <Route path="/customerlist" element={<CustomerList />} />
          <Route path="/addcustomer" element={<AddCustomer />} />
          <Route path="/orders" element={<Orders />} />
          <Route path="/orderdetails" element={<OrderDetails />} />
          <Route path="/paidreport" element={<PaidReport />} />
          <Route path="/gstreport" element={<GstReport />} />
          <Route path="/purchasereport" element={<PurchaseReport />} />
          <Route path="/employee" element={<Employee />} />
          <Route path='/addemployee' element={<AddEmployee />} />
          <Route path='/editcustomer' element={<EditCustomer />} />
        </Routes>
      </div>
    </div>
  );
};

export default App;
