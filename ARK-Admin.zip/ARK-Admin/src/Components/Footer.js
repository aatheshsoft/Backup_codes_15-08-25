import React from 'react';

const Footer = () => {
  return (
    <div className="container-fluid">
      {/* Footer start */}
      <footer className="footer">
        <div className="row">
          <div className="col-md-12 footer-copyright text-center">
            <p className="mb-0" style={{ color: "#fff" }}>
            Copyright © {new Date().getFullYear()} ARK Crackers. Developed by Aathesh Soft Solutions
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Footer;
