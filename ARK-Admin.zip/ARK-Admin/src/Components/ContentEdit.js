import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import ReactQuill from "react-quill";
import "react-quill/dist/quill.snow.css";
import Header from "../Components/Header";
import { Link } from "react-router-dom";
import axios from "axios";

const ContentEdit = () => {
  const { id } = useParams(); // Get the content ID from the URL
  const navigate = useNavigate();
  const [title, setTitle] = useState(""); // Title state
  const [content, setContent] = useState(""); // Content state
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

  // Fetch Content Details
  useEffect(() => {
    const fetchContent = async () => {
      try {
        console.log("Fetching content for ID:", id); // Debugging step
        const response = await axios.post(`${API_BASE_URL}content_detail.php`, { id });
  
        console.log("API Response:", response.data); // Debugging step
  
        if (response.data && response.data.head?.msg === "success" && response.data.body) {
          setTitle(response.data.body.name || ""); // Correcting title
          setContent(response.data.body.message || ""); // Correcting content
        } else {
          console.error("Invalid API response structure:", response.data);
        }
      } catch (error) {
        console.error("Error fetching content details:", error);
      }
    };
  
    fetchContent();
  }, [id]);
  
  // Update Content
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(`${API_BASE_URL}content_detail_update.php`, {
        id,
        message: content,
      });

      if (response.data.head.code === 200) {
        alert("Content updated successfully!");
        navigate("/content"); // Redirect to content list
      } else {
        alert("Failed to update content.");
      }
    } catch (error) {
      console.error("Error updating content:", error);
    }
  };

  // Quill Editor Modules
  const modules = {
    toolbar: [
      [{ font: [] }],
      [{ size: ["small", false, "large", "huge"] }],
      ["bold", "italic", "underline", "strike"],
      [{ color: [] }, { background: [] }],
      [{ script: "sub" }, { script: "super" }],
      [{ header: 1 }, { header: 2 }, { header: 3 }],
      [{ list: "ordered" }, { list: "bullet" }],
      [{ indent: "-1" }, { indent: "+1" }],
      [{ align: [] }],
      ["blockquote", "code-block"],
      ["link", "image"],
      ["clean"],
    ],
  };

  return (
    <>
      <Header />
      <div className="page-wrapper compact-wrapper" id="pageWrapper">
        <div className="page-body-wrapper">
          <div className="page-body">
            <div className="container-fluid">
              <div className="row">
                <div className="col-12">
                  <div className="row">
                    <div className="col-sm-12 m-auto">
                      <div className="card">
                        <div className="card-body">
                          <div className="card-header-2">
                            <h5>{title}</h5>
                          </div>

                          <div className="card-footer border-0 pb-0 d-flex justify-content-end">
                            <Link to="/content">
                              <button className="btn btn-primary me-3">Back</button>
                            </Link>
                          </div>
                          <br />

                          <div className="mb-4 row align-items-center">
                            <label className="form-label-title col-sm-3 mb-0">Title</label>
                            <div className="col-sm-9">{title}</div>
                          </div>

                          {/* Quill Text Editor */}
                          <form onSubmit={handleSubmit}>
                            <div className="mb-4 row align-items-center">
                              <label className="form-label-title col-sm-3 mb-0">Content:</label>
                              <div className="col-sm-9">
                                <ReactQuill
                                  theme="snow"
                                  value={content}
                                  onChange={setContent}
                                  modules={modules}
                                  style={{ minHeight: "200px" }}
                                />
                              </div>
                            </div>

                            <div className="card-footer border-0 pb-0 d-flex justify-content-end">
                              <button type="submit" className="btn btn-primary me-3">
                                Submit
                              </button>
                            </div>
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ContentEdit;
