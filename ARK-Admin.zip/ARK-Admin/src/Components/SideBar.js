import React, { useState, useEffect } from "react";
import { NavLink } from "react-router-dom";
import { FaUser, FaClipboardList, FaShoppingCart, FaBars } from "react-icons/fa";
import { RiShoppingBag4Fill } from "react-icons/ri";
import { ImCancelCircle } from "react-icons/im";
import { MdOutlineDashboard } from "react-icons/md";
import { BiSolidOffer } from "react-icons/bi";
import { GrGallery } from "react-icons/gr";
import { RiGalleryLine } from "react-icons/ri";
import { AiOutlineStock } from "react-icons/ai";
import { PiNewspaperClipping } from "react-icons/pi";
import { TiShoppingCart } from "react-icons/ti";
import Logo from '../Assets/ark-logo.png'
import "../Pages/Sidebar.css";
// import Logo from "../Assets/manift-logo.png";
import axios from "axios";

const SideBar = () => {
  const [isOpen, setIsOpen] = useState(true);
  const [permissions, setPermissions] = useState({});
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

  const toggleSidebar = () => {
    setIsOpen(!isOpen);
  };

/*   useEffect(() => {
    let userId = localStorage.getItem("user_id");
  
    if (!userId) {
      console.error("No user ID found. Please log in again.");
      return;
    }
  
    userId = userId.replace(/^"|"$/g, ''); // Remove extra double quotes if they exist
  
    const fetchPermissions = async () => {
      try {
        console.log("Sending API request with user_id:", userId);
  
        const response = await axios.post(
          `${API_BASE_URL}employee_login_previllage.php`,
          { user_id: userId }, // Ensure correct format
          {
            headers: {
              "Content-Type": "application/json",
              "Accept": "application/json",
            },
          }
        );
  
        console.log("API Fixed Response:", response.data);
  
        if (response.data.head.code === 200 && response.data.body.length > 0) {
          setPermissions(response.data.body[0]);
        } else {
          alert("Invalid Username and Password. Please check your credentials.");
        }
      } catch (error) {
        alert("API Error: Unable to fetch permissions.");
        console.error("API Error:", error);
      }
    };
  
    fetchPermissions();
  }, []); */
  
  // const Logo = JSON.parse(localStorage.getItem('logo'));

console.log(Logo);

  return (
    <div className="page-wrapper compact-wrapper" id="pageWrapper">
      <div className="page-body-wrapper">
        <div className={`sidebar-container1 ${isOpen ? "open" : "collapsed"}`}>
          <div className="sidebar-wrapper bubble-bg">
            <div className="sidebar-toggle1">
              {isOpen && (
                <NavLink to="/home" title="">
                  <img src={Logo} alt="" className="sidebar-logo"/>
                </NavLink>
              )}

              <button onClick={toggleSidebar} className="toggle-btn1">
                {isOpen ? (
                  <i className="ri-apps-line status_toggle middle sidebar-toggle"></i>
                ) : (
                  <FaBars />
                )}
              </button>
            </div>

            <nav className="sidebar-nav1"> 
              <ul>
                <NavLink to="/home" className={({ isActive }) => (isActive ? "active" : "")}>
                  <li>
                    <MdOutlineDashboard />
                    {isOpen && <span>Dashboard</span>}
                  </li>
                </NavLink>
                <NavLink to="/content" className={({ isActive }) => (isActive ? "active" : "")}>
                    <li>
                      <FaClipboardList />
                      {isOpen && <span>Content</span>}
                    </li>
                  </NavLink>
                  <NavLink to="/scrolllist" className={({ isActive }) => (isActive ? "active" : "")}>
                    <li>
                    <PiNewspaperClipping />
                      {isOpen && <span>Scroll News</span>}
                    </li>
                  </NavLink>
                {/* {console.log(" Rendering with permissions:", permissions)} */}

                {/* {permissions.customer === "1" && (
                  <NavLink to="/customerlist" className={({ isActive }) => (isActive ? "active" : "")}>
                    <li>
                      <FaUser />
                      {isOpen && <span>Customer</span>}
                    </li>
                  </NavLink>
                )} */}
                 <NavLink to="/discount" className={({ isActive }) => (isActive ? "active" : "")}>
                    <li>
                    <BiSolidOffer />
                      {isOpen && <span>Discount</span>}
                    </li>
                  </NavLink>
                  <NavLink to="/subcategory" className={({ isActive }) => (isActive ? "active" : "")}>
                    <li>
                      <RiShoppingBag4Fill />
                      {isOpen && <span>Products</span>}
                    </li>
                  </NavLink>
                

                   

                
                  <NavLink to="/orderlist" className={({ isActive }) => (isActive ? "active" : "")}>
                    <li>
                      <FaShoppingCart />
                      {isOpen && <span>Orders</span>}
                    </li>
                  </NavLink>
                
                {/* {permissions.cancel_orders === "1" && (
                  <NavLink to="/cancelorder" className={({ isActive }) => (isActive ? "active" : "")}>
                    <li>
                      <ImCancelCircle />
                      {isOpen && <span>Cancel Order</span>}
                    </li>
                  </NavLink>
                )} */}
          
                <NavLink to="/clientlogo" className={({ isActive }) => (isActive ? "active" : "")}>
                    <li>
                    <RiGalleryLine />

                      {isOpen && <span>Client Logo</span>}
                    </li>
                  </NavLink>

               

                  <NavLink to="/gallerylist" className={({ isActive }) => (isActive ? "active" : "")}>
                    <li>
                    <GrGallery />
                      {isOpen && <span>Shop Gallery</span>}
                    </li>
                  </NavLink>
 {/* <NavLink to="/shoporder" className={({ isActive }) => (isActive ? "active" : "")}>
                    <li>
                    <TiShoppingCart />


                      {isOpen && <span>Shop Order</span>}
                    </li>
                  </NavLink> */}
                 
                  <NavLink to="/stock" className={({ isActive }) => (isActive ? "active" : "")}>
                    <li>
                    <AiOutlineStock />

                      {isOpen && <span>Stock Report</span>}
                    </li>
                  </NavLink>

              </ul>
            </nav>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SideBar;
