import React, { useState, useEffect } from "react";
import Header from "../Components/Header";
import axios from "axios";

const UpdateList = () => {
  const [productlist, setProductList] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [loading, setLoading] = useState(true);
  const [editedProducts, setEditedProducts] = useState({});
const [updating, setUpdating] = useState(false);

  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

  useEffect(() => {
    setLoading(true);
    axios
      .post(`${API_BASE_URL}update_productlist.php`)
      .then((response) => {
        const res = response.data;
        if (res.head.code === 200 && res.body?.update_productlist) {
          const updated = res.body.update_productlist;

          // Store editable fields initially
          const initialEdits = {};
          updated.forEach((cat) => {
            cat.product.forEach((prod) => {
              initialEdits[prod.product_id] = {
                qty_per_box: prod.qty_per_box,
                rate: prod.rate,
                stock: prod.stock,
              };
            });
          });

          setProductList(updated);
          setFilteredProducts(updated);
          setEditedProducts(initialEdits);
        } else {
          console.error("Invalid response data");
        }
      })
      .catch((error) => console.error("API Error:", error))
      .finally(() => setLoading(false));
  }, []);

  const handleSearch = (e) => {
    const query = e.target.value.toLowerCase();
    setSearchQuery(query);

    const filtered = productlist
      .map((category) => {
        const filteredProducts = category.product.filter(
          (p) =>
            p.product_name.toLowerCase().includes(query) ||
            p.product_code?.toLowerCase().includes(query)
        );
        return { ...category, product: filteredProducts };
      })
      .filter((cat) => cat.product.length > 0);

    setFilteredProducts(filtered);
  };

  const handleInputChange = (product_id, field, value) => {
    setEditedProducts((prev) => ({
      ...prev,
      [product_id]: {
        ...prev[product_id],
        [field]: value,
      },
    }));
  };

  const handleUpdate = async () => {
     setUpdating(true);
    try {
      const updates = Object.entries(editedProducts);

      for (let [product_id, values] of updates) {
        const payload = {
          product_id,
          ...values,
        };

        await axios.post(`${API_BASE_URL}update_product_price.php`,
          payload
        );
      }

      alert("Products updated successfully!");
      window.location.reload();
    } catch (error) {
      console.error("Update Error:", error);
      alert("Failed to update products.");
    }finally {
    setUpdating(false); // Hide spinner
  }
  };

  return (
    <>
      <Header />
      <div className="page-wrapper compact-wrapper" id="pageWrapper">
        <div className="page-body-wrapper">
          <div className="page-body">
            <div className="container-fluid">
              <div className="row">
                <div className="col-sm-12">
                  <div className="card card-table">
                    <div className="card-body">
                      <div className="title-header option-title d-sm-flex d-block">
                        <h5>Product Update</h5>
                        <div className="col-sm-8">
                          <form className="theme-form theme-form-2 mega-form">
                            <div className="mb-4 row align-items-center">
                              <label className="col-sm-2 col-form-label" style={{ fontSize: "14px" }}>
                                Search:
                              </label>
                              <div className="col-sm-10">
                                <input
                                  type="text"
                                  className="form-control"
                                  placeholder="Search"
                                  value={searchQuery}
                                  onChange={handleSearch}
                                />
                              </div>
                            </div>
                          </form>
                        </div>
                      </div>

                      {loading ? (
                        <div style={{ display: "flex", justifyContent: "center", marginTop: "50px" }}>
                          <div className="loader"></div>
                        </div>
                      ) : (
                        <div className="table-responsive">
                          <table className="table all-package theme-table table-product" id="table_id">
                            <thead>
                              <tr>
                                <th>S.No.</th>
                                <th>Product</th>
                                <th>Qty Per Box</th>
                                <th style={{ textAlign: "center" }}>Price</th>
                                <th style={{ textAlign: "center" }}>Stock</th>
                              </tr>
                            </thead>
                            <tbody>
                              {filteredProducts.length > 0 ? (
                                (() => {
                                  let serialNumber = 1;
                                  return filteredProducts.map((category, catIdx) => (
                                    <React.Fragment key={catIdx}>
                                      <tr>
                                        <td colSpan="5" style={{ fontWeight: "bold", background: "rgb(255 95 87 / 94%)", textAlign: "center", color: "white" }}>
                                          {category.category_name}
                                        </td>
                                      </tr>
                                      {category.product.map((item, idx) => (
                                        <tr key={item.product_id}>
                                          <td>{serialNumber++}</td>
                                          <td>{item.product_name}</td>
                                          <td>
                                            <input
                                              type="text"
                                              className="form-control"
                                              value={editedProducts[item.product_id]?.qty_per_box || ""}
                                              onChange={(e) =>
                                                handleInputChange(item.product_id, "qty_per_box", e.target.value)
                                              }
                                            />
                                          </td>
                                          <td style={{ textAlign: "center" }}>
                                            <input
                                              type="number"
                                              className="form-control"
                                              value={editedProducts[item.product_id]?.rate || ""}
                                              onChange={(e) =>
                                                handleInputChange(item.product_id, "rate", e.target.value)
                                              }
                                            />
                                          </td>
                                          <td style={{ textAlign: "center" }}>
                                            <input
                                              type="number"
                                              className="form-control"
                                              value={editedProducts[item.product_id]?.stock || ""}
                                              onChange={(e) =>
                                                handleInputChange(item.product_id, "stock", e.target.value)
                                              }
                                            />
                                          </td>
                                        </tr>
                                      ))}
                                    </React.Fragment>
                                  ));
                                })()
                              ) : (
                                <tr>
                                  <td colSpan="5" className="text-center">
                                    No stock found
                                  </td>
                                </tr>
                              )}
                            </tbody>
                          </table>

                          <div className="card-footer border-0 pb-0 d-flex justify-content-end">
                                <button
                                    className="btn btn-primary me-3"
                                    type="button"
                                    onClick={handleUpdate}
                                    disabled={updating}
                                >
                                    {updating ? (
                                    <>
                                        <span
                                        className="spinner-border spinner-border-sm me-2"
                                        role="status"
                                        aria-hidden="true"
                                        ></span>
                                        Updating...
                                    </>
                                    ) : (
                                    "Update"
                                    )}
                                </button>
                                </div>

                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default UpdateList;
