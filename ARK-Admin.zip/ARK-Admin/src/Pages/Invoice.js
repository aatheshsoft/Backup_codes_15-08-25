import React, { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import axios from "axios";
import "./Invoice.css";
import Logo from'../Assets/pdf-header.jpg'
import { useParams } from "react-router-dom";

const Invoice = () => {
  const { id: order_id } = useParams(); 
  const [orderData, setOrderData] = useState(null);
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
  const [imageLoaded, setImageLoaded] = useState(false);

  useEffect(() => {
    if (!order_id) return;

    const fetchOrderDetails = async () => {
      try {
        const response = await axios.post(
          `${API_BASE_URL}order_details.php`,
          { order_id }
        );

        if (response.data.head.code === 200) {
          setOrderData(response.data.body);
        } else {
          console.error("Failed to fetch order details");
        }
      } catch (error) {
        console.error("Error fetching order details:", error);
      }
    };

    fetchOrderDetails();
  }, [order_id]);

   useEffect(() => {
    if (orderData && imageLoaded) {
      setTimeout(() => {
        window.print();
      }, 300); // slight delay to ensure everything is rendered
    }
  }, [orderData, imageLoaded]);

  if (!orderData) {
    return <p>Loading...</p>;
  }

  return (
    <div className="invoice-wrapper">
      <div className="invoice-container">
        <table className="invoice-table">
          <tbody>
            {/* Header with Logo */}
            <tr>
              <td className="invoice-header">
                <img
                  src={Logo}
                  alt="Company Logo"
                   onLoad={() => setImageLoaded(true)}
                />
                {/* <p><b>TAX INVOICE</b></p> */}
              </td>
              
            </tr>
           {/* GST Number */}
           <tr>
              <td className="order-info">
                <div className="order-row">
                  &nbsp;<span>GST Number: {orderData.gst_number}</span> &nbsp; 
                </div>
              </td>
            </tr>
            {/* Order Info */}
            <tr>
              <td className="order-info">
                <div className="order-row">
                  &nbsp;<span>Order ID: {orderData.order_id}</span> &nbsp;- &nbsp;
                  <span>Date: {orderData.orderdate}</span>
                </div>
              </td>
            </tr>

            {/* Billing & Shipping */}
            <tr>
              <td className="billing-shipping">
                <div className="billing">
                  <h3>Billing Information</h3>
                  <p>{orderData.billing_name}</p>
                  <p>
                    {orderData.billing_address}, {orderData.billing_city},{" "}
                    {orderData.billing_state}, {orderData.billing_pincode}
                  </p>
                  <p><strong>Mobile:</strong> {orderData.mobile}</p>
                  <p><strong>Email:</strong> {orderData.email}</p>
                </div>

                {/* <div className="shipping">
                  <h3>Shipping Information</h3>
                  <p>{orderData.delivery_name}</p>
                  <p>
                    {orderData.delivery_address}, {orderData.delivery_city},{" "}
                    {orderData.delivery_state}, {orderData.delivery_pincode}
                  </p>
                  <p><strong>Mobile:</strong> {orderData.mobile}</p>
                  <p><strong>Email:</strong> {orderData.email}</p>
                </div> */}
              </td>
            </tr>

            {/* Product Table */}
            <tr>
              <td className="products-section">
                <table className="product-table">
                  <thead>
                    <tr>
                      <th>S.No</th>
                      <th>Product Name</th>
                      <th>Qty</th>
                      <th>Price</th>
                    </tr>
                  </thead>
                  <tbody>
                    {orderData.order_details.map((item, index) => (
                      <tr key={index}>
                        <td>{index + 1}</td>
                        <td>{item.product_name}</td>
                        <td>{item.qty} x ₹{parseFloat(item.amount).toFixed(2)}</td>
                        <td align="right">₹{parseFloat(item.totalamount).toFixed(2)}</td>
                      </tr>
                    ))}
                    <tr>
                      <td colSpan="3" align="right"><b>Sub-Total</b></td>
                      <td align="right">₹{orderData.subtotal}</td>
                    </tr>
                    {/* <tr>
                      <td colSpan="3" align="right"><b>SGST (9%)</b></td>
                      <td align="right">₹{orderData.sgst_amt}</td>
                    </tr> */}
                    <tr>
                      <td colSpan="3" align="right"><b>Discount ({orderData.discount_percentage}%)</b></td>
                      <td align="right">₹{orderData.discount_amt}</td>
                    </tr>
                     {/* <tr>
                      <td colSpan="3" align="right"><b>CGST</b></td>
                      <td align="right">₹{orderData.cgst_amt}</td>
                    </tr>
                     <tr>
                      <td colSpan="3" align="right"><b>SGST</b></td>
                      <td align="right">₹{orderData.sgst_amt}</td>
                    </tr> */}
                    <tr>
                      <td colSpan="3" align="right"><b>Grand Total</b></td>
                      <td align="right">₹{orderData.total}</td>
                    </tr>
                  </tbody>
                </table>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Invoice;
