import React,{useEffect} from 'react'

const PrintInvoice = () => {
    useEffect(() => {
        window.print();
      }, []);
    
  return (
    <div className="invoice-container">
      <table width="100%" border="0" align="center" cellpadding="2" cellspacing="0">
        <tr>
          <td bgcolor="#0066CC">
            <table width="750" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td bgcolor="#FFFFFF">
                  <img src="https://www.easya.in/images/easya-logo.png" alt="Logo" />
                </td>
              </tr>
              <tr>
                <td bgcolor="#FFFFFF" style={{ borderTop: '2px solid #CC0000' }}>
                  <table width="100%" cellspacing="0" cellpadding="0" border="0">
                    <tr>
                      <td align="center">
                        <table width="100%" cellspacing="0" cellpadding="0" border="0">
                          <tr>
                            <td colspan="2" style={{ borderBottom: '2px solid #CC0000' }}>
                              <table width="100%" align="center" border="0" cellpadding="5" cellspacing="1">
                                <tr>
                                  <td width="33%" style={{ fontFamily: 'Verdana, Arial, Helvetica, sans-serif', fontSize: '14px', fontWeight: 'bold', textAlign: 'left' }}>Order ID: 72</td>
                                  <td width="33%" style={{ fontFamily: 'Verdana, Arial, Helvetica, sans-serif', fontSize: '14px', fontWeight: 'bold', textAlign: 'center' }}></td>
                                  <td width="33%" align="right" style={{ fontFamily: 'Verdana, Arial, Helvetica, sans-serif', fontSize: '14px', fontWeight: 'bold', textAlign: 'right' }}>Date: 08-01-2025</td>
                                </tr>
                              </table>
                            </td>
                          </tr>
                          <tr>
                            <td valign="top">
                              <table width="100%" align="center" border="0" cellpadding="2" cellspacing="1">
                                <tr>
                                  <td style={{ fontWeight: 'bold', fontSize: '14px', textTransform: 'uppercase', color: '#000000', fontFamily: 'Arial, Helvetica, sans-serif', letterSpacing: '2px', textAlign: 'left' }}>
                                    <b>Billing Information</b>
                                  </td>
                                </tr>
                                <tr>
                                  <td style={{ fontFamily: 'Verdana, Arial, Helvetica, sans-serif', fontSize: '14px', color: '#000000', paddingLeft: '4px', textAlign: 'left' }}>nandha</td>
                                </tr>
                                <tr>
                                  <td style={{ fontFamily: 'Verdana, Arial, Helvetica, sans-serif', fontSize: '14px', color: '#000000', paddingLeft: '4px', textAlign: 'left' }}>sivakasi</td>
                                </tr>
                                <tr>
                                  <td style={{ fontFamily: 'Verdana, Arial, Helvetica, sans-serif', fontSize: '14px', color: '#000000', paddingLeft: '4px', textAlign: 'left' }}>sivakasi</td>
                                </tr>
                                <tr>
                                  <td style={{ fontFamily: 'Verdana, Arial, Helvetica, sans-serif', fontSize: '14px', color: '#000000', paddingLeft: '4px', textAlign: 'left' }}>tamilnadu</td>
                                </tr>
                                <tr>
                                  <td style={{ fontFamily: 'Verdana, Arial, Helvetica, sans-serif', fontSize: '14px', color: '#000000', paddingLeft: '4px', textAlign: 'left' }}>123456</td>
                                </tr>
                                <tr>
                                  <td style={{ fontFamily: 'Verdana, Arial, Helvetica, sans-serif', fontSize: '14px', color: '#000000', paddingLeft: '4px', textAlign: 'left' }}>
                                    <b>Mobile No:</b> 1234567890
                                  </td>
                                </tr>
                                <tr>
                                  <td style={{ fontFamily: 'Verdana, Arial, Helvetica, sans-serif', fontSize: '14px', color: '#000000', paddingLeft: '4px', textAlign: 'left' }}>
                                    <b>Email ID:</b> customer@gmail.com
                                  </td>
                                </tr>
                              </table>
                            </td>
                            <td valign="top">
                              <table width="100%" align="center" border="0" cellpadding="2" cellspacing="1">
                                <tr>
                                  <td style={{ fontWeight: 'bold', fontSize: '12px', textTransform: 'uppercase', color: '#000000', fontFamily: 'Arial, Helvetica, sans-serif', letterSpacing: '2px', textAlign: 'left' }}>
                                    <b>Shipping Information</b>
                                  </td>
                                </tr>
                                <tr>
                                  <td style={{ fontFamily: 'Verdana, Arial, Helvetica, sans-serif', fontSize: '12px', color: '#000000', paddingLeft: '4px', textAlign: 'left' }}>aravinth</td>
                                </tr>
                                <tr>
                                  <td style={{ fontFamily: 'Verdana, Arial, Helvetica, sans-serif', fontSize: '12px', color: '#000000', paddingLeft: '4px', textAlign: 'left' }}>sithurajapuram123</td>
                                </tr>
                                <tr>
                                  <td style={{ fontFamily: 'Verdana, Arial, Helvetica, sans-serif', fontSize: '12px', color: '#000000', paddingLeft: '4px', textAlign: 'left' }}>svks</td>
                                </tr>
                                <tr>
                                  <td style={{ fontFamily: 'Verdana, Arial, Helvetica, sans-serif', fontSize: '12px', color: '#000000', paddingLeft: '4px', textAlign: 'left' }}>tamilnadu</td>
                                </tr>
                                <tr>
                                  <td style={{ fontFamily: 'Verdana, Arial, Helvetica, sans-serif', fontSize: '12px', color: '#000000', paddingLeft: '4px', textAlign: 'left' }}>123456</td>
                                </tr>
                              </table>
                            </td>
                          </tr>
                          {/* Product Table */}
                          <tr>
                            <td colspan="2">
                              <table width="100%" align="center" cellspacing="1" cellpadding="5" border="0">
                                <thead>
                                  <tr>
                                    <td width="5%" align="center" style={{ backgroundColor: '#CCCCCC', fontWeight: 'bold', fontSize: '14px', textTransform: 'uppercase' }}>
                                      <b>S.No</b>
                                    </td>
                                    <td style={{ backgroundColor: '#CCCCCC', fontWeight: 'bold', fontSize: '14px', textTransform: 'uppercase' }}>
                                      <b>Product Name</b>
                                    </td>
                                    <td width="25%" align="center" style={{ backgroundColor: '#CCCCCC', fontWeight: 'bold', fontSize: '14px', textTransform: 'uppercase' }}>
                                      <b>Qty</b>
                                    </td>
                                    <td width="15%" align="center" style={{ backgroundColor: '#CCCCCC', fontWeight: 'bold', fontSize: '14px', textTransform: 'uppercase' }}>
                                      <b>Price</b>
                                    </td>
                                  </tr>
                                </thead>
                                <tbody>
                                  <tr>
                                    <td align="center" style={{ borderBottom: '1px solid #F6F6F6' }}>1</td>
                                    <td style={{ borderBottom: '1px solid #F6F6F6' }}><b>SEWING MACHINE MOTOR RITA</b></td>
                                    <td style={{ borderBottom: '1px solid #F6F6F6' }}>
                                      1 x at <i style={{ fontSize: '11px' }} className="fas fa-rupee-sign"></i>1750.00
                                    </td>
                                    <td align="right" style={{ borderBottom: '1px solid #F6F6F6' }}>
                                      <i style={{ fontSize: '11px' }} className="fas fa-rupee-sign"></i>1750.00
                                    </td>
                                  </tr>
                                  {/* Total Section */}
                                  <tr>
                                    <td colSpan="3" align="right" style={{ borderBottom: '1px solid #F6F6F6' }}>
                                      <b>Sub-Total</b>
                                    </td>
                                    <td align="right" style={{ borderBottom: '1px solid #F6F6F6' }}>
                                      <i style={{ fontSize: '11px' }} className="fas fa-rupee-sign"></i>1750.00
                                    </td>
                                  </tr>
                                  <tr>
                                    <td colSpan="3" align="right" style={{ borderBottom: '1px solid #F6F6F6' }}>
                                      <b>SGST (9%)</b>
                                    </td>
                                    <td align="right" style={{ borderBottom: '1px solid #F6F6F6' }}>
                                      <i style={{ fontSize: '11px' }} className="fas fa-rupee-sign"></i>157.50
                                    </td>
                                  </tr>
                                  <tr>
                                    <td colSpan="3" align="right" style={{ borderBottom: '1px solid #F6F6F6' }}>
                                      <b>CGST (9%)</b>
                                    </td>
                                    <td align="right" style={{ borderBottom: '1px solid #F6F6F6' }}>
                                      <i style={{ fontSize: '11px' }} className="fas fa-rupee-sign"></i>157.50
                                    </td>
                                  </tr>
                                  <tr>
                                    <td colSpan="3" align="right" style={{ fontSize: '16px', fontWeight: 'bold', borderBottom: '2px solid #F6F6F6' }}>
                                      <b>Total</b>
                                    </td>
                                    <td align="right" style={{ fontSize: '16px', fontWeight: 'bold', borderBottom: '2px solid #F6F6F6' }}>
                                      <i style={{ fontSize: '16px' }} className="fas fa-rupee-sign"></i>2065.00
                                    </td>
                                  </tr>
                                </tbody>
                              </table>
                            </td>
                          </tr>
                          <tr>
                            <td colspan="2">
                              <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                <tr>
                                  <td style={{ paddingTop: '10px', fontFamily: 'Verdana, Arial, Helvetica, sans-serif', fontSize: '12px', color: '#000000', textAlign: 'center' }}>
                                    <p><strong>THANK YOU</strong></p>
                                    <p style={{ fontSize: '11px' }}>For your business. Visit us again</p>
                                  </td>
                                </tr>
                              </table>
                            </td>
                          </tr>
                        </table>
                      </td>
                    </tr>
                  </table>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </div>
  );
};

export default PrintInvoice;
