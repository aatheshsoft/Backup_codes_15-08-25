import React, { useEffect, useState } from "react";
import Header from "../Components/Header";
import { Link, useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import Skeleton from "react-loading-skeleton";
import "react-loading-skeleton/dist/skeleton.css";

const EditDiscount = () => {
  const { discount_id } = useParams();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

  const [formData, setFormData] = useState({
    start_amt: "",
    end_amt: "",
    discount_amt:"",
  });

  // Fetch category details on mount
  useEffect(() => {
    if (!discount_id) return;

    console.log("Fetching data for discount_id:", discount_id);
    setLoading(true);

    axios
      .post(`${API_BASE_URL}discount_detail.php`, {
        discount_id: discount_id,
      })
      .then((response) => {
        console.log("API Response:", response.data);
        if (response.data.head.code === 200) {
          const discountDetails = response.data.body;
          setFormData({
            start_amt: discountDetails.start_amt || "",
            end_amt: discountDetails.end_amt || "",
            discount_amt: discountDetails.discount_amt || "",
          });
        } else {
          alert(response.data.head?.msg || "Failed to fetch category details");
        }
      })
      .catch((error) => {
        console.error("Error fetching category details:", error);
      })
      .finally(() => setLoading(false));
  }, [discount_id]);




  // Handle form field changes
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };



  
  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();

    // if (!formData.start_amt || !formData.end_amt || formData.discount_amt ) {
    //   alert("Please fill in all fields before submitting.");
    //   return;
    // }

    console.log("Submitting data:", formData);

    axios
      .post(`${API_BASE_URL}discount_detail_update.php`, {
        discount_id: discount_id,
        start_amt: formData.start_amt,
        end_amt: formData.end_amt,
        discount_amt: formData.discount_amt,

      })
      .then((response) => {
        console.log("Update Response:", response.data);
        if (response.data.head.code === 200) {
          alert("Dsicount updated successfully!");
          navigate("/discount"); // Redirect after update
        } else {
          alert(response.data.head?.msg || "Failed to update category");
        }
      })
      .catch((error) => {
        console.error("Error updating category:", error);
        alert("An error occurred while updating. Please try again.");
      });
  };

  return (
    <>
      <Header />
      <div className="page-wrapper compact-wrapper" id="pageWrapper">
        <div className="page-body-wrapper">
          <div className="page-body">
            <div className="container-fluid">
              <div className="row">
                <div className="col-12">
                  <div className="row">
                    <div className="col-sm-12 m-auto">
                      <div className="card">
                        <div className="card-body">
                          <div className="title-header option-title d-sm-flex d-block">
                            <h5>Edit Discount</h5>
                            <div className="right-options">
                              <ul>
                                <li>
                                  <Link className="btn btn-solid" to="/discount">
                                    Back
                                  </Link>
                                </li>
                              </ul>
                            </div>
                          </div>

                          <form className="theme-form theme-form-2 mega-form" onSubmit={handleSubmit}>
                            {loading ? (
                              <>
                                {/* Skeleton Loader for Type of Category */}
                                <div className="mb-4 row align-items-center">
                                  <label className="form-label-title col-sm-3 mb-0">
                                    <Skeleton width={120} height={20} />
                                  </label>
                                  <div className="col-sm-9">
                                    <Skeleton height={40} />
                                  </div>
                                </div>

                                {/* Skeleton Loader for Main Category */}
                                <div className="mb-4 row align-items-center">
                                  <label className="form-label-title col-sm-3 mb-0">
                                    <Skeleton width={120} height={20} />
                                  </label>
                                  <div className="col-sm-9">
                                    <Skeleton height={40} />
                                  </div>
                                </div>

                                {/* Skeleton Loader for Buttons */}
                                <div className="card-footer border-0 pb-0 d-flex justify-content-end">
                                  <Skeleton width={100} height={40} />
                                  <Skeleton width={100} height={40} style={{ marginLeft: "10px" }} />
                                </div>
                              </>
                            ) : (
                              <>
                                {/* Type of Category Field */}
                                 <div className="mb-4 row align-items-center">
                                                <label className="form-label-title col-sm-3 mb-0">Start Amount</label>
                                                <div className="col-sm-9">
                                                <input
                                                    className="form-control"
                                                    type="text"
                                                    name="start_amt"
                                                    value={formData.start_amt}
                                                    onChange={handleChange}
                                                    placeholder="Enter Start Amount"
                                                    required
                                                />
                                                </div>
                                            </div>

                                            <div className="mb-4 row align-items-center">
                                                <label className="form-label-title col-sm-3 mb-0">End Amount</label>
                                                <div className="col-sm-9">
                                                <input
                                                    className="form-control"
                                                    type="text"
                                                    name="end_amt"
                                                    value={formData.end_amt}
                                                    onChange={handleChange}
                                                    placeholder="Enter End Amount"
                                                    required
                                                />
                                                </div>
                                            </div>


                                            <div className="mb-4 row align-items-center">
                                                <label className="form-label-title col-sm-3 mb-0">Discount Percentage</label>
                                                <div className="col-sm-9">
                                                <input
                                                    className="form-control"
                                                    type="text"
                                                    name="discount_amt"
                                                    value={formData.discount_amt}
                                                    onChange={handleChange}
                                                    placeholder="Enter Discount Percentage"
                                                    required
                                                />
                                                </div>
                                            </div>


                                {/* Buttons */}
                                <div className="card-footer border-0 pb-0 d-flex justify-content-end">
                                  <button className="btn btn-primary me-3" type="submit">
                                    Submit
                                  </button>
                                  <button
                                    className="btn btn-outline"
                                    type="button"
                                    onClick={() => navigate("/discount")}
                                  >
                                    Cancel
                                  </button>
                                </div>
                              </>
                            )}
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default EditDiscount;
