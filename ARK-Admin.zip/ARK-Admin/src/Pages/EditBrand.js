import React, { useState } from 'react';
import Header from "../Components/Header";
import { Link } from "react-router-dom";

const EditBrand = () => {
  const [brandName, setBrandName] = useState('');
  const [image, setImage] = useState(null);

  const handleSubmit = (event) => {
    event.preventDefault();
    // Handle the form submission logic here
    // You can send the form data to your API
    console.log('Brand Name:', brandName);
    console.log('Image:', image);
  };

  return (
    <>
    <Header />
    <div class="page-wrapper compact-wrapper" id="pageWrapper">
      <div class="page-body-wrapper">
    <div className="page-body">
      <div className="container-fluid">
        <div className="row">
          <div className="col-12">
            <div className="row">
              <div className="col-sm-12 m-auto">
                <div className="card">
                  <div className="card-body">
                    <div className="title-header option-title d-sm-flex d-block">
                      <h5>Edit Brand Name</h5>
                      <div className="right-options">
                        <ul>
                           <li>
                               <Link className="btn btn-solid" to="/brand">
                                 Back
                                </Link>
                            </li>
                        </ul>
                      </div>
                    </div>

                    <form
                      className="theme-form theme-form-2 mega-form"
                      onSubmit={handleSubmit}
                      encType="multipart/form-data"
                    >
                      <div className="mb-4 row align-items-center">
                        <label className="form-label-title col-sm-3 mb-0">Brand Name : </label>
                        <div className="col-sm-9">
                          <input
                            className="form-control"
                            type="text"
                            name="name"
                            value={brandName}
                            onChange={(e) => setBrandName(e.target.value)}
                            placeholder="Enter Brand Name"
                          />
                        </div>
                      </div>
                                              <div class="card-footer border-0 pb-0 d-flex justify-content-end">
                                            <button class="btn btn-primary me-3">Submit</button>
                                            <button class="btn btn-outline">Cancel</button>
                                        </div>	

                      <input type="hidden" name="id" value="" />
                      <input type="hidden" name="cid" value="1" />
                      <input type="hidden" name="scid" value="32" />
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    </div>
    </div>
    </>
  );
};

export default EditBrand;
