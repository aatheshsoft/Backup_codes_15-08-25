import React,{useState,useEffect} from "react";
import Header from "../Components/Header";
import { Link,useParams } from "react-router-dom";
import axios from "axios";

const SubCategory = () => {
  const[categories,setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const {category_id} = useParams();
  const [showModal, setShowModal] = useState(false);
  const [selectedcategoryId, setSelectedCategoryId] = useState(null);
  const [updateSuccess, setUpdateSuccess] = useState(false); 
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

  const openDeleteModal = (category_id) =>{
    setSelectedCategoryId(category_id)
    setShowModal(true);
  }
  const closeModal = () => {
    setSelectedCategoryId(null);
    setShowModal(false);
};

  useEffect(() =>{
    setLoading(true);
    console.log(category_id)
    axios.post (`${API_BASE_URL}category_list.php`,{
      
    })
    .then((response) =>{
      if(response.data.head.code === 200){
        const sortedCategories = response.data.body.sort((a,b) => a.rank - b.rank)
        
        setCategories(sortedCategories);
       
      }else{
        console.error("Error Fetching Data", response.data.head.msg)
      }
    })
    .catch((error) => {
      console.error("API Error:", error);
    })
    .finally(() => {
      setLoading(false);

    })
  },[])
  

const handleChange = (category_id,field,value) => {
  setCategories(categories.map(category =>
    category.category_id === category_id 
    ? { ...category, [field]: value } 
    : category
  ));
}

const handleUpdate = async(category_id,rank,front_active,non_discount,active) => {
  try{
    const response = await axios.post(`${API_BASE_URL}category_list_update.php`,{
      category_id,
      rank,
      front_active,
      non_discount,
      active,
    })
    if(response.data.head.code === 200){
      setCategories((prevCategories) =>
        prevCategories.map((category) =>
          category.category_id === category_id
            ? { ...category, rank, active } 
            : category
        )
      );
      setUpdateSuccess(true); // Set state for success
    }else{
      console.error('Error updating category:', response.data.head.msg);
    }
  }catch(error){
    console.error('Error updating category:', error);
  }
}

 useEffect(() => {
      if (updateSuccess) {
        alert("Category Updated Successfully");
        setUpdateSuccess(false); 
        window.location.href = window.location.href;
      }
    }, [updateSuccess]);



  const handleDelete = async () => {
    if(!selectedcategoryId) return;

    try{
      const response = await axios.post(`${API_BASE_URL}category_list_delete.php`,{
        category_id:selectedcategoryId,
      });
      if(response.data.head.code === 200){
        alert('Category Deleted Successfully')
        closeModal();
        window.location.reload();
      }else{
        alert(response.head?.msg || 'Failed To Delete  Category')
      }
    }catch(error){
      console.error("Error Deleting Category", error)
    }
  }


  return (
    <>
      <Header />
      <div class="page-wrapper compact-wrapper" id="pageWrapper">
        <div class="page-body-wrapper">
        <div className="page-body">
      <div className="container-fluid">
        <div className="row">
          <div className="col-sm-12">
            <div className="card card-table">
              <div className="card-body">
                <div className="title-header option-title d-sm-flex d-block">
                  <h5>List of Category</h5>
                  <div className="right-options">
                    <ul>
                      
                      <li>
                        <Link
                          className="btn btn-solid"
                          to="/updatelist"
                          // state={{ category_id }}
                        >
                          Update Product
                        </Link>
                      </li>
                      <li>
                        <Link
                          className="btn btn-solid"
                          to="/importproducts"
                          
                        >
                          Import
                        </Link>
                      </li>
                    </ul>
                  </div>
                </div>
                <form action="subcategory.php?cid=1" method="post">
                {loading ? (
                <div style={{ display: "flex", justifyContent: "center", marginTop: "50px" }}>
                <div className="loader"></div>
              </div>
              ) : (
                <>
                  <div className="table-responsive">
                    <table
                      className="table all-package theme-table table-product"
                      id="table_id"
                    >
                      <thead>
                        <tr>
                          <th>S.No.</th>
                          <th>Title</th>
                          <th style={{ textAlign: "center" }}>Rank</th>
                          <th style={{ textAlign: "center" }}>Index</th>
                          <th style={{ textAlign: "center" }}>Non-discount</th>
                          <th style={{ textAlign: "center" }}>Active</th>
                          {/* <th style={{ textAlign: "center" }}>Brand</th> */}
                          <th style={{ textAlign: "center" }}>Product</th>
                          <th style={{ textAlign: "center" }}>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                      {categories.map((Category, index) => (
                          <tr key={Category.category_id}>
                            <td>{index + 1}</td>
                            <td>{Category.category_name}</td>
                            <td style={{ textAlign: "center" }}>
                              <input
                                className="checkbox_animated check-it"
                                type="text"
                                size="4"
                                name={`rank_${Category.category_id}`}
                                value={Category.rank}
                                onChange={(e) => handleChange(Category.category_id, 'rank', e.target.value)}
                              />
                            </td>
                            <td style={{ textAlign: "center" }}>
                              <input
                                className="checkbox_animated check-it"
                                type="checkbox"
                                name={`front_active${Category.category_id}`}
                                value="1"
                                checked={Category.front_active === '1'}
                                onChange={(e) => handleChange(Category.category_id, 'front_active',e.target.checked ? '1' : '0')}
                              />   
                            </td>
                            <td style={{ textAlign: "center" }}>
                              <input
                                className="checkbox_animated check-it"
                                type="checkbox"
                                name={`non_discount${Category.category_id}`}
                                value="1"
                                checked={Category.non_discount === '1'}
                                onChange={(e) => handleChange(Category.category_id, 'non_discount',e.target.checked ? '1' : '0')}
                              />   
                            </td>
                            
                            <td style={{ textAlign: "center" }}>  
                              <input
                                className="checkbox_animated check-it"
                                type="checkbox"
                                name={`act_${Category.category_id}`}
                                value="1"
                                checked={Category.active === '1'}
                                onChange={(e) => handleChange(Category.category_id, 'active', e.target.checked ? '1' : '0')}
                              />
                            </td>
                            {/* <td style={{ textAlign: "center" }}>
                              <Link to= '/brand'>
                                <i className="ri-cast-fill ri-2x"></i>
                              </Link>
                            </td> */}
                            <td style={{ textAlign: "center" }}>
                              <Link
                                to={`/products/${Category.category_id}`}
                              >
                                <i className="ri-shopping-bag-line ri-2x"></i>
                              </Link>
                            </td>
                            <td style={{ textAlign: "center" }}>
                              <ul>
                                <li>
                                  <Link
                                    to={`/editsubcategory/${Category.category_id}`}
                                    state={{ category_id }}
                                    >
                                    
                                    <i className="ri-pencil-line"></i>
                                  </Link>
                                </li>
                                <li>
                                  <a
                                   href="#" onClick={(e) => { e.preventDefault(); openDeleteModal(Category.category_id); }}
                                  >
                                    <i className="ri-delete-bin-line"></i>
                                  </a>
                                </li>
                              </ul>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                
                  
                  <div class="card-footer border-0 pb-0 d-flex justify-content-end">
                  <ul>
                      
                      <li>
                        <Link
                          className="btn btn-solid"
                          to="/addsubcategory"
                          state={{ category_id }}
                        >
                          Add Category
                        </Link>
                      </li>
                     </ul>&nbsp;&nbsp;
                            <button class="btn btn-primary me-3" type="button"
                             onClick={() => {
                              categories.forEach((Category) => {
                                handleUpdate(Category.category_id, Category.rank,Category.front_active,Category.non_discount,Category.active );
                              });
                            }}
                            >Update</button>                                           
                        </div>
                        </>
                        )}
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
        </div>
      </div>

      {showModal && (
                <div className="modal fade show" style={{ display: "block" }}>
                    <div className="modal-dialog modal-dialog-centered">
                        <div className="modal-content">
                            <div className="modal-body">
                                <h5>Confirm Delete</h5>
                                <p>Are you sure you want to delete this subcategory?</p>
                                <button type="button" className="btn-close" onClick={closeModal}></button>
                            </div>
                            <div className="modal-footer">
                                <button type="button" className="btn btn-secondary" onClick={closeModal}>
                                    No
                                </button>
                                <button type="button" className="btn btn-danger" onClick={handleDelete}>
                                    Yes, Delete
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}
    </>
  );
};

export default SubCategory;
