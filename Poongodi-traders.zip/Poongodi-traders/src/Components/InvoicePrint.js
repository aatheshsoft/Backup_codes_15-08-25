import React,{useEffect} from "react";
import Logo from "../Assets/poongoditraders_logo.png"
import Image from "../Assets/lakshmi-icon.jpg"



const InvoicePrint = () => {
  const orderData = JSON.parse(localStorage.getItem("orderdata"));
  console.log("orderdata", orderData);

  useEffect(() => {
    //retrieve order data from local storage
    const orderData = JSON.parse(localStorage.getItem("orderdata"));

    
     setTimeout(() => {
      window.print();
    }, 500);

    return () => {
      // Clear local storage after printing
      localStorage.removeItem("orderdata");
    };
  }, []);
  

  if (!orderData || !orderData.body || !orderData.body.bill_detail || !orderData.body.final_billing) {
    return <p>No invoice data available.</p>;
  }


 const orderId = orderData.body.order_id;
 const time = orderData.body.order_time;
 const transport = orderData.body.transport;
 const vehicle = orderData.body.vehicle_no;



 const orderDate = orderData.body.order_date;
  const { bill_detail, final_billing } = orderData.body;
  const seller_detail = orderData.body.seller_detail;
  const buyer_detail = orderData.body.buyer_detail;

  // Calculate bottom section totals
  let totalAmount = 0;

  bill_detail.forEach((item) => {
    totalAmount += parseFloat(item.total_with_gst_per_product) || 0;
    
  });

  let taxSummary = {};

  // Process each tax category dynamically
  final_billing.forEach((item) => {
    Object.keys(item).forEach((taxKey) => {
      if (item[taxKey] && typeof item[taxKey] === "object") {
        const gstRate = parseInt(taxKey.replace("tax", ""), 10);
  
        if (!taxSummary[gstRate]) {
          taxSummary[gstRate] = {
            taxableValue: 0,
            cgst: 0,
            sgst: 0,
            totalTax: 0,
          };
        }
  
        taxSummary[gstRate].taxableValue += item[taxKey].without_gst || 0;
        taxSummary[gstRate].cgst += (item[taxKey].gst_amt || 0) / 2;
        taxSummary[gstRate].sgst += (item[taxKey].gst_amt || 0) / 2;
        taxSummary[gstRate].totalTax += item[taxKey].gst_amt || 0;
      }
    });
  });
  
  const numberToWords = (num) => {
    if (num === 0) return "Zero";
  
    const ones = [
      "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine",
      "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen",
      "Seventeen", "Eighteen", "Nineteen"
    ];
    const tens = [
      "", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"
    ];
  
    const convertBelowThousand = (n) => {
      if (n < 20) return ones[n];
      if (n < 100) return tens[Math.floor(n / 10)] + (n % 10 !== 0 ? " " + ones[n % 10] : "");
      return ones[Math.floor(n / 100)] + " Hundred" + (n % 100 !== 0 ? " and " + convertBelowThousand(n % 100) : "");
    };
  
    let integerPart = Math.floor(num); // Rupees
    let decimalPart = Math.round((num - integerPart) * 100); // Paise
  
    let result = "";
  
    // Convert Rupees
    if (integerPart > 0) {
      let crores = Math.floor(integerPart / 10000000);
      let lakhs = Math.floor((integerPart % 10000000) / 100000);
      let thousands = Math.floor((integerPart % 100000) / 1000);
      let hundreds = integerPart % 1000;
  
      if (crores) result += convertBelowThousand(crores) + " Crore ";
      if (lakhs) result += convertBelowThousand(lakhs) + " Lakh ";
      if (thousands) result += convertBelowThousand(thousands) + " Thousand ";
      if (hundreds) result += convertBelowThousand(hundreds);
    } else {
      result = "Zero";
    }
  
    result = result.trim();
  
    // Convert Paise if present
    if (decimalPart > 0) {
      result += ` and ${convertBelowThousand(decimalPart)} Paise`;
    }
  
    return result + " Only";
  };
  
  
  return (
    <div
    style={{
      width: "100%", 
      maxWidth: "100%", 
      margin: "auto", 
      padding: "10px",
      fontFamily: "Arial, sans-serif",
    }}
       className="invoice-container"
    >
  <div
  style={{
    position: "relative",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    padding: "0 10px",
    marginBottom: "10px",
  }}
>
  {/* Left - Logo */}
  <img
    src={Logo}
    alt="Poongodi Traders"
    style={{ width: "80px", height: "auto" }}
  />

  {/* Center - Tax Invoice */}
  <h2
    style={{
      position: "absolute",
      left: "50%",
      transform: "translateX(-50%)",
      margin: 0,
      color: "black",
      fontSize: "20px",
      fontWeight: "bold",
    }}
  >
    Tax Invoice
  </h2>
 
 

  {/* Right - Lakshmi Image */}
  <img
    src={Image}
    alt="Lakshmi"
    style={{ width: "70px", height: "70px", objectFit: "contain" }}
  />
</div>
<h3
    style={{
      position: "absolute",
      left: "50%",
      transform: "translateX(-50%)",
      marginTop:"-25px",
      color: "black",
      fontSize: "20px",
      fontWeight: "bold",
    }}
  >
    Poongodi Traders
  </h3>
<hr />

      {/* Header Section */}
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          borderBottom: "1px solid black",
          paddingBottom: "10px",
        }}
      >
        <div>
      
    <>
      <strong>{seller_detail.shop_name}</strong>,
      <br />
      <strong>{seller_detail.gst_no}</strong>,
      <br />
      {seller_detail.address}
      <br />
      {seller_detail.city}
      <br />
      {seller_detail.state} - {seller_detail.pincode} 
      <br />
      {seller_detail.phone}
      <br />
      
    </>
 
        </div>
        <div>
          <strong>Invoice No:</strong> {orderId}
          <br />
          <strong>Dated:</strong> {orderDate}
        </div>
      </div>

      {/* Buyer Details */}
      <div
        style={{
          marginTop: "10px",
          borderBottom: "1px solid black",
          paddingBottom: "10px",
          display: "flex",
          justifyContent: "space-between",
        }}
      >
       
    <div>
    <strong>Buyer (Bill to)</strong><br />
      <strong>{buyer_detail.name}</strong>,
      <br />
      {buyer_detail.tax_number}
      <br />
      {buyer_detail.address}
      <br />
      {buyer_detail.telephone}
      <br />
      
    </div>
   
   <div>
   <strong>Invoice Date & Time : </strong><p>{orderDate} & {time}</p> <br/>
   <strong>Vehicle Number : </strong><p> {vehicle}</p> <br/>
   <strong>Transport : </strong><p> {transport}</p>
   </div>
      </div> 

      {/* Product Table */}
      <table
        style={{
          width: "100%",
          borderCollapse: "collapse",
          marginTop: "10px",
        }}
      >
        <thead>
          <tr>
            <th style={{ border: "1px solid black", padding: "5px" }}>S No</th>
            <th style={{ border: "1px solid black", padding: "5px" }}>Description of Goods</th>
            <th style={{ border: "1px solid black", padding: "5px",textAlign:"center" }}>HSN/SAC</th>
            <th style={{ border: "1px solid black", padding: "5px",textAlign:"center" }}>Rate</th>
            <th style={{ border: "1px solid black", padding: "5px",textAlign:"center" }}>GST Rate</th>
            <th style={{ border: "1px solid black", padding: "5px",textAlign:"center" }}>Quantity</th>
            
            <th style={{ border: "1px solid black", padding: "5px",textAlign:"right"  }}>Amount</th>
          </tr>
        </thead>
        <tbody>
          {bill_detail.map((item, index) => (
            <tr key={index}>
              <td style={{ border: "1px solid black", padding: "5px" }}>{index + 1}</td>
              <td style={{ border: "1px solid black", padding: "5px" }}>{item.product_name}</td>
              <td style={{ border: "1px solid black", padding: "5px",textAlign:"center" }}>{item.hsn_code}</td>
              <td style={{ border: "1px solid black", padding: "5px",textAlign:"center"  }}>{parseFloat(item.amount_with_tax_per_product).toFixed(2)}</td>

              <td style={{ border: "1px solid black", padding: "5px",textAlign:"center" }}>{item.tax_percentage}%</td>
              <td style={{ border: "1px solid black", padding: "5px",textAlign:"center" }}>{item.qty}-{item.unit}</td>
              <td style={{ border: "1px solid black", padding: "5px", textAlign: "right" }}>
                {parseFloat(item.total_with_gst_per_product).toFixed(2)}
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Total Amount */}
      <div style={{ textAlign: "right", marginTop: "10px" }}>
              <strong>Sub-total : Rs. {Math.round(totalAmount).toFixed(2)} </strong>
            </div>
            <div style={{ textAlign: "right", marginTop: "10px" }}>
              <strong>CGST : Rs. {Object.values(taxSummary).reduce((acc, item) => acc + item.cgst, 0).toFixed(2)} </strong>
            </div>
            <div style={{ textAlign: "right", marginTop: "10px" }}>
              <strong>SGST : Rs. {Object.values(taxSummary).reduce((acc, item) => acc + item.sgst, 0).toFixed(2)} </strong>
            </div>
            <div style={{ textAlign: "right", marginTop: "10px" }}>
              <strong>
                Grand Total : Rs.{" "}
                {Math.round(
                  totalAmount +
                  Object.values(taxSummary).reduce((acc, item) => acc + item.cgst, 0) +
                  Object.values(taxSummary).reduce((acc, item) => acc + item.sgst, 0)
                ).toFixed(2)}
              </strong>
        </div>
      <div style={{ borderTop: "1px solid black", marginTop: "10px", paddingTop: "10px" }}>
  <strong>Amount Chargeable (in words):</strong> Indian Rupees {numberToWords(
               Math.round(   totalAmount +
                  Object.values(taxSummary).reduce((acc, item) => acc + item.cgst, 0) +
                  Object.values(taxSummary).reduce((acc, item) => acc + item.sgst, 0)
               )
                )}
   </div>



      {/* Tax Details */}
      <div style={{ borderTop: "1px solid black", marginTop: "10px", paddingTop: "10px" }}>
        <strong>Tax Details:</strong>
        <table style={{ width: "100%", borderCollapse: "collapse", marginTop: "10px" }}>
  <thead>
    <tr>
      {/* <th style={{ border: "1px solid black", padding: "5px" }}>Tax Rate</th> */}
      <th style={{ border: "1px solid black", padding: "5px",textAlign:"right"  }}>Taxable Value</th>
      <th style={{ border: "1px solid black", padding: "5px" }}>CGST(%)</th>
      <th style={{ border: "1px solid black", padding: "5px",textAlign:"right"  }}>CGST</th>
      <th style={{ border: "1px solid black", padding: "5px" }}>SGST(%)</th>
      <th style={{ border: "1px solid black", padding: "5px",textAlign:"right"  }}>SGST</th>
      <th style={{ border: "1px solid black", padding: "5px",textAlign:"right"  }}>Total Tax</th>
    </tr>
  </thead>
  <tbody>
  {Object.keys(taxSummary).map((taxRate) => (
    <tr key={taxRate}>
      <td style={{ border: "1px solid black", padding: "5px", textAlign: "right" }}>
        {taxSummary[taxRate].taxableValue.toFixed(2)}
      </td>
      <td style={{ border: "1px solid black", padding: "5px" }}>{(taxRate / 2)}%</td>
      <td style={{ border: "1px solid black", padding: "5px", textAlign: "right" }}>
        {taxSummary[taxRate].cgst.toFixed(2)}
      </td>
      <td style={{ border: "1px solid black", padding: "5px" }}>{(taxRate / 2)}%</td>
      <td style={{ border: "1px solid black", padding: "5px", textAlign: "right" }}>
        {taxSummary[taxRate].sgst.toFixed(2)}
      </td>
      <td style={{ border: "1px solid black", padding: "5px", textAlign: "right" }}>
        {taxSummary[taxRate].totalTax.toFixed(2)}
      </td>
    </tr>
  ))}

  {/* Total Row */}
  <tr>
    <th style={{ border: "1px solid black", padding: "5px", textAlign: "right" }}>
     Total :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; {(totalAmount).toFixed(2)}
    </th>
    <th style={{ border: "1px solid black", padding: "5px" }}>-</th>
    <th style={{ border: "1px solid black", padding: "5px", textAlign: "right" }}>
      {Object.values(taxSummary).reduce((acc, item) => acc + item.cgst, 0).toFixed(2)}
    </th>
    <th style={{ border: "1px solid black", padding: "5px" }}>-</th>
    <th style={{ border: "1px solid black", padding: "5px", textAlign: "right" }}>
      {Object.values(taxSummary).reduce((acc, item) => acc + item.sgst, 0).toFixed(2)}
    </th>
    <th style={{ border: "1px solid black", padding: "5px", textAlign: "right" }}>
      {Object.values(taxSummary).reduce((acc, item) => acc + item.totalTax, 0).toFixed(2)}
    </th>
  </tr>
</tbody>


        </table>
      </div>
   <div style={{ textAlign: "left"}}>
       Company's PAN :  <strong>AHEPV6120H</strong>
      </div>
      <hr />
      {/* Name : M/s Vijayakumar foodgrains 
Bank of baroda
Ac no :33090500007268
Ifsc : BARB0SIVAKA (Fifth character is zero )
Sivakasi branch */}
      <div  style={{ textAlign: "left"}}>
       Name :  <strong>Poongodi Traders</strong>
      </div>
      <div  style={{ textAlign: "left"}}>
       Bank Name :  <strong>Bank of baroda</strong>
      </div>
      <div  style={{ textAlign: "left"}}>
       Ac.no :  <strong>33090500007268</strong>
      </div>
      <div  style={{ textAlign: "left"}}>
       IFSC :  <strong>BARB0SIVAKA</strong>
      </div>
      <div  style={{ textAlign: "left"}}>
       Branch :  <strong>Sivakasi</strong>
      </div>
      <hr />

      {/* Declaration */}
      <div style={{ textAlign: "left", marginTop: "5px", width: "50%" }}>
        <strong style={{ borderBottom: "1px solid" }}>Declaration</strong>
        <p style={{marginBottom:"25px"}}>
          <b>We declare that this invoice shows the actual price of the goods described and that all particulars are true and correct.</b>
        </p>
      </div>

      {/* Authorized Signatory */}
      <div style={{ textAlign: "right", marginTop: "-40px" }}>
        <strong>Authorized Signatory</strong>
      </div>
    </div>
  );
};

export default InvoicePrint;
