import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <div className="container-fluid">
  {/* Footer - Only visible on large screens (768px and above) */}
  <footer className="footer d-none d-md-block">
    <div className="row">
      <div className="col-md-12 footer-copyright text-center">
        <p className="mb-0" style={{ color: "#fff" }}>
          Copyright {new Date().getFullYear()} © POONGODI TRADERS.
          Developed by Aathesh Soft Solutions.
        </p>
      </div>
    </div>
  </footer>

  {/* Menu - Only visible on small screens (Below 768px) */}
  <div className="mobile-menu d-md-none">
    <div className="row text-center">
      <div className="col">
        <Link to = '/products'>
        <i class="bi bi-bag" style={{ fontSize: "24px" }}></i>
        <p>Products</p>
        </Link>
      </div>
      <div className="col">
      <Link to = '/purchaselist'>
        <i class="bi bi-tag" style={{ fontSize: "24px" }}></i>
        <p>Purchase</p>
        </Link>
      </div>
      <div className="col">
      <Link to = '/pos'>
        <i class="bi bi-display" style={{ fontSize: "24px" }}></i>
        <p>POS</p>
        </Link>
      </div>
      <div className="col">
      <Link to = '/orderlist'>
        <i className="bi bi-bar-chart" style={{ fontSize: "24px" }}></i>
        <p>Sales</p>
        </Link>
      </div>
    </div>
  </div>
</div>

  );
};

export default Footer;
