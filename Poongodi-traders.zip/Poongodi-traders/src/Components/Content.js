import React, { useState } from 'react';
import Header from "../Components/Header";
import { Link } from "react-router-dom";

const Content = () => {
  return (
    <>
    <Header />
    <div class="page-wrapper compact-wrapper" id="pageWrapper">
      <div class="page-body-wrapper">
      <div className="page-body">
      {/* Container-fluid starts */}
      <div className="container-fluid">
        <div className="row">
          <div className="col-sm-12">
            <div className="card card-table">
              <div className="card-body">
                <div className="title-header option-title d-sm-flex d-block">
                  <h5>Contents Management</h5>
                  <p></p>
                </div>
                <div>
                  <div className="table-responsive">
                    <br />
                    <table className="table all-package theme-table table-product" id="table_id">
                      <thead>
                        <tr>
                          <th className="hilites">Title</th>
                          <th width="18%" className="hilites" align="center">Action</th>
                        </tr>
                      </thead>

                      <tbody>
                        <tr>
                          <td align="left">Home</td>
                          <td align="center">
                          <Link to="/contentedit" title="Edit">
                              <i className="ri-pencil-line"></i>
                            </Link>
                          </td>
                        </tr>
                        <tr>
                          <td align="left">About US</td>
                          <td align="center">
                          <Link to="/contentedit" title="Edit">
                              <i className="ri-pencil-line"></i>
                            </Link>
                          </td>
                        </tr>
                        <tr>
                          <td align="left">Contact us</td>
                          <td align="center">
                          <Link to="/contentedit" title="Edit">
                              <i className="ri-pencil-line"></i>
                            </Link>
                          </td>
                        </tr>
                        <tr>
                          <td align="left">Whole Sale Purchase</td>
                          <td align="center">
                          <Link to="/contentedit" title="Edit">
                              <i className="ri-pencil-line"></i>
                            </Link>
                          </td>
                        </tr>
                        <tr>
                          <td align="left">Privacy Policy</td>
                          <td align="center">
                          <Link to="/contentedit" title="Edit">
                              <i className="ri-pencil-line"></i>
                            </Link>
                          </td>
                        </tr>
                        <tr>
                          <td align="left">Shipping & Delivery Policy</td>
                          <td align="center">
                          <Link to="/contentedit" title="Edit">
                              <i className="ri-pencil-line"></i>
                            </Link>
                          </td>
                        </tr>
                        <tr>
                          <td align="left">Terms & Conditions</td>
                          <td align="center">
                            <Link to="/contentedit" title="Edit">
                              <i className="ri-pencil-line"></i>
                            </Link>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                    <input type="hidden" name="page" value="" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Container-fluid ends */}
    </div>
      </div>
    </div>
    </>
  )
}

export default Content