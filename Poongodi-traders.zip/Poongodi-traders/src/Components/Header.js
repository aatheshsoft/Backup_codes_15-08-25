import React, { useState, useEffect } from "react";
import { NavLink, Link, useNavigate } from "react-router-dom";
import { FaUser, FaBox, FaClipboardList, FaShoppingCart, FaSignOutAlt } from "react-icons/fa";
import { Offcanvas, Button } from "react-bootstrap";
import usericon from '../Assets/4.jpg';
import Logo from '../Assets/poongoditraders_logo.png';
import "../Pages/Sidebar.css";
import axios from "axios";
import { LuUsers } from "react-icons/lu";
import { FiImage } from "react-icons/fi";
import { IoSettingsOutline } from "react-icons/io5";
import { LuLogOut } from "react-icons/lu";
import { FiMonitor } from "react-icons/fi";
import { IoIosArrowForward } from "react-icons/io";
import { RiShoppingBag4Fill } from "react-icons/ri";
import { TbCategory2 } from "react-icons/tb";
import { MdOutlineDashboard } from "react-icons/md";
import { BiSolidPurchaseTag } from "react-icons/bi";
import { TbBrandAuth0 } from "react-icons/tb";
import { FaUsersRectangle } from "react-icons/fa6";
import { FaMoneyBill1 } from "react-icons/fa6";



const initializeFeatherIcons = () => {
    if (window.feather) {
        window.feather.replace();
    }
};

const Header = () => {
  const [permissions, setPermissions] = useState({});
  const [show, setShow] = useState(false);
  const navigate = useNavigate();
  const [isOpen, setIsOpen] = useState(true);
  const [isReportOpen, setIsReportOpen] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const [showModal, setShowModal] = useState(false);
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;



    const toggleReportMenu = () => {
    setIsReportOpen(!isReportOpen);
  };
    // Show the modal
    const openModal = () => {
      setShowModal(true);
    };
  
    // Hide the modal
    const closeModal = () => {
      setShowModal(false);
    };
   
    useEffect(() => {
        initializeFeatherIcons();
    }, []);


    const userId = localStorage.getItem("user_id");

  const handleLogout = () => {
    localStorage.removeItem("user_id"); // Remove userId from localStorage
    navigate("/login"); // Redirect to login page
  };
  const userName = JSON.parse(localStorage.getItem('user_name'));
  // console.log(userName);
  useEffect(() => {
    let userId = localStorage.getItem("user_id");
  
    if (!userId) {
      console.error("No user ID found. Please log in again.");
      return;
    }
  
    userId = userId.replace(/^"|"$/g, ''); // Remove extra double quotes if they exist
  
    const fetchPermissions = async () => {
      try {
        console.log("Sending API request with user_id:", userId);
  
        const response = await axios.post(`${API_BASE_URL}employee_login_previllage.php`,
          { user_id: userId }, // Ensure correct format
          {
            headers: {
              "Content-Type": "application/json",
              "Accept": "application/json",
            },
          }
        );
  
        console.log("API Fixed Response:", response.data);
  
        if (response.data.head.code === 200 && response.data.body.length > 0) {
          setPermissions(response.data.body[0]);
        } else {
          alert("Error : Previlage Error");
        }
      } catch (error) {
        alert("API Error: Unable to fetch permissions.");
        console.error("API Error:", error);
      }
    };
  
    fetchPermissions();
  }, []);


 


    return (
        <>
            <div className="page-wrapper compact-wrapper" id="pageWrapper">
                <div className="page-header">
                    <div className="header-wrapper m-0">
                        <div className="header-logo-wrapper p-0">
                            <div className="logo-wrapper">
                                <Link to="/home">
                                    <h4>Logo</h4>
                                </Link>
                            </div>
                            <div className="toggle-sidebar">
                                <i
                                    className="status_toggle middle sidebar-toggle"
                                    onClick={handleShow}
                                    style={{ cursor: "pointer" }}
                                >
                                    &#9776; {/* Menu icon */}
                                </i>
                            </div>
                        </div>
                        <div className="header-name">
                        <img
                          className="header-companylogo"
                          src={Logo}
                          alt="User"
                        />
                        </div>
                        
                        <div className="nav-right col-6 pull-right right-header p-0">
                        <div className="header-username">
                        <span className="username">
                                    {userName ? userName.charAt(0).toUpperCase() + userName.slice(1) : ""}
                                  </span>

                                            {/* <p className="mb-0 font-roboto">
                                                Admin <i className="middle ri-arrow-down-s-line"></i>
                                            </p> */}
                        </div> 
                            <ul className="nav-menus">
                                {/* <li>
                                    <div className="mode">
                                        <i className="ri-moon-line"></i>
                                    </div>
                                </li> */}
                              
                                <li className="profile-nav onhover-dropdown pe-0 me-0">
                                    <div className="media profile-media">
                                        <img
                                            className="user-profile rounded-circle"
                                            src={usericon}
                                            alt="User"
                                        />
                                        {/* <div className="user-name-hide media-body">
                                            <span>{userName}</span>
                                            <p className="mb-0 font-roboto">
                                                Admin <i className="middle ri-arrow-down-s-line"></i>
                                            </p>
                                        </div> */}
                                    </div>
                                    <ul className="profile-dropdown onhover-show-div">
                                    {permissions.employee === "1" && (
                                        <li>
                                            <Link to="/users">
                                            <LuUsers style={{fontSize:"18px"}}/>
                                            <span>Employees</span>
                                            </Link>
                                        </li>
                                    )}
                                   {/*  {permissions.banner === "1" && (
                                        <li>
                                            <Link to="/bannerlist">
                                            <FiImage style={{fontSize:"18px"}}/>
                                            <span>Banners</span>
                                            </Link>
                                        </li>
                                    )} */}
                                    {permissions.settings === "1" && (
                                        <li>
                                            <Link to="/settings">
                                            <IoSettingsOutline style={{fontSize:"18px"}}/>
                                            <span>Settings</span>
                                            </Link>
                                        </li>
                                    )}
                                        <li>
                                            <a  href="#" onClick={(openModal)}>
                                            <LuLogOut  style={{fontSize:"18px"}}/>
                                            <span>Log out</span>
                                            </a>
                                        </li>

     
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            {/* Offcanvas Sidebar */}
            <Offcanvas 
                        show={show} 
                        onHide={handleClose} 
                        placement="start" 
                        style={{ width: '250px' }} // Set width to 200px
                    >
                        <Offcanvas.Header closeButton>
                            <Offcanvas.Title> Menu</Offcanvas.Title>
                        </Offcanvas.Header>
                        <Offcanvas.Body>
                            <ul className="offcanvas-menu">
                                           
                                                           <NavLink to="/home" className={({ isActive }) => (isActive ? "active" : "")}>
                                                             <li>
                                                               <MdOutlineDashboard />&nbsp; &nbsp;
                                                               {isOpen && <span>Dashboard</span>}
                                                             </li> 
                                                           </NavLink>
                                           
                                                           {/* Customer Menu Item */}
                                                           {permissions.customer === "1" && (
                                                             <NavLink to="/customerlist" className={({ isActive }) => (isActive ? "active" : "")}>
                                                               <li>
                                                                 <FaUser />&nbsp;&nbsp;
                                                                 {isOpen && <span>Customer</span>}
                                                               </li>
                                                             </NavLink>
                                                           )}
                                           
                                                           {permissions.category === "1" && (
                                                               <NavLink to="/maincategory" className={({ isActive }) => (isActive ? "active" : "")}>
                                                               <li>
                                                               <TbCategory2 />&nbsp;&nbsp;
                                                               {isOpen && <span>Category</span>}
                                                               </li>
                                                             </NavLink>
                                                           )}
                                                           {permissions.brand === "1" && (
                                                             <NavLink to="/brand" className={({ isActive }) => (isActive ? "active" : "")}>
                                                               <li>
                                                               <TbBrandAuth0 />&nbsp;&nbsp;
                                                                 {isOpen && <span> Brand</span>}
                                                               </li>
                                                             </NavLink>
                                                           )}
                                                              <NavLink to="/supplier" className={({ isActive }) => (isActive ? "active" : "")}>
                                                               <li>
                                                               <FaUsersRectangle />&nbsp;&nbsp;
                                           
                                           
                                                               {isOpen && <span>Supplier</span>}
                                                               </li>
                                                             </NavLink>
                                                           {/* Product Menu Item */}
                                                           {permissions.product === "1" && (
                                                             <NavLink to="/products" className={({ isActive }) => (isActive ? "active" : "")}>
                                                               <li>
                                                                 <RiShoppingBag4Fill />&nbsp;&nbsp;
                                                                 {isOpen && <span>Products</span>}
                                                               </li>
                                                             </NavLink>
                                                           )}
                                           
                                                           {permissions.purchase_list === "1" && (
                                                             <NavLink to="/purchaselist" className={({ isActive }) => (isActive ? "active" : "")}>
                                                               <li>
                                                               <BiSolidPurchaseTag />&nbsp;&nbsp;
                                           
                                                                 {isOpen && <span>PurchaseList</span>}
                                                               </li>
                                                             </NavLink>
                                                             )}
                                           
                                                           {/* POS Menu Item */}
                                                           {permissions.pos === "1" && (
                                                               <NavLink to="/pos" className={({ isActive }) => (isActive ? "active" : "")}>
                                                                  <li>
                                                                     <FiMonitor />&nbsp;&nbsp;
                                                                        {isOpen && <span>POS</span>}
                                                                          </li>
                                                                 </NavLink>
                                                           )}
                                                           {/* Orders Menu Item */}
                                           
                                                           {permissions.orders === "1" && (
                                                             <NavLink to="/orderlist" className={({ isActive }) => (isActive ? "active" : "")}>
                                                               <li>
                                                                 <FaShoppingCart />&nbsp;&nbsp;
                                                                 {isOpen && <span>Sales</span>}
                                                               </li>
                                                             </NavLink>
                                                           )}
                                           
                                                           {/* Cancel Orders Menu Item */}
                                                           {permissions.expenses === "1" && (
                                                             <NavLink to="/expenses" className={({ isActive }) => (isActive ? "active" : "")}>
                                                               <li>
                                                               <FaMoneyBill1 />&nbsp;&nbsp;
                                                               {isOpen && <span>Expenses</span>}
                                                               </li>
                                                             </NavLink>
                                                           )} 
                                           
                                                           {/* Report Section */}
                                                           <li onClick={toggleReportMenu} className="report-menu">
                                                             <FaClipboardList />&nbsp;&nbsp;
                                                             {isOpen && <span>Reports</span>}
                                                             {/* Arrow Icon */}
                                                             <IoIosArrowForward
                                                               className={`arrow-icon ${isReportOpen ? "open" : ""}`} // Rotate the arrow when dropdown is open
                                                             />
                                                           </li>
                                                           {isReportOpen && (
                                                             <>
                                                             <ul className="report-dropdown">
                                                                {permissions?.payment_report === "1" && (
                                                               <NavLink to="/paymentpending" className={({ isActive }) => (isActive ? "active" : "")}>
                                                                 <li style={{fontSize:"14px"}}>
                                                                   
                                                                     {isOpen && <span> -  Payment Pending Report</span>}
                                                                 </li>
                                                               </NavLink>
                                                                )}
                                                             
                                                             </ul>
                                                             <ul className="report-dropdown">
                                                             {permissions?.stock_report === "1" && (
                                                            <NavLink to="/stock" className={({ isActive }) => (isActive ? "active" : "")}>
                                                              <li style={{fontSize:"14px"}}>
                                                                
                                                                  {isOpen && <span> -  Stock Report</span>}
                                                              </li>
                                                            </NavLink>
                                                             )}
                                                          
                                                          </ul>
                                           
                                                          <ul className="report-dropdown">
                                                             {permissions?.gst_report === "1" && (
                                                            <NavLink to="/gstreport" className={({ isActive }) => (isActive ? "active" : "")}>
                                                              <li style={{fontSize:"14px"}}>
                                                                
                                                                  {isOpen && <span> -  GST Report</span>}
                                                              </li>
                                                            </NavLink>
                                                             )}
                                                          
                                                          </ul>
                                                          <ul className="report-dropdown">
                                                                            {permissions?.paid_report === "1" && (
                                                                           <NavLink to="/paidreport" className={({ isActive }) => (isActive ? "active" : "")}>
                                                                             <li style={{fontSize:"14px"}}>
                                                                               
                                                                                 {isOpen && <span> -  Paid Report</span>}
                                                                             </li>
                                                                           </NavLink>
                                                                            )} 
                                                                         
                                                                         </ul>
                                                                         <ul className="report-dropdown">
                                                                            {permissions?.purchase_report === "1" && (
                                                                           <NavLink to="/purchasereport" className={({ isActive }) => (isActive ? "active" : "")}>
                                                                             <li style={{fontSize:"14px"}}>
                                                                               
                                                                                 {isOpen && <span> -  Purchase Report</span>}
                                                                             </li>
                                                                           </NavLink>
                                                                             )} 
                                                                         
                                                                         </ul>
                                                          </>
                                                           )}
                                           
                                                           
                                                         
                                          </ul>
                        </Offcanvas.Body>
                    </Offcanvas>

                    {showModal && (
                        <div className="modal fade show d-block" tabIndex="-1" role="dialog">
                        <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-body">
                <h5 className="modal-title" id="staticBackdropLabel">Logging Out</h5>
                <p>Are you sure you want to log out?</p>
                <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close" onClick={closeModal}></button>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" data-bs-dismiss="modal" onClick={closeModal}>
                  No
                </button>
                <button type="button" className="btn btn-primary" onClick={handleLogout}>
                  Yes
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
        </>
    );
};

export default Header;
