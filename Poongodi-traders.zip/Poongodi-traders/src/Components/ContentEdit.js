import React, { useState } from "react";
import ReactQuill from "react-quill";
import "react-quill/dist/quill.snow.css"; // Import Quill styles
import Header from "../Components/Header";
import { Link } from "react-router-dom";

const ContentEdit = () => {
  const [content, setContent] = useState("<p>Edit me!</p>"); // Default content



  // Toolbar Configuration (Without Video & With Custom Fonts)
  const modules = {
    toolbar: [
      [{ font: [] }],
      [{ size: ["small", false, "large", "huge"] }],
      ["bold", "italic", "underline", "strike"],
      [{ color: [] }, { background: [] }],
      [{ script: "sub" }, { script: "super" }],
      [{ header: 1 }, { header: 2 }, { header: 3 }],
      [{ list: "ordered" }, { list: "bullet" }], // ✅ Ensure both list types are included
      [{ indent: "-1" }, { indent: "+1" }],
      [{ align: [] }],
      ["blockquote", "code-block"],
      ["link", "image"],
      ["clean"],
    ],
  };
  
  const formats = [
    "font",
    "size",
    "bold",
    "italic",
    "underline",
    "strike",
    "color",
    "background",
    "script",
    "header",
    "list",  // ✅ Make sure "list" is included
    "indent",
    "align",
    "blockquote",
    "code-block",
    "link",
    "image",
  ];
  

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(content); // Handle form submission (send to API if needed)
  };

  return (
    <>
      <Header />
      <div className="page-wrapper compact-wrapper" id="pageWrapper">
        <div className="page-body-wrapper">
          <div className="page-body">
            <div className="container-fluid">
              <div className="row">
                <div className="col-12">
                  <div className="row">
                    <div className="col-sm-12 m-auto">
                      <div className="card">
                        <div className="card-body">
                          <div className="card-header-2">
                            <h5>Home Contents</h5>
                          </div>

                          <div className="card-footer border-0 pb-0 d-flex justify-content-end">
                            <Link to="/content">
                              <button className="btn btn-primary me-3">Back</button>
                            </Link>
                          </div>
                          <br />

                          <div className="mb-4 row align-items-center">
                            <label className="form-label-title col-sm-3 mb-0">Title</label>
                            <div className="col-sm-9">Home</div>
                          </div>

                          {/* Full Featured Text Editor */}
                          <form onSubmit={handleSubmit} encType="multipart/form-data">
                            <div className="mb-4 row align-items-center">
                              <label className="form-label-title col-sm-3 mb-0">Content:</label>
                              <div className="col-sm-9">
                                <div className="custom-quill">
                                  <ReactQuill
                                    theme="snow"
                                    value={content}
                                    onChange={setContent}
                                    modules={modules}
                                    formats={formats}
                                    style={{ minHeight: "200px" }}
                                  />
                                </div>
                              </div>
                            </div>

                            <div className="card-footer border-0 pb-0 d-flex justify-content-end">
                              <button type="submit" name="submit" value="submit" className="btn btn-primary me-3">
                                Submit
                              </button>
                            </div>
                            <input type="hidden" name="content_id" value="1" />
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ContentEdit;
