import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Header from '../Components/Header';
import axios from 'axios';

const Users = () => {
    const [employees, setEmployees] = useState([]);
    const [loading, setLoading] = useState(true);
    const [updatedStatus, setUpdatedStatus] = useState({});
    const [showModal, setShowModal] = useState(false);
    const [selectedUserId, setSelectedUserId] = useState(null);
    const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

    // Open modal and set selected user_id
    const openDeleteModal = (user_id) => {
        setSelectedUserId(user_id);
        setShowModal(true);
    };

    // Close modal
    const closeModal = () => {
        setSelectedUserId(null);
        setShowModal(false);
    };

    useEffect(() => {
        const fetchEmployees = async () => {
            try {
                const response = await axios.post(`${API_BASE_URL}employe_list.php`);
                const data = response.data.body;
                setEmployees(data);

                // Initialize updatedStatus with user_status from API response
                const initialStatus = {};
                data.forEach(employee => {
                    initialStatus[employee.user_id] = employee.user_status === "1" ? 1 : 0;
                });
                setUpdatedStatus(initialStatus);

                setLoading(false);
            } catch (error) {
                console.error('Error Fetching Data:', error);
                setLoading(false);
            }
        };
        fetchEmployees();
    }, []);

    // Handle checkbox change
    const handleCheckboxChange = (user_id, checked) => {
        setUpdatedStatus(prevState => ({
            ...prevState,
            [user_id]: checked ? 1 : 0,
        }));
    };

    // Send updated statuses to API
    const handleUpdate = async () => {
      if (Object.keys(updatedStatus).length === 0) {
          alert("No changes made!");
          return;
      }
  
      try {
          for (const user_id of Object.keys(updatedStatus)) {
              const updatedData = {
                  user_id, 
                  user_status: updatedStatus[user_id].toString() // Ensure correct format
              };
  
              console.log("Sending data to API:", updatedData);
  
              const response = await axios.post(
                  `${API_BASE_URL}employe_list_update.php`,
                  updatedData
              );
  
              console.log('Status update response:', response.data);
  
              if (response.data.head?.code !== 200) {
                  alert(response.data.head?.msg || `Failed to update status for User ID: ${user_id}`);
                  return; // Stop execution if any update fails
              }
          }
          
          alert('Employee detail Updated Succeefully');
          window.location.reload();
      } catch (error) {
          console.error('Error updating status:', error);
          alert('An error occurred while updating statuses');
      }
  };

  
  const handleDelete = async () => {
    if (!selectedUserId) return;

    try {
        const response = await axios.post(`${API_BASE_URL}employe_list_delete.php` , {
            user_id: selectedUserId,
        });

        console.log("Delete Response:", response.data);

        if (response.data.head?.code === 200) {
            alert("Employee deleted successfully");
            closeModal();
            window.location.reload();

        } else {
            alert(response.data.head?.msg || "Failed to delete employee");
        }
    } catch (error) {
        console.error("Error deleting employee:", error);
        alert("An error occurred while deleting the employee");
    }
};

  


    return (
        <>
            <Header />
            <div className="page-wrapper compact-wrapper" id="pageWrapper">
                <div className="page-body-wrapper">
                    <div className="page-body">
                        <div className="container-fluid">
                            <div className="row">
                                <div className="col-sm-12">
                                    <div className="card card-table">
                                        <div className="card-body">
                                            <div className="title-header option-title d-sm-flex d-block">
                                                <h5>Employee Management</h5>
                                                <div className="right-options">
                                                    <ul>
                                                        <li>
                                                            <Link className="btn btn-solid" to="/addusers">
                                                                Add Employee
                                                            </Link>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>

                                            {/* Table with Loader */}
                                            <div className="table-responsive">
                                                {loading ? (
                                                    <div className="d-flex justify-content-center align-items-center" style={{ height: '200px' }}>
                                                        <div className="spinner-border text-primary" style={{ width: '3rem', height: '3rem' }} role="status">
                                                            <span className="visually-hidden">Loading...</span>
                                                        </div>
                                                    </div>
                                                ) : (
                                                    <table className="table all-package theme-table table-product" id="table_id">
                                                        <thead>
                                                            <tr>
                                                                <th>Name</th>
                                                                <th>Email</th>
                                                                <th>Mobile</th>
                                                                <th>Login Status</th>
                                                                <th>Previlage</th>
                                                                <th>Action</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            {employees.map((employee, index) => (
                                                                <tr key={employee.user_id} className={index % 2 === 0 ? 'evenrow' : 'oddrow'}>
                                                                    <td align="left">{employee.name}</td>
                                                                    <td align="left">{employee.email}</td>
                                                                    <td align="left">{employee.phone}</td>
                                                                    <td>
                                                                        <input
                                                                            className="checkbox_animated check-it"
                                                                            type="checkbox"
                                                                            name={`physc_${employee.user_id}`}
                                                                            value="1"
                                                                            checked={updatedStatus[employee.user_id] === 1}
                                                                            onChange={(e) => handleCheckboxChange(employee.user_id, e.target.checked)}
                                                                        />
                                                                    </td>
                                                                    <td align="center">
                                                                        <Link to={`/previlage/${employee.user_id}`}>
                                                                            <i className="ri-store-3-line ri-2x"></i>
                                                                        </Link>
                                                                    </td>
                                                                    <td align="center">
                                                                        <ul>
                                                                        <li>
                                                                            <Link to={`/editusers/${employee.user_id}`}>
                                                                                <i className="ri-pencil-line"></i>
                                                                            </Link>
                                                                        </li>
                                                                            <li>
                                                                                <a
                                                                                    href="javascript:void(0)"
                                                                                    onClick={() => openDeleteModal(employee.user_id)}
                                                                                >
                                                                                    <i className="ri-delete-bin-line"></i>
                                                                                </a>
                                                                            </li>
                                                                        </ul>
                                                                    </td>
                                                                </tr>
                                                            ))}
                                                        </tbody>
                                                    </table>
                                                )}
                                            </div>

                                            <div className="card-footer border-0 pb-0 d-flex justify-content-end">
                                                <button className="btn btn-primary me-3" type="button" onClick={handleUpdate}>
                                                    Update
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {showModal && (
                <div className="modal fade show" style={{ display: "block" }}>
                    <div className="modal-dialog modal-dialog-centered">
                        <div className="modal-content">
                            <div className="modal-body">
                                <h5>Confirm Deletion</h5>
                                <p>Are you sure you want to delete this employee?</p>
                                <button type="button" className="btn-close" onClick={closeModal}></button>
                            </div>
                            <div className="modal-footer">
                                <button type="button" className="btn btn-secondary" onClick={closeModal}>
                                    No
                                </button>
                                <button type="button" className="btn btn-danger" onClick={handleDelete}>
                                    Yes, Delete
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </>
    );
};

export default Users;
