import React, { useEffect, useState } from 'react';
import Header from '../Components/Header';
import axios from 'axios';
import Skeleton from "react-loading-skeleton";
import "react-loading-skeleton/dist/skeleton.css";




const Settings = () => {
  const [loading, setLoading] = useState(true);
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

  const [formData, setFormData] = useState({
    phonenumber: '',
    address: '',
    gstnumber:'',
    city: '',
    state: '',
    pincode: '',

  
  });

  const handleChange = (e) => {
    const { name, value } = e.target;

    // Mobile Number Validation (Allow Only 10 Digits)
    if (name === "phonenumber") {
        const sanitizedValue = value.replace(/\D/g, ""); // Remove non-numeric characters
        if (sanitizedValue.length > 10) {
            
            return; // Stop updating state if more than 10 digits
        }
        setFormData({
            ...formData,
            [name]: sanitizedValue, // Update only if valid
        });
    } else {
        // Update state for other inputs
        setFormData({
            ...formData,
            [name]: value,
        });
    }
};


  useEffect(() => {
    axios.post(`${API_BASE_URL}setting_detail.php`)
      .then((response) => {
        if (response.data.head.code === 200) {
          const Admindata = response.data.body;
          setFormData({
             id:Admindata.id,
            phonenumber: Admindata.phone || '',
            address: Admindata.address || '',
            gstnumber: Admindata.gst_no || '', 
            city: Admindata.city || '',
            state: Admindata.state || '',
            pincode: Admindata.pincode || '',

          });
          setLoading(false);
        } else {
          console.error("Error Fetching Data:", response.data.head.msg);
        }
      })
      .catch((error) => {
        console.error("API Error:", error);
      });
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    const payload = {
      id: formData.id, // Assuming '1' is the id you want to update, or get it from the form

      phone: formData.phonenumber,
      gst_no: formData.gstnumber,
      city: formData.city,
      state: formData.state,
      pincode: formData.pincode,

      address: formData.address
    };
    axios.post(`${API_BASE_URL}setting_update.php`, payload)
      .then((response) => {
        if (response.data.head.code === 200) {
          alert('Details Updated Successfully');
          window.location.reload();
          
        } else {
          alert("Update failed", response.data.head.msg);
          console.log('Update failed', response.data.head.msg);
        }
      })
      .catch((error) => {
        console.error("Update API Error", error);
      });
  };
  return (
    <>
      <Header />
      <div className="page-wrapper compact-wrapper" id="pageWrapper">
        <div className="page-body-wrapper">
          <div className="page-body">
            <div className="container-fluid">
              <div className="row">
                <div className="col-12">
                  <div className="row">
                    <div className="col-sm-12 m-auto">
                      <div className="card">
                        <div className="card-body">
                          <div className="card-header-2">
                            <h5>Settings</h5>
                          </div>
                          <form onSubmit={handleSubmit} encType="multipart/form-data">
                              {loading ? (
                                // Skeleton Loading - Placeholder
                                <>
                                  {Object.entries(formData).map(([key, value]) => (
                                        key !== "id" && ( // Exclude the 'id' field
                                          <div className="mb-4 row align-items-center" key={key}>
                                            <label className="form-label-title col-sm-3 mb-0">
                                              {key === "gstnumber" ? "GST Number" : key.replace(/_/g, " ").replace(/\b\w/g, (l) => l.toUpperCase())}
                                            </label>
                                            <div className="col-sm-9">
                                              <input
                                                type="text"
                                                name={key}
                                                className="form-control"
                                                value={value}
                                                size="30"
                                                maxLength={key === "gstnumber" ? 15 : key === "pincode" ? 6 : undefined} // Set max length to 15 for GST Number
                                                onChange={handleChange}
                                                placeholder={`Enter ${key === "gstnumber" ? "GST Number" : key.replace(/_/g, " ").replace(/\b\w/g, (l) => l.toUpperCase())}`}
                                              />
                                            </div>
                                          </div>
                                        )
                                      ))}

                                </>
                              ) : (
                                // Render actual form data once loading is complete
                                <>
                                  {Object.entries(formData).map(([key, value]) => (
                                      key !== "id" && ( // Exclude the 'id' field
                                        <div className="mb-4 row align-items-center" key={key}>
                                          <label className="form-label-title col-sm-3 mb-0">
                                            {key === "gstnumber" ? "GST Number" : key.replace(/_/g, " ").replace(/\b\w/g, (l) => l.toUpperCase())}
                                          </label>
                                          <div className="col-sm-9">
                                            <input
                                              type="text"
                                              name={key}
                                              className="form-control"
                                              value={value}
                                              size="30"
                                              maxLength={key === "gstnumber" ? 15 :key === "pincode" ? 6 : undefined} // Set max length to 15 for GST Number
                                              onChange={handleChange}
                                              placeholder={`Enter ${key === "gstnumber" ? "GST Number" : key.replace(/_/g, " ").replace(/\b\w/g, (l) => l.toUpperCase())}`}
                                            />
                                          </div>
                                        </div>
                                      )
                                    ))}


                                </>
                              )}
                              <div className="card-footer border-0 pb-0 d-flex justify-content-center">
                                <button
                                  type="submit"
                                  name="submit"
                                  value="Commit Changes"
                                  className="btn btn-primary me-3"
                                >
                                  Commit Changes
                                </button>
                              </div>
                            </form>

                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Settings;
