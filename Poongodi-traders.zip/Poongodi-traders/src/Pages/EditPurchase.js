import React, { useState,useEffect } from "react";
import Header from "../Components/Header";
import {useNavigate, useParams } from "react-router-dom";
import axios from "axios";

const EditPurchase = () => {
    const purchase_id = useParams();
    console.log("ID" ,purchase_id );
  const [categories, setCategories] = useState([]);
  const [brandName, setBrandName] = useState([]);
  const navigate = useNavigate();
  const [products, setProducts] = useState([]);
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
  const [supplierList, setSupplierList] = useState("")

  const [formData, setFormData] = useState({
    product_code: "",
    product_id: "",
    product_name: "",
    category_id: "",
    brand_id: "",
    hsn_code: "",
    gst: "",
    qty: "",
    unit: "",
    purchase_rate: "",
    sales_rate: "",
    supplier_name: "",
    supplier_mobile: "",
    gst_nbr: "",
    sku_no: "",
    note: ""
  });
 
  useEffect(() => {
    const fetchPurchaseDetails = async () => {
      try {
        console.log("Sending Request Data:", { purchase_list_id: purchase_id });

        const response = await axios.post(
          `${API_BASE_URL}pos_api/pos_purchase_detail.php`,
          { purchase_list_id: purchase_id.purchase_id }, // Extract the value
          {
            headers: {
              "Content-Type": "application/json",
            },
          }          
        );
        console.log("API Response:", response.data);
  
        if (response.data.head.code === 200 && response.data.body) {
          const data = response.data.body; // No [0], since body is an object
  
          setFormData((prevFormData) => ({
            ...prevFormData, 
            purchase_id: data.purchase_id || "",
            product_id: data.product_id || "",
            category_id: data.category_id || "",
            category_name: data.category_name || "",
            brand_id: data.brand_id || "",
            brand_name: data.brand_name || "",
            product_name: data.product_name || "",
            product_code: data.product_code || "",
            hsn_code: data.hsn_code || "",
            qty: data.qty || "",
            unit:data.unit || "",
            gst: data.gst || "",
            sku_no: data.sku_no || "",
            purchase_rate: data.purchase_rate || "",
            sales_rate: data.sales_rate || "",
            supplier_name: data.supplier_name || "",
            gst_nbr: data.gst_nbr || "",
            supplier_mobile: data.supplier_mobile || "",
            note: data.note || "",
          }));
        } else {
          console.log("No data found:", response.data);
        }
      } catch (error) {
        console.error("Error fetching data: ", error);
      }
    };
  
    if (purchase_id) {
      fetchPurchaseDetails();
    }
  }, [purchase_id]);
   // Re-run when purchase_id changes
  
   useEffect(() => {
    axios
      .post(`${API_BASE_URL}supplier_list.php`)
      .then((res) => {
        if (res.data && res.data.body && Array.isArray(res.data.body)) {
          setSupplierList(res.data.body);
        } else {
          console.error("API response is not an array:", res.data.body);
          setSupplierList([]); // fallback to empty array
        }
      })
      .catch((err) => {
        console.error("Error fetching supplier list", err);
        setSupplierList([]); // fallback to empty array
      });
  }, []);




  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };
  
  useEffect(() => {
    axios.post(`${API_BASE_URL}category_list.php`)
      .then(response => {
        if (response.data.head.code === 200) {
          setCategories(response.data.body);
        } else {
          console.error("Error fetching categories:", response.data.head.msg);
        }
      })
      .catch(error => console.error("API Error:", error));
  }, []);
  useEffect(() => {
       
    axios
      .post(`${API_BASE_URL}brand_list.php`)
      .then((response) => {
        if (response.data.head.code === 200) {
          
          
        setBrandName(response.data.body); // Store sorted categories in state
        } else {
          console.error("Error Fetching Data:", response.data.head.msg);
        }
      })
      .catch((error) => {
        console.error("API Error:", error);
      })
      
  }, []);

  useEffect(() => {
    axios.post(`${API_BASE_URL}pos_api/product_list_dropdown.php`)
      .then(response => {
        if (response.data.head.code === 200) {
          setProducts(response.data.body);
        } else {
          console.error("Error fetching products:", response.data.head.msg);
        }
      })
      .catch(error => console.error("API Error:", error));
  }, []);

 
  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log(formData)
    console.log(purchase_id)
    try {
        const response = await axios.post(
            `${API_BASE_URL}pos_api/pos_purchase_edit.php`,
            {
              ...formData, 
              purchase_list_id: purchase_id.purchase_id,
              
            }
            
          );
     console.log("Update Response:", response.data);
      if (response.data.head.code === 200) {
        alert("Updated successfully!");
        navigate('/purchaselist')
      } else {
        alert("Update failed!");
      }
    } catch (error) {
      console.error("Error updating data: ", error);
    }
  };
  
  const handleSupplierChange = (selectedName) => {
    const selectedSupplier = supplierList.find(
      (supplier) => supplier.supplier_name === selectedName
    );
  
    if (selectedSupplier) {
      setFormData({
        ...formData,
        supplier_name: selectedSupplier.supplier_name,
        supplier_mobile: selectedSupplier.mobile,
        gst_nbr: selectedSupplier.gst_number
      });
    }
  };

  return (
    <>
      <Header />
      <div className="page-wrapper compact-wrapper" id="pageWrapper">
        <div className="page-body-wrapper">
          <div className="page-body">
            <div className="container-fluid">
              <div className="row">
                <div className="col-12">
                  <div className="row">
                    <div className="col-sm-12 m-auto">
                      <div className="card">
                        <div className="card-body">
                          <div className="title-header option-title d-sm-flex d-block">
                            <h5>Edit Purchase</h5>
                            <div className="right-options">
                              <ul>
                                <li>
                                  <button className="btn btn-solid" onClick={() => window.history.back()}>
                                    Back
                                  </button>
                                </li> 
                              </ul>
                            </div>
                          </div>

                          <form className="theme-form theme-form-2 mega-form" onSubmit={(e) => handleSubmit(e, formData)}>
    <div className="row">
        {/* Product Name */}
        <div className="col-md-6 mb-4">
            <label className="form-label-title">Product Name</label>
            <select
                className="js-example-basic-single w-100 form-control"
                name="product"
                value={formData.product_id}
                onChange={(e) => {
                    const selectedProduct = products.find(product => product.product_id.toString() === e.target.value);
                    setFormData({
                        ...formData,
                        product_id: selectedProduct.product_id,
                        product_name: selectedProduct.product_name,
                        product_code: selectedProduct.product_code,
                        category_id: selectedProduct.category_id,
                        category_name: selectedProduct.category_name,
                        brand_id: selectedProduct.brand_id,
                        brand_name: selectedProduct.brand_name,
                        hsn_code: selectedProduct.hsn_code,
                        sku_no: selectedProduct.sku_no,
                        gst: selectedProduct.tax,
                        unit: selectedProduct.unit,
                    });
                }}
                required
            >
                <option value="">Select Product Name</option>
                {products.map((product) => (
                    <option key={product.product_code} value={product.product_id}>
                        {product.product_name}
                    </option>
                ))}
            </select>
        </div>

        {/* Product Code */}
        <div className="col-md-6 mb-4">
            <label className="form-label-title">Product Code</label>
            <input className="form-control" name="product_code" value={formData.product_code} readOnly />
        </div>

        {/* Category Name */}
        <div className="col-md-3 mb-4">
            <label className="form-label-title">Category</label>
            <input className="form-control" type="text" name="category_name" value={formData.category_name} readOnly />
        </div>

        {/* Brand Name */}
        <div className="col-md-3 mb-4">
            <label className="form-label-title">Brand</label>
            <input className="form-control" type="text" name="brand_name" value={formData.brand_name} readOnly />
        </div>

        {/* HSN Code */}
        <div className="col-md-3 mb-4">
            <label className="form-label-title">HSN Code</label>
            <input className="form-control" type="text" name="hsn_code" value={formData.hsn_code} readOnly />
        </div>

        {/* GST */}
        <div className="col-md-3 mb-4">
            <label className="form-label-title">GST (%)</label>
            <input className="form-control" type="text" name="gst" value={formData.gst} readOnly />
        </div>

        {/* Quantity */}
        <div className="col-md-3 mb-4">
            <label className="form-label-title">Quantity</label>
            <input className="form-control" type="text" name="qty" value={formData.qty} onChange={handleChange} />
        </div>

        {/* Unit */}
        <div className="col-md-3 mb-4">
            <label className="form-label-title">Unit</label>
            <input className="form-control" type="text" name="unit" value={formData.unit} readOnly />
        </div>

        {/* Purchase Rate */}
        <div className="col-md-3 mb-4">
            <label className="form-label-title">Purchase Rate</label>
            <input className="form-control" type="text" name="purchase_rate" placeholder="Enter Purchase Rate" value={formData.purchase_rate} onChange={handleChange} />
        </div>

        {/* Sales Rate */}
        <div className="col-md-3 mb-4">
            <label className="form-label-title">Sales Rate</label>
            <input className="form-control" type="text" name="sales_rate" placeholder="Enter Sales Rate" value={formData.sales_rate} onChange={handleChange} />
        </div>

        {/* Supplier Name */}
        <div className="col-md-3 mb-4">
                                    <label className="form-label-title">Supplier Name</label>
                                    <select
  className="form-control"
  name="supplier_name"
  value={formData.supplier_name}
  onChange={(e) => handleSupplierChange(e.target.value)}
>
  <option value="">Select Supplier</option>
  {Array.isArray(supplierList) &&
  supplierList.map((supplier) => (
    <option key={supplier.id} value={supplier.supplier_name}>
      {supplier.supplier_name}
    </option>
))}
</select>
                                  </div>

                                  <div className="col-md-3 mb-4">
                                    <label className="form-label-title">Supplier Mobile</label>
                                    <input
  className="form-control"
  type="text"
  name="supplier_mobile"
  placeholder="Enter Supplier Mobile"
  value={formData.supplier_mobile}
  onChange={handleChange}
/>
                                  </div>

                                  <div className="col-md-3 mb-4">
                                    <label className="form-label-title">GST Number</label>
                                    <input
  className="form-control"
  type="text"
  name="gst_nbr"
  placeholder="Enter GST Number"
  value={formData.gst_nbr}
  onChange={handleChange}
/>
                                  </div>

        {/* SKU No */}
        <div className="col-md-3 mb-4">
            <label className="form-label-title">SKU No</label>
            <input className="form-control" type="text" name="sku_no" value={formData.sku_no} readOnly />
        </div>

        {/* Note - Full Width */}
        <div className="col-12 mb-4">
            <label className="form-label-title">Note</label>
            <textarea className="form-control" rows="5" name="note" value={formData.note} onChange={handleChange}></textarea>
        </div>
    </div>

    {/* Submit & Cancel Buttons */}
    <div className="card-footer border-0 pb-0 d-flex justify-content-end">
        <button className="btn btn-primary me-3" type="submit">Submit</button>
        <button className="btn btn-outline" type="button" onClick={() => window.history.back()}>Cancel</button>
    </div>
</form>

                          {/* End Form Section */}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

export default  EditPurchase; 