import React, { useEffect, useState } from "react";
import axios from "axios";
import { useParams } from 'react-router-dom';
import Logo from "../Assets/poongoditraders_logo.png";
import Image from "../Assets/lakshmi-icon.jpg";

const PaidPrint = () => {
  const [receiptData, setReceiptData] = useState(null);
  const { order_id, paid_id } = useParams();

  useEffect(() => {
    axios.post('https://poongoditraders.com/billing_pos/pos_api/paid_report_print_detail.php', {
      order_id: order_id,
      paid_id: paid_id
    })
      .then((res) => {
        if (res.data.head.code === 200) {
          setReceiptData(res.data.body);
        }
      })
      .catch((err) => {
        console.error("API Error:", err);
      });
  }, []);

  const {
    order_id: receiptOrderId,
    order_date,
    last_paid_amt,
    last_payment_date,
    bill_detail,
    buyer_detail,
    seller_detail,
    paid_history
  } = receiptData || {};


  useEffect(() => {
    if (!receiptData || !receiptData.buyer_detail) return;
  
    const originalTitle = document.title;
  
    const timer = setTimeout(() => {
      document.title = `Paid Receipt_${receiptData.buyer_detail.name}`;
      window.print();
  
      
      setTimeout(() => {
        document.title = originalTitle;
      }, 1000); 
    }, 2000);
  
    return () => {
      clearTimeout(timer);
      document.title = originalTitle;
    };
  }, [receiptData]); 

  if (!receiptData) return <p>Loading receipt...</p>




  return (
    <>
                <div className="container receipt-container" style={{ color: "black" }}>

          <div className="position-relative mb-3">
              {/* Row for logo + image */}
              <div className="d-flex justify-content-between align-items-start px-2">
                {/* Left Logo */}
                <div>
                  <img
                    src={Logo}
                    alt="Poongodi Traders Logo"
                    style={{ maxWidth: "80px", height: "48px" }}
                  />
                </div>

                {/* Right Image */}
                
              

              {/* Center Text */}
              <div className="text-center mt-2 px-2" >
                <h5 className="mb-1 fw-bold">{seller_detail.shop_name}</h5>
                <p className="mb-1">{seller_detail.address}</p>
                <p className="mb-1">
                  {seller_detail.city}, {seller_detail.state} - {seller_detail.pincode}
                </p>
                <p className="mb-1">Phone: {seller_detail.phone}</p>
                <p className="mb-1">GST No: {seller_detail.gst_no}</p>
              </div>
              <div>
                  <img
                    src={Image}
                    alt="Lakshmi"
                    style={{ maxWidth: "50px", height: "55px", objectFit: "contain" }}
                  />
                </div>
            </div>
            </div>



      <hr />

      {/* Tax Invoice Title */}
      <div className="text-center mb-3">
        <h5 style={{ color: "black",fontWeight:"bold" }}>PAYMENT RECEIPT</h5>
      </div>

      <hr />

      {/* Buyer & Order Details */}
      <div className="row mb-3 detail">
        <div className="col-md-6 col-sm-6 ">
          <h5 className="mb-1" style={{ color: "black",fontWeight:"bold" }}>Buyer Details</h5>
          <p className="mb-1"> <strong>Name:</strong> {buyer_detail.name}</p>
          <p className="mb-1"><strong>Phone:</strong> {buyer_detail.telephone}</p>
          <p className="mb-1"><strong>Address:</strong> {buyer_detail.address}</p>
          {buyer_detail.tax_number && (
            <p><strong>Tax No:</strong> {buyer_detail.tax_number}</p>
          )}
        </div>

        <div className="col-md-6 col-sm-6 ">
          <h5 className="mb-1" style={{ color: "black",fontWeight:"bold" }}>Order Details</h5>
          <p className="mb-1"><strong>Order ID:</strong> #{order_id}</p>
          <p className="mb-1"><strong>Order Date:</strong> {order_date}</p>
          <p className="mb-1"><strong>Payment Date:</strong> {last_payment_date}</p>
        </div>
      </div>

      <hr />

      {/* Payment Table */}
      <table className="table table-bordered table-sm" >
        <thead className="thead-dark" >
          <tr>
            <th style={{ textAlign: "center", color: "black",fontSize:"12px"  }}>S.No</th>
            <th style={{ textAlign: "center", color: "black",fontSize:"12px"   }}>Payment</th>
            <th style={{ textAlign: "center", color: "black",fontSize:"12px"   }}>Amount (₹)</th>
          </tr>
        </thead>
        <tbody>
          {(Array.isArray(paid_history) ? paid_history : [paid_history]).map((item, index) => (
            <tr key={index}>
              <td style={{ textAlign: "center", color: "black"  }}>{index + 1}</td>
              <td style={{ textAlign: "center", color: "black"  }}>Payment Received</td>
              <td style={{ textAlign: "center", color: "black"  }}><strong>{item.last_paid_amt}</strong></td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Print Button */}
     {/*  <div className="text-center mt-4 "  >
        <button className="btn btn-primary" onClick={handlePrint}>Print Receipt</button>
      </div> */}

    </div>
    </>
  );
};

export default PaidPrint;
