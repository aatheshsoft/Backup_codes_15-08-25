import React, { useEffect, useState } from "react";
import "./PrintSales.css";
import Logo from "../Assets/poongoditraders_logo.png";
import Image from "../Assets/lakshmi-icon.jpg";


const PrintSalesList = () => {
  const [orderList, setOrderList] = useState([]);
const formatDate = (dateStr) => {
  if (!dateStr) return "";
  const [year, month, day] = dateStr.split("-");
  return `${day}/${month}/${year}`;
};
 const fromdate = localStorage.getItem("fromdate");
const todate = localStorage.getItem("todate");
  useEffect(() => {
    const orderData = localStorage.getItem("filtersales");
 

// console.log("From Date:", formatDate(fromdate));  
// console.log("To Date:", formatDate(todate)); 

    if (orderData) {
      try {
        const parsedData = JSON.parse(orderData);
        setOrderList(parsedData); // ✅ Store parsed array in state
      } catch (e) {
        console.error("Invalid JSON in localStorage:", e);
      }
    }
  }, []);
  

  useEffect(() => {
    if (orderList.length > 0) {
      setTimeout(() => {
        window.print();
      }, 300);
    }
  }, [orderList]);

  if (orderList.length === 0) {
    return <p>Please Wait Loading...</p>;
  }

  return (
    <div className="invoice-wrapper">
        <div className="position-relative mb-3">
                      {/* Row for logo + image */}
                      <div className="d-flex justify-content-between align-items-start px-2">
                        {/* Left Logo */}
                        <div>
                          <img
                            src={Logo}
                            alt="Poongodi Traders Logo"
                            style={{ maxWidth: "80px", height: "48px" }}
                          />
                        </div>
        
                        {/* Right Image */}
                        
                      
        
                      {/* Center Text */}
                      {/* {orderData && orderData.seller_detail && ( */}
                        <>
                      <div className="text-center mt-2 px-2" >
                        <h5 className="mb-1 fw-bold">Tax Invoice</h5>
                        <h5 className="mb-1 fw-bold">Poongodi Traders</h5>
                        <p className="mb-1">Door no.7/643Q, Kannan Complex, Kamrajapuram Colony,</p>
                        <p className="mb-1">
                          Sivakasi, Tamil Nadu - 626124
                        </p>
                        <p className="mb-1">Phone:  9786301208</p>
                        <p className="mb-1">GST No: 33AHEPV6120H1ZG</p>
                      </div>
                      </>
                      {/* )} */}
                      <div >
                          <img
                            src={Image}
                            alt="Lakshmi"
                            style={{ maxWidth: "50px", height: "55px", objectFit: "contain" }}
                          />
                        </div>
                    </div>
                    </div>
                    <hr />

      <div className="invoice-container">
        { fromdate !== "" ? <p>From : { formatDate(fromdate)} - To : { formatDate(todate)}</p> : <p></p>}

        {/* <table className="invoice-table">
          <tbody>
            <tr>
              <td className="products-section"> */}
                <table className="product-table ">
                  <thead>
                    <tr>
                      <th>Order ID</th>
                      <th>Order Date</th>
                      <th>Customer Name</th>
                      <th>HSN Code</th>
                      <th>Qty</th>
                      <th>GST</th>
                      <th>Amount</th>

                    </tr>
                  </thead>
                  <tbody>
                    {orderList.map((item, index) => (
                      <tr key={index}> 
                        <td>{item.order_id}</td>
                        <td>{item.orderdate}</td>
                        <td>{item.name}</td>
                        <td align="right">{item.hsn_code}</td>
                        <td>{item.qty}</td>
                        <td>{Number(item.gst_amount).toFixed(2)}</td>
                        <th>{item.amount}</th>
                      </tr>
                    ))}
                  </tbody>
                </table>
              {/* </td>
            </tr>
          </tbody>
        </table> */}
      </div>
    </div>
  );
};

export default PrintSalesList;
