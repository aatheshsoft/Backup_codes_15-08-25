import React, { useEffect, useState } from "react";
import Header from "../Components/Header";
import axios from "axios";
import Image from '../Assets/print.gif'

const PaidReport = () => {
  const [orders, setOrders] = useState([]);
  const [filteredOrders, setFilteredOrders] = useState([]);
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [loading, setLoading] = useState(true);
  const [userList, setUserList] = useState([]);
  const [selectedUser, setSelectedUser] = useState("");
//   const [showPaymentForm, setShowPaymentForm] = useState(false); // Controls form visibility
  const [paidAmount, setPaidAmount] = useState(0);
  const [balance, setBalance] = useState(0);
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;


  useEffect(() => {
    setLoading(true);
    axios
      .post(`${API_BASE_URL}pos_api/pos_paid_report_payment.php`)
      .then((response) => {
        if (response.data.head.code === 200 && Array.isArray(response.data.body)) {
          const paidList = response.data.body[0]?.paid_list || [];
          const users = response.data.body[0]?.user_list || [];
          setOrders(paidList);
          setFilteredOrders(paidList);
          setUserList(users);
        } else {
          console.error("Error Fetching Data:", response.data.head.msg);
          setOrders([]);
          setFilteredOrders([]);
          setUserList([]);
        }
      })
      .catch((error) => {
        console.error("API Error:", error);
        setOrders([]);
        setFilteredOrders([]);
        setUserList([]);
      })
      .finally(() => {
        setLoading(false);
      });
  }, []);

  const convertDate = (dateString) => {
    if (!dateString) return null;
    const parts = dateString.split("-");
    return parts.length === 3 ? `${parts[2]}-${parts[1]}-${parts[0]}` : null;
  };

  const handleFilter = (e) => {
    e.preventDefault();
  
    let filtered = orders;
  
    if (fromDate && toDate) {
      const startDate = new Date(fromDate);
      const endDate = new Date(toDate);
  
      if (isNaN(startDate) || isNaN(endDate)) {
        console.error("Invalid date range");
        return;
      }
  
      filtered = filtered.filter((order) => {
        const orderDate = new Date(order.order_date.split("-").reverse().join("-"));
        return orderDate >= startDate && orderDate <= endDate;
      });
    }
  
    if (selectedUser && selectedUser.name) {  // Check selectedUser.name instead of selectedUser
      filtered = filtered.filter((order) => order.user_name === selectedUser.name);
    //   setShowPaymentForm(true);
      setPaidAmount(0);
    } else {
    //   setShowPaymentForm(false);
    }
  
    setFilteredOrders(filtered);
  };
  

  // Calculate Totals Dynamically
  const totalAmount = filteredOrders.reduce((acc, order) => acc + parseFloat(order.actual_amount || 0), 0);
  const totalPaid = filteredOrders.reduce((acc, order) => acc + parseFloat(order.paid_amount || 0), 0);
  const totalBalance = filteredOrders.reduce((acc, order) => acc + parseFloat(order.pending_balance || 0), 0);

  // Update Balance when Paid Amount changes
  useEffect(() => {
    setBalance(totalBalance - paidAmount);
  }, [paidAmount, totalBalance]);

  const handleSubmitPayment = (e) => {
    e.preventDefault();

    if (!selectedUser) {
      alert("Please select a user.");
      return;
    }
// console.log(paidAmount);
console.log(totalBalance >= paidAmount);

if (totalBalance >= paidAmount ){
  const payload = {
    user_id: selectedUser.user_id,
    paid_amount: paidAmount,
    // balance: balance
  };

  axios
    .post(`${API_BASE_URL}pos_api/pos_update_payment.php`, payload)
    .then((response) => {
      console.log(response)
      if (response.data.head.code === 200) {
        alert("Payment updated successfully!");
        window.location.reload();
        // setShowPaymentForm(false);
      } else {
        alert("Error updating payment: " + response.data.head.msg);
      }
    })
    .catch((error) => {
      console.error("API Error:", error);
      alert("An error occurred while updating payment.");
    });
}else{
  alert("Excessive Amount Entered.Please Enter Sufficient Amount")
}
   
  };


  return (
    <>
      <Header />
      <div className="page-wrapper compact-wrapper" id="pageWrapper">
        <div className="page-body-wrapper">
          <div className="page-body">
            <div className="container-fluid">
              <div className="row">
                <div className="col-sm-12">
                  <div className="card card-table">
                    <div className="card-body">
                      <div className="title-header option-title d-sm-flex d-block">
                        <h5>List of Paid Report</h5>
                      </div>

                      {/* Date and User Filter */}
                      <div className="row">
                        <div className="col-sm-12">
                          <form onSubmit={handleFilter} className="theme-form theme-form-2 mega-form">
                            <div className="mb-4 row align-items-center">
                              <label className="col-auto col-form-label form-label-title">From Date:</label>
                              <div className="col-md-2">
                                <input className="form-control" type="date" value={fromDate} onChange={(e) => setFromDate(e.target.value)} />
                              </div>
                              <label className="col-auto col-form-label form-label-title">To Date:</label>
                              <div className="col-md-2">
                                <input className="form-control" type="date" value={toDate} onChange={(e) => setToDate(e.target.value)} />
                              </div>
                              <div className="col-md-2">
                              <select
                                      className="form-control payment-customer-dropdown" // Add "form-select" for proper Bootstrap styling
                                      value={selectedUser ? JSON.stringify(selectedUser) : ""}
                                      onChange={(e) => setSelectedUser(JSON.parse(e.target.value))}
                                    >
                                      <option  value="0">Select Customer</option>
                                      {userList.map((user) => (
                                        <option key={user.user_id} value={JSON.stringify({ user_id: user.user_id, name: user.name })}>
                                          {user.name}
                                        </option>
                                      ))}
                                    </select>

                              </div>
                              <div className="col-md-2">
                                <button type="submit" className="btn btn-primary me-3">Submit</button>
                              </div>
                            </div>
                          </form>
                        </div>
                      </div>

                      {/* Order Table */}
                      {loading ? (
                        <div className="d-flex justify-content-center align-items-center" style={{ height: "200px" }}>
                          <div className="spinner-border text-primary" style={{ width: "3rem", height: "3rem" }} role="status">
                            <span className="visually-hidden">Loading...</span>
                          </div>
                        </div>
                      ) : (
                        <div className="table-responsive">
                          <table className="table all-package theme-table table-product">
                            <thead>
                              <tr>
                                <th>Order ID</th>
                                <th>Date</th>
                                <th>Customer Name</th>
                                <th>Mobile Number</th>
                                <th style={{ textAlign: "right" }}>Amount</th>
                                <th style={{ textAlign: "right" }}>Paid</th>
                                <th style={{ textAlign: "right" }}>Balance</th>
                                <th>Print</th>
                              </tr>
                            </thead>
                            <tbody>
                              {filteredOrders.length > 0 ? (
                                filteredOrders.map((order) => (
                                  <tr key={order.order_id}>
                                    <td>{order.order_id}</td>
                                    <td>{order.paid_date || "N/A"}</td>
                                    <td>{order.user_name || "N/A"}</td>
                                    <td>{order.mobile || "N/A"}</td>
                                    <td style={{ textAlign: "right" }}>
                                            <i className="fas fa-rupee-sign"></i> 
                                          {parseFloat((order.actual_amount || "0").toString().replace(/,/g, "")).toFixed(2)}
                                        </td>
                                        <td style={{ textAlign: "right" }}>
                                          <i className="fas fa-rupee-sign"></i> 
                                          {parseFloat((order.paid_amount || "0").toString().replace(/,/g, "")).toFixed(2)}
                                        </td>
                                        <td style={{ textAlign: "right" }}>
                                          <i className="fas fa-rupee-sign"></i> 
                                          {parseFloat((order.pending_balance || "0").toString().replace(/,/g, "")).toFixed(2)}
                                        </td>       

                                    <td style={{ textAlign: "right" }}>
                                    <a 
                                      href={`/paidprint/${order.order_id}/${order.paid_id}`} 
                                      target="_blank" 
                                      rel="noopener noreferrer"
                                    >
                                        <img src={Image} alt="Product" />
                                    </a>

                                      </td>

                                  </tr>
                                ))
                              ) : (
                                <tr>
                                  <td colSpan="7" className="text-center">No orders found</td>
                                </tr>
                              )}
                              <tr id="total">
                                        
                                <td colspan="4" ><h3>Total:</h3></td>
                                <td colspan="" style={{ textAlign: "right" }}><h3><i class="fas fa-rupee-sign"></i>{totalAmount.toFixed(2)}</h3></td>
                                <td  style={{ textAlign: "right" }}><h3><i class="fas fa-rupee-sign"></i>{totalPaid.toFixed(2)}</h3></td>
                                
                                
                                <td   style={{ textAlign: "right" }}><h3><i class="fas fa-rupee-sign"></i>{totalBalance.toFixed(2)}</h3></td>
                                  <td></td>
                                
                              </tr>
                              {/* <tr>
                                <td colspan="10"></td>
                              </tr> */}
                            </tbody>

                          </table>
                        </div>
                      )}

                      {/* Payment Form (Only Visible After Submit Button Click) */}
                      {/* {showPaymentForm && (
                        <div className="row">
                          <div className="col-sm-12">
                            <form  className="theme-form theme-form-2 mega-form"  onSubmit={handleSubmitPayment}>
                              <div className="mb-4 row align-items-center">
                                <label className="col-sm-2 col-form-label form-label-title">Paid Amount:</label>
                                <div className="col-md-2">
                                  <input className="form-control" type="text" name="paid_amount" placeholder="Enter Paid Amount" value={paidAmount} onChange={(e) => setPaidAmount(Number(e.target.value))} />
                                </div>
                                <label className="col-sm-2 col-form-label form-label-title">Balance:</label>
                                <div className="col-md-2">
                                  <input className="form-control" type="text" name="balance" placeholder="Balance Amount" value={balance.toFixed(2)} readOnly />
                                </div>
                                <div className="col-md-2">
                                  <button className="btn btn-primary me-3" type="submit">Submit</button>
                                </div>
                              </div>
                            </form>
                          </div>
                        </div>
                      )} */}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default PaidReport;
