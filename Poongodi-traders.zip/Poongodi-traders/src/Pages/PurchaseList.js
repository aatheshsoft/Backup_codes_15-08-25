import React, { useEffect, useState } from "react";
import Header from "../Components/Header";
import { Link, useParams } from "react-router-dom";
import axios from "axios";

const PurchaseList = () => {
  const { category_id, subcategory_id } = useParams();
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [categories, setCategories] = useState([]);
  const [updateSuccess, setUpdateSuccess] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [selectedproductId, setSelectedProductId] = useState(null);
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

    const [currentPage, setCurrentPage] = useState(1);
    const recordsPerPage = 25;
    const totalRecords = categories.length;
    const totalPages = Math.ceil(totalRecords / recordsPerPage);
    const[filteredproducts,setFilteredProducts] = useState("");
    // Calculate records for the current page
    const indexOfLastRecord = currentPage * recordsPerPage;
    const indexOfFirstRecord = indexOfLastRecord - recordsPerPage;
    const currentRecords = filteredproducts.slice(indexOfFirstRecord, indexOfLastRecord);
  
    // Function to change the page
    const paginate = (pageNumber) => {
      if (pageNumber >= 1 && pageNumber <= totalPages) {
        setCurrentPage(pageNumber);
      }
    };
  


  const openDeleteModal = (purchase_id) => {
    setSelectedProductId(purchase_id);
    setShowModal(true);
  };
  const closeModal = () => {
    setSelectedProductId(null);
    setShowModal(false);
  };

  useEffect(() => {
    setLoading(true);
    axios
      .post(`${API_BASE_URL}pos_api/pos_purchase_list.php`)
      .then((response) => {
        if (response.data.head.code === 200) {
          setCategories(response.data.body || []);
          setFilteredProducts(response.data.body || [])
          console.log(response.data.body || [])
        } else {
          console.error("Error Fetching:", response.data.head.msg);
        }
      })
      .catch((error) => {
        console.error("API Error:", error);
      }).finally(() => {
        setLoading(false);
      });
  }, []); 
  


  const handleDelete = async () => {
    if (!selectedproductId) return;

    try {
      const response = await axios.post(
        `${API_BASE_URL}pos_api/purchase_list_delete.php`,
        {
          purchase_list_id: selectedproductId,
        }
      );
      if (response.data.head.code === 200) {
        alert("Data Deleted Successfully");
        closeModal();
        window.location.reload();
      } else {
        alert(response.head?.msg || "Failed To Delete Subcategory");
      }
    } catch (error) {
      console.error("Error Deleting Category", error);
    }
  };




  return (
    <>
      <Header />
      <div class="page-wrapper compact-wrapper" id="pageWrapper">
        <div class="page-body-wrapper">
          <div className="page-body">
            <div className="container-fluid">
              <div className="row">
                <div className="col-sm-12">
                  <div className="card card-table">
                    <div className="card-body">
                      <div className="title-header option-title d-sm-flex d-block">
                        <h5>List of Purchase</h5>
                        <div className="right-options">
                          <ul>
                            {/* <li>
                              <Link
                                className="btn btn-solid"
                                to={`/subcategory/${category_id}`}
                              >
                                Back
                              </Link>
                            </li> */}

                            <li>
                              <Link
                                className="btn btn-solid"
                                to="/addpurchase"
                                
                              >
                                Add Purchase
                              </Link>
                            </li>
                          </ul>
                        </div>
                      </div>

                      {/* <div class="row">
                        <div class="col-sm-6">
                          <form
                            method="post"
                            action="reportdriver.php"
                            class="theme-form theme-form-2 mega-form"
                          >
                            <div class="mb-4 row align-items-center">
                             
                              <label
                                for="search"
                                class="col-sm-2 col-form-label"
                              >
                                Search:
                              </label>
                              <div class="col-sm-10">
                                <input
                                  type="text"
                                  id="search"
                                  name="search"
                                  class="form-control"
                                  placeholder="Search Products"
                                />
                              </div>
                            </div>
                          </form>
                        </div>
                      </div> */}
                      
                      <form action="product.php?cid=1&scid=32" method="post">
                        {loading ? (
                          <div
                            className="d-flex justify-content-center align-items-center"
                            style={{ height: "200px" }}
                          >
                            <div
                              className="spinner-border text-primary"
                              style={{ width: "3rem", height: "3rem" }}
                              role="status"
                            >
                              <span className="visually-hidden">
                                Loading...
                              </span>
                            </div>
                          </div>
                        ) : (
                          <>
                            <div className="table-responsive">
                              <table
                                className="table all-package theme-table table-product"
                                id="table_id"
                              >
                                <thead>
                                  <tr>
                                    <th>S.No.</th>
                                    <th style={{ textAlign: "center" }}>
                                      Date
                                    </th>
                                    <th>ProductCode</th>
                                    <th>Product Name</th>
                                    <th>Product Rate</th>
                                    <th>HSN Code</th>
                                    <th>GST(%)</th>
                                    <th style={{ textAlign: "center" }}>
                                      Action
                                    </th>
                                  </tr>
                                </thead>
                                <tbody>
                                {currentRecords.length > 0 ? (
                                            currentRecords.map((item, index) => (
                                              <tr key={index}>
                                                <td>{index + 1}</td> {/* Display index-based numbering */}

                                                <td style={{ textAlign: "center" }}>{item.added_date}</td>
                                                <td>{item.product_code || "N/A"}</td>
                                                <td>{item.product_name || "N/A"}</td>
                                                <td style={{ textAlign: "center" }}>{item.sales_rate}</td>
                                                <td style={{ textAlign: "center" }}>{item.hsn_code}</td>
                                                <td style={{ textAlign: "center" }}>{item.gst}</td>
                                                <td style={{ textAlign: "center" }}>
                                                  <ul>
                                                    <li>
                                                      <Link to=
                                                       {`/editpurchase/${item.purchase_id}`}

                                                      >
                                                        {console.log(item.purchase_id)}
                                                        <i className="ri-pencil-line"></i>
                                                      </Link>
                                                    </li>
                                                    <li>
                                                      <a
                                                        href="#"
                                                        onClick={(e) => {
                                                          e.preventDefault();
                                                          openDeleteModal(item.purchase_id); // Pass correct product_id
                                                        }}
                                                      >
                                                        <i className="ri-delete-bin-line"></i>
                                                      </a>
                                                    </li>
                                                  </ul>
                                                </td>
                                              </tr>
                                            ))
                                          ) : (
                                            <tr>
                                              <td colSpan="8" className="text-center">No Record found</td>
                                            </tr>
                                          )}

                                          <td colSpan="9">
                                                                                  <table width="100%" border="1" style={{ borderCollapse: "collapse", border: "1px solid #000" }}>
                                                                                    <tr>
                                                                                      <td width="20%">Page {currentPage} of {totalPages}</td>
                                                                                      <td style={{ textAlign: "right" }}>
                                                                                        {/* Previous Button */}
                                                                                        {currentPage > 1 ? (
                                                                                          <a className="pagetext" href="javascript:void(0);" onClick={() => paginate(currentPage - 1)}>
                                                                                            &laquo; Previous
                                                                                          </a>
                                                                                        ) : (
                                                                                          <span>&laquo; Previous</span>
                                                                                        )}
                                                                                          &nbsp;
                                                                                        {/* Page Numbers */}
                                                                                        {[...Array(totalPages)].map((_, i) => (
                                                                                          <React.Fragment key={i}>
                                                                                          <a
                                                                                            key={i}
                                                                                            className={`pagetext ${currentPage === i + 1 ? "active" : ""}`}
                                                                                            href="javascript:void(0);"
                                                                                            onClick={() => paginate(i + 1)}
                                                                                          >
                                                                                            {i + 1}
                                                                                          </a>
                                                                                          &nbsp;
                                                                                          </React.Fragment>
                                                                                        ))}
                                          
                                                                                        {/* Next Button */}
                                                                                        {currentPage < totalPages ? (
                                                                                          <a className="pagetext" href="javascript:void(0);" onClick={() => paginate(currentPage + 1)}>
                                                                                            Next &raquo;
                                                                                          </a>
                                                                                        ) : (
                                                                                          <span>Next &raquo;</span>
                                                                                        )}
                                          
                                                                                        {/* Last Button */}
                                                                                        {currentPage < totalPages ? (
                                                                                          <a className="pagetext" href="javascript:void(0);" onClick={() => paginate(totalPages)}>
                                                                                            Last &raquo;&raquo;
                                                                                          </a>
                                                                                        ) : (
                                                                                          <span>Last &raquo;&raquo;</span>
                                                                                        )}
                                                                                      </td>
                                                                                    </tr>
                                                                                  </table>
                                                                                </td>

                                </tbody>
                              </table>
                            </div>
                            {/* <div className="card-footer border-0 pb-0 d-flex justify-content-end">
                              <button
                                className="btn btn-primary me-3"
                                type="button"
                                
                              >
                                Update
                              </button>
                            </div> */}
                          </>
                        )}
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {showModal && (
        <div className="modal fade show" style={{ display: "block" }}>
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-body">
                <h5>Confirm Delete</h5>
                <p>Are you sure you want to delete this product?</p>
                <button
                  type="button"
                  className="btn-close"
                  onClick={closeModal}
                ></button>
              </div>
              <div className="modal-footer">
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={closeModal}
                >
                  No
                </button>
                <button
                  type="button"
                  className="btn btn-danger"
                  onClick={handleDelete}
                >
                  Yes, Delete
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default PurchaseList;
