import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import Header from "../Components/Header";
import axios from "axios";
import Image from '../Assets/print.gif'

const OrderList = () => {
  const [orders, setOrders] = useState([]);
  const [filteredOrders, setFilteredOrders] = useState([]);
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [loading, setLoading] = useState(true); 
  const [currentPage, setCurrentPage] = useState(1);
  const recordsPerPage = 25;
  const totalRecords = filteredOrders.length;
  const totalPages = Math.ceil(totalRecords / recordsPerPage);
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
  const [selectedorderId, setSelectedOrderId] = useState(null);
  const [showModal, setShowModal] = useState(false);

  // Calculate records for the current page
  const indexOfLastRecord = currentPage * recordsPerPage;
  const indexOfFirstRecord = indexOfLastRecord - recordsPerPage;
  const currentRecords = filteredOrders.slice(indexOfFirstRecord, indexOfLastRecord);

localStorage.setItem('filtersales', JSON.stringify(filteredOrders)); 

localStorage.setItem('fromdate',fromDate);
localStorage.setItem('todate',toDate);

  // Function to change the page
  const paginate = (pageNumber) => {
    if (pageNumber >= 1 && pageNumber <= totalPages) {
      setCurrentPage(pageNumber);
    }
  };
  const openDeleteModal = (order_id) => {
    setSelectedOrderId(order_id);
    setShowModal(true);
  };
  const closeModal = () => {
    setSelectedOrderId(null);
    setShowModal(false);
  };
  useEffect(() => {
    setLoading(true);
    axios.post(`${API_BASE_URL}order.php`)
      .then((response) => {
        if (response.data.head.code === 200 && Array.isArray(response.data.body)) {
          setOrders(response.data.body);
          setFilteredOrders(response.data.body);
        } else {
          console.error("Error Fetching Data:", response.data.head.msg);
          setOrders([]);
          setFilteredOrders([]);
        }
      })
      .catch((error) => {
        console.error("API Error:", error);
        setOrders([]);
        setFilteredOrders([]);
      }) .finally(() => {
        setLoading(false); // Set loading to false after API call
      });
  }, []);

  const convertDate = (dateString) => {
    if (!dateString || !dateString.includes("/")) return null; // Handle invalid formats
    const parts = dateString.split("/");
    if (parts.length !== 3) return null;
    return `${parts[2]}-${parts[1]}-${parts[0]}`; // Convert to YYYY-MM-DD
  };
  

  // ✅ Date Filter with Safe Date Handling
  const handleFilter = (e) => {
    e.preventDefault();

    if (!fromDate || !toDate) {
        console.error("Date fields are empty");
        return;
    }

    // Parse input dates (YYYY-MM-DD format from input fields)
    const startDate = new Date(fromDate);
    startDate.setHours(0, 0, 0, 0); // Ensure the entire day is included

    const endDate = new Date(toDate);
    endDate.setHours(23, 59, 59, 999); // Include full day

    if (isNaN(startDate.getTime()) || isNaN(endDate.getTime())) {
        console.error("Invalid date range");
        return;
    }

    // Filter orders based on date range
    const filtered = orders.filter((order) => {
        if (!order.orderdate) return false; // Skip if order date is missing

        // Convert "DD-MM-YYYY" to a Date object
        const [day, month, year] = order.orderdate.split("-").map(Number);
        const orderDate = new Date(year, month - 1, day); // Months are zero-based

        // Normalize orderDate to ignore time differences
        orderDate.setHours(0, 0, 0, 0);

        return orderDate >= startDate && orderDate <= endDate;
    });

    setFilteredOrders(filtered);
};


  

  // ✅ Search Function with Safe Property Access
  const handleSearch = (e) => {
    const query = e.target.value;
    setSearchQuery(query);

    const searchedOrders = orders.filter((order) => {
      return (
        order.name?.toLowerCase().includes(query.toLowerCase()) ||
        order.mobile?.includes(query) ||
        order.order_id?.includes(query)
      );
    });

    setFilteredOrders(searchedOrders);
    setCurrentPage(1);

  };

  const totalAmount = currentRecords.reduce((sum, order) => {
    const amount = parseFloat(order.amount.replace(/,/g, "") || 0);
    return sum + amount;
  }, 0).toFixed(2);

  const handleDelete = async () => {
    if (!selectedorderId) return;

    try {
      const response = await axios.post(
        `${API_BASE_URL}order_delete.php`,
        {
          order_id: selectedorderId,
        }
      ); 
      if (response.data.head.code === 200) {
        alert("Order Deleted Successfully");
        closeModal();
        window.location.reload();
      } else {
        alert(response.head?.msg || "Failed To Delete Subcategory");
      }
    } catch (error) {
      console.error("Error Deleting Category", error);
    }
  };

  return (
    <>
      <Header />
      <div className="page-wrapper compact-wrapper" id="pageWrapper">
        <div className="page-body-wrapper">
          <div className="page-body">
            <div className="container-fluid">
              <div className="row">
                <div className="col-sm-12">
                  <div className="card card-table">
                    <div className="card-body">
                      <div className="title-header option-title d-sm-flex d-block">
                        <h5>List of Sales</h5>
                      </div>

                      {/* Date Filter */}
                      <div className="row">
                              <div className="col-sm-12">
                                <form onSubmit={handleFilter} className="theme-form theme-form-2 mega-form">
                                  <div className="mb-3 row align-items-center">
                                    
                                    {/* From Date */}
                                    <div className="col-auto text-end">
                                      <label className="col-form-label form-label-title">From Date:</label>
                                    </div>
                                    <div className="col-md-3">
                                      <input
                                        className="form-control"
                                        type="date"
                                        value={fromDate}
                                        onChange={(e) => setFromDate(e.target.value)}
                                      />
                                    </div>

                                    {/* To Date */}
                                    <div className="col-auto text-end">
                                      <label className="col-form-label form-label-title">To Date:</label>
                                    </div>
                                    <div className="col-md-3">
                                      <input
                                        className="form-control"
                                        type="date"
                                        value={toDate}
                                        onChange={(e) => setToDate(e.target.value)}
                                      />
                                    </div>
                                    &nbsp;&nbsp;&nbsp;
                                    {/* Submit Button */}
                                    <div className="col-md-2">
                                      <button type="submit" className="btn btn-primary">
                                        Submit
                                      </button>
                                    </div>

                                  </div>
                                </form>
                              </div>
                            </div>



                      {/* Search Box */}
                      <div className="row">
                        <div className="col-12">
                          <div className="d-flex flex-wrap align-items-center justify-content-between gap-2">
                            {/* Search Form */}
                            <form className="theme-form theme-form-2 mega-form flex-grow-1">
                              <div className="row align-items-center">
                                <label htmlFor="search" className="col-auto col-form-label">
                                  Search:
                                </label>
                                <div className="col-lg-4">
                                  <input
                                    type="text"
                                    id="search"
                                    name="search"
                                    className="form-control"
                                    placeholder="Search Order"
                                    value={searchQuery}
                                    onChange={handleSearch}
                                  />
                                </div>
                              </div>
                            </form>

                            {/* Print Icon */}
                            <a
                              href="/printsaleslist"
                              target="_blank"
                              rel="noopener noreferrer"
                              className="d-flex align-items-center"
                              style={{ marginLeft: '10px' }}
                            >
                              <img src={Image} alt="Print" style={{ maxHeight: '36px' }} />
                            </a>
                          </div>
                        </div>
                      </div>
                      <br/> 

                      {/* Order Table */}
                      {loading ? (
                                  <div className="d-flex justify-content-center align-items-center" style={{ height: '200px' }}>
                                    <div className="spinner-border text-primary" style={{ width: '3rem', height: '3rem' }} role="status">
                                      <span className="visually-hidden">Loading...</span>
                                    </div>
                                  </div>
                                ) : (
                                  <>
                      <div className="table-responsive">
                        <table className="table all-package theme-table table-product">
                          <thead>
                            <tr>
                              <th>Order ID</th>
                              <th>Date</th>
                              <th>Customer Name</th>
                              <th style={{textAlign:"center"}}>Mobile Number</th>
                              <th style={{textAlign:"right"}}>Amount</th>
                              <th style={{textAlign:"center"}}>Payment Status</th>
                              <th style={{textAlign:"center"}}>View</th>
                              <th style={{textAlign:"center"}}>Action</th>
                            </tr>
                          </thead>
                          <tbody>
                            {currentRecords.length > 0 ? (
                              currentRecords.map((order) => (
                                <tr key={order.order_id}>
                                  <td>{order.order_id}</td>
                                  <td>{order.orderdate || "N/A"}</td>
                                  <td>{order.name || "N/A"}</td>
                                  <td style={{textAlign:"center"}} >{order.billing_phonenumber || "N/A"}</td>
                                  <td style={{textAlign:"right"}}>
                                    <i className="fas fa-rupee-sign"></i> {parseFloat(order.amount.replace(/,/g, "") || 0).toFixed(2)}
                                  </td>
                                  <td style={{ color: order.balance > 0 ? "red" : "green" }}>{order.balance > 0 ? "Pending" : "Paid"}</td>


                                  <td>
                                  <ul>
                                    <li>
                                    <Link to={`/orderdetails/${order.order_id}`}>
                                      <i className="ri-eye-line"></i>
                                    </Link>
                                    </li>
                                   
                                    </ul>
                                  </td>
                                  <td>
                                    <ul>
                                    <li>
                                      <Link
                                        to={`/editorderdate/${order.order_id}`}
                                        
                                      >
                                        <i className="ri-pencil-line"></i>
                                      </Link>
                                    </li>
                                    
                                    <li>
                                            <a
                                              href="#"
                                              onClick={(e) => {
                                                e.preventDefault();
                                                openDeleteModal(
                                                  order.order_id
                                                );
                                              }}
                                            >
                                              <i className="ri-delete-bin-line"></i>
                                            </a>
                                          </li>
                                    
                                    </ul>
                                  </td>
                                </tr>
                              ))
                            ) : (
                              <tr>
                                <td colSpan="5" className="text-center">
                                  No orders found
                                </td>
                              </tr>
                            )}
                           <tr id="total">
                            <td colSpan="4">
                              <h3>Total:</h3>
                            </td>
                            <td style={{ textAlign: "right" }}>
                              <h3>
                                <i className="fas fa-rupee-sign"></i> {totalAmount}
                              </h3>
                            </td>
                            <td></td>
                          </tr>

                  <td colSpan="9">
                  <table width="100%" border="1" style={{ borderCollapse: "collapse", border: "1px solid #000" }}>
                    <tr>
                      <td width="20%">Page {currentPage} of {totalPages}</td>
                      <td style={{ textAlign: "right" }}>
                        {/* Previous Button */}
                        {currentPage > 1 ? (
                          <a className="pagetext" href="javascript:void(0);" onClick={() => paginate(currentPage - 1)}>
                            &laquo; Previous
                          </a>
                        ) : (
                          <span>&laquo; Previous</span>
                        )}
                        &nbsp;
                        {/* Page Numbers */}
                        {[...Array(totalPages)].map((_, i) => (
                           <React.Fragment key={i}>
                          <a
                            key={i}
                            className={`pagetext ${currentPage === i + 1 ? "active" : ""}`}
                            href="javascript:void(0);"
                            onClick={() => paginate(i + 1)}
                          >
                            {i + 1}
                          </a>
                          &nbsp;
                          </React.Fragment>
                        ))}

                        {/* Next Button */}
                        {currentPage < totalPages ? (
                          <a className="pagetext" href="javascript:void(0);" onClick={() => paginate(currentPage + 1)}>
                            Next &raquo;
                          </a>
                        ) : (
                          <span>Next &raquo;</span>
                        )}

                        {/* Last Button */}
                        {currentPage < totalPages ? (
                          <a className="pagetext" href="javascript:void(0);" onClick={() => paginate(totalPages)}>
                            Last &raquo;&raquo;
                          </a>
                        ) : (
                          <span>Last &raquo;&raquo;</span>
                        )}
                      </td>
                    </tr>
                  </table>
                </td>
                
                          </tbody>
                        </table>
                      </div>
                      </>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {showModal && (
        <div className="modal fade show" style={{ display: "block" }}>
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-body">
                <h5>Confirm Delete</h5>
                <p>Are you sure you want to delete this product?</p>
                <button
                  type="button"
                  className="btn-close"
                  onClick={closeModal}
                ></button>
              </div>
              <div className="modal-footer">
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={closeModal}
                >
                  No
                </button>
                <button
                  type="button"
                  className="btn btn-danger"
                  onClick={handleDelete}
                >
                  Yes, Delete
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default OrderList;
