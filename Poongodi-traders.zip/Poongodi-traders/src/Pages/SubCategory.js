import React,{useState,useEffect} from "react";
import Header from "../Components/Header";
import { Link,useParams } from "react-router-dom";
import axios from "axios";

const SubCategory = () => {
  const[categories,setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const {category_id} = useParams();
  const [showModal, setShowModal] = useState(false);
  const [selectedcategoryId, setSelectedCategoryId] = useState(null);
  const [updateSuccess, setUpdateSuccess] = useState(false); 
  
  const openDeleteModal = (subcategory_id) =>{
    setSelectedCategoryId(subcategory_id)
    setShowModal(true);
  }
  const closeModal = () => {
    setSelectedCategoryId(null);
    setShowModal(false);
};

  useEffect(() =>{
    setLoading(true);
    console.log(category_id)
    axios.post ('https://www.aatheshsoft.com/admin_api/subcategory_list.php',{
      category_id:category_id
    })
    .then((response) =>{
      if(response.data.head.code === 200){
        const sortedCategories = response.data.body.sort((a,b) => a.rank - b.rank)
        
        setCategories(sortedCategories);
       
      }else{
        console.error("Error Fetching Data", response.data.head.msg)
      }
    })
    .catch((error) => {
      console.error("API Error:", error);
    })
    .finally(() => {
      setLoading(false);

    })
  },[])
  

const handleChange = (subcategory_id,field,value) => {
  setCategories(categories.map(category =>
    category.subcategory_id === subcategory_id 
    ? { ...category, [field]: value } 
    : category
  ));
}

const handleUpdate = async(subcategory_id,rank,front_active,active) => {
  try{
    const response = await axios.post('https://www.aatheshsoft.com/admin_api/subcategory_list_update.php',{
      subcategory_id,
      active,
      front_active,
      rank,
    })
    if(response.data.head.code === 200){
      setCategories((prevCategories) =>
        prevCategories.map((category) =>
          category.subcategory_id === subcategory_id
            ? { ...category, rank, active } 
            : category
        )
      );
      setUpdateSuccess(true); // Set state for success
    }else{
      console.error('Error updating category:', response.data.head.msg);
    }
  }catch(error){
    console.error('Error updating category:', error);
  }
}

 useEffect(() => {
      if (updateSuccess) {
        alert("Category Updated Successfully");
        setUpdateSuccess(false); 
        window.location.reload();
      }
    }, [updateSuccess]);



  const handleDelete = async () => {
    if(!selectedcategoryId) return;

    try{
      const response = await axios.post('https://www.aatheshsoft.com/admin_api/subcategory_list_delete.php',{
        subcategory_id:selectedcategoryId,
      });
      if(response.data.head.code === 200){
        alert('Subcategory Deleted Successfully')
        closeModal();
        window.location.reload();
      }else{
        alert(response.head?.msg || 'Failed To Delete Subcategory')
      }
    }catch(error){
      console.error("Error Deleting Category", error)
    }
  }


  return (
    <>
      <Header />
      <div class="page-wrapper compact-wrapper" id="pageWrapper">
        <div class="page-body-wrapper">
        <div className="page-body">
      <div className="container-fluid">
        <div className="row">
          <div className="col-sm-12">
            <div className="card card-table">
              <div className="card-body">
                <div className="title-header option-title d-sm-flex d-block">
                  <h5>List of Sub Category</h5>
                  <div className="right-options">
                    <ul>
                      <li>
                        <Link className="btn btn-solid" to="/maincategory">
                          Back
                        </Link>
                      </li>
                      <li>
                        <Link
                          className="btn btn-solid"
                          to="/addsubcategory"
                          state={{ category_id }}
                        >
                          Add Sub Category
                        </Link>
                      </li>
                    </ul>
                  </div>
                </div>
                <form action="subcategory.php?cid=1" method="post">
                {loading ? (
                <div className="d-flex justify-content-center align-items-center" style={{ height: '200px' }}>
                  <div className="spinner-border text-primary" style={{ width: '3rem', height: '3rem' }} role="status">
                    <span className="visually-hidden">Loading...</span>
                  </div>
                </div>
              ) : (
                <>
                  <div className="table-responsive">
                    <table
                      className="table all-package theme-table table-product"
                      id="table_id"
                    >
                      <thead>
                        <tr>
                          <th>S.No.</th>
                          <th>Sub Category</th>
                          <th style={{ textAlign: "center" }}>Rank</th>
                          <th style={{ textAlign: "center" }}>Index</th>
                          <th style={{ textAlign: "center" }}>Active</th>
                          <th style={{ textAlign: "center" }}>Brand</th>
                          <th style={{ textAlign: "center" }}>Product</th>
                          <th style={{ textAlign: "center" }}>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                      {categories.map((subCategory, index) => (
                          <tr key={subCategory.subcategory_id}>
                            <td>{index + 1}</td>
                            <td>{subCategory.subcategory_name}</td>
                            <td style={{ textAlign: "center" }}>
                              <input
                                className="checkbox_animated check-it"
                                type="text"
                                size="4"
                                name={`rank_${subCategory.subcategory_id}`}
                                value={subCategory.rank}
                                onChange={(e) => handleChange(subCategory.subcategory_id, 'rank', e.target.value)}
                              />
                            </td>
                            <td style={{ textAlign: "center" }}>
                              <input
                                className="checkbox_animated check-it"
                                type="checkbox"
                                name={`front_active${subCategory.subcategory_id}`}
                                value="1"
                                checked={subCategory.front_active === '1'}
                                onChange={(e) => handleChange(subCategory.subcategory_id, 'front_active',e.target.checked ? '1' : '0')}
                              />   
                            </td>
                            <td style={{ textAlign: "center" }}>  
                              <input
                                className="checkbox_animated check-it"
                                type="checkbox"
                                name={`act_${subCategory.subcategory_id}`}
                                value="1"
                                checked={subCategory.active === '1'}
                                onChange={(e) => handleChange(subCategory.subcategory_id, 'active', e.target.checked ? '1' : '0')}
                              />
                            </td>
                            <td style={{ textAlign: "center" }}>
                              <Link to= '/brand'>
                                <i className="ri-cast-fill ri-2x"></i>
                              </Link>
                            </td>
                            <td style={{ textAlign: "center" }}>
                              <Link
                                to={`/products/${category_id}/${subCategory.subcategory_id}`}
                              >
                                <i className="ri-shopping-bag-line ri-2x"></i>
                              </Link>
                            </td>
                            <td style={{ textAlign: "center" }}>
                              <ul>
                                <li>
                                  <Link
                                    to={`/editsubcategory/${subCategory.subcategory_id}`}
                                    state={{ category_id }}
                                    >
                                    
                                    <i className="ri-pencil-line"></i>
                                  </Link>
                                </li>
                                <li>
                                  <a
                                   href="#" onClick={(e) => { e.preventDefault(); openDeleteModal(subCategory.subcategory_id); }}
                                  >
                                    <i className="ri-delete-bin-line"></i>
                                  </a>
                                </li>
                              </ul>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  <div class="card-footer border-0 pb-0 d-flex justify-content-end">
                            <button class="btn btn-primary me-3" type="button"
                             onClick={() => {
                              categories.forEach((subCategory) => {
                                handleUpdate(subCategory.subcategory_id, subCategory.rank, subCategory.front_active,subCategory.active );
                              });
                            }}
                            >Update</button>                                           
                        </div>
                        </>
                        )}
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
        </div>
      </div>

      {showModal && (
                <div className="modal fade show" style={{ display: "block" }}>
                    <div className="modal-dialog modal-dialog-centered">
                        <div className="modal-content">
                            <div className="modal-body">
                                <h5>Confirm Delete</h5>
                                <p>Are you sure you want to delete this subcategory?</p>
                                <button type="button" className="btn-close" onClick={closeModal}></button>
                            </div>
                            <div className="modal-footer">
                                <button type="button" className="btn btn-secondary" onClick={closeModal}>
                                    No
                                </button>
                                <button type="button" className="btn btn-danger" onClick={handleDelete}>
                                    Yes, Delete
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}
    </>
  );
};

export default SubCategory;
