import React, { useState } from "react";
import Header from "../Components/Header";
import { Link, useLocation, useNavigate } from "react-router-dom";
import axios from "axios";

const AddSubcategory = () => {
  const location = useLocation();
  const navigate = useNavigate();
  // Get the category_id passed from the SubCategory page
  const category_id = location.state?.category_id; // Get category_id from state

  // Set state for form data
  const [subcategoryName, setSubcategoryName] = useState("");
  const [image, setImage] = useState(null);

  // Handle form submission
  const handleImageChange = (e) => {
    const file = e.target.files[0]; // Get the selected file
    if (file) {
      setImage(file); // Store the file object
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
  
    if (!image) {
      alert("Please select an image.");
      return;
    }
  
    // Convert image to base64 string
    const toBase64 = (file) => 
      new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result);
        reader.onerror = (error) => reject(error);
      });
  
    try {
      const base64Image = await toBase64(image);
  
      const data = {
        cid: category_id,
        subcategory_name: subcategoryName,
        image: base64Image, // Send the image as a Base64 string
      };
  
      console.log("Sending Data:", data);
  
      const response = await axios.post(
        "https://www.aatheshsoft.com/admin_api/subcategory_add.php",
        data,
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
  
      console.log(response.data);
      if (response.data.head.code === 200) {
        console.log("✅ Subcategory added successfully!");
        navigate(`/subcategory/${category_id}`);
      } else {
        console.error("❌ Error adding subcategory:", response.data.head.msg);
      }
    } catch (error) {
      console.error("❌ API error:", error);
    }
  };
  
  

return (
    <>
      <Header />
      <div class="page-wrapper compact-wrapper" id="pageWrapper">
        <div class="page-body-wrapper">
          <div className="page-body">
            <div className="container-fluid">
              <div className="row">
                <div className="col-12">
                  <div className="row">
                    <div className="col-sm-12 m-auto">
                      <div className="card">
                        <div className="card-body">
                          <div className="title-header option-title d-sm-flex d-block">
                            <h5>Add Sub Category Images</h5>
                            <div className="right-options">
                              <ul>
                                <li>
                                  <Link
                                    className="btn btn-solid"
                                    to={`/subcategory/${category_id}`}
                                  >
                                    Back
                                  </Link>
                                </li>
                              </ul>
                            </div>
                          </div>

                          <form
                            class="theme-form theme-form-2 mega-form"
                            onSubmit={handleSubmit}
                          >
                            <div class="mb-4 row align-items-center">
                              <label class="form-label-title col-sm-3 mb-0">
                                Product Name
                              </label>
                              <div class="col-sm-9">
                                <input
                                  class="form-control"
                                  type="text"
                                  placeholder="Enter Product Name"
                                  value={subcategoryName}
                                  onChange={(e) => setSubcategoryName(e.target.value)}
                                  required
                                />
                              </div>
                            </div>

                            <div class="mb-4 row align-items-center">
                              <label class="form-label-title col-sm-3 mb-0">
                                Upload Image
                              </label>
                              <div class="col-sm-9">
                                <input
                                  class="form-control form-choose"
                                  type="file"
                                  id="formFile"
                                  multiple
                                  onChange={handleImageChange}
                                  required
                                />
                              </div>
                            </div>

                            <div class="card-footer border-0 pb-0 d-flex justify-content-end">
                              <button class="btn btn-primary me-3" type="submit">
                                Submit
                              </button>
                              <button class="btn btn-outline" type="reset">
                                Cancel
                              </button>
                            </div>
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default AddSubcategory;
