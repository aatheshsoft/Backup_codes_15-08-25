import React, { useEffect, useState } from 'react';
import Header from "../Components/Header";
import { Link, useNavigate, useParams } from "react-router-dom";
import axios from 'axios';

const EditBrand = () => {
  const { brand_id } = useParams(); // Get brand_id from the URL
  const [brandName, setBrandName] = useState('');
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('');
  const navigate = useNavigate();
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

  useEffect(() => {
    // Fetch categories
    axios.post(`${API_BASE_URL}category_list.php`)
      .then(response => {
        setCategories(response.data.body); // Assuming API returns an array of categories
      })
      .catch(error => console.error("Error fetching categories:", error));

    // Fetch brand details
    axios.post(`${API_BASE_URL}brand_detail.php`, { brand_id })
      .then(response => {
        if (response.data.head.code === 200) {
          const brandData = response.data.body;
          setBrandName(brandData.brand_name);

          // Find matching category ID based on category name
          axios.post(`${API_BASE_URL}category_list.php`)
            .then(categoryRes => {
              const categoryList = categoryRes.data.body;
              setCategories(categoryList);

              const matchedCategory = categoryList.find(cat => cat.category_name === brandData.type_of_category);
              if (matchedCategory) {
                setSelectedCategory(matchedCategory.category_id);
              }
            })
            .catch(error => console.error("Error fetching categories:", error));
        }
      })
      .catch(error => console.error("Error fetching brand details:", error));
  }, [brand_id]);

  const handleSubmit = (event) => {
    event.preventDefault();
  
    const requestData = {
      brand_id: brand_id,  // Ensure brand_id is passed correctly
      brand_name: brandName,
      category_id: selectedCategory, // Ensure category_id is correctly assigned
    };
  
    axios.post(`${API_BASE_URL}brand_detail_update.php`, requestData, {
      headers: { 'Content-Type': 'application/json' }
    })
      .then(response => {
        console.log("Update Response:", response.data);
        if (response.data.head.code === 200) {
          alert("Brand updated successfully!");
          navigate('/brand')
        } else {
          console.error("Error updating brand:", response.data.head.msg);
        }
      })
      .catch(error => console.error("Error updating brand:", error));
  };
  
  return (
    <>
      <Header />
      <div className="page-wrapper compact-wrapper" id="pageWrapper">
        <div className="page-body-wrapper">
          <div className="page-body">
            <div className="container-fluid">
              <div className="row">
                <div className="col-12">
                  <div className="row">
                    <div className="col-sm-12 m-auto">
                      <div className="card">
                        <div className="card-body">
                          <div className="title-header option-title d-sm-flex d-block">
                            <h5>Edit Brand</h5>
                            <div className="right-options">
                              <ul>
                                <li>
                                  <Link className="btn btn-solid" to="/brand">Back</Link>
                                </li>
                              </ul>
                            </div>
                          </div>

                          <form className="theme-form theme-form-2 mega-form" onSubmit={handleSubmit}>
                            <div className="mb-4 row align-items-center">
                              <label className="form-label-title col-sm-3 mb-0">Type of Category</label>
                              <div className="col-sm-9">
                                <select
                                  className="js-example-basic-single w-100 form-control"
                                  name="category"
                                  value={selectedCategory}
                                  onChange={(e) => setSelectedCategory(e.target.value)}
                                  required
                                >
                                  <option value="">Select Type</option>
                                  {categories.map((category) => (
                                    <option key={category.category_id} value={category.category_id}>
                                      {category.category_name}
                                    </option>
                                  ))}
                                </select>
                              </div>
                            </div>

                            <div className="mb-4 row align-items-center">
                              <label className="form-label-title col-sm-3 mb-0">Brand Name:</label>
                              <div className="col-sm-9">
                                <input
                                  className="form-control"
                                  type="text"
                                  name="brand_name"
                                  value={brandName}
                                  onChange={(e) => setBrandName(e.target.value)}
                                  placeholder="Enter Brand Name"
                                  required
                                />
                              </div>
                            </div>

                            <div className="card-footer border-0 pb-0 d-flex justify-content-end">
                              <button className="btn btn-primary me-3" type="submit">Submit</button>
                              <button className="btn btn-outline" type="button" onClick={() => window.history.back()}>Cancel</button>
                            </div>
                          </form>

                          <input type="hidden" name="brand_id" value={brand_id} />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default EditBrand;
