import React, { useEffect, useState } from "react";
import Header from "../Components/Header";
import { Link, useParams,useLocation, useNavigate } from "react-router-dom";
import axios from "axios";
import Skeleton from "react-loading-skeleton";
import "react-loading-skeleton/dist/skeleton.css";


const EditSubcategory = () => {
  const {subcategory_id} = useParams();
  const [subcategory, setSubcategory] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [image, setImage] = useState(null); 

  // for back navigation purpose
  const location = useLocation();
  const navigate = useNavigate();
  // Get the category_id passed from the SubCategory page
  const category_id = location.state?.category_id; // Get category_id from state
  console.log(category_id);
//-------end-------------


  const apiUrl = "https://www.aatheshsoft.com/admin_api/subcategory_detail.php";

  useEffect(() => {
    const fetchSubcategory = async () => {
      try {
        const response = await axios.post(apiUrl, { subcategory_id: subcategory_id });
        console.log("API Response:", response.data); // Debugging
        if (response.data && response.data.body) {
          setSubcategory(response.data.body);
        } else {
          setError("No data found");
        }
      } catch (error) {
        setError("Failed to fetch data");
      } finally {
        setLoading(false);
      }
    };
  
    fetchSubcategory();
  }, [subcategory_id]);


  const handleImageChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result); // Set the image in Base64 format
      };
      reader.readAsDataURL(file); // Convert the image to Base64
    }
  };

  const handleSubmit = async (event) => {
   event.preventDefault();
    const formData = {
      subcategory_id,
      subcategory_name: event.target.name.value,
      image:image || "",
    };
    try{
      const response = await axios.post ('https://www.aatheshsoft.com/admin_api/subcategory_detail_update.php',formData)
      
      if(response.data.head.code === 200){
        alert('Subcategory detail updated successfully');
        navigate(`/subcategory/${category_id}`);
      }
      else{
        setError("Failed to update subcategory");
      }
    }catch (error) {
      setError("Error updating subcategory");
    }
   
  };


  const handleDeleteImage = () => {
    // Add API call to delete image
    alert("Delete image API to be implemented!");
  };

  if (loading) return <p>Loading...</p>;
  if (error) return <p className="text-danger">{error}</p>;

  return (
    <>
      <Header />
      <div className="page-wrapper compact-wrapper" id="pageWrapper">
        <div className="page-body-wrapper">
          <div className="page-body">
            <div className="container-fluid">
              <div className="row">
                <div className="col-12">
                  <div className="row">
                    <div className="col-sm-12 m-auto">
                      <div className="card">
                        <div className="card-body">
                          <div className="title-header option-title d-sm-flex d-block">
                            <h5>Edit Sub Category</h5>
                            <div className="right-options">
                              <ul>
                                <li>
                                  <Link className="btn btn-solid"  to={`/subcategory/${category_id}`}>
                                    Back
                                  </Link>
                                </li>
                              </ul>
                            </div>
                          </div>

                          <form className="theme-form theme-form-2 mega-form"  onSubmit={handleSubmit}>
                            <div className="mb-4 row align-items-center">
                              <label className="form-label-title col-sm-3 mb-0">Sub Category</label>
                              <div className="col-sm-9">
                                <input
                                  className="form-control"
                                  type="text"
                                  name="name"
                                  autoComplete="off"
                                  defaultValue={subcategory.subcategory_name}
                                  placeholder="Enter Sub Category"
                                />
                              </div>
                            </div>

                            {/* Display image if exists */}
                            {subcategory.image ? (
                              <div className="mb-4 row align-items-center">
                                <label className="form-label-title col-sm-3 mb-0">Current Image</label>
                                <div className="col-sm-9">
                                  <img
                                    src={subcategory.image}
                                    alt="Subcategory"
                                    style={{ width: "100px", height: "100px", objectFit: "cover" }}
                                  />
                                  <button className="btn btn-danger mt-2" type="button" onClick={handleDeleteImage}>
                                    Delete Image
                                  </button>
                                </div>
                              </div>
                            ) : (
                              <div className="mb-4 row align-items-center">
                                <label className="form-label-title col-sm-3 mb-0">Upload Image</label>
                                <div className="col-sm-9">
                                  <input type="file" className="form-control" name="image" onChange={handleImageChange}/>
                                  <p>Size of image: 800*800</p>
                                </div>
                              </div>
                            )}
        
                            <div className="card-footer border-0 pb-0 d-flex justify-content-end">
                              <button className="btn btn-primary me-3" type="submit">
                                Submit
                              </button>
                              <button className="btn btn-outline" type="button" onClick={() => window.history.back()}>
                                Cancel
                              </button>
                            </div>
                          </form>

                          <input type="hidden" name="id" value={subcategory.id} />
                          <input type="hidden" name="cid" value={subcategory.cid} />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default EditSubcategory;
