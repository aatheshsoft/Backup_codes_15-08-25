import React, { useState, useEffect } from "react";
import Header from "../Components/Header";
import axios from "axios";

const PurchaseReport = () => {
  const [gstReport, setGstReport] = useState([]);
  const [originalGstReport, setOriginalGstReport] = useState([]); // Store all data
  const [uniqueGstRates, setUniqueGstRates] = useState([]);
  const [selectedGst, setSelectedGst] = useState("18"); // Default GST rate
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [gstTotal, setGstTotal] = useState("");
  const [ratetotal, setRateTotal] = useState("");
  const [productTotal, setProductTotal] = useState("");
  const [loading, setLoading] = useState(true);
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

  useEffect(() => {
    fetchGstReport();
  }, [selectedGst]);

  const fetchGstReport = async () => {
    setLoading(true);
    try {
      const response = await axios.post(
        `${API_BASE_URL}pos_api/pos_report_purchase.php`,
        { gst: selectedGst }
      );

      if (response.data.head.code === 200) {
        setOriginalGstReport(response.data.body.purchase_report || []); // Store unfiltered data
        setGstReport(response.data.body.purchase_report || []); // Initially show all data
        setUniqueGstRates(response.data.body.list_of_gst);
        setGstTotal(response.data.body.gst_total);
        setProductTotal(response.data.body.product_total);
        setRateTotal(response.data.body.product_total_without_gst);
      } else {
        console.error("Error fetching data:", response.data.head.msg);
      }
    } catch (error) {
      console.error("API Error:", error);
    }finally{
      setLoading(false);
    };
  };

  const handleFilter = (e) => {
    e.preventDefault();
  
    if (!fromDate || !toDate) {
      setGstReport(originalGstReport);
      setGstTotal(
        originalGstReport.reduce((acc, item) => acc + parseFloat(item.gst_amt), 0)
      );
      setProductTotal(
        originalGstReport.reduce((acc, item) => acc + parseFloat(item.total_with_gst), 0)
      );
      setRateTotal(
        originalGstReport.reduce((acc, item) => acc + parseFloat(item.total_without_gst), 0)
      );
      return;
    }
  
    const from = new Date(fromDate);
    from.setHours(0, 0, 0, 0);
  
    const to = new Date(toDate);
    to.setHours(23, 59, 59, 999);
  
    console.log("Filtering from:", from, "to:", to);
    console.log("All Data:", originalGstReport);
  
    const filtered = originalGstReport.filter((item) => {
      if (!item.purchase_date) {
        console.log("Skipping item - purchase_date is undefined:", item);
        return false;
      }
  
      const [day, month, year] = item.purchase_date.split("-");
      if (!day || !month || !year) {
        console.log("Skipping item - Invalid date format:", item.purchase_date);
        return false;
      }
  
      const formattedDate = new Date(`${year}-${month}-${day}`);
      formattedDate.setHours(0, 0, 0, 0);
  
      console.log("Checking:", formattedDate, "against range:", from, "-", to);
  
      return formattedDate.getTime() >= from.getTime() && formattedDate.getTime() <= to.getTime();
    });
  
    console.log("Filtered Data:", filtered);
    setGstReport(filtered);
  
    // Recalculate totals for filtered data
    const newGstTotal = filtered.reduce((acc, item) => acc + parseFloat(item.gst_amt || 0), 0);
    const newProductTotal = filtered.reduce((acc, item) => acc + parseFloat(item.total_with_gst || 0), 0);
    const newRateTotal =  filtered.reduce((acc, item) => acc + parseFloat(item.total_without_gst || 0), 0);
    setGstTotal(newGstTotal.toFixed(2));
    setProductTotal(newProductTotal.toFixed(2));
    setRateTotal(newRateTotal.toFixed(2));
    console.log(newRateTotal.toFixed(2));
  };
  
  
   
  
  return (
    <>
      <Header />
      <div className="page-wrapper compact-wrapper" id="pageWrapper">
        <div className="page-body-wrapper">
          <div className="page-body">
            <div className="container-fluid">
              <div className="row">
                <div className="col-sm-12">
                  <div className="card card-table">
                    <div className="card-body">
                      <div className="title-header option-title d-sm-flex d-block">
                        <h5>Purchase Report</h5>
                      </div>
                      <div>
                        <div className="row">
                          <div className="col-sm-12">
                            <form className="theme-form theme-form-2 mega-form" onSubmit={handleFilter}>
                              <div className="mb-4 row align-items-center">
                                
                                <label className="col-auto col-form-label form-label-title">
                                  From Date:
                                </label>
                                <div className="col-md-2">
                                  <input
                                    className="form-control"
                                    type="date"
                                    value={fromDate}
                                    onChange={(e) => setFromDate(e.target.value)}
                                  />
                                </div>
                                <label className="col-auto col-form-label form-label-title">
                                  To Date:
                                </label>
                                <div className="col-md-2">
                                  <input
                                    className="form-control"
                                    type="date"
                                    value={toDate}
                                    onChange={(e) => setToDate(e.target.value)}
                                  />
                                </div>
                                <div className="col-md-2">
                                  <button type="submit" className="btn btn-primary me-3">
                                    Submit
                                  </button>
                                </div>
                                <div className="col-md-2">
                                  <select
                                    className="form-control  gst-report-dropdown"
                                    value={selectedGst}
                                    onChange={(e) => setSelectedGst(e.target.value)}
                                  >
                                    {uniqueGstRates.length > 0 ? (
                                      uniqueGstRates.map((gst, index) => (
                                        <option key={index} value={gst.gst_percentage}>
                                          {gst.gst_percentage}%
                                        </option>
                                      ))
                                    ) : (
                                      <option disabled>No GST Rates Available</option>
                                    )}
                                  </select>
                                </div>
                              </div>
                            </form>
                          </div>
                        </div>
                        
                        <div className="table-responsive">
                        {loading ? (
                          <div
                            className="d-flex justify-content-center align-items-center"
                            style={{ height: "200px" }}
                          >
                            <div
                              className="spinner-border text-primary"
                              style={{ width: "3rem", height: "3rem" }}
                              role="status"
                            >
                              <span className="visually-hidden">
                                Loading...
                              </span>
                            </div>
                          </div>
                        ) : (
                          <>
                          <table className="table all-package theme-table table-product">
                            <thead>
                              <tr>
                                <th>S.No.</th>
                                {/* <th>Order ID</th> */}
                                <th>Purchase Date</th>
                                <th>Supplier Name</th>
                                <th>Product Name</th>
                                <th>Rate</th>
                                <th>Tax %</th>
                                <th style={{ textAlign: "right" }}>GST Amount</th>
                                <th style={{ textAlign: "right" }}>Total</th>
                              </tr>
                            </thead>
                            <tbody>
                              {gstReport.length > 0 ? (
                                gstReport.map((item, index) => (
                                  <tr key={item.purchase_id}>
                                    <td>{index + 1}</td>
                                    {/* <td>{item.order_id}</td> */}
                                    <td>{item.purchase_date}</td>
                                    <td>{item.supplier_name}</td>
                                    <td title={`Order ID: ${item.purchase_id}`}>{item.product_name}</td>
                                    <td style={{ textAlign: "center" }}>{item.total_without_gst}</td>
                                    <td>{item.gst_percentage}%</td>
                                    <td style={{ textAlign: "right" }}>
                                      <i className="fas fa-rupee-sign"></i> {item.gst_amt}
                                    </td>
                                    <td style={{ textAlign: "right" }}>
                                      <i className="fas fa-rupee-sign"></i> {item.total_with_gst}
                                    </td>
                                  </tr>
                                ))
                              ) : (
                                <tr>
                                  <td colSpan="7" className="text-center">
                                    No data available
                                  </td>
                                </tr>
                              )}
                              {/* Total Row */}
                              <tr id="total">
                                <td colSpan="4" style={{ textAlign: "left" }}>
                                  <h3>Total:</h3>
                                </td>
                                <td style={{ textAlign: "left" }}>
                                  <h3><i className="fas fa-rupee-sign"></i> {ratetotal}</h3>
                                </td>
                                <td></td>
                                <td style={{ textAlign: "right" }}>
                                  <h3><i className="fas fa-rupee-sign"></i> {gstTotal}</h3>
                                </td>
                                <td style={{ textAlign: "right" }}>
                                  <h3><i className="fas fa-rupee-sign"></i> {productTotal}</h3>
                                </td>
                              </tr>
                            </tbody>
                          </table>
                          </>
                        )}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default PurchaseReport;
