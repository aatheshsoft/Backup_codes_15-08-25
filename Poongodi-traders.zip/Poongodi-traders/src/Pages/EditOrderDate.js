import React, { useEffect, useState } from "react";
import Header from "../Components/Header";
import { Link, useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import Skeleton from "react-loading-skeleton";
import "react-loading-skeleton/dist/skeleton.css";

const EditOrderDate = () => {
  const { order_id } = useParams();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [orderData, setOrderData] = useState({
    // type_of_category: "",
    order_date: "",
  });
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

  // Fetch category details on mount
  useEffect(() => {
    if (!order_id) return;

    console.log("Fetching data for order_id:", order_id);
    setLoading(true);

    axios
      .post(`${API_BASE_URL}invoice_date_detail.php`, {
        order_id: order_id,
      })
      .then((response) => {
        console.log("API Response:", response.data);
        if (response.data.head.code === 200) {
          const orderDetails = response.data.body;
          setOrderData({
            // type_of_category: categoryDetails.type_of_category || "",
            order_date: orderDetails.order_date || "",
          });
        } else {
          alert(response.data.head?.msg || "Failed to fetch date details");
        }
      })
      .catch((error) => {
        console.error("Error fetching date details:", error);
      })
      .finally(() => setLoading(false));
  }, [order_id]);




  // Handle form field changes
  const handleChange = (e) => {
    setOrderData({ ...orderData, [e.target.name]: e.target.value });
  };



  
  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();

    if (!orderData.order_date) {
      alert("Please fill in all fields before submitting.");
      return;
    }

    console.log("Submitting data:", orderData);

    axios
      .post(`${API_BASE_URL}invoice_date_update.php`, {
        order_id: order_id,
        order_date: orderData.order_date,
        // type_of_category: orderData.type_of_category,
      })
      .then((response) => {
        console.log("Update Response:", response.data);
        if (response.data.head.code === 200) {
          alert("Order Date updated successfully!");
          navigate("/orderlist"); // Redirect after update
        } else {
          alert(response.data.head?.msg || "Failed to update order date");
        }
      })
      .catch((error) => {
        console.error("Error updating order date:", error);
        alert("An error occurred while updating. Please try again.");
      });
  };


  

  return (
    <>
      <Header />
      <div className="page-wrapper compact-wrapper" id="pageWrapper">
        <div className="page-body-wrapper">
          <div className="page-body">
            <div className="container-fluid">
              <div className="row">
                <div className="col-12">
                  <div className="row">
                    <div className="col-sm-12 m-auto">
                      <div className="card">
                        <div className="card-body">
                          <div className="title-header option-title d-sm-flex d-block">
                            <h5>Edit Order Date</h5>
                            <div className="right-options">
                              <ul>
                                <li>
                                  <Link className="btn btn-solid" to="/orderlist">
                                    Back
                                  </Link>
                                </li>
                              </ul>
                            </div>
                          </div>

                          <form className="theme-form theme-form-2 mega-form" onSubmit={handleSubmit}>
                            {loading ? (
                              <>
                                {/* Skeleton Loader for Type of Category */}
                                <div className="mb-4 row align-items-center">
                                  <label className="form-label-title col-sm-3 mb-0">
                                    <Skeleton width={120} height={20} />
                                  </label>
                                  <div className="col-sm-9">
                                    <Skeleton height={40} />
                                  </div>
                                </div>

                                {/* Skeleton Loader for Main Category */}
                                <div className="mb-4 row align-items-center">
                                  <label className="form-label-title col-sm-3 mb-0">
                                    <Skeleton width={120} height={20} />
                                  </label>
                                  <div className="col-sm-9">
                                    <Skeleton height={40} />
                                  </div>
                                </div>

                                {/* Skeleton Loader for Buttons */} 
                                <div className="card-footer border-0 pb-0 d-flex justify-content-end">
                                  <Skeleton width={100} height={40} />
                                  <Skeleton width={100} height={40} style={{ marginLeft: "10px" }} />
                                </div>
                              </>
                            ) : (
                              <>
                                {/* Type of Category Field */}
                               {/*  <div className="mb-4 row align-items-center">
                                  <label className="form-label-title col-sm-3 mb-0">Type of Category</label>
                                  <div className="col-sm-9">
                                    <select
                                      className="js-example-basic-single w-100"
                                      name="type_of_category"
                                      value={categoryData.type_of_category}
                                      onChange={handleChange}
                                    >
                                      <option value="">Select Type</option>
                                      <option>Home Appliances</option>
                                      <option>Kitchen Appliances</option>
                                      <option>Accessories</option>
                                      <option>Electronics</option>
                                    </select>
                                  </div>
                                </div> */}

                                {/* Main Category Field */}
                                <div className="mb-4 row align-items-center">
                                  <label className="form-label-title col-sm-3 mb-0">Order Date</label>
                                  <div className="col-sm-9">
                                    <input
                                      className="form-control"
                                      type="text"
                                      name="order_date"
                                      autoComplete="off"
                                      value={orderData.order_date}
                                      placeholder="Enter Order Date"
                                      onChange={handleChange}
                                    />
                                  </div>
                                </div>

                                {/* Buttons */}
                                <div className="card-footer border-0 pb-0 d-flex justify-content-end">
                                  <button className="btn btn-primary me-3" type="submit">
                                    Submit
                                  </button>
                                  <button
                                    className="btn btn-outline"
                                    type="button"
                                    onClick={() => navigate("/orderlist")}
                                  >
                                    Cancel
                                  </button>
                                </div>
                              </>
                            )}
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default EditOrderDate;
