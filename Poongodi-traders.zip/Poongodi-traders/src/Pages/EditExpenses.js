import React, { useState, useEffect } from "react";
import { Link, useParams, useNavigate } from "react-router-dom";
import Header from "../Components/Header";
import axios from "axios";

const EditExpenses = () => {
  const { id } = useParams(); 
  const navigate = useNavigate();
  const [expense, setExpense] = useState(null);
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

  useEffect(() => {
    const fetchExpense = async () => {
      try {
        const response = await axios.post(`${API_BASE_URL}expense_detail.php`, {id:id });
        if (response.data.head.code === 200) {
            setExpense(response.data.body);
        } else {
          console.error("Error fetching expense details:", response.data.head.msg);
        }
      } catch (error) {
        console.error("API Error:", error);
      }
    };

    fetchExpense();
  }, [id]);

  const handleChange = (e) => {
    setExpense({ ...expense, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(`${API_BASE_URL}expense_detail_update.php`, {
        id:id,
        type: expense.type,
        amount: expense.amount,
        description: expense.description, 
      });
      if (response.data.head.code === 200) {
        alert("expense details updated successfully!");
        navigate("/expenses");
      } else {
        alert("Failed to update expense details: " + response.data.head.msg);
      }
    } catch (error) {
      console.error("API Error:", error);
      alert("An error occurred while updating expense details.");
    }
  };

  if (!expense) {
    return <p>Loading expense details...</p>;
  }

  return (
    <>
      <Header />
      <div className="page-wrapper compact-wrapper" id="pageWrapper">
        <div className="page-body-wrapper">
          <div className="page-body">
            <div className="container-fluid">
              <div className="row">
                <div className="col-12">
                  <div className="row">
                    <div className="col-sm-12 m-auto">
                      <div className="card">
                        <div className="card-body">
                          <div className="title-header option-title d-sm-flex d-block">
                            <h5>Edit Supplier</h5>
                            <div className="right-options">
                              <ul>
                                <li>
                                  <Link className="btn btn-solid" to="/expenses">Back</Link>
                                </li>
                              </ul>
                            </div>
                          </div>

                          <form className="theme-form theme-form-2 mega-form" onSubmit={handleSubmit}>
                            <div className="mb-4 row align-items-center">
                              <label className="form-label-title col-sm-3 mb-0">Type</label>
                              <div className="col-sm-9">
                                <input className="form-control" type="text" name="type" value={expense.type || ""} onChange={handleChange} required />
                              </div>
                            </div>
                            <div className="mb-4 row align-items-center">
                              <label className="form-label-title col-sm-3 mb-0">Amount</label>
                              <div className="col-sm-9">
                                <textarea rows="3" className="form-control" name="amount" value={expense.amount || ""} onChange={handleChange} required></textarea>
                              </div>
                            </div>
                            <div className="mb-4 row align-items-center">
                              <label className="form-label-title col-sm-3 mb-0">Description</label>
                              <div className="col-sm-9">
                                <input className="form-control" type="text" name="description" value={expense.description || ""}
                                 onChange={handleChange} 
                                 required 
                                
                                 />
                              </div>
                            </div>
                           
                            
                            <div className="card-footer border-0 pb-0 d-flex justify-content-end">
                              <button className="btn btn-primary me-3" type="submit">Submit</button>
                              <button className="btn btn-outline" type="button" onClick={() => window.history.back()}>Cancel</button>
                            </div>
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default EditExpenses;
