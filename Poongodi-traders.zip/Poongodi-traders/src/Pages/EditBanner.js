import React, { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import axios from 'axios';
import Header from '../Components/Header';

const EditBanner = () => {
    const { banner_id } = useParams(); 
    const navigate = useNavigate();
    
    const [oldImage, setOldImage] = useState(""); 
    const [newImageBase64, setNewImageBase64] = useState(""); 
    const [loading, setLoading] = useState(false);

    // Fetch old banner details
    useEffect(() => {
        axios.post("https://www.aatheshsoft.com/admin_api/banner_detail.php", { banner_id })
            .then((response) => {
                if (response.data.head.code === 200) {
                    setOldImage(response.data.body.image); 
                } else {
                    alert("Error fetching banner details: " + response.data.head.msg);
                }
            })
            .catch((error) => {
                console.error("API Error:", error);
                alert("Failed to load banner details!");
            });
    }, [banner_id]);

    // Convert selected file to Base64
    const handleFileChange = (e) => {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onloadend = () => {
                setNewImageBase64(reader.result); 
            };
        }
    };

    // Submit updated banner
    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!newImageBase64) {
            alert("Please select an image to update!");
            return;
        }

        setLoading(true);
        try {
            const response = await axios.post(
                "https://www.aatheshsoft.com/admin_api/banner_detail_update.php",
                { banner_id, image: newImageBase64 } 
            );

            if (response.data.head.code === 200) {
                alert("Banner updated successfully!");
                navigate("/bannerlist"); 
            } else {
                alert("Error: " + response.data.head.msg);
            }
        } catch (error) {
            console.error("API Error:", error);
            alert("Something went wrong! Please try again.");
        } finally {
            setLoading(false);
        }
    };

    return (
        <>
            <Header />
            <div className="page-wrapper compact-wrapper" id="pageWrapper">
                <div className="page-body-wrapper">
                    <div className="page-body">
                        <div className="container-fluid">
                            <div className="row">
                                <div className="col-12">
                                    <div className="row">
                                        <div className="col-sm-12 m-auto">
                                            <div className="card">
                                                <div className="card-body">
                                                    <div className="title-header option-title d-sm-flex d-block">
                                                        <h5>Edit Banner Images</h5>
                                                        <div className="right-options">
                                                            <ul>
                                                                <li>
                                                                    <Link className="btn btn-solid" to="/bannerlist">Back</Link>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>

                                                    <form className="theme-form theme-form-2 mega-form" onSubmit={handleSubmit}>
                                                        {/* Display Old Image (Small Size) */}
                                                        {oldImage && (
                                                            <div className="mb-4 row align-items-center">
                                                                <label className="form-label-title col-sm-3 mb-0">Old Image</label>
                                                                <div className="col-sm-9">
                                                                    <img src={oldImage} alt="Old Banner" width="200px" height="100px" />
                                                                </div>
                                                            </div>
                                                        )}

                                                        {/* Upload New Image */}
                                                        <div className="mb-4 row align-items-center">
                                                            <label className="form-label-title col-sm-3 mb-0">Upload New Image</label>
                                                            <div className="col-sm-9">
                                                                <input 
                                                                    className="form-control form-choose" 
                                                                    type="file" 
                                                                    accept="image/*"
                                                                    onChange={handleFileChange} 
                                                                />
                                                            </div>
                                                        </div>

                                                        <div className="card-footer border-0 pb-0 d-flex justify-content-end">
                                                            <button type="submit" className="btn btn-primary me-3" disabled={loading}>
                                                                {loading ? "Updating..." : "Update"}
                                                            </button>
                                                            <button type="button" className="btn btn-outline" onClick={() => navigate("/bannerlist")}>Cancel</button>
                                                        </div>
                                                    </form>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </>
    );
};

export default EditBanner;
