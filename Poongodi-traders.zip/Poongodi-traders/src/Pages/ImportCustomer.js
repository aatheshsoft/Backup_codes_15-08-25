import React, { useState } from "react";
import Header from "../Components/Header";
import { useNavigate } from "react-router-dom";

const ImportCustomer = () => {
  const navigate = useNavigate();
  const [file, setFile] = useState(null);
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

  // Handle file selection
  const handleFileChange = (event) => {
    setFile(event.target.files[0]);
  };

  // Handle form submission
  const handleSubmit = async (event) => {
    event.preventDefault();

    if (!file) {
      alert("Please select an Excel file first.");
      return;
    }

    const formData = new FormData();
    formData.append("upload", file);
    formData.append("import", "Import");

    try {
      const response = await fetch(
        `${API_BASE_URL}import_excell_customer.php`,
        {
          method: "POST",
          body: formData,
          headers: {
            Accept: "application/json",
          },
        }
      );

      const textResponse = await response.text();
      console.log("Raw Response:", textResponse);

      let result;
      try {
        result = JSON.parse(textResponse);
      } catch (jsonError) {
        console.error("Error parsing JSON:", jsonError);
        alert("Invalid response from the server.");
        return;
      }

      console.log("Response JSON:", result);

      if (result && result.head) {
        alert(result.head.msg); // Show success message
        navigate("/customerlist");
      } else {
        alert("Unexpected response structure from API.");
      }
    } catch (error) {
      console.error("Error uploading file:", error);
      alert("An error occurred while importing the file.");
    }
  };

  return (
    <>
      <Header />
      <div className="page-wrapper compact-wrapper" id="pageWrapper">
        <div className="page-body-wrapper">
          <div className="page-body">
            <div className="container-fluid">
              <div className="row">
                <div className="col-12">
                  <div className="row">
                    <div className="col-sm-12 m-auto">
                      <div className="card">
                        <div className="card-body">
                          <div className="card-header-2">
                            <h5>Import Customer</h5>
                          </div>
                          <div className="card-footer border-0 pb-0 d-flex justify-content-end">
                            <button
                              className="btn btn-primary me-3"
                              onClick={() => window.history.back()}
                            >
                              Back
                            </button>
                          </div>
                          <form onSubmit={handleSubmit}>
                            <div className="mb-4 row align-items-center">
                              <label className="form-label-title col-sm-3 mb-0">
                                Select an Excel file:
                              </label>
                              <div className="col-sm-9">
                                <div className="dropzone-wrapper">
                                  <div className="dropzone-desc">
                                    <i className="ri-upload-2-line"></i>
                                    <p>Choose an Excel file or drag it here.</p>
                                  </div>
                                  <input
                                    type="file"
                                    name="upload"
                                    className="typeforms"
                                    onChange={handleFileChange}
                                    accept=".csv" // Allow Excel files
                                  />
                                </div>
                              </div>
                            </div>
                            <div className="mb-4 row align-items-center">
                              <label className="form-label-title col-sm-12 mb-0">
                                Upload an Csv file with the following columns:
                                Customer Name, Phone number, Credit Limit, Gst Number,
                                
                              </label>
                            </div>
                            <div className="card-footer border-0 pb-0 d-flex justify-content-center">
                              <button
                                type="submit"
                                className="btn btn-primary me-3"
                              >
                                Import
                              </button>
                            </div>
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ImportCustomer;
