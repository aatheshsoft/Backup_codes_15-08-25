import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import Header from "../Components/Header";
import axios from "axios";

const CancelOrder = () => {
  const [orders, setOrders] = useState([]);
  const [filteredOrders, setFilteredOrders] = useState([]);
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [loading, setLoading] = useState(true); 

  useEffect(() => {
    setLoading(true);
    axios.post('https://www.aatheshsoft.com/admin_api/cancel_order.php')
      .then((response) => {
        if (response.data.head.code === 200 && Array.isArray(response.data.body)) {
          setOrders(response.data.body);
          setFilteredOrders(response.data.body);
        } else {
          console.error("Error Fetching Data:", response.data.head.msg);
          setOrders([]);
          setFilteredOrders([]);
        }
      })
      .catch((error) => {
        console.error("API Error:", error);
        setOrders([]);
        setFilteredOrders([]);
      }).finally(() => {
        setLoading(false); // Set loading to false after API call
      });
  }, []);

  
  // ✅ Convert DD/MM/YYYY → YYYY-MM-DD for correct comparison
  const convertDate = (dateString) => {
    if (!dateString) return null; // Handle empty or null dates
    const parts = dateString.split("/"); // Split "DD/MM/YYYY"
    if (parts.length !== 3) return null; // Ensure valid format
    return `${parts[2]}-${parts[1]}-${parts[0]}`; // Convert to "YYYY-MM-DD"
  };

  // ✅ Date Filter with Safe Date Handling
  const handleFilter = (e) => {
    e.preventDefault();
    if (!fromDate || !toDate) {
      console.error("Date fields are empty");
      return;
    }

    const startDate = new Date(fromDate);
    const endDate = new Date(toDate);

    if (isNaN(startDate) || isNaN(endDate)) {
      console.error("Invalid date range");
      return;
    }

    const filtered = orders.filter((order) => {
      const orderDateFormatted = convertDate(order.orderdate); // Convert API date format
      const orderDate = orderDateFormatted ? new Date(orderDateFormatted) : null;
      return orderDate && orderDate >= startDate && orderDate <= endDate;
    });

    setFilteredOrders(filtered);
  };

  // ✅ Search Function with Safe Property Access
  const handleSearch = (e) => {
    const query = e.target.value.toLowerCase();
    setSearchQuery(query);

    const searchedOrders = orders.filter((order) => {
      return (
        order.name?.toLowerCase().includes(query) ||
        order.mobile?.includes(query) ||
        order.order_id?.includes(query)
      );
    });

    setFilteredOrders(searchedOrders);
  };

  return (
    <>
      <Header />
      <div className="page-wrapper compact-wrapper" id="pageWrapper">
        <div className="page-body-wrapper">
          <div className="page-body">
            <div className="container-fluid">
              <div className="row">
                <div className="col-sm-12">
                  <div className="card card-table">
                    <div className="card-body">
                      <div className="title-header option-title d-sm-flex d-block">
                        <h5>List of Cancel Orders</h5>
                      </div>

                      {/* Date Filter */}
                      <div className="row">
                        <div className="col-sm-12">
                          <form onSubmit={handleFilter} className="theme-form theme-form-2 mega-form">
                            <div className="mb-4 row align-items-center">
                              <label className="col-sm-2 col-form-label form-label-title">
                                From Date:
                              </label>
                              <div className="col-md-2">
                                <input
                                  className="form-control"
                                  type="date"
                                  value={fromDate}
                                  onChange={(e) => setFromDate(e.target.value)}
                                />
                              </div>
                              <label className="col-sm-2 col-form-label form-label-title">
                                To Date:
                              </label>
                              <div className="col-md-2">
                                <input
                                  className="form-control"
                                  type="date"
                                  value={toDate}
                                  onChange={(e) => setToDate(e.target.value)} 
                                       
                                />
                              </div>
                              <div className="col-md-2">
                                <button type="submit" className="btn btn-primary me-3">
                                  Submit
                                </button>
                              </div>
                            </div>
                          </form>
                        </div>
                      </div>

                      {/* Search Box */}
                      <div className="row">
                        <div className="col-sm-6">
                          <form className="theme-form theme-form-2 mega-form">
                            <div className="mb-4 row align-items-center">
                              <label htmlFor="search" className="col-sm-2 col-form-label">
                                Search:
                              </label>
                              <div className="col-sm-10">
                                <input
                                  type="text"
                                  id="search"
                                  name="search"
                                  className="form-control"
                                  placeholder="Search Order"
                                  value={searchQuery}
                                  onChange={handleSearch}
                                />
                              </div>
                            </div>
                          </form>
                        </div>
                      </div>

                      {/* Order Table */}
                      {loading ? (
        <div className="d-flex justify-content-center align-items-center" style={{ height: '200px' }}>
          <div className="spinner-border text-primary" style={{ width: '3rem', height: '3rem' }} role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      ) : (
        <>
                      <div className="table-responsive">
                        <table className="table all-package theme-table table-product">
                          <thead>
                            <tr>
                              <th>Order ID</th>
                              <th>Date</th>
                              <th>Customer Name</th>
                              <th>Amount</th>
                              <th>View</th>
                              <th>Action</th>
                            </tr>
                          </thead>
                          <tbody>
                            {filteredOrders.length > 0 ? (
                              filteredOrders.map((order) => (
                                <tr key={order.order_id}>
                                  <td>{order.order_id}</td>
                                  <td>{order.orderdate || "N/A"}</td>
                                  <td>{order.name || "N/A"}</td>
                                  <td>
                                    <i className="fas fa-rupee-sign"></i> {parseFloat(order.amount.replace(/,/g, "") || 0).toFixed(2)}
                                  </td>
                                  <td>
                                    <Link to={`/cancelorderdetails/${order.order_id}`}>
                                      <i className="ri-eye-line"></i>
                                    </Link>
                                  </td>
                                  <td>
                                    <ul>                                                               
                                        <li><a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#exampleModalToggle"><i class="ri-delete-bin-line"></i></a>
                                        </li>
                                    </ul>
                                  </td>
                                </tr>
                              ))
                            ) : (
                              <tr>
                                <td colSpan="5" className="text-center">
                                  No orders found
                                </td>
                              </tr>
                            )}
                          </tbody>
                        </table>
                      </div>
                      </>
      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default CancelOrder;
