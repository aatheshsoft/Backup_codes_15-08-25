import React, { useState,useEffect } from "react";
import Header from "../Components/Header";
import {useNavigate } from "react-router-dom";
import axios from "axios";

const AddPurchase = () => {
  const [categories, setCategories] = useState([]);
  const [brandName, setBrandName] = useState([]);
  const navigate = useNavigate();
  const [products, setProducts] = useState([]);
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
  const [supplierList, setSupplierList] = useState("")

  const [formData, setFormData] = useState({
    pid: "",
    cid: "",
    brand_id: "",
    product_name: "",
    product_code: "",
    sku_no: "",
    hsn_code: "",
    supplier_name: "",
    supplier_mobile: "",
    purchase_rate: "",
    sales_rate: "",
    gst_nbr: "",
    note: "",
    gst: "",
    qty: "",
    unit: "",
  });
  const handleChange = (e) => {
    const { name, value } = e.target;
  
    if (name === "product") {
      const selectedProduct = JSON.parse(value);
      
      setFormData((prevData) => ({
        ...prevData,
        pid: selectedProduct.pid,
        product_name: selectedProduct.product_name,
        product_code: selectedProduct.product_code, // Auto-fill product code
        category_id: selectedProduct.category_id,
        category_name: selectedProduct.category_name, // Auto-fill category name
        brand_id: selectedProduct.brand_id,
        brand_name: selectedProduct.brand_name, // Auto-fill brand name
        hsn_code: selectedProduct.hsn_code, // Auto-fill HSN code
        sku_no: selectedProduct.sku_no, // Auto-fill SKU number
        gst: selectedProduct.tax, // Auto-fill GST
        unit: selectedProduct.unit, // Auto-fill unit
      }));
    } else {
      setFormData((prevData) => ({
        ...prevData,
        [name]: value,
      }));
    }
  };
  
  
  
  useEffect(() => {
    axios.post(`${API_BASE_URL}category_list.php`)
      .then(response => {
        if (response.data.head.code === 200) {
          setCategories(response.data.body);
        } else {
          console.error("Error fetching categories:", response.data.head.msg);
        }
      })
      .catch(error => console.error("API Error:", error));
  }, []);
  useEffect(() => {
       
    axios
      .post(`${API_BASE_URL}brand_list.php`)
      .then((response) => {
        if (response.data.head.code === 200) {
          
          
        setBrandName(response.data.body); // Store sorted categories in state
        } else {
          console.error("Error Fetching Data:", response.data.head.msg);
        }
      })
      .catch((error) => {
        console.error("API Error:", error);
      })
      
  }, []);

  useEffect(() => {
    axios.post(`${API_BASE_URL}pos_api/product_list_dropdown.php`)
      .then(response => {
        if (response.data.head.code === 200) {
          setProducts(response.data.body);
        } else {
          console.error("Error fetching products:", response.data.head.msg);
        }
      })
      .catch(error => console.error("API Error:", error));
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const updatedFormData = { ...formData };
      console.log("Sending data:", updatedFormData);
  
      const response = await axios.post(
        `${API_BASE_URL}pos_api/pos_purchase_add.php`,
        updatedFormData,
        { headers: { "Content-Type": "application/json" } }
      );
  
      console.log("Full API Response:", response);
  
      // Ensure data is valid JSON
      let responseData;
      try {
        responseData = JSON.parse(response.data.replace(/^[^\{]+/, "")); // Remove non-JSON characters
      } catch (parseError) {
        console.error("Error parsing JSON response:", parseError);
        alert("Invalid response format from server.");
        return;
      }
  
      if (responseData?.head?.code === 200) {
        console.log("Response:", responseData);
        alert("Product purchased successfully!");
        navigate("/purchaselist");
      } else {
        console.error("API Error:", responseData?.head?.msg);
        alert(responseData?.head?.msg || "Unexpected error occurred");
      }
    } catch (error) {
      console.error("Error adding product:", error);
      alert("Failed to add product");
    }
  };
  
  
  useEffect(() => {
    axios
      .post(`${API_BASE_URL}supplier_list.php`)
      .then((res) => {
        if (res.data && res.data.body && Array.isArray(res.data.body)) {
          setSupplierList(res.data.body);
        } else {
          console.error("API response is not an array:", res.data.body);
          setSupplierList([]); // fallback to empty array
        }
      })
      .catch((err) => {
        console.error("Error fetching supplier list", err);
        setSupplierList([]); // fallback to empty array
      });
  }, []);
  
  const handleSupplierChange = (selectedName) => {
    const selectedSupplier = supplierList.find(
      (supplier) => supplier.supplier_name === selectedName
    );
  
    if (selectedSupplier) {
      setFormData({
        ...formData,
        supplier_name: selectedSupplier.supplier_name,
        supplier_mobile: selectedSupplier.mobile,
        gst_nbr: selectedSupplier.gst_number
      });
    }
  };
  
  return (
    <>
      <Header />
      <div className="page-wrapper compact-wrapper" id="pageWrapper">
        <div className="page-body-wrapper">
          <div className="page-body">
            <div className="container-fluid">
              <div className="row">
                <div className="col-12">
                  <div className="row">
                    <div className="col-sm-12 m-auto">
                      <div className="card">
                        <div className="card-body">
                          <div className="title-header option-title d-sm-flex d-block">
                            <h5>Add Purchase</h5>
                            <div className="right-options">
                              <ul>
                                <li>
                                  <button className="btn btn-solid" onClick={() => window.history.back()}>
                                    Back
                                  </button>
                                </li>
                              </ul>
                            </div>
                          </div>

                          <form className="theme-form theme-form-2 mega-form" onSubmit={handleSubmit}>
                                <div className="row">
                                  {/* Product Name */}
                                  <div className="col-md-6 mb-4">
                                    <div className="row align-items-center">
                                      <label className="col-md-4 form-label-title col-sm-4 mb-0">Product Name:</label>
                                      <div className="col-md-7 col-sm-12">
                                        <select
                                          className="js-example-basic-single w-100"
                                          name="product"
                                          value={formData.pid || ""}
                                          onChange={(e) => {
                                            const selectedProduct = products.find(
                                              (product) => product.product_id.toString() === e.target.value
                                            );
                                            if (selectedProduct) {
                                              setFormData({
                                                ...formData,
                                                pid: selectedProduct.product_id,
                                                product_name: selectedProduct.product_name,
                                                product_code: selectedProduct.product_code,
                                                cid: selectedProduct.category_id,
                                                category_name: selectedProduct.category_name,
                                                brand_id: selectedProduct.brand_id,
                                                brand_name: selectedProduct.brand_name,
                                                hsn_code: selectedProduct.hsn_code,
                                                sku_no: selectedProduct.sku_no,
                                                gst: selectedProduct.tax,
                                                unit: selectedProduct.unit,
                                              });
                                            }
                                          }}
                                          required
                                        >
                                          <option value="">Select Product Name</option>
                                          {products.map((product) => (
                                            <option key={product.product_code} value={product.product_id}>
                                              {product.product_name}
                                            </option>
                                          ))}
                                        </select>
                                      </div>
                                    </div>
                                  </div>

                                  {/* Product Code */}
                                  <div className="col-md-6 mb-4">
                                    <div className="row align-items-center">
                                      <label className="col-md-4 form-label-title col-sm-4 mb-0">Product Code:</label>
                                      <div className="col-md-7 col-sm-12">
                                        <input
                                          type="text"
                                          className="form-control"
                                          name="product_code"
                                          value={formData.product_code || ""}
                                          readOnly
                                        />
                                      </div>
                                    </div>
                                  </div>

                                  {/* Row with 4 inputs per row */}
                                  <div className="col-md-3 mb-4">
                                    <label className="form-label-title">Category</label>
                                    <input className="form-control" type="text" name="category_name" value={formData.category_name} readOnly />
                                  </div>

                                  <div className="col-md-3 mb-4">
                                    <label className="form-label-title">Brand</label>
                                    <input className="form-control" type="text" name="brand_name" value={formData.brand_name} readOnly />
                                  </div>

                                  <div className="col-md-3 mb-4">
                                    <label className="form-label-title">HSN Code</label>
                                    <input className="form-control" type="text" name="hsn_code" value={formData.hsn_code} readOnly />
                                  </div>

                                  <div className="col-md-3 mb-4">
                                    <label className="form-label-title">GST (%)</label>
                                    <input className="form-control" type="text" name="gst" value={formData.gst} readOnly />
                                  </div>

                                  <div className="col-md-3 mb-4">
                                    <label className="form-label-title">Qty</label>
                                    <input className="form-control" type="text" name="qty" placeholder="Enter Qty" value={formData.qty} onChange={handleChange} />
                                  </div>

                                  <div className="col-md-3 mb-4">
                                    <label className="form-label-title">Unit</label>
                                    <input className="form-control" type="text" name="unit" value={formData.unit} readOnly />
                                  </div>

                                  <div className="col-md-3 mb-4">
                                    <label className="form-label-title">Purchase Rate</label>
                                    <input className="form-control" type="text" name="purchase_rate" placeholder="Enter Purchase Rate" value={formData.purchase_rate} onChange={handleChange} />
                                  </div>

                                  <div className="col-md-3 mb-4">
                                    <label className="form-label-title">Sales Rate</label>
                                    <input className="form-control" type="text" name="sales_rate" placeholder="Enter Sales Rate" value={formData.sales_rate} onChange={handleChange} />
                                  </div>

                                  <div className="col-md-3 mb-4">
                                    <label className="form-label-title">Supplier Name</label>
                                    <select
  className="form-control"
  name="supplier_name"
  value={formData.supplier_name}
  onChange={(e) => handleSupplierChange(e.target.value)}
>
  <option value="">Select Supplier</option>
  {Array.isArray(supplierList) &&
  supplierList.map((supplier) => (
    <option key={supplier.id} value={supplier.supplier_name}>
      {supplier.supplier_name}
    </option>
))}
</select>
                                  </div>

                                  <div className="col-md-3 mb-4">
                                    <label className="form-label-title">Supplier Mobile</label>
                                    <input
  className="form-control"
  type="text"
  name="supplier_mobile"
  placeholder="Enter Supplier Mobile"
  value={formData.supplier_mobile}
  onChange={handleChange}
/>
                                  </div>

                                  <div className="col-md-3 mb-4">
                                    <label className="form-label-title">GST Number</label>
                                    <input
  className="form-control"
  type="text"
  name="gst_nbr"
  placeholder="Enter GST Number"
  value={formData.gst_nbr}
  onChange={handleChange}
/>
                                  </div>

                                  <div className="col-md-3 mb-4">
                                    <label className="form-label-title">SKU.No</label>
                                    <input className="form-control" type="text" name="sku_no" value={formData.sku_no} readOnly />
                                  </div>

                                  {/* Notes - Full Width */}
                                  <div className="col-12 mb-4">
                                    <label className="form-label-title">Note</label>
                                    <textarea className="form-control" rows="5" name="note" placeholder="Note" value={formData.note} onChange={handleChange}></textarea>
                                  </div>

                                  {/* Buttons */}
                                  <div className="col-12 d-flex justify-content-end">
                                    <button className="btn btn-primary me-3" type="submit">
                                      Submit
                                    </button>
                                    <button className="btn btn-outline" onClick={() => window.history.back()}>
                                      Cancel
                                    </button>
                                  </div>
                                </div>
                              </form>

                          {/* End Form Section */}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

export default AddPurchase;