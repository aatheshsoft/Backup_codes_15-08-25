import React,{useState,useEffect} from "react";
import Header from "../Components/Header";
import { Link } from "react-router-dom";
import axios from "axios";


const Brand = () => {
    const [brands, setBrands] = useState([]);
    const [showModal, setShowModal] = useState(false);
    const [selectedbrandId, setSelectedBrandId] = useState(null);
    const [loading, setLoading] = useState(true);
    const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
    const openDeleteModal = (brand_id) =>{
      setSelectedBrandId(brand_id)
      setShowModal(true);
    }
    
    const closeModal = () => {
      setSelectedBrandId(null);
      setShowModal(false);
  };





      useEffect(() => {
        setLoading(true);
        axios
          .post(`${API_BASE_URL}brand_list.php`)
          .then((response) => {
            if (response.data.head.code === 200) {
              
              
              setBrands(response.data.body); // Store sorted categories in state
            } else {
              console.error("Error Fetching Data:", response.data.head.msg);
            }
          })
          .catch((error) => {
            console.error("API Error:", error);
          }).finally(() => {
            setLoading(false);
          });
          
      }, []);
      const handleDelete = async () => {
        if(!selectedbrandId) return;
        console.log("selectedbrandId",selectedbrandId)
        try {
          const response = await axios.post(`${API_BASE_URL}brand_list_delete.php`,{
          brand_id: selectedbrandId,
          });

          if(response.data.head.code === 200) {
            alert('Brand Deleted Successfully')
            closeModal();
            window.location.reload();

          } else{
            alert(response.data.head?.msg || "Failed to delete category");
          }
         
        }
        catch(error) {
          console.error("Error Deleting Category", error)
          }

      };



  return (
    <>
      <Header />
      <div class="page-wrapper compact-wrapper" id="pageWrapper">
        <div class="page-body-wrapper">
        <div className="page-body">
      <div className="container-fluid">
        <div className="row">
          <div className="col-sm-12">
            <div className="card card-table">
              <div className="card-body">
                <div className="title-header option-title d-sm-flex d-block">
                  <h5>List of Brand</h5>
                  <div className="right-options">
                    <ul>
                      
                      <li>
                        <Link className="btn btn-solid" to="/addbrand">
                          Add Brand
                        </Link>
                      </li>
                    </ul>
                  </div>
                </div>

                                      <form>
                                      {loading ? (
                                                <div
                                                  className="d-flex justify-content-center align-items-center"
                                                  style={{ height: "200px" }}
                                                >
                                                  <div
                                                    className="spinner-border text-primary"
                                                    style={{ width: "3rem", height: "3rem" }}
                                                    role="status"
                                                  >
                                                    <span className="visually-hidden">
                                                      Loading...
                                                    </span>
                                                  </div>
                                                </div>
                                              ) : (
                                                <>
                                        <div className="table-responsive">
                                          <table className="table all-package theme-table table-product" id="table_id">
                                            <thead>
                                              <tr>
                                                <th>S.No.</th>
                                                <th>Brand Name</th>
                                                <th>Category Type</th>
                                          {/*       <th style={{ textAlign: 'center' }}>Rank</th>
                                                <th style={{ textAlign: 'center' }}>Active</th> */}
                                                <th style={{ textAlign: 'center' }}>Action</th>
                                              </tr>
                                            </thead>

                                            <tbody>
                                              {brands.map((brand, index) => (
                                                <tr key={brand.brand_id}>
                                                  <td>{index + 1}</td>
                                                  <td>{brand.brand_name}</td>
                                                  <td>{brand.type_of_category}</td>
                                                  
                                                  <td style={{ textAlign: 'center' }}>
                                                    <ul>
                                                      <li>
                                                        <Link to={`/editbrand/${brand.brand_id}`}>
                                                          <i className="ri-pencil-line"></i>
                                                        </Link>
                                                      </li>
                                                      <li>
                                                        <a href=""onClick={(e) => { e.preventDefault(); openDeleteModal(brand.brand_id); }}>
                                                          <i className="ri-delete-bin-line"></i>
                                                        </a>
                                                      </li>
                                                    </ul>
                                                  </td>
                                                </tr>
                                              ))}
                                            </tbody>
                                          </table>
                                        </div>
                                        </>
                                              )}
                                      </form>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
      {showModal && (
                <div className="modal fade show" style={{ display: "block" }}>
                    <div className="modal-dialog modal-dialog-centered">
                        <div className="modal-content">
                            <div className="modal-body">
                                <h5>Confirm Delete</h5>
                                <p>Are you sure you want to delete this brand?</p>
                                <button type="button" className="btn-close" onClick={closeModal}></button>
                            </div>
                            <div className="modal-footer">
                                <button type="button" className="btn btn-secondary" onClick={closeModal}>
                                    No
                                </button>
                                <button type="button" className="btn btn-danger" onClick={handleDelete}>
                                    Yes, Delete
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}

    </>
  );
};

export default Brand;
