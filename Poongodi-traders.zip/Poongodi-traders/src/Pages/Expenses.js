import React, { useEffect, useState } from "react";
import Header from "../Components/Header";
import { Link } from "react-router-dom";
import axios from "axios";

const Expenses = () => {
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [expenselist, setExpense] = useState([]);
  const [filteredExpenselist, setFilteredexpenselist] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const recordsPerPage = 25;
  const totalRecords = filteredExpenselist.length;
  const totalPages = Math.ceil(totalRecords / recordsPerPage);
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [Total, setTotal] = useState("");
  const [productTotal, setProductTotal] = useState("");
  const [gstReport, setGstReport] = useState([]);
  const [originalGstReport, setOriginalGstReport] = useState([]); 

  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
  // Calculate records for the current page
  const indexOfLastRecord = currentPage * recordsPerPage;
  const indexOfFirstRecord = indexOfLastRecord - recordsPerPage;
  const currentRecords = filteredExpenselist.slice(
    indexOfFirstRecord,
    indexOfLastRecord
  );

  // Function to change the page
  const paginate = (pageNumber) => {
    if (pageNumber >= 1 && pageNumber <= totalPages) {
      setCurrentPage(pageNumber);
    }
  };

  useEffect(() => {
    setLoading(true);
    axios
        .post(`${API_BASE_URL}expense_list.php`)
        .then((response) => {
            if (response.data.head.code === 200) {
                const allExpenses = response.data.body;
                
                // Set expenses and filtered list
                setExpense(allExpenses);
                setFilteredexpenselist(allExpenses);

                // Calculate initial total only after setting expenses
                const initialTotal = allExpenses.reduce((acc, item) => acc + parseFloat(item.amount || 0), 0);
                setTotal(initialTotal.toFixed(2));
            } else {
                console.error("Error Fetching Data", response.data.head.msg);
                setExpense([]);
                setFilteredexpenselist([]);
                setTotal(0);  // Clear total if data fetch fails
            }
        })
        .catch((error) => console.error("API Error:", error))
        .finally(() => setLoading(false));
}, []);


  const [selectedId, setSelectedId] = useState(null);

  const handleDelete = async () => {
    if (!selectedId) {
      alert("Invalid User ID");
      return;
    }

    try {
      const response = await axios.post(
        `${API_BASE_URL}expense_list_delete.php`,
        { id: selectedId }
      );

      if (response.data.head.code === 200) {
        //   alert("Customer deleted successfully!");
        window.location.reload();
      } else {
        alert("Error: " + response.data.head.msg);
      }
    } catch (error) {
      console.error("Delete API Error:", error);
      alert("Failed to delete expense. Please try again.");
    }
  };

 


  const handleFilter = (e) => {
    e.preventDefault();

    // If no date is selected, reset to all expenses
    if (!fromDate || !toDate) {
        setFilteredexpenselist(expenselist);
        const allTotal = expenselist.reduce((acc, item) => acc + parseFloat(item.amount || 0), 0);
        setTotal(allTotal.toFixed(2));
        return;
    }

    const from = new Date(fromDate);
    from.setHours(0, 0, 0, 0);

    const to = new Date(toDate);
    to.setHours(23, 59, 59, 999);

    const filteredData = expenselist.filter((item) => {
        const itemDate = item.date || "";
        if (!itemDate) return false;

        const [day, month, year] = itemDate.split("-");
        if (!day || !month || !year) return false;

        const formattedDate = new Date(`${year}-${month}-${day}`);
        formattedDate.setHours(0, 0, 0, 0);

        return formattedDate >= from && formattedDate <= to;
    });

    setFilteredexpenselist(filteredData);

    // Calculate total for filtered data
    const filteredTotal = filteredData.reduce((acc, item) => acc + parseFloat(item.amount || 0), 0);
    setTotal(filteredTotal.toFixed(2));

    // Reset to first page after filtering
    setCurrentPage(1);
};






  

  return (
    <>
      <Header />
      <div class="page-wrapper compact-wrapper" id="pageWrapper">
        <div class="page-body-wrapper">
          <div class="page-body">
            <div class="container-fluid">
              <div class="row">
                <div class="col-sm-12">
                  <div class="card card-table">
                    <div class="card-body">
                      <div class="title-header option-title d-sm-flex d-block">
                        <h5>
                          <i class="ri-file-user-fill"></i> List Expenses
                        </h5>
                        <div className="right-options">
                          <ul>
                            <li>
                              <Link
                                className="btn btn-solid"
                                to="/addexpenses"
                                // state={{ category_id, subcategory_id }} // pass the id using state
                              >
                                Add Expenses
                              </Link>
                            </li>
                          </ul>
                        </div>
                      </div>
                      <div className="row">
                          <div className="col-sm-12">
                            <form className="theme-form theme-form-2 mega-form" onSubmit={handleFilter}>
                              <div className="mb-4 row align-items-center">
                                
                                <label className="col-auto col-form-label form-label-title">
                                  From Date:
                                </label>
                                <div className="col-md-2">
                                  <input
                                    className="form-control"
                                    type="date"
                                    value={fromDate}
                                    onChange={(e) => setFromDate(e.target.value)}
                                  />
                                </div>
                                <label className="col-auto col-form-label form-label-title">
                                  To Date:
                                </label>
                                <div className="col-md-2">
                                  <input
                                    className="form-control"
                                    type="date"
                                    value={toDate}
                                    onChange={(e) => setToDate(e.target.value)}
                                  />
                                </div>
                                <div className="col-md-2">
                                  <button type="submit" className="btn btn-primary me-3">
                                    Submit
                                  </button>
                                </div>
                                
                              </div>
                            </form>
                          </div>
                        </div>
                      <div>
                        <div class="table-responsive">
                          <table
                            class="table all-package theme-table table-product"
                            id="table_id"
                          >
                            {loading ? (
                              <div
                                className="d-flex justify-content-center align-items-center"
                                style={{ height: "200px" }}
                              >
                                <div
                                  className="spinner-border text-primary"
                                  style={{ width: "3rem", height: "3rem" }}
                                  role="status"
                                >
                                  <span className="visually-hidden">
                                    Loading...
                                  </span>
                                </div>
                              </div>
                            ) : (
                              <>
                                <thead>
                                  <tr>
                                    <th>S.No.</th>

                                    <th>Date</th>

                                    <th>Type of Expense</th>
                                    <th>Amount</th>
                                    <th>Description</th>

                                    <th style={{ textAlign: "center" }}>
                                      Action
                                    </th>
                                  </tr>
                                </thead>

                                <tbody>
                                  {currentRecords.length > 0 ? (
                                    currentRecords.map((item, index) => (
                                      <tr key={item.id}>
                                        <td>
                                          {indexOfFirstRecord + index + 1}
                                        </td>

                                        <td>{item.date}</td>

                                        <td>{item.type}</td>
                                        <td style={{ textAlign: "center" }}>{item.amount}</td>
                                        <td>{item.description}</td>

                                        <td>
                                          <ul>
                                            <li>
                                              <Link
                                                to={`/editexpenses/${item.id}`}
                                              >
                                                <i className="ri-pencil-line"></i>
                                              </Link>
                                            </li>
                                            <li>
                                              {" "}
                                              <a
                                                href="javascript:void(0)"
                                                data-bs-toggle="modal"
                                                data-bs-target="#deleteModal"
                                                onClick={() =>
                                                  setSelectedId(item.id)
                                                }
                                              >
                                                <i className="ri-delete-bin-line"></i>
                                              </a>
                                            </li>
                                          </ul>
                                        </td>
                                      </tr>
                                    ))
                                  ) : (
                                    <tr>
                                      <td colSpan="5" className="text-center">
                                        No Record found
                                      </td>
                                    </tr>
                                  )}
                                  <tr id="total">
                            <td colSpan="3">
                              <h3>Total:</h3>
                            </td>
                            <td style={{ textAlign: "center" }}>
                              <h3>
                                <i className="fas fa-rupee-sign"></i> {Total} 
                              </h3>
                            </td>
                            <td></td>
                          </tr>

                                  <td colSpan="9">
                                    <table
                                      width="100%"
                                      border="1"
                                      style={{
                                        borderCollapse: "collapse",
                                        border: "1px solid #000",
                                      }}
                                    >
                                      <tr>
                                        <td width="20%">
                                          Page {currentPage} of {totalPages}
                                        </td>
                                        <td style={{ textAlign: "right" }}>
                                          {/* Previous Button */}
                                          {currentPage > 1 ? (
                                            <a
                                              className="pagetext"
                                              href="javascript:void(0);"
                                              onClick={() =>
                                                paginate(currentPage - 1)
                                              }
                                            >
                                              &laquo; Previous
                                            </a>
                                          ) : (
                                            <span>&laquo; Previous</span>
                                          )}
                                          &nbsp;
                                          {/* Page Numbers */}
                                          {[...Array(totalPages)].map(
                                            (_, i) => (
                                              <React.Fragment key={i}>
                                                <a
                                                  className={`pagetext ${
                                                    currentPage === i + 1
                                                      ? "active"
                                                      : ""
                                                  }`}
                                                  href="javascript:void(0);"
                                                  onClick={() =>
                                                    paginate(i + 1)
                                                  }
                                                >
                                                  {i + 1}
                                                </a>
                                                &nbsp;
                                              </React.Fragment>
                                            )
                                          )}
                                          {/* Next Button */}
                                          {currentPage < totalPages ? (
                                            <a
                                              className="pagetext"
                                              href="javascript:void(0);"
                                              onClick={() =>
                                                paginate(currentPage + 1)
                                              }
                                            >
                                              Next &raquo;
                                            </a>
                                          ) : (
                                            <span>Next &raquo;</span>
                                          )}
                                          {/* Last Button */}
                                          {currentPage < totalPages ? (
                                            <a
                                              className="pagetext"
                                              href="javascript:void(0);"
                                              onClick={() =>
                                                paginate(totalPages)
                                              }
                                            >
                                              Last &raquo;&raquo;
                                            </a>
                                          ) : (
                                            <span>Last &raquo;&raquo;</span>
                                          )}
                                        </td>
                                      </tr>
                                    </table>
                                  </td>
                                </tbody>
                              </>
                            )}
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div
        className="modal fade"
        id="deleteModal"
        tabIndex="-1"
        aria-hidden="true"
      >
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title">Confirm Delete</h5>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div className="modal-body">
              Are you sure you want to delete this expense?
            </div>
            <div className="modal-footer">
              <button
                type="button"
                className="btn btn-secondary"
                data-bs-dismiss="modal"
              >
                Cancel
              </button>
              <button
                type="button"
                className="btn btn-danger"
                onClick={handleDelete}
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Expenses;
