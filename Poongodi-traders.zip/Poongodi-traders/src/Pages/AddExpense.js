import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import Header from "../Components/Header";
import axios from "axios";

const AddExpense = () => {
    const navigate = useNavigate();
    const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
  const [expense, setExpense] = useState({
    type: "",
    
    amount: "",
    description: "",
  });

  const [loading, setLoading] = useState(false);
/*   const [error, setError] = useState(null);
  const [successMessage, setSuccessMessage] = useState(""); */

  const handleChange = (e) => {
    setExpense({ ...expense, [e.target.name]: e.target.value });
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
  
    const payload = {
        type: expense.type,

      amount: expense.amount,     
      description: expense.description,        
    };
  
    console.log("Payload:", payload);
  
    try {
      const response = await fetch(`${API_BASE_URL}expense_add.php`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json",
        },
        body: JSON.stringify(payload),
      });
  
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
  
      const data = await response.json();
      // console.log("API Response:", data);
  
      if (data.head.code === 200) {
        alert("Expense added successfully!");
        navigate("/expenses"); // Redirect after success
      } else {
        alert("Failed to add Expense. Error: " + data.head.msg);
      }
    } catch (error) {
      console.error("Network/API Error:", error);
      alert("Failed To Add Expense");
    } finally {
      setLoading(false);
    }
  };
  
  

  return (
    <>
      <Header />
      <div className="page-wrapper compact-wrapper" id="pageWrapper">
        <div className="page-body-wrapper">
          <div className="page-body">
            <div className="container-fluid">
              <div className="row">
                <div className="col-12">
                  <div className="row">
                    <div className="col-sm-12 m-auto">
                      <div className="card">
                        <div className="card-body">
                          <div className="title-header option-title d-sm-flex d-block">
                            <h5>Add Expense</h5>
                            <div className="right-options">
                              <ul>
                                <li>
                                  <Link className="btn btn-solid" to="/expenses">Back</Link>
                                </li>
                              </ul>
                            </div>
                          </div>

                         {/*  {error && <div className="alert alert-danger">{error}</div>}
                          {successMessage && <div className="alert alert-success">{successMessage}</div>} */}

                          <form className="theme-form theme-form-2 mega-form" onSubmit={handleSubmit}>
                            <div className="mb-4 row align-items-center">
                              <label className="form-label-title col-sm-3 mb-0">Type</label>
                              <div className="col-sm-9">
                                <input
                                  className="form-control"
                                  type="text"
                                  name="type"
                                  value={expense.type}
                                  onChange={handleChange}
                                  required
                                  placeholder="Enter Type"
                                />
                              </div>
                            </div>
                            <div className="mb-4 row align-items-center">
                              <label className="form-label-title col-sm-3 mb-0">Amount</label>
                              <div className="col-sm-9">
                              <input
                                      className="form-control"
                                      type="text"
                                      name="amount"  // FIXED
                                      value={expense.amount}
                                      onChange={handleChange}
                                      placeholder="Enter Amount"
                                       
                                    />
                              </div>
                            </div>
                            <div className="mb-4 row align-items-center">
                              <label className="form-label-title col-sm-3 mb-0">Description</label>
                              <div className="col-sm-9">
                                <textarea
                                  rows="3"
                                  className="form-control"
                                  name="description"
                                  value={expense.description}
                                  onChange={handleChange}
                                  required
                                  placeholder="Enter Description"
                                ></textarea>
                              </div>
                            </div>
                            
                            
                            {/* <div className="mb-4 row align-items-center">
                              <label className="form-label-title col-sm-3 mb-0">GST Number</label>
                              <div className="col-sm-9">
                              <input
                                    className="form-control"
                                    type="text"
                                    name="gst_number"  // FIXED
                                    value={supplier.gst_number}
                                    onChange={handleChange}
                                    placeholder="Enter GST Number"
                                     maxLength="15"
                                  />
                              </div>
                            </div> */}
                            <div className="card-footer border-0 pb-0 d-flex justify-content-end">
                              <button className="btn btn-primary me-3" type="submit" disabled={loading}>
                                {loading ? "Submitting..." : "Submit"}
                              </button>
                              <button className="btn btn-outline" type="button" onClick={() => window.history.back()}>
                                Cancel
                              </button>
                            </div>
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default AddExpense;
