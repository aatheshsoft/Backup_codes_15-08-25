import React, { useEffect, useState } from "react";
import "./PrintSales.css";
import Logo from "../Assets/poongoditraders_logo.png";
import Image from "../Assets/lakshmi-icon.jpg";
import axios from "axios";

const PrintStock = () => {
  const [stockList, setStockList] = useState([]);
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

//   const formatDate = (dateStr) => {
  
//     if (!dateStr) return "";
//   const [year, month, day] = dateStr.split("-");
//   return `${day}/${month}/${year}`;
// };
//  const fromdate = localStorage.getItem("fromdate");
// const todate = localStorage.getItem("todate");
//   useEffect(() => {
//     const orderData = localStorage.getItem("filtersales");
 

// // console.log("From Date:", formatDate(fromdate));  
// // console.log("To Date:", formatDate(todate)); 

//     if (orderData) {
//       try {
//         const parsedData = JSON.parse(orderData);
//         setStockList(parsedData); // ✅ Store parsed array in state
//       } catch (e) {
//         console.error("Invalid JSON in localStorage:", e);
//       }
//     }
//   }, []);
  
useEffect(() => {
    axios
      .post(`${API_BASE_URL}pos_api/pos_report_stock.php`)
      .then((response) => {
        console.log("API Response:", response.data); // Debugging
        if (response.data.head.code === 200) {
          if (response.data.body.length > 0 && response.data.body[0].stock_report) {
            setStockList(response.data.body[0].stock_report);
            // setFilteredProducts(response.data.body[0].stock_report);
          } else {
            console.error("Stock report is missing in the response.");
          }
        } else {
          console.error("Error:", response.data.head.msg);
        }
      })
      .catch((error) => {
        console.error("API Error:", error);
      })
  }, []);
  useEffect(() => {
    if (stockList.length > 0) {
      setTimeout(() => {
        window.print();
      }, 300);
    }
  }, [stockList]);



  if (stockList.length === 0) {
    return <p>Please Wait Loading...</p>;
  }



  return (
    <div className="invoice-wrapper">
        <div className="position-relative mb-3">
                      {/* Row for logo + image */}
                      <div className="d-flex justify-content-between align-items-start px-2">
                        {/* Left Logo */}
                        <div>
                          <img
                            src={Logo}
                            alt="Poongodi Traders Logo"
                            style={{ maxWidth: "80px", height: "48px" }}
                          /> 
                        </div>
        
                        {/* Right Image */}
                        
                      
        
                      {/* Center Text */}
                      {/* {orderData && orderData.seller_detail && ( */}
                        <>
                      <div className="text-center mt-2 px-2" >
                        <h5 className="mb-1 fw-bold">Stock Details</h5>
                        <h5 className="mb-1 fw-bold">Poongodi Traders</h5>
                        <p className="mb-1">Door no.7/643Q, Kannan Complex, Kamrajapuram Colony,</p>
                        <p className="mb-1">
                          Sivakasi, Tamil Nadu - 626124
                        </p>
                        <p className="mb-1">Phone:  9786301208</p>
                        <p className="mb-1">GST No: 33AHEPV6120H1ZG</p>
                      </div>
                      </>
                      {/* )} */}
                      <div >
                          <img
                            src={Image}
                            alt="Lakshmi"
                            style={{ maxWidth: "50px", height: "55px", objectFit: "contain" }}
                          />
                        </div>
                    </div>
                    </div>
                    <hr />

      <div className="invoice-container">
        {/* { fromdate !== "" ? <p>From : { formatDate(fromdate)} - To : { formatDate(todate)}</p> : <p></p>} */}

        {/* <table className="invoice-table">
          <tbody>
            <tr>
              <td className="products-section"> */}
                <table className="product-table ">
                  <thead>
                    <tr>
                      <th>S.No</th>
                      <th>Product Code</th>
                      <th>Product Name</th>
                      <th style={{textAlign:"center"}}>Stock</th>
                      

                    </tr>
                  </thead>
                  <tbody>
                    {stockList.map((item, index) => (
                      <tr key={index}> 
                        <td>{index+1}</td>
                        <td>{item.product_code}</td>
                        <td>{item.product_name}</td>
                        <td style={{textAlign:"center"}}>{item.stock}</td>
                       
                      </tr>
                    ))}
                  </tbody>
                </table>
              {/* </td>
            </tr>
          </tbody>
        </table> */}
      </div>
    </div>
  );
};

export default PrintStock;
