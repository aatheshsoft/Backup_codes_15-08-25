import React from 'react';
import './App.css'
import { BrowserRouter, Route, Routes, Navigate, useLocation } from 'react-router-dom';
import SideBar from './Components/SideBar';
import Home from './Pages/Home';
import Customerlist from './Pages/Customerlist';
import OrderList from './Pages/OrderList';
import OrderDetails from './Pages/OrderDetails';
import BannerList from './Pages/BannerList';
import AddBanner from './Pages/AddBanner';
import Maincategory from './Pages/Maincategory';
import AddMaincategory from './Pages/AddMaincategory';
import SubCategory from './Pages/SubCategory';
import AddSubcategory from './Pages/AddSubcategory';
import Products from './Pages/Products';
import AddProducts from './Pages/AddProducts';
import Login from './Components/Login';
import Settings from './Components/Settings';
import Users from './Components/Users';
import Previlage from './Components/Previlage';
import Addusers from './Components/Addusers';
import Stock from './Pages/Stock';
import Brand from './Pages/Brand';
import AddBrand from './Pages/AddBrand';
import CanceOrder from './Pages/CanceOrder';
import CancelOrderDetails from './Pages/CancelOrderDetails';
import EditMaincategory from './Pages/EditMaincategory';
import EditSubcategory from './Pages/EditSubcategory';
import EditProducts from './Pages/EditProducts';
import EditBrand from './Pages/EditBrand';
import Content from './Components/Content';
import ContentEdit from './Components/ContentEdit';
import ViewCustomer from './Pages/ViewCustomer';
import Editusers from './Components/Editusers';
import Invoice from './Pages/Invoice';
import Pos from './Pages/Pos';
import CustomOrderList from './Pages/CustomOrderLIst';
import CustomOrderDetails from './Pages/CustomOrderDetails';
import EditBanner from './Pages/EditBanner';
import Footer from './Components/Footer'
import PaymenyPending from './Pages/PaymenyPending';
import InvoicePrint from './Components/InvoicePrint';
import PurchaseList from './Pages/PurchaseList';
import AddPurchase from './Pages/AddPurchase';
import EditPurchase from './Pages/EditPurchase';
import ImportProducts from './Components/ImportProducts';
import ImportCustomer from './Pages/ImportCustomer';
import AddCustomer from './Pages/AddCustomer';
import GstReport from './Pages/GstReport';
import { matchPath } from 'react-router-dom';
import Unit from './Pages/Unit';
import AddUnit from './Pages/AddUnit';
import EditUnit from './Pages/EditUnit';
import Supplier from './Pages/Supplier';
import AddSupplier from './Pages/AddSupplier';
import EditSupplier from './Pages/EditSupplier';
import PurchaseDetails from './Pages/PurchaseDetails';

const AppLayout = () => {
    const location = useLocation();
    const isLoginPage = location.pathname === '/login';
    const isInvoicePage = matchPath("/invoice/:order_id", location.pathname);
    const isPosPage = location.pathname === "/pos"; 
    const isInvoicePrintPage = location.pathname === "/invoiceprint";

    return (
        <div>
            {!isLoginPage &&!isInvoicePage && !isPosPage && !isInvoicePrintPage &&  <SideBar />}
            <Routes>
                <Route path="/" element={<Navigate to="/login" />} />
                <Route path="/login" element={<Login />} />
                <Route path="/home" element={<Home />} />
                <Route path="/customerlist" element={<Customerlist />} />
                <Route path="/orderlist" element={<OrderList />} />
                <Route path="/orderdetails/:order_id" element={<OrderDetails />} />
                <Route path="/bannerlist" element={<BannerList />} />
                <Route path="/addbanner" element={<AddBanner />} />
                <Route path="/editbanner/:banner_id" element={<EditBanner />} />
                <Route path="/maincategory" element={<Maincategory />} />
                <Route path="/addmaincategory" element={<AddMaincategory />} />
                <Route path="/subcategory/:category_id" element={<SubCategory />} />
                <Route path="/addsubcategory" element={<AddSubcategory />} />
                <Route path="/products" element={<Products />} />   
                <Route path="/addproducts" element={<AddProducts />} />
                <Route path="/settings" element={<Settings />} />
                <Route path="/users" element={<Users />} />
                <Route path="/previlage/:employee_id" element={<Previlage />} />
                <Route path="/addusers" element={<Addusers />} />
                <Route path="/editusers/:user_id" element={<Editusers />} />
                <Route path="/stock" element={<Stock />} />
                <Route path="/gstreport" element = {<GstReport />} />
                <Route path="/brand" element ={<Brand />} />
                <Route path="/editbrand/:brand_id" element ={<EditBrand />} />
                <Route path="/addbrand" element = {<AddBrand />} />
                <Route path="/editmaincategory/:category_id" element = {<EditMaincategory />} />
                <Route path="/editsubcategory/:subcategory_id" element = {<EditSubcategory />} />
                <Route path="/editproducts/:product_id" element = {<EditProducts />} />
                <Route path="/cancelorder" element = {<CanceOrder />} />
                <Route path="/cancelorderdetails/:order_id" element = {<CancelOrderDetails />} />
                <Route path="/content" element = {<Content />} />
                <Route path="/contentedit" element = {<ContentEdit />} />
                <Route path="/viewcustomer/:user_id" element = {<ViewCustomer />} />
                <Route path="/invoice/:order_id" element = {<Invoice />} />
                <Route path="/customorderlist/:user_id" element = {<CustomOrderList />} />
                <Route path="/customorderdetails/:order_id" element = {<CustomOrderDetails />} />\
                <Route path="/pos" element = {<Pos />} />
                <Route path="/paymentpending" element = {<PaymenyPending />} />
                <Route path="/invoiceprint" element = {<InvoicePrint />} />
                <Route path="/purchaselist" element = {<PurchaseList />} /> 
                <Route path="/addpurchase" element = {<AddPurchase />} />             
                <Route path="/editpurchase/:purchase_id" element = {<EditPurchase />} />
                <Route path="/importproducts" element = {<ImportProducts />} />
                <Route path="/importcustomer" element = {<ImportCustomer />} />
                <Route path="/addcustomer" element = {<AddCustomer />} />
                <Route path="/unit" element ={<Unit />} />
                <Route path="/addunit" element={<AddUnit />} />
                <Route path="/editunit/:unit_id" element={<EditUnit />} />
                <Route path="/supplier" element={<Supplier />} />
                <Route path="/addsupplier" element={<AddSupplier />} />
                <Route path="/editsupplier/:id" element={<EditSupplier />} />
                <Route path="/purchasedetails/:order_id" element={<PurchaseDetails />} />
            </Routes>
            {!isLoginPage &&!isInvoicePage && !isPosPage && !isInvoicePrintPage &&  <Footer />}
        </div>
    );
};

const App = () => {
    return (
        <BrowserRouter>
            <AppLayout />
        </BrowserRouter>
    );
};

export default App;
