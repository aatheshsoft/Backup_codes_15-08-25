import React, { useState, useEffect } from "react";
import Header from "../Components/Header";
import { Link, useNavigate, useParams } from "react-router-dom";
import axios from "axios";

const EditProducts = () => {
  const navigate = useNavigate();
  const { product_id } = useParams();
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
  const [unit, setUnit] = useState([]);

  const [products, setProducts] = useState({
    product_code: "",
    product_name: "",
    box_content: "",
    rate_per: "",
    brand_id: "",
    category_id: "",
    stock: "",
    buy_price: "",
    sell_price: "",
    tax: "",
    unit: "",
    supplier_id:"",
    supplier_name:"",
    
  });

  const [categories, setCategories] = useState([]);
  const [brands, setBrands] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("");
  const [selectedBrand, setSelectedBrand] = useState("");
  const [supplier, setSupplier] =  useState([]);
  const [selectedsupplier, setSelectedSupplier] = useState("");



  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await axios.post(
          `${API_BASE_URL}product_detail.php`,
          { product_id }
        );

        if (response.data && response.data.body) {
          const productData = response.data.body;
          setProducts(productData);
          setSelectedCategory(productData.category_id);
          setSelectedBrand(productData.brand_id);
          setSelectedSupplier(productData.supplier_id);
        } else {
          setError("No data found");
        }
      } catch (error) {
        setError("Failed to fetch data");
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();

    axios
      .post(`${API_BASE_URL}category_list.php`)
      .then((res) => setCategories(res.data.body || []))
      .catch((err) => console.error("Category fetch error:", err));
      axios
      .post(`${API_BASE_URL}supplier_list.php`)
      .then((res) => setSupplier(res.data.body || []))
      .catch((err) => console.error("Category fetch error:", err));
    axios
      .post(`${API_BASE_URL}brand_list.php`)
      .then((res) => setBrands(res.data.body || []))
      .catch((err) => console.error("Brand fetch error:", err));
  }, [product_id]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setProducts((prev) => ({ ...prev, [name]: value }));
  };

  const handleUpdate = async (event) => {
    event.preventDefault();

    try {
      const response = await axios.post(
        `${API_BASE_URL}product_detail_update.php`,
        { product_id, ...products }
      );

      if (response.data.head.code === 200) {
        alert("Product updated successfully!");
        navigate("/products");
      } else {
        alert("Update failed: " + response.data.head.msg);
      }
    } catch (error) {
      alert("Failed to update product.");
    }
  };
  useEffect(() => {
    axios.post(`${API_BASE_URL}unit_list.php`)
      .then((response) => {
        if (response.data.head.code === 200) {
          setUnit(response.data.body); // Store units in state
        } else {
          console.error("Error fetching units:", response.data.head.msg);
        }
      })
      .catch((error) => {
        console.error("API Error:", error);
      });
  }, []);
  if (loading) return <p> </p>;
  if (error) return <p className="text-danger">{error}</p>;

  return (
    <>
      <Header />
      <div className="page-wrapper compact-wrapper" id="pageWrapper">
        <div className="page-body-wrapper">
          <div className="page-body">
            <div className="container-fluid">
              <div className="row">
                <div className="col-12">
                  <div className="card">
                    <div className="card-body">
                      <div className="title-header option-title d-sm-flex d-block">
                        <h5>Edit Product</h5>
                        <div className="right-options">
                          <ul>
                            <li>
                              <Link
                                className="btn btn-solid"
                                onClick={() => window.history.back()}
                              >
                                Back
                              </Link>
                            </li>
                          </ul>
                        </div>
                      </div>

                      <form className="theme-form theme-form-2 mega-form" onSubmit={handleUpdate}>
                                  <div className="row">
                                    {/* Product Code */}
                                    <div className="col-md-6">
                                      <div className="mb-4">
                                        <label>Product Code</label>
                                        <input
                                          className="form-control"
                                          name="product_code"
                                          type="text"
                                          placeholder="Enter Product Code"
                                          value={products.product_code || ""}
                                          onChange={handleInputChange}
                                        />
                                      </div>
                                    </div>

                                    {/* Product Name */}
                                    <div className="col-md-6">
                                      <div className="mb-4">
                                        <label>Product Name</label>
                                        <input
                                          required
                                          className="form-control"
                                          type="text"
                                          name="product_name"
                                          placeholder="Enter Product Name"
                                          value={products.product_name || ""}
                                          onChange={handleInputChange}
                                        />
                                      </div>
                                    </div>

                                    {/* First row with four columns */}
                                    <div className="col-md-3 col-sm-6">
                                      <div className="mb-4">
                                        <label>Box Content</label>
                                        <input
                                          className="form-control"
                                          type="text"
                                          name="box_content"
                                          placeholder="Enter Box Content"
                                          value={products.box_content || ""}
                                          onChange={handleInputChange}
                                        />
                                      </div>
                                    </div>

                                    <div className="col-md-3 col-sm-6">
                                      <div className="mb-4">
                                        <label>Stock</label>
                                        <input
                                          className="form-control"
                                          type="text"
                                          name="stock"
                                          placeholder="Enter Stock"
                                          value={products.stock || ""}
                                          onChange={handleInputChange}
                                        />
                                      </div>
                                    </div>

                                    <div className="col-md-3 col-sm-6">
                                        <div className="mb-4">
                                          <label>Unit</label>
                                          <select
                                            className="form-select"
                                            name="unit"
                                            value={products.unit || ""}
                                            onChange={handleInputChange}
                                          >
                                            <option value="">Select Unit</option>
                                            {unit.map((unit) => (
                                              <option key={unit.unit_id} value={unit.unit_name}>
                                                {unit.unit_name}
                                              </option>
                                            ))}
                                          </select>
                                        </div>
                                      </div>

                                    {/* <div className="col-md-3 col-sm-6">
                                      <div className="mb-4">
                                        <label>Brand</label>
                                        <select
                                          className="form-select"
                                          name="brand_id"
                                          value={selectedBrand}
                                          onChange={(e) => {
                                            setSelectedBrand(e.target.value);
                                            setProducts((prev) => ({
                                              ...prev,
                                              brand_id: e.target.value,
                                            }));
                                          }}
                                        >
                                          <option value="">Select Brand</option>
                                          {brands.map((brand) => (
                                            <option key={brand.brand_id} value={brand.brand_id}>
                                              {brand.brand_name}
                                            </option>
                                          ))}
                                        </select>
                                      </div>
                                    </div> */}

                                    {/* Second row with four columns */}
                                    <div className="col-md-3 col-sm-6">
                                      <div className="mb-4">
                                        <label>Category</label>
                                        <select
                                          className="form-select"
                                          name="category_id"
                                          value={selectedCategory}
                                          onChange={(e) => {
                                            setSelectedCategory(e.target.value);
                                            setProducts((prev) => ({
                                              ...prev,
                                              category_id: e.target.value,
                                            }));
                                          }}
                                        >
                                          <option value="">Select Category</option>
                                          {categories.map((category) => (
                                            <option key={category.category_id} value={category.category_id}>
                                              {category.category_name}
                                            </option>
                                          ))}
                                        </select>
                                      </div>
                                    </div>

                                    {/* <div className="col-md-3 col-sm-6">
                                      <div className="mb-4">
                                        <label>GST (%)</label>
                                        <input
                                          className="form-control"
                                          type="text"
                                          name="tax"
                                          placeholder="0"
                                          value={products.tax || ""}
                                          onChange={handleInputChange}
                                        />
                                      </div>
                                    </div> */}

                                    <div className="col-md-3 col-sm-6">
                                      <div className="mb-4">
                                        <label>Rate</label>
                                        <input
                                          className="form-control"
                                          type="text"
                                          name="buy_price"
                                          placeholder="0"
                                          value={products.buy_price || ""}
                                          onChange={handleInputChange}
                                        />
                                      </div>
                                    </div>

                                    <div className="col-md-3 col-sm-6">
                                      <div className="mb-4">
                                        <label>Rate Per</label>
                                        <input
                                          className="form-control"
                                          type="text"
                                          name="rate_per"
                                          placeholder="Enter Rate Per"
                                          value={products.rate_per || ""}
                                          onChange={handleInputChange}
                                        />
                                      </div>
                                    </div>
                                    <div className="col-md-3 col-sm-6 mb-4">
                                                  <label className="form-label-title">Supplier Name</label>
                                                  <select
                                                    className="form-control"
                                                    name="supplier_id"
                                                    value={selectedsupplier} // Ensure correct binding
                                                    onChange={(e) => {
                                                      const selectedId = e.target.value;
                                                      
                                                      // Find the supplier object using supplier_id
                                                      const selectedSupplier = supplier.find((sup) => String(sup.id) === String(selectedId));

                                                      if (selectedSupplier) {
                                                        setSelectedSupplier(selectedSupplier.supplier_id); // ✅ Store correct supplier_id
                                                        setProducts((prev) => ({
                                                          ...prev,
                                                          supplier_id: selectedSupplier.id, // ✅ Ensure supplier_id is stored correctly
                                                          supplier_name: selectedSupplier.supplier_name, // ✅ Dynamically store supplier_name
                                                        }));
                                                      }
                                                    }}
                                                    required
                                                  >
                                                    <option value="">Select Supplier</option>
                                                    {supplier.map((sup) => (
                                                      <option key={sup.id} value={sup.id}>
                                                        {sup.supplier_name}
                                                      </option>
                                                    ))}
                                                  </select>
                                                </div>

                                  </div>

                                  {/* Submit and Cancel Buttons */}
                                  <div className="d-flex justify-content-end">
                                    <button className="btn btn-primary me-3" type="submit">
                                      Submit
                                    </button>
                                    <button
                                      className="btn btn-outline"
                                      type="button"
                                      onClick={() => window.history.back()}
                                    >
                                      Cancel
                                    </button>
                                  </div>
                                </form>

                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default EditProducts;
