import React, { useState, useEffect } from "react";
import Header from "../Components/Header";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const AddProducts = () => {
  const navigate = useNavigate();
  const [categories, setCategories] = useState([]);
  const [supplier, setSupplier] =  useState([]);
  const [brands, setBrands] = useState([]);
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
  const [unit, setUnit] = useState([]);
  const [formData, setFormData] = useState({
    cid: "",
    supplier_id:"",
    brand_id: "",
    product_name: "",
    product_code: "",
    box_content: "",
    rate_per: "",
    stock: "",
    tax: "" || 0,
    buy_price: "",
    sell_price: "",
    unit: "",
    supplier_name:"",
  });

  // Fetch Categories & Brands
  useEffect(() => {
    axios
      .post(`${API_BASE_URL}category_list.php`)
      .then((res) => setCategories(res.data.body || []))
      .catch((err) => console.error("Category fetch error:", err));
      axios
      .post(`${API_BASE_URL}supplier_list.php`)
      .then((res) => setSupplier(res.data.body || []))
      .catch((err) => console.error("Category fetch error:", err));
    axios
      .post(`${API_BASE_URL}brand_list.php`)
      .then((res) => setBrands(res.data.body || []))
      .catch((err) => console.error("Brand fetch error:", err));
  }, []);
  console.log(brands);

  // Handle input change
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevState) => ({ ...prevState, [name]: value }));
  };

  // Handle Form Submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const updatedFormData = { ...formData };

      console.log("Sending Data:", updatedFormData);

      const response = await axios.post(
        `${API_BASE_URL}product_add.php`,
        updatedFormData,
        { headers: { "Content-Type": "application/json" } }
      );

      if (response.data.head.code === 200) {
        alert("Product added successfully!");
        navigate("/products");
      } else {
        alert(response.data.head.msg);
      }
    } catch (error) {
      console.error("Error adding product:", error);
      alert("Failed to add product");
    }
  };

  useEffect(() => {
    axios.post(`${API_BASE_URL}unit_list.php`)
      .then((response) => {
        if (response.data.head.code === 200) {
          setUnit(response.data.body); // Store units in state
        } else {
          console.error("Error fetching units:", response.data.head.msg);
        }
      })
      .catch((error) => {
        console.error("API Error:", error);
      });
  }, []);

  return (
    <>
      <Header />
      <div className="page-wrapper compact-wrapper" id="pageWrapper">
        <div className="page-body-wrapper">
          <div className="page-body">
            <div className="container-fluid">
              <div className="row">
                <div className="col-12">
                  <div className="row">
                    <div className="col-sm-12 m-auto">
                      <div className="card">
                        <div className="card-body">
                          <div className="title-header option-title d-sm-flex d-block">
                            <h5>Add Product</h5>
                            <div className="right-options">
                              <ul>
                                <li>
                                  <button
                                    className="btn btn-solid"
                                    onClick={() => window.history.back()}
                                  >
                                    Back
                                  </button>
                                </li>
                              </ul>
                            </div>
                          </div>

                          <form
                            className="theme-form theme-form-2 mega-form"
                            onSubmit={handleSubmit}
                          >
                            <div className="row">
                              {/* Product Code */}
                              <div className="col-md-6 mb-4">
                                <label className="form-label-title">
                                  Product Code
                                </label>
                                <input
                                  required
                                  className="form-control"
                                  name="product_code"
                                  type="text"
                                  placeholder="Enter Product Code"
                                  onChange={handleChange}
                                />
                              </div>

                              {/* Product Name */}
                              <div className="col-md-6 mb-4">
                                <label className="form-label-title">
                                  Product Name
                                </label>
                                <input
                                  required
                                  className="form-control"
                                  type="text"
                                  name="product_name"
                                  placeholder="Enter Product Name"
                                  onChange={handleChange}
                                />
                              </div>

                              {/* Other Inputs (4 per row) */}

                              <div className="col-md-3 col-sm-6 mb-4">
                                <label className="form-label-title">
                                  Box Content
                                </label>
                                <input
                                  className="form-control"
                                  type="text"
                                  name="box_content"
                                  placeholder="Enter Box Content"
                                  onChange={handleChange}
                                />
                              </div>
                              <div className="col-md-3 col-sm-6 mb-4">
                                <label className="form-label-title">
                                  Stock
                                </label>
                                <input
                                  className="form-control"
                                  type="text"
                                  name="stock"
                                  placeholder="Enter Stock"
                                  onChange={handleChange}
                                />
                              </div>
                              <div className="col-md-3 col-sm-6 mb-4">
                                  <label className="form-label-title">Unit</label>
                                  <select
                                    className="form-control"
                                    name="unit"
                                    value={formData.unit}
                                    onChange={handleChange}
                                    required
                                  >
                                    <option value="">Select Unit</option>
                                    {unit.map((unit) => (
                                      <option key={unit.unit_id} value={unit.unit_name}>
                                        {unit.unit_name}
                                      </option>
                                    ))}
                                  </select>
                                </div>
                              {/* <div className="col-md-3 col-sm-6 mb-4">
                                <label className="form-label-title">
                                  Brand
                                </label>
                                <select
                                  className="form-control"
                                  name="brand_id"
                                  onChange={handleChange}
                                  required
                                >
                                  <option value="">Select Brand</option>
                                  {brands.map((brand) => (
                                    <option
                                      key={brand.brand_id}
                                      value={brand.brand_id}
                                    >
                                      {brand.brand_name}
                                    </option>
                                  ))}
                                </select>
                              </div> */}

                              <div className="col-md-3 col-sm-6 mb-4">
                                <label className="form-label-title">
                                  Category
                                </label>
                                <select
                                  className="form-control"
                                  name="cid"
                                  onChange={handleChange}
                                  required
                                >
                                  <option value="">Select Category</option>
                                  {categories.map((cat) => (
                                    <option
                                      key={cat.category_id}
                                      value={cat.category_id}
                                    >
                                      {cat.category_name}
                                    </option>
                                  ))}
                                </select>
                              </div>
                              {/* <div className="col-md-3 col-sm-6 mb-4">
        <label className="form-label-title">GST (%)</label>
        <input
          className="form-control"
          type="text"
          name="tax"
          placeholder="0"
          onChange={handleChange}
        />
      </div> */}
                              <div className="col-md-3 col-sm-6 mb-4">
                                <label className="form-label-title">Rate</label>
                                <input
                                  className="form-control"
                                  type="text"
                                  name="buy_price"
                                  placeholder="0"
                                  onChange={handleChange}
                                />
                              </div>
                              <div className="col-md-3 col-sm-6 mb-4">
                                <label className="form-label-title">
                                  Rate Per
                                </label>
                                <input
                                  className="form-control"
                                  type="text"
                                  name="rate_per"
                                  placeholder="Enter Rate Per"
                                  onChange={handleChange}
                                />
                              </div>
                              <div className="col-md-3 col-sm-6 mb-4">
                                <label className="form-label-title">
                                  Supplier Name
                                </label>
                                <select
                                  className="form-control"
                                  name="supplier_id"
                                  onChange={handleChange}
                                  required
                                >
                                  <option value="">Select Supplier</option>
                                  {supplier.map((supplier) => (
                                    <option
                                      key={supplier.id}
                                      value={supplier.id}
                                    >
                                      {supplier.supplier_name}
                                    </option>
                                  ))}
                                </select>
                              </div>
                            </div>

                            {/* Buttons */}
                            <div className="card-footer border-0 pb-0 d-flex justify-content-end">
                              <button
                                className="btn btn-primary me-3"
                                type="submit"
                              >
                                Submit
                              </button>
                              <button
                                className="btn btn-outline"
                                onClick={() => window.history.back()}
                              >
                                Cancel
                              </button>
                            </div>
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default AddProducts;
