import React, { useState, useEffect } from 'react';
import { useNavigate } from "react-router-dom";
import axios from 'axios';
import Header from "../Components/Header";
import { Link } from "react-router-dom";

const AddBrand = () => {
  const [brandName, setBrandName] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const [categories, setCategories] = useState([]);
  const navigate = useNavigate();
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

  // Fetch categories from API
  useEffect(() => {
    axios.post(`${API_BASE_URL}category_list.php`)
      .then(response => {
        if (response.data.head.code === 200) {
          setCategories(response.data.body);
        } else {
          console.error("Error fetching categories:", response.data.head.msg);
        }
      })
      .catch(error => console.error("API Error:", error));
  }, []);



  const handleSubmit = (event) => {
    event.preventDefault();
    
    if (!brandName || !categoryId) {
      alert("Please enter Brand Name and select Category.");
      return;
    }

    const formData = {
      category_id: categoryId,
      brand_name: brandName
    };
console.log(formData);
    axios.post(`${API_BASE_URL}brand_add.php`, formData, {
      headers: { 'Content-Type': 'application/json' }
    })
      .then(response => {
        console.log("Response:", response.data);
        if (response.data.head.code === 200) {
          alert("Brand added successfully!");
          navigate('/brand'); // Redirect after success
        } else {
          alert( response.data.head.msg);
        }
      })
      .catch(error => {
        console.error("API Error:", error);
        alert("Failed to add brand.");
      });
  };

  return (
    <>
      <Header />
      <div className="page-wrapper compact-wrapper" id="pageWrapper">
        <div className="page-body-wrapper">
          <div className="page-body">
            <div className="container-fluid">
              <div className="row">
                <div className="col-12">
                  <div className="row">
                    <div className="col-sm-12 m-auto">
                      <div className="card">
                        <div className="card-body">
                          <div className="title-header option-title d-sm-flex d-block">
                            <h5>Add Brand Name</h5>
                            <div className="right-options">
                              <ul>
                                <li>
                                  <Link className="btn btn-solid" to="/brand">
                                    Back
                                  </Link>
                                </li>
                              </ul>
                            </div>
                          </div>

                          <form className="theme-form theme-form-2 mega-form" onSubmit={handleSubmit}>
                            <div className="mb-4 row align-items-center">
                              <label className="form-label-title col-sm-3 mb-0">Type of Category</label>
                              <div className="col-sm-9">
                                <select
                                  className="js-example-basic-single w-100 form-control"
                                  name="category_id"
                                  value={categoryId}
                                  onChange={(e) => setCategoryId(e.target.value)}
                                  required
                                >
                                  <option value="">Select Type</option>
                                  {categories.map((category) => (
                                    <option key={category.category_id} value={category.category_id}>
                                      {category.category_name}
                                    </option>
                                  ))}
                                </select>
                              </div>
                            </div>

                            <div className="mb-4 row align-items-center">
                              <label className="form-label-title col-sm-3 mb-0">Brand Name:</label>
                              <div className="col-sm-9">
                                <input
                                  className="form-control"
                                  type="text"
                                  name="brand_name"
                                  value={brandName}
                                  onChange={(e) => setBrandName(e.target.value)}
                                  placeholder="Enter Brand Name"
                                  required
                                />
                              </div>
                            </div>

                            <div className="card-footer border-0 pb-0 d-flex justify-content-end">
                              <button type="submit" className="btn btn-primary me-3">Submit</button>
                              <button type="button" className="btn btn-outline" onClick={() => window.history.back()} >Cancel</button>
                            </div>
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default AddBrand;
