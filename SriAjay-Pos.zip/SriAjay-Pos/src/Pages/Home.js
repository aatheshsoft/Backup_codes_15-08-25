import React, { useEffect, useState } from 'react';
import Header from '../Components/Header';
import axios from 'axios';

const Home = () => {
    const [homedata, setHomeData] = useState({}); 
    const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;


    useEffect(() => {
        axios.post(`${API_BASE_URL}dashboard.php`)
        .then((response) => {
            if (response.data.head.code === 200) {
                setHomeData(response.data.body);
            } else {
                console.error("Error Fetching Data", response.data.head.msg);
            }
        })
        .catch((error) => {
            console.error("API Error:", error);
        });
    }, []); 



    return (
        <>
        <Header/>
        <div class="page-wrapper compact-wrapper" id="pageWrapper">
        <div class="page-body-wrapper">
        <div class="page-body">
            <div class="container-fluid">
                <div class="row">

                    <div class="col-sm-6 col-xxl-3 col-lg-6">
                        <div class="main-tiles border-5 border-0 card-hover card o-hidden">
                            <div class="custome-3-bg b-r-4 card-body">
                                <div class="media align-items-center static-top-widget">
                                    <div class="media-body p-0">
                                        <span class="m-0">Total Revenue</span>
                                        <h4 class="mb-0 counter">
                                            <i class="fas fa-rupee-sign"></i>: {homedata.total_revenue || 0} 
                                            <span class="badge badge-light-primary grow">
                                                <i data-feather="trending-up"></i>8.5%
                                            </span>
                                        </h4>
                                    </div>
                                    <div class="align-self-center text-center">
                                        <i class="ri-coin-fill"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-6 col-xxl-3 col-lg-6">
                        <div class="main-tiles border-5 card-hover border-0 card o-hidden">
                            <div class="custome-2-bg b-r-4 card-body">
                                <div class="media static-top-widget">
                                    <div class="media-body p-0">
                                        <span class="m-0">Total Orders</span>
                                        <h4 class="mb-0 counter">
                                            {homedata.total_order || 0}
                                        </h4>
                                    </div>
                                    <div class="align-self-center text-center">
                                        <i class="ri-coin-fill"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-6 col-xxl-3 col-lg-6">
                        <div class="main-tiles border-5 card-hover border-0 card o-hidden">
                            <div class="custome-3-bg b-r-4 card-body">
                                <div class="media static-top-widget">
                                    <div class="media-body p-0">
                                        <span class="m-0">Total Products</span>
                                        <h4 class="mb-0 counter">{homedata.total_product || 0}</h4>
                                    </div>
                                    <div class="align-self-center text-center">
                                        <i class="ri-shopping-cart-fill"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-6 col-xxl-3 col-lg-6">
                        <div class="main-tiles border-5 card-hover border-0 card o-hidden">
                            <div class="custome-4-bg b-r-4 card-body">
                                <div class="media static-top-widget">
                                    <div class="media-body p-0">
                                        <span class="m-0">Total Customers</span>
                                        <h4 class="mb-0 counter">{homedata.total_customer || 0}</h4>
                                    </div>
                                    <div class="align-self-center text-center">
                                        <i class="ri-user-add-line"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        </div>
        </div>
        
        </>
    );
};

export default Home;
