import React, { useEffect, useState } from "react";
import Header from "../Components/Header";
import { Link, useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import Skeleton from "react-loading-skeleton";
import "react-loading-skeleton/dist/skeleton.css";

const EditMaincategory = () => {
  const { category_id } = useParams();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [categoryData, setCategoryData] = useState({
    type_of_category: "",
    category_name: "",
  });
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

  // Fetch category details on mount
  useEffect(() => {
    if (!category_id) return;

    console.log("Fetching data for category_id:", category_id);
    setLoading(true);

    axios
      .post(`${API_BASE_URL}category_detail.php`, {
        category_id: category_id,
      })
      .then((response) => {
        console.log("API Response:", response.data);
        if (response.data.head.code === 200) {
          const categoryDetails = response.data.body;
          setCategoryData({
            // type_of_category: categoryDetails.type_of_category || "",
            category_name: categoryDetails.category_name || "",
          });
        } else {
          alert(response.data.head?.msg || "Failed to fetch category details");
        }
      })
      .catch((error) => {
        console.error("Error fetching category details:", error);
      })
      .finally(() => setLoading(false));
  }, [category_id]);




  // Handle form field changes
  const handleChange = (e) => {
    setCategoryData({ ...categoryData, [e.target.name]: e.target.value });
  };



  
  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();

    if (!categoryData.category_name) {
      alert("Please fill in all fields before submitting.");
      return;
    }

    console.log("Submitting data:", categoryData);

    axios
      .post(`${API_BASE_URL}category_detail_update.php`, {
        category_id: category_id,
        category_name: categoryData.category_name,
        type_of_category: categoryData.type_of_category,
      })
      .then((response) => {
        console.log("Update Response:", response.data);
        if (response.data.head.code === 200) {
          alert("Category updated successfully!");
          navigate("/maincategory"); // Redirect after update
        } else {
          alert(response.data.head?.msg || "Failed to update category");
        }
      })
      .catch((error) => {
        console.error("Error updating category:", error);
        alert("An error occurred while updating. Please try again.");
      });
  };

  return (
    <>
      <Header />
      <div className="page-wrapper compact-wrapper" id="pageWrapper">
        <div className="page-body-wrapper">
          <div className="page-body">
            <div className="container-fluid">
              <div className="row">
                <div className="col-12">
                  <div className="row">
                    <div className="col-sm-12 m-auto">
                      <div className="card">
                        <div className="card-body">
                          <div className="title-header option-title d-sm-flex d-block">
                            <h5>Edit Main Category</h5>
                            <div className="right-options">
                              <ul>
                                <li>
                                  <Link className="btn btn-solid" to="/maincategory">
                                    Back
                                  </Link>
                                </li>
                              </ul>
                            </div>
                          </div>

                          <form className="theme-form theme-form-2 mega-form" onSubmit={handleSubmit}>
                            {loading ? (
                              <>
                                {/* Skeleton Loader for Type of Category */}
                                <div className="mb-4 row align-items-center">
                                  <label className="form-label-title col-sm-3 mb-0">
                                    <Skeleton width={120} height={20} />
                                  </label>
                                  <div className="col-sm-9">
                                    <Skeleton height={40} />
                                  </div>
                                </div>

                                {/* Skeleton Loader for Main Category */}
                                <div className="mb-4 row align-items-center">
                                  <label className="form-label-title col-sm-3 mb-0">
                                    <Skeleton width={120} height={20} />
                                  </label>
                                  <div className="col-sm-9">
                                    <Skeleton height={40} />
                                  </div>
                                </div>

                                {/* Skeleton Loader for Buttons */}
                                <div className="card-footer border-0 pb-0 d-flex justify-content-end">
                                  <Skeleton width={100} height={40} />
                                  <Skeleton width={100} height={40} style={{ marginLeft: "10px" }} />
                                </div>
                              </>
                            ) : (
                              <>
                                {/* Type of Category Field */}
                               {/*  <div className="mb-4 row align-items-center">
                                  <label className="form-label-title col-sm-3 mb-0">Type of Category</label>
                                  <div className="col-sm-9">
                                    <select
                                      className="js-example-basic-single w-100"
                                      name="type_of_category"
                                      value={categoryData.type_of_category}
                                      onChange={handleChange}
                                    >
                                      <option value="">Select Type</option>
                                      <option>Home Appliances</option>
                                      <option>Kitchen Appliances</option>
                                      <option>Accessories</option>
                                      <option>Electronics</option>
                                    </select>
                                  </div>
                                </div> */}

                                {/* Main Category Field */}
                                <div className="mb-4 row align-items-center">
                                  <label className="form-label-title col-sm-3 mb-0">Main Category</label>
                                  <div className="col-sm-9">
                                    <input
                                      className="form-control"
                                      type="text"
                                      name="category_name"
                                      autoComplete="off"
                                      value={categoryData.category_name}
                                      placeholder="Enter Main Category"
                                      onChange={handleChange}
                                    />
                                  </div>
                                </div>

                                {/* Buttons */}
                                <div className="card-footer border-0 pb-0 d-flex justify-content-end">
                                  <button className="btn btn-primary me-3" type="submit">
                                    Submit
                                  </button>
                                  <button
                                    className="btn btn-outline"
                                    type="button"
                                    onClick={() => navigate("/maincategory")}
                                  >
                                    Cancel
                                  </button>
                                </div>
                              </>
                            )}
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default EditMaincategory;
