import axios from "axios";
import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

const Invoice = () => {
const[orderData, setOrderData]= useState(null);
const { order_id } = useParams();
const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

const [totalAmount, setTotalAmount] = useState(0);
const[grandtotal, setGrandTotal] = useState(0);
const [taxSummary, setTaxSummary] = useState({
  cgst: 0,
  sgst: 0,
  packing_charge: 0,
  totalTax: 0,
  
});


useEffect(() => {
  const fetchOrderDetails = async () => {
    try {
      const response = await axios.post(`${API_BASE_URL}print_detail.php`, { order_id });

      if (response.data.head.code === 200) {
        const data = response.data.body;
        setOrderData(data);

        const subtotal = parseFloat(data.final_billing?.[0]?.subtotal || 0);
        const cgst = parseFloat(data.final_billing?.[0]?.cgst || 0);
        const sgst = parseFloat(data.final_billing?.[0]?.sgst || 0);
        const packing = parseFloat(data.final_billing?.[0]?.packing_charge || 0);
        const gst_total = parseFloat(data.final_billing?.[0]?.gst_total || 0);
        const total = parseFloat(data.final_billing?.[0]?.total || 0);
        setTotalAmount(subtotal); // You may want to include packing here if needed
        setGrandTotal(total);
        setTaxSummary({
          cgst,
          sgst,
          packing_charge: packing,
          totalTax: gst_total,
        });
      } else {
        console.error("Failed to fetch order details");
      }
    } catch (err) {
      console.error("Error fetching data", err);
    }
  };

  fetchOrderDetails();
}, []);



// const bill_detail = orderData?.bill_detail || [];
// const final_billing = orderData?.final_billing || [];


// // Calculate bottom section totals
// let totalAmount = 0;

// bill_detail.forEach((item) => {
//   totalAmount += parseFloat(item.total_per_product) || 0;
  
// });

// let taxSummary = {};

// // final_billing.forEach((item) => {
// //   Object.keys(item).forEach((taxKey) => {
// //     if (item[taxKey] && typeof item[taxKey] === "object") {
// //       const gstRate = parseInt(taxKey.replace("tax", ""), 10); // Extract tax percentage (e.g., 12 from "tax12")

// //       if (!taxSummary[gstRate]) {
// //         taxSummary[gstRate] = {
// //           taxableValue: "",
// //           cgst: 0,
// //           sgst: 0,
// //           totalTax: "",
// //         };
// //       }

// //       taxSummary[gstRate].taxableValue += item[taxKey].without_gst || 0;
// //       taxSummary[gstRate].cgst += (item[taxKey].gst_amt || 0) / 2;
// //       taxSummary[gstRate].sgst += (item[taxKey].gst_amt || 0) / 2;
// //       taxSummary[gstRate].totalTax += item[taxKey].gst_amt || 0;
// //     }
// //   });
// // });

const numberToWords = (num) => {
  if (num === 0) return "Zero";

  const ones = [
    "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine",
    "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen",
    "Seventeen", "Eighteen", "Nineteen"
  ];
  const tens = [
    "", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"
  ];

  const convertBelowThousand = (n) => {
    if (n < 20) return ones[n];
    if (n < 100) return tens[Math.floor(n / 10)] + (n % 10 !== 0 ? " " + ones[n % 10] : "");
    return ones[Math.floor(n / 100)] + " Hundred" + (n % 100 !== 0 ? " and " + convertBelowThousand(n % 100) : "");
  };

  let integerPart = Math.floor(num); // Rupees
  let decimalPart = Math.round((num - integerPart) * 100); // Paise

  let result = "";

  // Convert Rupees
  if (integerPart > 0) {
    let crores = Math.floor(integerPart / 10000000);
    let lakhs = Math.floor((integerPart % 10000000) / 100000);
    let thousands = Math.floor((integerPart % 100000) / 1000);
    let hundreds = integerPart % 1000;

    if (crores) result += convertBelowThousand(crores) + " Crore ";
    if (lakhs) result += convertBelowThousand(lakhs) + " Lakh ";
    if (thousands) result += convertBelowThousand(thousands) + " Thousand ";
    if (hundreds) result += convertBelowThousand(hundreds);
  } else {
    result = "Zero";
  }

  result = result.trim();

  // Convert Paise if present
  if (decimalPart > 0) {
    result += ` and ${convertBelowThousand(decimalPart)} Paise`;
  }

  return result + " Only";
};


useEffect(() => {
  const waitForContentAndPrint = () => {
    const contentReady = document.readyState === 'complete';
    const hasContent = document.body && document.body.innerText.trim().length > 0;

    if (contentReady && hasContent) {
      if (window.flutter_inappwebview) {
        window.flutter_inappwebview.callHandler('onPrintRequest');
      } else {
        window.print();
      }
    } else {
      setTimeout(waitForContentAndPrint, 200); // Retry after delay
    }
  };

  const timer = setTimeout(waitForContentAndPrint, 2000);

  return () => clearTimeout(timer);
}, []);




if (!orderData || !orderData.final_billing) return null;



return (



    <div className="invoice-container" style={{
      width: "100%", 
      maxWidth: "100%", 
      margin: "auto", 
      padding: "10px",
      fontFamily: "Arial, sans-serif",
      // overflowX: "auto"
    }}>
    
      <h2 style={{ textAlign: "center", marginBottom: "10px",color:"black" }}>Tax Invoice</h2>
      <div style={{ display: "flex", justifyContent: "space-between", borderBottom: "1px solid black", paddingBottom: "10px" }}>
      <div>
    {orderData && orderData.seller_detail && (
    <>
      <strong>{orderData.seller_detail.shop_name}</strong>,
      <br />
      <strong>{orderData.seller_detail.gst_no}</strong>,
      <br />
      {orderData.seller_detail.address}
      <br />
      {orderData.seller_detail.city}
      <br />
      {orderData.seller_detail.state} - {orderData.seller_detail.pincode}
      <br />
      {orderData.seller_detail.phone}
      <br />
      
    </>
  )}
</div>

  {orderData ? (
          <div>
          <strong>Invoice No:</strong> {orderData.order_id}
          <br />
          <strong>Dated:</strong> {orderData.order_date}
          </div>
          ) : (
            <p> </p>
          )}

      </div>
      <div style={{ marginTop: "10px", borderBottom: "1px solid black", paddingBottom: "10px" }}>
      {orderData && orderData.buyer_detail && (
    <>
    <strong>Buyer (Bill to)</strong><br />
      <strong>{orderData.buyer_detail.name}</strong>,
      <br />
      {orderData.buyer_detail.tax_number}
      <br />
      {orderData.buyer_detail.address}
      <br />
      {orderData.buyer_detail.state}<br />
      {orderData.buyer_detail.telephone}
      <br />
      
    </>
  )}
      </div>
      
      <table style={{ width: "100%", borderCollapse: "collapse", marginTop: "10px" }}>
        <thead>
          <tr>
            <th style={{ border: "1px solid black", padding: "5px" }}>S No</th>
            <th style={{ border: "1px solid black", padding: "5px" }}>Description of Goods</th>
            <th style={{ border: "1px solid black", padding: "5px", textAlign: "center" }}>Rate</th>
            <th style={{ border: "1px solid black", padding: "5px", textAlign: "center" }}>Quantity</th>
            <th style={{ border: "1px solid black", padding: "5px", textAlign: "right" }}>Amount</th>
          </tr>
        </thead>
        <tbody>
          {orderData?.bill_detail?.length > 0 ? (
            orderData.bill_detail.map((item, index) => (
              <tr key={index}>
                <td style={{ border: "1px solid black", padding: "5px" }}>{index + 1}</td>
                <td style={{ border: "1px solid black", padding: "5px" }}>{item.product_name}</td>
                <td style={{ border: "1px solid black", padding: "5px", textAlign: "center" }}>
                  {Number(item.amount_per_product || 0).toFixed(2)}
                </td>
                <td style={{ border: "1px solid black", padding: "5px", textAlign: "center" }}>
                  {item.qty} - {item.unit}
                </td>
                <td style={{ border: "1px solid black", padding: "5px", textAlign: "right" }}>
                  {Number(item.total_per_product || 0).toFixed(2)}
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="7" style={{ textAlign: "center", padding: "10px" }}>Loading...</td>
            </tr>
          )}
        </tbody>
      </table>

      <div style={{ textAlign: "right", marginTop: "10px" }}>
        <strong>Sub-total : Rs. {Math.round(totalAmount).toFixed(2)}</strong>
      </div>
      {orderData?.buyer_detail?.state?.trim().toLowerCase() === "tamilnadu" ? (
        <>
      <div style={{ textAlign: "right", marginTop: "10px" }}>
        <strong>CGST ({orderData.final_billing[0].cgst_percentage})% : Rs. {taxSummary.cgst?.toFixed(2) || "0.00"}</strong>
      </div>
      <div style={{ textAlign: "right", marginTop: "10px" }}>
        <strong>SGST ({orderData.final_billing[0].sgst_percentage})% : Rs. {taxSummary.sgst?.toFixed(2) || "0.00"}</strong>
      </div>
      </>
      ):(
        <div style={{ textAlign: "right", marginTop: "10px" }}>
        <strong>IGST ({(
  parseFloat(orderData?.final_billing?.[0]?.cgst_percentage || 0) + 
  parseFloat(orderData?.final_billing?.[0]?.sgst_percentage || 0))})%  : Rs. {taxSummary.totalTax?.toFixed(2) || "0.00"}</strong>
      </div>
      )}
      <div style={{ textAlign: "right", marginTop: "10px" }}>
        <strong>Packing Charge ({orderData.final_billing[0].packing_charge_percentage})% : Rs. {taxSummary.packing_charge?.toFixed(2) || "0.00"}</strong>
      </div>
      <div style={{ textAlign: "right", marginTop: "10px" }}>
        <strong>
          Grand Total : Rs.{" "}
          {(grandtotal).toFixed(2) || "0.00"}
        </strong>
      </div>

      <div style={{ borderTop: "1px solid black", marginTop: "10px", paddingTop: "10px" }}>
        <strong>Amount Chargeable (in words):</strong> Indian Rupees{" "}
        {numberToWords(
          Math.round(
            totalAmount +
            taxSummary.cgst +
            taxSummary.sgst
          )
        ).toUpperCase()}
      </div>
      {orderData?.buyer_detail?.state?.trim().toLowerCase() === "tamilnadu" ? (
      <div style={{ borderTop: "1px solid black", marginTop: "10px", paddingTop: "10px" }}>
        <strong>Tax Details:</strong>
        <table style={{ width: "100%", borderCollapse: "collapse", marginTop: "10px" }}>
          <thead>
            <tr>
              <th style={{ border: "1px solid black", padding: "5px", textAlign: "right" }}>Taxable Value</th>
              
              <th style={{ border: "1px solid black", padding: "5px" }}>CGST(%)</th>
              <th style={{ border: "1px solid black", padding: "5px", textAlign: "right" }}>CGST</th>
              <th style={{ border: "1px solid black", padding: "5px" }}>SGST(%)</th>
              <th style={{ border: "1px solid black", padding: "5px", textAlign: "right" }}>SGST</th>
              
              <th style={{ border: "1px solid black", padding: "5px", textAlign: "right" }}>Total Tax</th>
            </tr>
          </thead>
          <tbody>
          {orderData?.final_billing?.length > 0 && (
  <tr>
    <td style={{ border: "1px solid black", padding: "5px", textAlign: "right" }}>
      {parseFloat(orderData?.final_billing?.[0]?.subtotal || 0).toFixed(2)}
    </td>
    <td style={{ border: "1px solid black", padding: "5px" }}>
      {orderData?.final_billing?.[0]?.cgst_percentage || 0}%
    </td>
    <td style={{ border: "1px solid black", padding: "5px", textAlign: "right" }}>
      {parseFloat(orderData?.final_billing?.[0]?.cgst || 0).toFixed(2)}
    </td>
    <td style={{ border: "1px solid black", padding: "5px" }}>
      {orderData?.final_billing?.[0]?.sgst_percentage || 0}%
    </td>
    <td style={{ border: "1px solid black", padding: "5px", textAlign: "right" }}>
      {parseFloat(orderData?.final_billing?.[0]?.sgst || 0).toFixed(2)}
    </td>
    <td style={{ border: "1px solid black", padding: "5px", textAlign: "right" }}>
      {parseFloat(orderData?.final_billing?.[0]?.gst_total || 0).toFixed(2)}
    </td>
  </tr>
)}

            {/* Total Row */}
            <tr>
              <th style={{ border: "1px solid black", padding: "5px", textAlign: "right" }}>
                Total :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; {(totalAmount).toFixed(2)}
              </th>
              <th style={{ border: "1px solid black", padding: "5px" }}>-</th>
              <th style={{ border: "1px solid black", padding: "5px", textAlign: "right" }}>
                {taxSummary.cgst?.toFixed(2) || "0.00"}
              </th>
              <th style={{ border: "1px solid black", padding: "5px" }}>-</th>
              <th style={{ border: "1px solid black", padding: "5px", textAlign: "right" }}>
                {taxSummary.sgst?.toFixed(2) || "0.00"}
              </th>
              <th style={{ border: "1px solid black", padding: "5px", textAlign: "right" }}>
                {taxSummary.totalTax?.toFixed(2) || "0.00"}
              </th>
            </tr>
          </tbody>
        </table>
      </div>
      ):(
        <p></p>
      )}


      {/* <div style={{ borderTop: "1px solid black", marginTop: "10px", paddingTop: "10px" }}>
        Tax Amount (in words) : <strong>Indian Rupees Seven Thousand Nine Hundred Twenty Two Only</strong>
      </div> */}
      <div style={{ textAlign: "left", marginTop: "20px" }}>
       Company's PAN :  <strong>ALVPS4061P</strong>
      </div>
      <div style={{ textAlign: "left", marginTop: "5px",width:"50%" }}>
        <strong style={{borderBottom:"1px solid"}}>Declaration</strong><br/>
        <p><b>We declare that this invoice  shows the</b> </p>
         <p style={{fontSize:"10px"}}> actual price of the goods described and that all particulars are true and correct.</p>
      </div>
      <div style={{ textAlign: "right", marginTop: "-40px" }}>
        <strong >Authorized Signatory</strong>
      </div>
    </div>
  );
};

export default Invoice; 