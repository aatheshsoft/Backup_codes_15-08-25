import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import Header from "../Components/Header";
import axios from "axios";

const AddSupplier = () => {
    const navigate = useNavigate();
    const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
  const [supplier, setSupplier] = useState({
    supplier_name: "",
    
    gst_number: "",
    mobile: "",
    address: "",
  });

  const [loading, setLoading] = useState(false);
/*   const [error, setError] = useState(null);
  const [successMessage, setSuccessMessage] = useState(""); */

  const handleChange = (e) => {
    setSupplier({ ...supplier, [e.target.name]: e.target.value });
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
  
    const payload = {
        supplier_name: supplier.name,

      gst_number: supplier.gst_number,      // FIXED
      mobile: supplier.mobile,        // FIXED
      address: supplier.address,
    };
  
    console.log("Payload:", payload);
  
    try {
      const response = await fetch(`${API_BASE_URL}supplier_add.php`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json",
        },
        body: JSON.stringify(payload),
      });
  
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
  
      const data = await response.json();
      console.log("API Response:", data);
  
      if (data.head.code === 200) {
        alert("Supplier added successfully!");
        navigate("/supplier"); // Redirect after success
      } else {
        alert("Failed to add supplier. Error: " + data.head.msg);
      }
    } catch (error) {
      console.error("Network/API Error:", error);
      alert("Required field is empty");
    } finally {
      setLoading(false);
    }
  };
  
  

  return (
    <>
      <Header />
      <div className="page-wrapper compact-wrapper" id="pageWrapper">
        <div className="page-body-wrapper">
          <div className="page-body">
            <div className="container-fluid">
              <div className="row">
                <div className="col-12">
                  <div className="row">
                    <div className="col-sm-12 m-auto">
                      <div className="card">
                        <div className="card-body">
                          <div className="title-header option-title d-sm-flex d-block">
                            <h5>Add Supplier</h5>
                            <div className="right-options">
                              <ul>
                                <li>
                                  <Link className="btn btn-solid" to="/supplier">Back</Link>
                                </li>
                              </ul>
                            </div>
                          </div>

                         {/*  {error && <div className="alert alert-danger">{error}</div>}
                          {successMessage && <div className="alert alert-success">{successMessage}</div>} */}

                          <form className="theme-form theme-form-2 mega-form" onSubmit={handleSubmit}>
                            <div className="mb-4 row align-items-center">
                              <label className="form-label-title col-sm-3 mb-0">Name</label>
                              <div className="col-sm-9">
                                <input
                                  className="form-control"
                                  type="text"
                                  name="name"
                                  value={supplier.name}
                                  onChange={handleChange}
                                  required
                                  placeholder="Enter Name"
                                />
                              </div>
                            </div>
                            <div className="mb-4 row align-items-center">
                              <label className="form-label-title col-sm-3 mb-0">Address</label>
                              <div className="col-sm-9">
                                <textarea
                                  rows="3"
                                  className="form-control"
                                  name="address"
                                  value={supplier.address}
                                  onChange={handleChange}
                                  required
                                  placeholder="Enter Address"
                                ></textarea>
                              </div>
                            </div>
                            <div className="mb-4 row align-items-center">
                              <label className="form-label-title col-sm-3 mb-0">Phone Number</label>
                              <div className="col-sm-9">
                              <input
                                      className="form-control"
                                      type="text"
                                      name="mobile"  // FIXED
                                      value={supplier.mobile}
                                      onChange={handleChange}
                                      placeholder="Enter Phone Number"
                                       maxLength="10"
                                      onInput={(e) => {
                                        e.target.value = e.target.value.replace(/\D/g, ""); // Remove non-numeric characters
                                        if (e.target.value.length > 10) {
                                            e.target.value = e.target.value.slice(0, 10); // Limit to 10 digits
                                        }
                                    }}
                                    />
                              </div>
                            </div>
                            
                            <div className="mb-4 row align-items-center">
                              <label className="form-label-title col-sm-3 mb-0">GST Number</label>
                              <div className="col-sm-9">
                              <input
                                    className="form-control"
                                    type="text"
                                    name="gst_number"  // FIXED
                                    value={supplier.gst_number}
                                    onChange={handleChange}
                                    placeholder="Enter GST Number"
                                     maxLength="15"
                                  />
                              </div>
                            </div>
                            <div className="card-footer border-0 pb-0 d-flex justify-content-end">
                              <button className="btn btn-primary me-3" type="submit" disabled={loading}>
                                {loading ? "Submitting..." : "Submit"}
                              </button>
                              <button className="btn btn-outline" type="button" onClick={() => window.history.back()}>
                                Cancel
                              </button>
                            </div>
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default AddSupplier;
