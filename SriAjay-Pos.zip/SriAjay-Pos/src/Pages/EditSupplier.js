import React, { useState, useEffect } from "react";
import { Link, useParams, useNavigate } from "react-router-dom";
import Header from "../Components/Header";
import axios from "axios";

const EditSupplier = () => {
  const { id } = useParams(); // Get user_id from URL params
  const navigate = useNavigate();
  const [supplier, setSupplier] = useState(null);
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

  useEffect(() => {
    const fetchCustomer = async () => {
      try {
        const response = await axios.post(`${API_BASE_URL}supplier_detail.php`, { supplier_id:id });
        if (response.data.head.code === 200) {
            setSupplier(response.data.body);
        } else {
          console.error("Error fetching customer details:", response.data.head.msg);
        }
      } catch (error) {
        console.error("API Error:", error);
      }
    };

    fetchCustomer();
  }, [id]);

  const handleChange = (e) => {
    setSupplier({ ...supplier, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(`${API_BASE_URL}supplier_detail_update.php`, {
        supplier_id:id,
        supplier_name: supplier.supplier_name,
        // credit_limit: customer.credit_limit,
        gst_number: supplier.gst_number,
        mobile: supplier.mobile, // Assuming mobile = telephone
        address: supplier.address,
      });
      if (response.data.head.code === 200) {
        alert("Supplier details updated successfully!");
        navigate("/supplier");
      } else {
        alert("Failed to update supplier details: " + response.data.head.msg);
      }
    } catch (error) {
      console.error("API Error:", error);
      alert("An error occurred while updating supplier details.");
    }
  };

  if (!supplier) {
    return <p>Loading supplier details...</p>;
  }

  return (
    <>
      <Header />
      <div className="page-wrapper compact-wrapper" id="pageWrapper">
        <div className="page-body-wrapper">
          <div className="page-body">
            <div className="container-fluid">
              <div className="row">
                <div className="col-12">
                  <div className="row">
                    <div className="col-sm-12 m-auto">
                      <div className="card">
                        <div className="card-body">
                          <div className="title-header option-title d-sm-flex d-block">
                            <h5>Edit Supplier</h5>
                            <div className="right-options">
                              <ul>
                                <li>
                                  <Link className="btn btn-solid" to="/supplier">Back</Link>
                                </li>
                              </ul>
                            </div>
                          </div>

                          <form className="theme-form theme-form-2 mega-form" onSubmit={handleSubmit}>
                            <div className="mb-4 row align-items-center">
                              <label className="form-label-title col-sm-3 mb-0">Name</label>
                              <div className="col-sm-9">
                                <input className="form-control" type="text" name="supplier_name" value={supplier.supplier_name || ""} onChange={handleChange} required />
                              </div>
                            </div>
                            <div className="mb-4 row align-items-center">
                              <label className="form-label-title col-sm-3 mb-0">Address</label>
                              <div className="col-sm-9">
                                <textarea rows="3" className="form-control" name="address" value={supplier.address || ""} onChange={handleChange} required></textarea>
                              </div>
                            </div>
                            <div className="mb-4 row align-items-center">
                              <label className="form-label-title col-sm-3 mb-0">Phone Number</label>
                              <div className="col-sm-9">
                                <input className="form-control" type="text" name="mobile" value={supplier.mobile || ""}
                                 onChange={handleChange} 
                                 required 
                                 maxLength="10"
                                 onInput={(e) => {
                                   e.target.value = e.target.value.replace(/\D/g, ""); // Remove non-numeric characters
                                   if (e.target.value.length > 10) {
                                       e.target.value = e.target.value.slice(0, 10); // Limit to 10 digits
                                   }
                               }}
                                 />
                              </div>
                            </div>
                           {/*  <div className="mb-4 row align-items-center">
                              <label className="form-label-title col-sm-3 mb-0">Credit Limit</label>
                              <div className="col-sm-9">
                                <input className="form-control" type="text" name="credit_limit" value={supplier.credit_limit || ""} onChange={handleChange} required />
                              </div>
                            </div> */}
                            <div className="mb-4 row align-items-center">
                              <label className="form-label-title col-sm-3 mb-0">Gst Number</label>
                              <div className="col-sm-9">
                                <input className="form-control" type="text" name="gst_number" value={supplier.gst_number || ""} onChange={handleChange}   maxLength="15"  />
                              </div>
                            </div>
                            <div className="card-footer border-0 pb-0 d-flex justify-content-end">
                              <button className="btn btn-primary me-3" type="submit">Submit</button>
                              <button className="btn btn-outline" type="button" onClick={() => window.history.back()}>Cancel</button>
                            </div>
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default EditSupplier;
