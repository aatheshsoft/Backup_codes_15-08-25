import React, { useEffect, useState } from 'react'
import { Link,useParams } from 'react-router-dom';
import Header from '../Components/Header';
import Image from '../Assets/print.gif'
import axios from 'axios';



const PurchaseDetails = () => {
const {order_id} = useParams();
const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

const[purchasedetails,setPurchaseDetails] = useState([])
 
useEffect(() =>{
  axios.post(`${API_BASE_URL}pos_api/pos_purchase_list_details.php`,{purchase_id:order_id})
  .then((response) =>{
    if(response.data.head.code === 200){
      setPurchaseDetails(response.data.body)
    }else{
      console.error("Error Fetching Data:", response.data.head.msg);
    }
  })
  
  .catch((error) => {
    console.error("API Error:", error);
  });
})

  return (
    <>
    <Header />
    <div class="page-wrapper compact-wrapper" id="pageWrapper">
      <div class="page-body-wrapper">
        <div class="page-body">
          <div class="container-fluid">
            <div class="row">
              <div class="col-sm-12">
                <div class="card card-table">
                  <div class="card-body">
                    <div class="title-header option-title d-sm-flex d-block">
                      <h5> Purchase Details</h5>
                      <div class="right-options">
                        <ul>
                          <li>
                            <Link class="btn btn-solid" to="/purchaselist">Back</Link>
                          </li>
                        </ul>
                      </div>
                    </div>
                    <div class="table-responsive">
                      <table class="table theme-table table-product" id="table_id">
                       {/*  <!-- Order Summary --> */}
                        <tr>
                          <td>
                            <table width="100%" cellspacing="0" cellpadding="0" border="0">
                              <tr>
                                <td class="blacktext"><b>Order ID:</b> {purchasedetails.purchase_id}</td>
                             
                                {/* <td rowspan="2" align="right">
                                    <a 
                                      href={`/invoice/${purchasedetails.order_id}`} 
                                      target="_blank" 
                                      rel="noopener noreferrer"
                                    >
                                      <img src={Image} alt="Print" border="0" />
                                    </a>
                                  </td> */}

                              </tr>
                              <tr>
                          <td class="blacktext"><b>Order Date:</b> {purchasedetails.orderdate}</td>
                        </tr>
                             {/*  <tr>
                                <td class="blacktext"><b>Customer Name:</b>{orderdetails.billing_name}</td>
                              </tr> */}
                            </table>
                          </td>
                        </tr>
                       {/*  <tr>
                          <td class="blacktext"><b>Email:</b> {orderdetails.email}</td>
                        </tr>
                        <tr>
                          <td class="blacktext"><b>Mobile Number:</b> {orderdetails.mobile}</td>
                        </tr> */}
                       
                      {/*   <!-- Billing & Shipping Information --> */}
                        <tr>
                          <td>
                            <table width="100%" align="center" border="0" cellpadding="2" cellspacing="3">
                              <tr>
                                <td class="hilites" align="left" colspan="2"  style={{width:"50%"}}><b>Supplier Details</b></td>
                                <td></td>
                                {/* <td class="hilites" align="center" colspan="2" style={{width:"50%"}}><b>Shop Details</b></td> */}
                              </tr>
                              <tr>
                                <td class="frmlefttb" >Name:</td>
                                <td class="frmrighttb">{purchasedetails.supplier_name}</td>
                                {/* <td>-</td> */}
                             {/*    <td class="frmlefttb">Name:</td>
                                <td class="frmrighttb">{orderdetails.delivery_name}</td> */}
                              </tr>
                              <tr>
                                <td class="frmlefttb">Address:</td>
                                <td class="frmrighttb">{purchasedetails.supplier_address}</td>
                                {/* <td>-</td> */}
                             {/*    <td class="frmlefttb">Address:</td>
                                <td class="frmrighttb">{orderdetails.delivery_address}</td> */}
                              </tr>
                              <tr>
                               {/*  <td class="frmlefttb">City:</td>
                                <td class="frmrighttb">{orderdetails.billing_city}</td> */}
                               {/*  <td>-</td> */}
                              {/*   <td class="frmlefttb">City:</td>
                                <td class="frmrighttb">{orderdetails.delivery_city}</td> */}
                              </tr>
                              <tr>
                             {/*    <td class="frmlefttb">State:</td>
                                <td class="frmrighttb">{orderdetails.billing_state}</td> */}
                               {/*  <td>-</td> */}
                             {/*    <td class="frmlefttb">State:</td>
                                <td class="frmrighttb">{orderdetails.delivery_state}</td> */}
                              </tr>
                              <tr>
                               {/*  <td class="frmlefttb">Postcode:</td>
                                <td class="frmrighttb">{orderdetails.billing_pincode}</td> */}
                                {/* <td>-</td> */}
                               {/*  <td class="frmlefttb">Postcode:</td>
                                <td class="frmrighttb">{orderdetails.delivery_pincode}</td> */}
                              </tr>
                            </table>
                          </td>
                        </tr>
                        {/* <!-- Product Details --> */}
                        <tr>
                          <td>
                            <table width="100%" align="center" cellspacing="1" cellpadding="5" border="0">
                              <tr className='orderdetail-thead'>
                                <td class="hilites orderdetail-td "><b>S.No</b></td>
                                {/* <td class="hilites"><b>Image</b></td> */}
                                <td class="hilites orderdetail-td"><b>Product Name</b></td>
                                <td class="hilites orderdetail-td"><b>Qty</b></td>
                                <td class="hilites orderdetail-td"><b>Sell price</b></td>
                                <td class="hilites orderdetail-td"><b>Buy price</b></td>
                                
                                <td class="hilites orderdetail-td" align="right"><b>Total</b></td>
                                <td></td>
                                {/* <td class="hilites" align="center"><b>Cancel</b></td> */}
                              </tr>
                              {purchasedetails.order_details?.map((product, index) => (
                                  <tr key={product.order_detail_id}>
                                    <td>{index + 1}</td>
                                    
                                    <td>
                                   
                                    {product.product_name}
                                      {/* {parseInt(product.cancel) === 1 && (
                                        <div style={{ color: "red", fontSize: "12px",fontWeight:"bold" }}>(Cancelled)</div>
                                      )} */}
                                    </td>
                                    <td>{product.qty}</td>
                                    <td>₹{parseFloat(product.sell_price).toFixed(2)}</td>
                                    <td>₹{parseFloat(product.buy_price).toFixed(2)}</td>
                                    <td align="right">₹{parseFloat(product.buy_price*product.qty).toFixed(2)}</td>
                                    
                                  </tr>
                                ))}
                              
                              {/* <tr>
                                <td colspan="5" align="right" className="text-end"><b>Sub-Total</b></td>
                                <td align="right">
                                    <b>₹{(purchasedetails?.total ? Number(purchasedetails.total) : 0).toFixed(2)}</b>
                                  </td>

                               
                              </tr> */}
                             {/*  <tr>
                                <td colspan="5" align="right"><b>Discount</b></td>
                                <td align="right">₹0.00</td>
                                <td></td>
                              </tr> */}
                              {/* <tr>
                                <td colspan="4" align="right" className="text-end"><b>CGST</b></td>
                                <td align="right">₹{purchasedetails.cgst_amt}</td>
                                <td></td>
                              </tr>
                              <tr>
                                <td colspan="4" align="right" className="text-end"><b>SGST </b></td>
                                <td align="right">₹{purchasedetails.sgst_amt}</td>
                                <td></td>
                              </tr> */}
                              <tr>
                                <td colspan="5" align="right" className="text-end"><b>Grand Total</b></td>
                                <td align="right"><b>₹{purchasedetails.total}</b></td>
                                <td></td>
                              </tr>
                             
                          
                               
                            </table>
                          </td>
                        </tr>
                     
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    </>
  );
};

export default PurchaseDetails;
