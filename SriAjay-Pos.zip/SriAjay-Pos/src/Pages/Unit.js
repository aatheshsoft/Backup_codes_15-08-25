import React,{useState,useEffect} from 'react'
import Header from '../Components/Header';
import { Link } from "react-router-dom";
import axios from "axios";

const Unit = () => {
  const [units, setUnits] = useState([]);
  const [loading, setLoading] = useState(true); 
  const [showModal, setShowModal] = useState(false);
  const [selectedunitId, setSelectedUnitId] = useState(null);
  const [updateSuccess, setUpdateSuccess] = useState(false); 
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;


  const openDeleteModal = (unit_id) =>{
    setSelectedUnitId(unit_id)
    setShowModal(true);
  }
  
  const closeModal = () => {
    setSelectedUnitId(null);
    setShowModal(false);
};
    useEffect(() => {
      setLoading(true); // Set loading to true before fetching data
      axios
        .post(`${API_BASE_URL}unit_list.php`)
        .then((response) => {
          if (response.data.head.code === 200) {
            // Sort categories by rank after fetching data
            
            setUnits(response.data.body); // Store sorted categories in state
            console.log(response.data.body)
          } else {
            console.error("Error Fetching Data:", response.data.head.msg);
          }
        })
        .catch((error) => {
          console.error("API Error:", error);
        })
        .finally(() => {
          setLoading(false); // Set loading to false after API call
        });
    }, []);

   
      const handleDelete = async () => {
        if(!selectedunitId) return;

        try {
          const response = await axios.post(`${API_BASE_URL}unit_list_delete.php`,{
            unit_id:selectedunitId,
          });

          if(response.data.head.code === 200) {
            alert('Unit Deleted Successfully')
            closeModal();
            window.location.reload();

          } else{
            alert(response.data.head?.msg || "Failed to delete Unit");
          }
         
        }
        catch(error) {
          console.error("Error Deleting Unit", error)
          }

      };
    
  return (
    <>
    <Header/>
    <div class="page-wrapper compact-wrapper" id="pageWrapper">
        <div class="page-body-wrapper">
        <div className="page-body">
      <div className="container-fluid">
        <div className="row">
          <div className="col-sm-12">
            <div className="card card-table">
              <div className="card-body">
                <div className="title-header option-title d-sm-flex d-block">
                  <h5>List of Unit</h5>
                  <div className="right-options">
                    <ul>
                      <li>
                        <Link className="btn btn-solid" to="/addunit">
                          Add Unit 
                        </Link>
                      </li>
                    </ul>
                  </div>
                </div>
                <div>
                <form>
      {loading ? (
        <div className="d-flex justify-content-center align-items-center" style={{ height: '200px' }}>
          <div className="spinner-border text-primary" style={{ width: '3rem', height: '3rem' }} role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      ) : (
        <>
          <div className="table-responsive">
            <table className="table all-package theme-table table-product">
              <thead>
                <tr>
                  <th>S.No.</th>
                  <th>Unit</th>
                  {/* <th style={{ textAlign: 'center' }}>Stock</th>
                  <th style={{ textAlign: 'center' }}>Rank</th>
                  <th style={{ textAlign: 'center' }}>Active</th>
                  <th style={{ textAlign: 'center' }}>Sub Category</th> */}
                  <th style={{ textAlign: 'center' }}>Action</th>
                </tr>
              </thead>
              <tbody>
                {units.length > 0 ? (
                  units.map((unit, index) => (
                    <tr key={unit.unit_id}>
                      <td>{index + 1}</td>
                      <td>{unit.unit_name}</td>
                     
                      <td style={{ textAlign: 'center' }}>
                        <ul>
                          <li>
                            <Link to={`/editunit/${unit.unit_id}`}>
                              <i className="ri-pencil-line"></i>
                            </Link>
                          </li>
                          <li>
                            <a href="#" onClick={(e) => { e.preventDefault(); openDeleteModal(unit.unit_id); }}>
                              <i className="ri-delete-bin-line"></i>
                            </a>
                          </li>
                        </ul>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="7" style={{ textAlign: 'center' }}>
                      No units found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
          {/* <div className="card-footer border-0 pb-0 d-flex justify-content-end">
            <button
              className="btn btn-primary me-3"
              type="button"
              onClick={() => {
                categories.forEach((category) => {
                  handleUpdate(category.category_id, category.rank, category.active);
                });
              }}
            >  
              Update
            </button>
          </div> */}
        </>
      )}
    </form>    
            </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

        </div>
     </div>
     {showModal && (
                <div className="modal fade show" style={{ display: "block" }}>
                    <div className="modal-dialog modal-dialog-centered">
                        <div className="modal-content">
                            <div className="modal-body">
                                <h5>Confirm Delete</h5>
                                <p>Are you sure you want to delete this category?</p>
                                <button type="button" className="btn-close" onClick={closeModal}></button>
                            </div>
                            <div className="modal-footer">
                                <button type="button" className="btn btn-secondary" onClick={closeModal}>
                                    No
                                </button>
                                <button type="button" className="btn btn-danger" onClick={handleDelete}>
                                    Yes, Delete
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}

    </>
  )
}

export default Unit;