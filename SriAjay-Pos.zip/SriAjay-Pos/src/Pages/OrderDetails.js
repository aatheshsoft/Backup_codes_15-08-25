import React, { useEffect, useState } from 'react'
import { Link,useParams } from 'react-router-dom';
import Header from '../Components/Header';
import Image from '../Assets/print.gif'
import axios from 'axios';



const OrderDetails = () => {
const {order_id} = useParams();
const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

const[orderdetails,setOrderDetails] = useState([])
 
useEffect(() =>{
  axios.post(`${API_BASE_URL}order_details.php`,{order_id})
  .then((response) =>{
    if(response.data.head.code === 200){
      setOrderDetails(response.data.body)
    }else{
      console.error("Error Fetching Data:", response.data.head.msg);
    }
  })
  
  .catch((error) => {
    console.error("API Error:", error);
  });
})
/* const handleCancel = async (orderNo) => {
  console.log(orderNo);
  try {
    const response = await axios.post(
      "https://www.aatheshsoft.com/admin_api/cancel_product.php",
      { order_no: orderNo }
    );

    if (response.data.head.code === 200) {
      alert("Product canceled successfully!");
      // You may also update state here to reflect changes in the UI
    } else {
      alert("Failed to cancel product: " + response.data.message);
    }
  } catch (error) {
    console.error("Error canceling product:", error);
    alert("An error occurred while canceling the product.");
  }
}; */

/* const Handleupdate = async () => {
  console.log("clicked") 
} */
  return (
    <>
    <Header />
    <div class="page-wrapper compact-wrapper" id="pageWrapper">
      <div class="page-body-wrapper">
        <div class="page-body">
          <div class="container-fluid">
            <div class="row">
              <div class="col-sm-12">
                <div class="card card-table">
                  <div class="card-body">
                    <div class="title-header option-title d-sm-flex d-block">
                      <h5> Order Details</h5>
                      <div class="right-options">
                        <ul>
                          <li>
                            <Link class="btn btn-solid" to="/orderlist">Back</Link>
                          </li>
                        </ul>
                      </div>
                    </div>
                    <div class="table-responsive">
                      <table class="table theme-table table-product" id="table_id">
                       {/*  <!-- Order Summary --> */}
                        <tr>
                          <td>
                            <table width="100%" cellspacing="0" cellpadding="0" border="0">
                              <tr>
                                <td class="blacktext"><b>Order ID:</b> {orderdetails.order_id}</td>
                             
                                <td rowspan="2" align="right">
                                    <a 
                                      href={`/invoice/${orderdetails.order_id}`} 
                                      target="_blank" 
                                      rel="noopener noreferrer"
                                    >
                                      <img src={Image} alt="Print" border="0" />
                                    </a>
                                  </td>

                              </tr>
                              <tr>
                          <td class="blacktext"><b>Order Date:</b> {orderdetails.orderdate}</td>
                        </tr>
                             {/*  <tr>
                                <td class="blacktext"><b>Customer Name:</b>{orderdetails.billing_name}</td>
                              </tr> */}
                            </table>
                          </td>
                        </tr>
                       {/*  <tr>
                          <td class="blacktext"><b>Email:</b> {orderdetails.email}</td>
                        </tr>
                        <tr>
                          <td class="blacktext"><b>Mobile Number:</b> {orderdetails.mobile}</td>
                        </tr> */}
                       
                      {/*   <!-- Billing & Shipping Information --> */}
                        <tr>
                          <td>
                            <table width="100%" align="center" border="0" cellpadding="2" cellspacing="3">
                              <tr>
                                <td class="hilites" align="left" colspan="2"  style={{width:"50%"}}><b>Customer Details</b></td>
                                <td></td>
                                {/* <td class="hilites" align="center" colspan="2" style={{width:"50%"}}><b>Shop Details</b></td> */}
                              </tr>
                              <tr>
                                <td class="frmlefttb" >Name:</td>
                                <td class="frmrighttb">{orderdetails.billing_name}</td>
                                {/* <td>-</td> */}
                             {/*    <td class="frmlefttb">Name:</td>
                                <td class="frmrighttb">{orderdetails.delivery_name}</td> */}
                              </tr>
                              <tr>
                                <td class="frmlefttb">Address:</td>
                                <td class="frmrighttb">{orderdetails.billing_address}</td>
                                {/* <td>-</td> */}
                             {/*    <td class="frmlefttb">Address:</td>
                                <td class="frmrighttb">{orderdetails.delivery_address}</td> */}
                              </tr>
                              <tr>
                                <td class="frmlefttb">State:</td>
                                <td class="frmrighttb">{orderdetails.billing_state}</td>
                                {/* <td>-</td> */}
                             {/*    <td class="frmlefttb">Address:</td>
                                <td class="frmrighttb">{orderdetails.delivery_address}</td> */}
                              </tr>
                              <tr>
                               {/*  <td class="frmlefttb">City:</td>
                                <td class="frmrighttb">{orderdetails.billing_city}</td> */}
                               {/*  <td>-</td> */}
                              {/*   <td class="frmlefttb">City:</td>
                                <td class="frmrighttb">{orderdetails.delivery_city}</td> */}
                              </tr>
                              <tr>
                             {/*    <td class="frmlefttb">State:</td>
                                <td class="frmrighttb">{orderdetails.billing_state}</td> */}
                               {/*  <td>-</td> */}
                             {/*    <td class="frmlefttb">State:</td>
                                <td class="frmrighttb">{orderdetails.delivery_state}</td> */}
                              </tr>
                              <tr>
                               {/*  <td class="frmlefttb">Postcode:</td>
                                <td class="frmrighttb">{orderdetails.billing_pincode}</td> */}
                                {/* <td>-</td> */}
                               {/*  <td class="frmlefttb">Postcode:</td>
                                <td class="frmrighttb">{orderdetails.delivery_pincode}</td> */}
                              </tr>
                            </table>
                          </td>
                        </tr>
                        {/* <!-- Product Details --> */}
                        <tr>
                          <td>
                            <table width="100%" align="center" cellspacing="1" cellpadding="5" border="0">
                              <tr className='orderdetail-thead'>
                                <td class="hilites orderdetail-td "><b>S.No</b></td>
                                {/* <td class="hilites"><b>Image</b></td> */}
                                <td class="hilites orderdetail-td"><b>Product Name</b></td>
                                <td class="hilites orderdetail-td"><b>Qty</b></td>
                                <td class="hilites orderdetail-td"><b>Price</b></td>
                                
                                <td class="hilites orderdetail-td" align="right"><b>Total</b></td>
                                <td></td>
                                {/* <td class="hilites" align="center"><b>Cancel</b></td> */}
                              </tr>
                              {orderdetails.order_details?.map((product, index) => (
                                  <tr key={product.order_detail_id}>
                                    <td>{index + 1}</td>
                                    
                                    <td>
                                   
                                    {product.product_name}
                                      
                                    </td>
                                    <td>{product.qty}</td>
                                    <td>₹{parseFloat(product.amount).toFixed(2)}</td>
                                    <td align="right">₹{parseFloat(product.totalamount).toFixed(2)}</td>
                                    {/* <td align="center">
                                    {parseInt(product.cancel) !== 1 ? ( // Hide cancel button if already canceled
                                        <button
                                          onClick={() => handleCancel(product.order_no)}
                                          title="Cancel Product"
                                          style={{ background: "none", border: "none", cursor: "pointer" }}
                                        >
                                          <i className="ri-close-circle-line" style={{ color: "red" }}></i>
                                        </button>
                                      ):(
                                        <div style={{ color: "red", fontSize: "12px",fontWeight:"bold" }}>(Cancelled)</div>
                                      )
                                    }
                                    </td> */}
                                  </tr>
                                ))}
                              
                              <tr>
                                <td colspan="4" align="right" className="text-end"><b>Sub-Total</b></td>
                                <td align="right">
                                    <b>₹{(orderdetails?.subtotal ? Number(orderdetails.subtotal) : 0).toFixed(2)}</b>
                                  </td>

                                <td></td>
                              </tr>
                             {/*  <tr>
                                <td colspan="5" align="right"><b>Discount</b></td>
                                <td align="right">₹0.00</td>
                                <td></td>
                              </tr> */}
                                    {orderdetails.billing_state?.toLowerCase() === "tamilnadu" ? (                                     
                                       <>
                                        <tr>
                                          <td colSpan="4" align="right" className="text-end"><b>CGST</b></td>
                                          <td align="right">₹{orderdetails.cgst_amt}</td>
                                          <td></td>
                                        </tr>
                                        <tr>
                                          <td colSpan="4" align="right" className="text-end"><b>SGST</b></td>
                                          <td align="right">₹{orderdetails.sgst_amt}</td>
                                          <td></td>
                                        </tr>
                                      </>
                                    ) : (
                                      <tr>
                                        <td colSpan="4" align="right" className="text-end"><b>IGST</b></td>
                                        <td align="right">
                                              ₹
                                              {(
                                                parseFloat(orderdetails.cgst_amt || 0) + parseFloat(orderdetails.sgst_amt || 0)
                                              ).toFixed(2)}
                                            </td>

                                        <td></td>
                                      </tr>
                                    )}

                              <tr>
                                <td colspan="4" align="right" className="text-end"><b>Packing Charge </b></td>
                                <td align="right">₹{orderdetails.packing_charge}</td>
                                <td></td>
                              </tr>
                              <tr>
                                <td colspan="4" align="right" className="text-end"><b>Grand Total</b></td>
                                <td align="right"><b>₹{orderdetails.total}</b></td>
                                <td></td>
                              </tr>
                             
                          
                               
                            </table>
                          </td>
                        </tr>
                     
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    </>
  );
};

export default OrderDetails;
