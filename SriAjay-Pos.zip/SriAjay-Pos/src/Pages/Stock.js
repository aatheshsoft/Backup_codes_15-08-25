import React, { useState,useEffect } from "react";
import Header from "../Components/Header";
import { Link } from "react-router-dom";
import axios from "axios";

const Stock = () => {

  const [stock, setStock] = useState([]);
  const [supplier, setSupplier] = useState([]);
   const [currentPage, setCurrentPage] = useState(1);
   const recordsPerPage = 25;
   const totalRecords = stock.length;
   const [searchQuery, setSearchQuery] = useState("");
   const[filteredproducts,setFilteredProducts] = useState("");
   const totalPages = Math.ceil(filteredproducts.length / recordsPerPage);

   const [loading, setLoading] = useState(true);
   const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
   const [selectedSupplier, setSelectedSupplier] = useState("");
    // Calculate records for the current page
    const indexOfLastRecord = currentPage * recordsPerPage;
    const indexOfFirstRecord = indexOfLastRecord - recordsPerPage;
    const currentRecords = filteredproducts.slice(indexOfFirstRecord, indexOfLastRecord);
  
    // Function to change the page
    const paginate = (pageNumber) => {
      if (pageNumber >= 1 && pageNumber <= totalPages) {
        setCurrentPage(pageNumber);
      }
    };

  useEffect(() => {
    setLoading(true);
    axios
      .post(`${API_BASE_URL}pos_api/pos_report_stock.php`)
      .then((response) => {
        console.log("API Response:", response.data); // Debugging
        if (response.data.head.code === 200) {
          if (response.data.body.length > 0 && response.data.body[0].stock_report) {
            setStock(response.data.body[0].stock_report);
            setSupplier(response.data.body[0].supplier_list);
            setFilteredProducts(response.data.body[0].stock_report);
            
          } else {
            console.error("Stock report is missing in the response.");
          }
        } else {
          console.error("Error:", response.data.head.msg);
        }
      })
      .catch((error) => {
        console.error("API Error:", error);
      }).finally(() => {
        setLoading(false);
      });
  }, []);

  const uniqueSuppliers = [...new Set(supplier.map(item => item.supplier_name).filter(name => name))];

  // Handle supplier selection
  const handleSupplierChange = (e) => {
    const selected = e.target.value;
    setSelectedSupplier(selected);

    if (selected) {
      const filtered = stock.filter(item => item.supplier_name === selected);
      setFilteredProducts(filtered);
      setCurrentPage(1);
    } else {
      setFilteredProducts(stock);
    }
    
  };
  const handleSearch = (e) => {
    const query = e.target.value; // Convert search query to lowercase
    setSearchQuery(query);
  
    const searchedOrders = stock.filter((item) => {
      return (
        item.product_name?.toLowerCase().includes(query.toLowerCase()) || 
        item.product_code?.toLowerCase().includes(query.toLowerCase()) // Convert product_code to lowercase for comparison
      );
    });
  
    setFilteredProducts(searchedOrders);
    setCurrentPage(1);
  };
  



  return (
    <>
    <Header />
    <div class="page-wrapper compact-wrapper" id="pageWrapper">
      <div class="page-body-wrapper">
        <div class="page-body">
                <div class="container-fluid">
                  <div class="row">
                    <div class="col-sm-12">
                      <div class="card card-table">
                        <div class="card-body">
                          <div class="title-header option-title d-sm-flex d-block">
                            <h5>List of Stock</h5>
                            {/* <div class="right-options">
                              <ul>
                                <li>
                                  <Link class="btn btn-solid" onClick={() => window.history.back()}>Back</Link>
                                </li>
                              </ul>
                            </div> */}
                      <div className="col-md-4">
                      <select className="form-control" value={selectedSupplier} onChange={handleSupplierChange}>
                            <option value="">All Suppliers</option>
                            {uniqueSuppliers.map((supplier, index) => (
                              <option key={index} value={supplier}>{supplier}</option>
                            ))}
                          </select>
                      </div>
                            <div class=" col-md-6 col-sm-5">
                          <form
                            
                            class="theme-form theme-form-2 mega-form"
                          >
                            <div class=" row align-items-center">
                              {/* <!-- Search Box --> */}
                              <label
                                for="search"
                                class="col-sm-2 col-form-label"
                                style={{fontSize:"14px"}}
                              >
                                Search:
                              </label>
                              <div class="col-sm-10">
                                <input
                                  type="text"
                                  id="search"
                                  name="search"
                                  class="form-control"
                                  placeholder="Search"
                                  value={searchQuery}
                                  onChange={handleSearch}
                                />
                            
                              </div>
                            </div>
                          </form>
                          
                        </div>
                      </div>
                         

                          <div>
                            <form>
                            {loading ? (
                          <div
                            className="d-flex justify-content-center align-items-center"
                            style={{ height: "200px" }}
                          >
                            <div
                              className="spinner-border text-primary"
                              style={{ width: "3rem", height: "3rem" }}
                              role="status"
                            >
                              <span className="visually-hidden">
                                Loading...
                              </span>
                            </div>
                          </div>
                        ) : (
                          <>
                              <div class="table-responsive">
                              <table className="table all-package theme-table table-product" id="table_id">
                                  <thead>
                                    <tr>
                                      <th>S.No.</th>
                                      <th>Product Code</th>
                                      <th>Product</th>
                                      <th style={{ textAlign: "center" }}>Stock (in case)</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {currentRecords.length > 0 ? (
                                      currentRecords.map((item, index) => (
                                        <tr key={index}>
                                          <td>{indexOfFirstRecord + index + 1}</td>
                                          <td>{item.product_code}</td>
                                          <td>{item.product_name}</td>
                                          <td style={{ textAlign: "center" }}>{item.stock}</td>
                                        </tr>
                                      ))
                                    ) : (
                                      <tr>
                                        <td colSpan="4" className="text-center">
                                          No stock found
                                        </td>
                                      </tr>
                                    )}
                                    {totalPages > 1 && (
                                     <td colSpan="9">
                                                      <table width="100%" border="1" style={{ borderCollapse: "collapse", border: "1px solid #000" }}>
                                                        <tr>
                                                          <td width="20%">Page {currentPage} of {totalPages}</td>
                                                          <td style={{ textAlign: "right" }}>
                                                            {/* Previous Button */}
                                                            {currentPage > 1 ? (
                                                              <a className="pagetext" href="javascript:void(0);" onClick={() => paginate(currentPage - 1)}>
                                                                &laquo; Previous
                                                              </a>
                                                            ) : (
                                                              <span>&laquo; Previous</span>
                                                            )}
                                                            &nbsp;
                                                            {/* Page Numbers */}
                                                            {[...Array(totalPages)].map((_, i) => (
                                                                <React.Fragment key={i}>
                                                                  <a
                                                                    className={`pagetext ${currentPage === i + 1 ? "active" : ""}`}
                                                                    href="javascript:void(0);"
                                                                    onClick={() => paginate(i + 1)}
                                                                  >
                                                                    {i + 1}
                                                                  </a>
                                                                  &nbsp;
                                                                </React.Fragment>
                                                              ))}
                                    
                                                            {/* Next Button */}
                                                            {currentPage < totalPages ? (
                                                              <a className="pagetext" href="javascript:void(0);" onClick={() => paginate(currentPage + 1)}>
                                                                Next &raquo;
                                                              </a>
                                                            ) : (
                                                              <span>Next &raquo;</span>
                                                            )}
                                    
                                                            {/* Last Button */}
                                                            {currentPage < totalPages ? (
                                                              <a className="pagetext" href="javascript:void(0);" onClick={() => paginate(totalPages)}>
                                                                Last &raquo;&raquo;
                                                              </a>
                                                            ) : (
                                                              <span>Last &raquo;&raquo;</span>
                                                            )}
                                                          </td>
                                                        </tr>
                                                      </table>
                                                    </td>
                                    )}
                                                  </tbody>
                                                </table>
                                              </div>
                                              </>
                                            )}
                                      </form>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
    </div>
    </>
  )
}

export default Stock