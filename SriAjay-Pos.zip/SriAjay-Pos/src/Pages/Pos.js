import React, { useEffect, useState } from "react";
import { Container, Row, Col, Button, Table, Form, InputGroup, Card,Modal } from "react-bootstrap";
import { FaPlus, FaSearch, FaShoppingCart, FaTrash } from "react-icons/fa";
import { BiRupee } from "react-icons/bi";
import { RiSave3Line } from "react-icons/ri";
import { LuPrinter } from "react-icons/lu";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";
import Spinner from "react-bootstrap/Spinner";

 
const POS = () => {
  const [cart, setCart] = useState([]);
  const [filteredCodes, setFilteredCodes] = useState([]);
  const [products, setProducts] = useState([]);
  const [fullproducts, setFullProducts] = useState([]);
  const [productCode, setProductCode] = useState("");
  const [productName, setProductName] = useState("");
  const [selectedCustomer, setSelectedCustomer] = useState("");
  const [loading, setLoading] = useState(true);
  const [Loading1, setLoading1] = useState();
  const [Loading2, setLoading2] = useState();
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
  const [gst, setGST] = useState({ cgst: "0", sgst: "0", packingCharge: "0.00" });

  const [customer, setCustomer] = useState([]);
  const [show, setShow] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const navigate = useNavigate()
  const [formData, setFormData] = useState({
    customerName: "",
    address: "",
    phonenumber:"",
    // creditlimit:"",
    gstin: "",
    state:"",
  });
console.log(searchTerm);
  const handleShow = () => setShow(true);
  const handleClose = () => setShow(false);

  // Handle Form Input Change
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
   
  
    const payload = {
      name: formData.customerName,
      // credit_limit: formData.creditlimit,  // FIXED
      tax_number: formData.gstin,      // FIXED
      telephone: formData.phonenumber,        // FIXED
      address: formData.address,
      state:formData.state
    };
  
    console.log("Payload:", payload);
  
    try {
      const response = await fetch(`${API_BASE_URL}customer_add.php`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json",
        },
        body: JSON.stringify(payload),
      });
  
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
  
      const data = await response.json();
      console.log("API Response:", data);
  
      if (data.head.code === 200) {
        alert("Customer added successfully!");
       setShow(false);
       window.location.reload();
      } else {
        alert("Failed to add customer. Error: " + data.head.msg);
      }
    } catch (error) {
      console.error("Network/API Error:", error);
      alert("Required field is empty");
    } 
  };

useEffect(() => {
  setLoading(true);
  axios.post(`${API_BASE_URL}pos_api/pos_product_list.php`)
    .then((response) => {
      if (response.data.head.code === 200) {
        setProducts(response.data.body.product);
        setFullProducts(response.data.body.product);
        setCustomer(response.data.body.customer);

        // Extract and store GST details
        const gstData = response.data.body.gst;
        if (gstData) {
          setGST({
            cgst: gstData.cgst,
            sgst: gstData.sgst,
            packingCharge: gstData.packing_charge
          });
          console.log(gstData);

        }
      } else {
        console.error("Error Fetching Data", response.data.head.msg);
      }
    })
    .catch((error) => {
      console.error("API Error:", error);
    })
    .finally(() => {
      setTimeout(() => setLoading(false), 500); // Delay for better UI
    });
}, []);



  // Handle product code input with dropdown suggestion
  const handleCodeInput = (event) => {
    const code = event.target.value.trim().toUpperCase();
    setProductCode(code);
  
    if (code.length === 0) {
      setFilteredCodes([]);
      setProductName("");
      return;
    }
  
    // Filter products for dropdown suggestions
    const filtered = products.filter((p) => p.product_code.includes(code));
    setFilteredCodes(filtered);
  
    // Find exact match when full code is entered
    const product = products.find((p) => p.product_code === code);
  
    if (product) {
      setFilteredCodes([]); // Close dropdown
  
      if (!product.stock || product.stock <= 0) {
        alert(`"${product.product_name}" is out of stock!`);
        setProductName(""); // Clear product name to prevent selection
        return;
      }
  
      setProductName(product.product_name);
      addToCart(product); // ✅ Add only if in stock
    } else {
      setProductName(""); // Clear if no exact match
    }
  };
  
  
  // Handle dropdown selection
  const handleDropdownSelect = (product) => {
    setFilteredCodes([]); // Close dropdown
  
    // Ensure product is valid
    if (!product || !product.product_code || !product.product_name) {
      alert("Invalid product selection!");
      return;
    }
  
    // Strict stock check
    if (!product.stock || product.stock <= 0) {
      alert(`"${product.product_name}" is out of stock!`);
      return;
    }
  
    setProductCode(product.product_code);
    setProductName(product.product_name);
    addToCart(product); // ✅ Add to cart only if in stock
  };
  
  
  
  // Handle Product Name Input
  const handleNameInput = (event) => {
    const name = event.target.value.trim();
    setProductName(name);

    if (!products.length) return; // Ensure products are loaded

    // Find product ignoring case and trimming spaces
    const product = products.find((p) => p.product_name.trim().toLowerCase() === name.toLowerCase());

    console.log("Selected Name:", name);
    console.log("Matching Product:", product);

    if (product) {
        if (!product.product_code) {
            alert("Invalid product details!");
            setProductCode("");
            setProductName("");
            return;
        }

        if (!product.stock || product.stock <= 0) {
            alert(`"${product.product_name}" is out of stock!`);
            setProductCode("");
            setProductName("");
            return;
        }

        setProductCode(product.product_code);
        addToCart(product);
    } else {
        setProductCode("");
    }
};

  

  // Add Product to Cart
  const addToCart = (product) => {
    if (product.stock === 0) {
      alert(`"${product.product_name}" is out of stock!`);
      return; // Prevent adding to cart
    }
  
    setCart((prevCart) => {
      const existingProduct = prevCart.find((item) => item.product_id === product.product_id);
      if (existingProduct) {
        if (existingProduct.qty + 1 > product.stock) {
          alert(`Only ${product.stock} items available in stock!`);
          return prevCart;
        }
        return prevCart.map((item) =>
          item.product_id === product.product_id ? { ...item, qty: existingProduct.qty + 1 } : item
        );
      } else {
        return [...prevCart, { ...product, qty: 1 }];
      }
    });
  };
  

  const handleQtyChange = (e, product) => {
    let prevQty = product.qty; // Store previous quantity
    let newQty = e.target.value.replace(/^0+/, ""); // Remove leading zeros

    if (newQty === "" || isNaN(newQty)) {
        newQty = "";
    } else {
        newQty = parseInt(newQty, 10);

        // ✅ Ensure new quantity is not less than 1
        if (newQty < 1) {
            newQty = 1;
        }

        // ✅ Handle stock limit and show alert correctly
        if (newQty > product.stock) {
            alert(`Only ${product.stock} items available in stock!`);
            newQty = product.stock; // Reset to max stock
        }
    }

    // ✅ Update state correctly
    setCart((prevCart) =>
        prevCart.map((item) =>
            item.product_id === product.product_id ? { ...item, qty: newQty } : item
        )
    );
};

// ✅ Ensure Minimum Quantity = 1 on Blur
const handleQtyBlur = (e, product) => {
    let newQty = parseInt(e.target.value, 10) || 1;
    if (newQty < 1) newQty = 1;

    setCart((prevCart) =>
        prevCart.map((item) =>
            item.product_id === product.product_id ? { ...item, qty: newQty } : item
        )
    );
};
const calculateTotal = () => {
  return cart.reduce((total, item) => {
    return total + item.sell_price * item.qty;
  }, 0) || 0;
};

// Get CGST and SGST from the API response
const cgstAmount = (calculateTotal()* (parseFloat(gst.cgst)/100));
const sgstAmount = ( calculateTotal()*(parseFloat(gst.sgst)/100));
const IgstAmount= cgstAmount + sgstAmount;
// Convert packing charge from string to float
const packingCharge = gst.packingCharge
  ? (parseFloat(gst.packingCharge) / 100) * calculateTotal()
  : 0;
// Calculate Grand Total
const grandtotal = Math.round(calculateTotal() + cgstAmount + sgstAmount + packingCharge);

// ✅ Console Debugging
console.log("Subtotal:", calculateTotal().toFixed(2));
console.log("CGST (" + gst.cgst + "%):", cgstAmount.toFixed(2));
console.log("SGST (" + gst.sgst + "%):", sgstAmount.toFixed(2));
console.log("Packing Charge:", packingCharge.toFixed(2));
console.log("Grand Total:", grandtotal);



  const removeItem = (id) => {
    setCart(cart.filter((item) => item.product_id !== id));
  };
  
  const handleSave = () => {
    if (!selectedCustomer) {
      alert("Please select a customer.");
      return;
    }
    setLoading1(true);
    if (!cart || cart.length === 0) {
      alert("Please select a product");
      return;
  }
  
    
    const orderData = {
      user_id: selectedCustomer.user_id,
      billing_name: selectedCustomer.name,
      billing_phonenumber: selectedCustomer.telephone,
      billing_state:selectedCustomer.state,
      total: grandtotal,
      subtotal: calculateTotal(),
      cgst:cgstAmount,
      sgst:sgstAmount,
      packing_charge:packingCharge,
      productdetails: cart.map(item => ({
        product_id: item.product_id,
        product_name: item.product_name,
        rate_per:item.rate_per,
        box_contents:item.box_contents,
        qty: item.qty,
        unit: item.unit,
        amount_per_product:item.sell_price,
        total_per_product:item.sell_price*item.qty,

      }))
    };
      console.log(orderData);
            axios.post(`${API_BASE_URL}pos_api/pos_order.php`, orderData)
  
      .then(response => {
        if(response.data.head.code === 200){
          console.log("Order Saved:", response.data);
          alert("Order saved successfully!");
          setCart([]);
          window.location.reload();
        }else{
          console.log("Error",response.data.head.msg)
        }
      
      })
      .catch(error => {
        console.error("Save Order Error:", error);
        alert("Failed to save order.");
      }) .finally(() => {
        setLoading1(false);
      });
  };



  // const handleSavePrint = () => {

  //   if (!selectedCustomer) {
  //     alert("Please select a customer.");
  //     return;
  //   }
  //  setLoading2(true);
  //   if (!cart || cart.length === 0) {
  //     alert("Please select a product");
  //     return;
  //   }
  
  //   const orderData = {
  //     user_id: selectedCustomer.user_id,
  //     billing_name: selectedCustomer.name,
  //     billing_phonenumber: selectedCustomer.telephone,
  //     billing_state:selectedCustomer.state,
  //     total: grandtotal,
  //     subtotal: calculateTotal(),
  //     cgst:cgstAmount,
  //     sgst:sgstAmount,
  //     packing_charge:packingCharge,
  //     productdetails: cart.map(item => ({
  //       product_id: item.product_id,
  //       product_name: item.product_name,
  //       rate_per:item.rate_per,
  //       box_contents:item.box_contents,
  //       qty: item.qty,
  //       unit: item.unit,
  //       amount_per_product:item.sell_price,
  //       total_per_product:item.sell_price*item.qty,

  //     })),
  //   };
  
  //   console.log(orderData);
  
  //   axios.post(`${API_BASE_URL}pos_api/pos_order.php`, orderData)
  //     .then(response => {
  //       if (response.data.head.code === 200) {
  //         console.log("Order Saved:", response.data);
  //         localStorage.setItem('orderdata', JSON.stringify(response.data));
  //         alert("Order saved successfully!");
  
  //         // ✅ Open invoice print page with order details (separate tab)
  //         const printWindow = window.open('/invoiceprint', '_blank');
  
  //         // ✅ Reset billing page without waiting
  //         setCart([]);
  //         setProductCode("");
  //         setProductName("");
  //         setSelectedCustomer(null);
  //         setFilteredCodes([]);
  
  //       } else {
  //         console.log("Error", response.data.head.msg);
  //       }
  //     })
  //     .catch(error => {
  //       console.error("Save Order Error:", error);
  //       alert("Failed to save order.");
  //     }) .finally(() => {
  //       setLoading2(false);
  //     });
  // };
  
  
  
  
  


const handleCustomerSelect = (e) => {
    const selectedId = e.target.value;
    const selected = customer.find(c => c.user_id === selectedId);
    if (selected) {
      setSelectedCustomer({ 
        user_id: selected.user_id, 
        name: selected.name,
        phonenumber:selected.telephone, 
        is_bill_eligible: parseFloat(selected.is_bill_eligible) 
      });
    }
  };
console.log(selectedCustomer);


const cleanText = (text) => (text ? text.replace(/[\u200B-\u200D\uFEFF]/g, "").trim().toLowerCase() : "");

const filteredProducts = fullproducts.filter((product) => {
  const search = cleanText(searchTerm);
  const productName = cleanText(product.product_name);
  const categoryName = cleanText(product.category_name);
  const brand = cleanText(product.brand);

  console.log(`Checking: Brand="${brand}", Search="${search}"`);

  return (
    productName.includes(search) ||
    categoryName.includes(search) ||
    brand.includes(search)
  );
});





  
  return (
    <Container fluid classNam  e="p-3" style={{ minHeight: "100vh" }}>
      <Row>
        <Col md={6} className="border-end mt-2"  style={{
            height: "95vh",
            display: "flex",
            flexDirection: "column",
          }}>
          <InputGroup className="mb-3">
          <Form.Select
                  value={selectedCustomer ? selectedCustomer.user_id : ""} // ✅ Ensures dropdown resets
                  onChange={(e) => {
                    const user = customer.find(c => c.user_id === e.target.value);
                    setSelectedCustomer(user || null); // ✅ Update or reset properly
                  }}
                >
                  <option value="">Select Customer</option>
                  {Array.isArray(customer) && customer.map((c) => (
                      <option key={c.user_id} value={c.user_id}>{c.name}</option>
                    ))}

                </Form.Select>
             &nbsp; &nbsp;
            <Button variant="primary" onClick={handleShow} style={{marginTop:"0px"}} >
              <FaPlus />

            </Button>&nbsp;&nbsp;
            <Button className="btn btn-solid pos-back-btn" onClick={() => window.history.back()}>
                  Back
                </Button>
          </InputGroup>

          <Row>
            <Col md={6}>
            <InputGroup className="mb-3">
                <Form.Control
                  type="text"
                  placeholder="Enter Product Code"
                  value={productCode}
                  onChange={handleCodeInput}
                  autoComplete="off"
                />
               {Array.isArray(filteredCodes) && filteredCodes.length > 0 && (
                          <div
                            className="dropdown-menu show"
                            style={{ width: "100%", marginTop: "50px", overflowY: "scroll", height: "50vh" }}
                          >
                            {filteredCodes.map((product) => (
                              <div
                                key={product.product_id}
                                style={{ cursor: "pointer", color: "black" }}
                                className="dropdown-item"
                                onClick={() => handleDropdownSelect(product)} // ✅ Separate function for dropdown
                              >
                                {product.product_code} - {product.product_name}
                              </div>
                            ))}
                          </div>
                        )}

              </InputGroup>

            </Col>

            <Col md={6}>
              <InputGroup className="mb-3">
                <Form.Select value={productName} onChange={handleNameInput}>
                  <option value="">Select Product</option>
                  {Array.isArray(products) && products.map((product) => (
                      <option key={product.product_id} value={product.product_name}>
                        {product.product_name}
                      </option>
                    ))}

                </Form.Select>
              </InputGroup>
            </Col>
          </Row>

          {/* Table to Display Selected Products */}
          <div style={{ flexGrow: 1, overflowY: "auto", border: "1px solid #ddd" }}>
            <Table bordered responsive>
              <thead>
                <tr>
                  <th>S.No</th>
                  <th>Item</th>
                  <th style={{textAlign:"right"}}>Price</th>
                  {/* <th>GST</th>  */}
                  <th>Qty</th>
                  <th style={{textAlign:"right"}}>Total</th>
                  <th>Del</th>
                </tr>
              </thead>
              <tbody>
                {cart.map((item, index) => (
                  <tr key={item.product_id}>
                    <td>{index + 1}</td>
                    <td>{item.product_name}</td>
                    <td style={{textAlign:"right"}}><BiRupee />{item.sell_price}</td>
                    {/* <td>{item.tax} %</td> */}
                    <td>
                    <input
                          type="number"
                          value={item.qty}
                          min="1"
                          max={item.stock}
                          className="form-control text-center"
                          style={{ width: "60px" }}
                          onInput={(e) => handleQtyChange(e, item)}  // ✅ Works for both typing & button clicks
                          onBlur={(e) => handleQtyBlur(e, item)}
                      />
                    </td>


                    <td style={{textAlign:"right"}}><BiRupee />{(item.sell_price * item.qty || 0).toFixed(2)} </td>
                    <td>
                      <Button variant="danger" size="sm" onClick={() => removeItem(item.product_id)}>
                        <FaTrash />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </div>

          <div className="bg-light p-3 border rounded d-flex justify-content-between print-btn-group">
        {/*     {selectedCustomer && selectedCustomer.is_bill_eligible < calculateTotal() ? (
            <h5 style={{ color: "red", fontWeight:"bold" }}> Purchase Limit Exceeded</h5>
          ) : ( */}
            <>
            <div className="print-btn">
              <Button variant="dark" onClick={handleSave} style={{width:"80px",height:"40px"}}>
              
                  {Loading1 ? (
                    <Spinner animation="border" size="sm" />
                  ) : (
                    <>
                      <RiSave3Line /> &nbsp; Save
                    </>
                  )}
                </Button>

              &nbsp;&nbsp;

             {/*  <Button variant="dark"  onClick={handleSavePrint} style={{width:"130px",height:"40px"}}>
              {Loading2 ? (
                    <Spinner animation="border" size="sm" />
                  ) : (
                    <>
                <LuPrinter />&nbsp; Save & Print
                </>
                  )}
                </Button> */}
              </div>
            </>
      {/*     )} */}
         <div style={{ display: "flex", flexDirection: "column", gap: "5px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", width: "250px" }}>
            <h5 style={{ color: "black",fontWeight:"bold" }}>Sub-Total:</h5>
            <h5 style={{ color: "black",fontWeight:"bold" }}><BiRupee />{calculateTotal().toFixed(2)}</h5>
          </div>

  {selectedCustomer?.state?.toLowerCase() === "tamilnadu" ? (
  <>
    <div style={{ display: "flex", justifyContent: "space-between", width: "250px" }}>
      <h5 style={{ color: "black" }}>CGST:</h5>
      <h5 style={{ color: "black", fontWeight: "bold" }}><BiRupee />{cgstAmount.toFixed(2)}</h5>
    </div>

    <div style={{ display: "flex", justifyContent: "space-between", width: "250px" }}>
      <h5 style={{ color: "black" }}>SGST:</h5>
      <h5 style={{ color: "black", fontWeight: "bold" }}><BiRupee />{sgstAmount.toFixed(2)}</h5>
    </div>
  </>
) : (
  <div style={{ display: "flex", justifyContent: "space-between", width: "250px" }}>
    <h5 style={{ color: "black" }}>IGST:</h5>
    <h5 style={{ color: "black", fontWeight: "bold" }}><BiRupee />{IgstAmount.toFixed(2)}</h5>
  </div>
)}


          
          <div style={{ display: "flex", justifyContent: "space-between", width: "250px" }}>
            <h5 style={{ color: "black" }}>Packing Charge:</h5>
            <h5 style={{ color: "black",fontWeight:"bold" }}><BiRupee />{packingCharge.toFixed(2)}</h5>
          </div>
          <div style={{ display: "flex", justifyContent: "space-between", width: "250px", fontWeight: "bold" }}>
            <h5 style={{ color: "black",fontWeight:"bold" }}>Grand Total:</h5>
            <h5 style={{ color: "black",fontWeight:"bold" }}><BiRupee />{grandtotal.toFixed(2)}</h5>
          </div>
        </div>

        </div>   
        
      </Col>

      <Col md={6}>
      <Row>
        <Col md={7}>
          <InputGroup className="mb-3 mt-2">
            <Form.Control
              placeholder="Type category, product, or brand name"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            &nbsp;&nbsp;
            <Button variant="primary" style={{marginTop:"0px"}}>
              <FaSearch />
            </Button>
          </InputGroup>
        </Col>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        {/* <Col md={2}>
          <div className="right-options">
            <ul>
              <li>
                <Button className="btn btn-solid" onClick={() => window.history.back()}>
                  Close
                </Button>
              </li>
            </ul>
          </div>
        </Col> */}
      </Row>
      <div style={{ overflowY: "scroll", height: "90vh", overflowX: "hidden" }}>
        {loading ? (
          <div
            className="d-flex justify-content-center align-items-center"
            style={{ height: "200px" }}
          >
            <div
              className="spinner-border text-primary"
              style={{ width: "3rem", height: "3rem" }}
              role="status"
            >
              <span className="visually-hidden">Loading...</span>
            </div>
          </div>
        ) : (
          <>
            <Row className="g-3">
            {Array.isArray(filteredProducts) && filteredProducts.length > 0 ? (
                    filteredProducts.map((product) => (
                      <Col lg={4} md={6} key={product.product_id}>
                        <Card className="text-center border" style={{ height: "150px", backgroundColor: "#dee3d6" }}>
                          <Card.Body>
                            <Card.Title style={{ fontSize: "12px", color: "black" }}>
                              {product.product_name}
                            </Card.Title>
                            <Card.Title style={{ fontSize: "12px" }}>{product.product_code}</Card.Title>
                            <Card.Text style={{ fontSize: "11px", fontWeight: "bold" }}>
                              Price: <BiRupee style={{ fontSize: "11px" }} />
                              {product.sell_price} <br />
                              Stock:
                              <span
                                style={{
                                  backgroundColor: product.stock > 10 ? "green" : "red",
                                  color: "white",
                                  padding: "3px 8px",
                                  borderRadius: "5px",
                                  fontSize: "12px",
                                  fontWeight: "bold",
                                  marginLeft: "5px",
                                  display: "inline-block",
                                }}
                              >
                                {product.stock}
                              </span>
                            </Card.Text>
                          </Card.Body>
                        </Card>
                      </Col>
                    ))
                  ) : (
                    <p style={{ textAlign: "center", fontWeight: "bold" }}>No products found</p>
                  )}

            </Row>
          </>
        )}
      </div>


    </Col>
      </Row>
      {/* -------------Customer Add Modal  Start --------------- */}
                <Modal show={show} onHide={handleClose} centered>
                  <Modal.Header closeButton>
                    <Modal.Title>Add Customer</Modal.Title>
                  </Modal.Header>
                  <Modal.Body>
                    <Form onSubmit={handleSubmit}>
                      {/* Customer Name */}
                      <Form.Group className="mb-3">
                        <Form.Label>Customer Name</Form.Label>
                        <Form.Control
                          type="text"
                          name="customerName"
                          value={formData.customerName}
                          onChange={handleChange}
                          placeholder="Enter Customer Name"
                          required
                        />
                      </Form.Group>

                      <Form.Group className="mb-3">
                        <Form.Label>Phone Number</Form.Label>
                        <Form.Control
                          type="text"
                          name="phonenumber"
                          value={formData.phonenumber}
                          onChange={handleChange}
                          placeholder="Enter Phone Number"
                          required
                          maxLength={10} 
                        />
                      </Form.Group>

                     

                      {/* Address */}
                      <Form.Group className="mb-3">
                        <Form.Label>Address</Form.Label>
                        <Form.Control
                          as="textarea"
                          name="address"
                          value={formData.address}
                          onChange={handleChange}
                          placeholder="Enter Address"
                          rows={3}
                         
                        />
                      </Form.Group>
                      <Form.Group className="mb-3">
                        <Form.Label>State</Form.Label>
                        <Form.Control
                          type="text"
                          name="state"
                          value={formData.state}
                          onChange={handleChange}
                          placeholder="Enter State"
                          
                        />
                      </Form.Group>


                      {/* GSTIN/UIN */}
                      <Form.Group className="mb-3">
                        <Form.Label>GSTIN/UIN</Form.Label>
                        <Form.Control
                          type="text"
                          name="gstin"
                          value={formData.gstin}
                          onChange={handleChange}
                          placeholder="Enter GSTIN/UIN"
                          maxLength = {15}
                        />
                      </Form.Group>

                      {/* Submit Button */}
                      <Button variant="success" type="submit">
                        Submit
                      </Button>
                    </Form>
                  </Modal.Body>
                </Modal>
                {/* -------------Customer Add Modal  End --------------- */}
    </Container>
  );
};

export default POS;
