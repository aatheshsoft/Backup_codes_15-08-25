import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Logo from'../Assets/sriajay-logo.png'
import axios from 'axios';


const Login = () => {
    const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

    const navigate = useNavigate();
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');
    
        if (!API_BASE_URL) {
            console.error('API_BASE_URL is not defined.');
            setError('Internal configuration error.'); 
            return;
        }
    
        try {
            const response = await axios.post(
                `${API_BASE_URL}login.php`,
                { email, password },
                { headers: { 'Content-Type': 'application/json' } }
            );
    
            console.log('Raw API Response:', response.data);
    
            let responseData = response.data;
    
            // Ensure responseData is an object
            if (typeof responseData === 'string') {
                if (responseData.startsWith('testdata')) {
                    responseData = responseData.replace(/^testdata/, '');
                }
                try {
                    responseData = JSON.parse(responseData);
                } catch (err) {
                    console.error('Error parsing response JSON:', err);
                    setError('Invalid response from server.');
                    return;
                }
            }
    
            console.log('Parsed API Response:', responseData);
    
            if (responseData?.head?.msg === 'success') {
                localStorage.setItem('user_id', JSON.stringify(responseData.body.user_id));
                localStorage.setItem('user_name', JSON.stringify(responseData.body.name));
    
                navigate('/home');
            } else {
                setError(responseData.head?.msg || 'Invalid email or password');
            }
        } catch (error) {
            console.error('Login Error:', error.response?.data || error.message);
            setError(error.response?.data?.head?.msg || 'An error occurred while logging in.');
        }
    };
    

    return (
        <section className="log-in-section background-image-2 section-b-space">
           

            <div className="container w-100">
            <a href="#" className="logo-login">
                <img src={Logo} className="img-fluid" alt="Logo" />
            </a>
                <div className="row">
                    <div className="col-xxl-6 col-xl-5 col-lg-6 d-lg-block d-none ms-auto">
                        <div className="image-contain">
                            <img src="assets/images/log-in.png" className="img-fluid" alt="Login Visual" />
                        </div>
                    </div>

                    <div className="col-xxl-4 col-xl-5 col-lg-6 col-sm-8 mx-auto">
                        <div className="log-in-box">
                            <div className="log-in-title">
                                <h3>Welcome To  Smart POS </h3>
                                <h4>Log In Your Account</h4>
                            </div>

                            <div className="input-box">
                                <form className="row g-4" onSubmit={handleSubmit}>
                                    <div className="col-12">
                                        <div className="form-floating theme-form-floating log-in-form">
                                            <input
                                                type="email"
                                                className="form-control"
                                                id="email"
                                                placeholder="Email Address"
                                                value={email}
                                                onChange={(e) => setEmail(e.target.value)}
                                                required
                                            />
                                            <label htmlFor="email">Email Address</label>
                                        </div>
                                    </div>

                                    <div className="col-12">
                                        <div className="form-floating theme-form-floating log-in-form">
                                            <input
                                                type="password"
                                                className="form-control"
                                                id="password"
                                                placeholder="Password"
                                                value={password}
                                                onChange={(e) => setPassword(e.target.value)}
                                                required
                                            />
                                            <label htmlFor="password">Password</label>
                                        </div>
                                    </div>

                                    {error && (
                                        <div className="col-12">
                                            <p style={{ color: 'red', textAlign: 'center' }}>{error}</p>
                                        </div>
                                    )}

                                    <div className="col-12">
                                        <button
                                            className="btn btn-animation w-100 justify-content-center"
                                            type="submit"
                                        >
                                            Log In
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default Login;
