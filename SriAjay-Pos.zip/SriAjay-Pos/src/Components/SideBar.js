import React, { useState, useEffect } from "react";
import { NavLink } from "react-router-dom";
import { FaUser, FaClipboardList, FaShoppingCart, FaBars } from "react-icons/fa";
import { RiShoppingBag4Fill } from "react-icons/ri";
import { MdOutlineDashboard } from "react-icons/md";
import { FiMonitor } from "react-icons/fi";
import { IoIosArrowForward } from "react-icons/io"; // Import the arrow icon
import { TbCategory2 } from "react-icons/tb";
import { BiSolidPurchaseTag } from "react-icons/bi";
import { FaUsersRectangle } from "react-icons/fa6";

import { TbBrandAuth0 } from "react-icons/tb";
import "../Pages/Sidebar.css";
import Logo from "../Assets/sriajay-logo.png";
import axios from "axios";
import { LuWeight } from "react-icons/lu";


const SideBar = () => {
  const [isOpen, setIsOpen] = useState(true);
  const [permissions, setPermissions] = useState({});
  const [isReportOpen, setIsReportOpen] = useState(false); // State to handle report dropdown
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

  const toggleSidebar = () => {
    setIsOpen(!isOpen);
  };

  // Toggle the report dropdown
  const toggleReportMenu = () => {
    setIsReportOpen(!isReportOpen);
  };

  useEffect(() => {
    let userId = localStorage.getItem("user_id");
  
    if (!userId) {
      console.error("No user ID found. Please log in again.");
      return;
    }
  
    userId = userId.replace(/^"|"$/g, ''); // Remove extra double quotes if they exist
  
    const fetchPermissions = async () => {
      try {
        console.log("Sending API request with user_id:", userId);
  
        const response = await axios.post(
          `${API_BASE_URL}employee_login_previllage.php`,
          { user_id: userId }, // Ensure correct format
          {
            headers: {
              "Content-Type": "application/json",
              "Accept": "application/json",
            },
          }
        );
  
        console.log("API Fixed Response:", response.data);
  
        if (response.data.head.code === 200 && response.data.body.length > 0) {
          setPermissions(response.data.body[0]);
        } else {
          // alert("Invalid Username and Password. Please check your credentials.");
        }
      } catch (error) {
        alert("API Error: Unable to fetch permissions.");
        console.error("API Error:", error);
      }
    };
  
    fetchPermissions();
  }, []);

  return (
    <div className="page-wrapper compact-wrapper" id="pageWrapper">
      <div className="page-body-wrapper">
        <div className={`sidebar-container1 ${isOpen ? "open" : "collapsed"}`}>
          <div className="sidebar-wrapper">
            <div className="sidebar-toggle1">
              {isOpen && (
                <NavLink to="/home" title="logo">
                  <img src={Logo} alt="logo" style={{height:"75px",width:"210px"}}/>
                </NavLink>
              )}
&nbsp;&nbsp;

              <button onClick={toggleSidebar} className="toggle-btn1">
                {isOpen ? (
                  <i className="ri-apps-line status_toggle middle sidebar-toggle"></i>
                ) : (
                  <FaBars />
                )}
              </button>
            </div>

            <nav className="sidebar-nav1">
              <ul>
                <NavLink to="/home" className={({ isActive }) => (isActive ? "active" : "")}>
                  <li>
                    <MdOutlineDashboard />
                    {isOpen && <span>Dashboard</span>}
                  </li>
                </NavLink>

                {/* Customer Menu Item */}
                {permissions.customer === "1" && (
                  <NavLink to="/customerlist" className={({ isActive }) => (isActive ? "active" : "")}>
                    <li>
                      <FaUser />
                      {isOpen && <span>Customer</span>}
                    </li>
                  </NavLink>
                )}

                {permissions.category === "1" && (
                    <NavLink to="/maincategory" className={({ isActive }) => (isActive ? "active" : "")}>
                    <li>
                    <TbCategory2 />
                    {isOpen && <span>Category</span>}
                    </li>
                  </NavLink>
                )}
                {permissions.unit === "1" && (
                 <NavLink to="/unit" className={({ isActive }) => (isActive ? "active" : "")}>
                    <li>
                    <LuWeight />

                    {isOpen && <span>Unit</span>}
                    </li>
                  </NavLink>
                )}
                {/* {permissions.brand === "1" && (
                  <NavLink to="/brand" className={({ isActive }) => (isActive ? "active" : "")}>
                    <li>
                    <TbBrandAuth0 />
                      {isOpen && <span> Brand</span>}
                    </li>
                  </NavLink>
                )} */}

                {/* Product Menu Item */}
                {permissions.product === "1" && (
                  <NavLink to="/products" className={({ isActive }) => (isActive ? "active" : "")}>
                    <li>
                      <RiShoppingBag4Fill />
                      {isOpen && <span>Products</span>}
                    </li>
                  </NavLink>
                )}
                {permissions.supplier === "1" && (
                  <NavLink to="/supplier" className={({ isActive }) => (isActive ? "active" : "")}>
                    <li>
                    <FaUsersRectangle />


                    {isOpen && <span>Supplier</span>}
                    </li>
                  </NavLink>
                )}
                {permissions.purchase_list === "1" && (
                  <NavLink to="/purchaselist" className={({ isActive }) => (isActive ? "active" : "")}>
                    <li>
                    <BiSolidPurchaseTag />

                      {isOpen && <span>Purchase List</span>}
                    </li>
                  </NavLink>
                  )}

                {/* POS Menu Item */}
                {permissions.pos === "1" && (
                    <NavLink to="/pos" className={({ isActive }) => (isActive ? "active" : "")}>
                       <li>
                          <FiMonitor />
                             {isOpen && <span>POS</span>}
                               </li>
                      </NavLink>
                )}
                {/* Orders Menu Item */}

                {permissions.orders === "1" && (
                  <NavLink to="/orderlist" className={({ isActive }) => (isActive ? "active" : "")}>
                    <li>
                      <FaShoppingCart />
                      {isOpen && <span>Sales</span>}
                    </li>
                  </NavLink>
                )}

                {/* Cancel Orders Menu Item */}
               {/*  {permissions.cancel_orders === "1" && (
                  <NavLink to="/cancelorder" className={({ isActive }) => (isActive ? "active" : "")}>
                    <li>
                      <ImCancelCircle />
                      {isOpen && <span>Cancel Order</span>}
                    </li>
                  </NavLink>
                )} */}

                {/* Report Section */}
                <li onClick={toggleReportMenu} className="report-menu">
                  <FaClipboardList />
                  {isOpen && <span>Reports</span>}
                  {/* Arrow Icon */}
                  <IoIosArrowForward
                    className={`arrow-icon ${isReportOpen ? "open" : ""}`} // Rotate the arrow when dropdown is open
                  />
                </li>
                {isReportOpen && (
                  <>
                  <ul className="report-dropdown">
                     {permissions?.payment_report === "1" && (
                    <NavLink to="/paymentpending" className={({ isActive }) => (isActive ? "active" : "")}>
                      <li style={{fontSize:"14px"}}>
                        
                          {isOpen && <span> -  Payment Pending Report</span>}
                      </li>
                    </NavLink>
                     )}
                  
                  </ul>
                  <ul className="report-dropdown">
                  {permissions?.stock_report === "1" && (
                 <NavLink to="/stock" className={({ isActive }) => (isActive ? "active" : "")}>
                   <li style={{fontSize:"14px"}}>
                     
                       {isOpen && <span> -  Stock Report</span>}
                   </li>
                 </NavLink>
                  )}
               
               </ul>

               <ul className="report-dropdown">
                  {permissions?.gst_report === "1" && (
                 <NavLink to="/gstreport" className={({ isActive }) => (isActive ? "active" : "")}>
                   <li style={{fontSize:"14px"}}>
                     
                       {isOpen && <span> -  GST Report</span>}
                   </li>
                 </NavLink>
                  )}
               
               </ul>
               </>
                )}

                
              </ul>
            </nav>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SideBar;
