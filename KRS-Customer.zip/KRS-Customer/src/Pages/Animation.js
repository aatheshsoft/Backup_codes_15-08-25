import React, { useEffect, useRef } from 'react';

const Animation = () => {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    let w, h;
    const particles = [];
    const rockets = [];
    const probability = 0.02; // Probability for fireworks
    const rocketProbability = 0.01; // Probability for rocket
    let xPoint, yPoint;

    const resizeCanvas = () => {
      w = canvas.width = window.innerWidth;
      h = canvas.height = window.innerHeight;
    };

    const updateWorld = () => {
      update();
      paint();
      requestAnimationFrame(updateWorld);
    };

    const update = () => {
      // Create fireworks at random locations
      if (particles.length < 500 && Math.random() < probability) {
        createFirework();
      }

      // Create rockets from the bottom of the screen
      if (rockets.length < 10 && Math.random() < rocketProbability) {
        createRocket();
      }

      // Update particles (fireworks)
      const aliveParticles = [];
      for (let i = 0; i < particles.length; i++) {
        if (particles[i].move()) {
          aliveParticles.push(particles[i]);
        }
      }
      particles.length = 0;
      particles.push(...aliveParticles);

      // Update rockets
      const aliveRockets = [];
      for (let i = 0; i < rockets.length; i++) {
        if (rockets[i].move()) {
          aliveRockets.push(rockets[i]);
        } else {
          // Create an explosion when the rocket reaches its peak
          createExplosion(rockets[i].x, rockets[i].y);
        }
      }
      rockets.length = 0;
      rockets.push(...aliveRockets);
    };

    const paint = () => {
      ctx.clearRect(0, 0, w, h); // Clear the canvas for each frame
      ctx.globalCompositeOperation = 'lighter'; // For glowing effect

      // Draw all particles (fireworks)
      for (const particle of particles) {
        particle.draw(ctx);
      }

      // Draw all rockets
      for (const rocket of rockets) {
        rocket.draw(ctx);
      }
    };

    // Create random firework particles
    const createFirework = () => {
      xPoint = Math.random() * (w - 200) + 100;
      yPoint = Math.random() * (h - 200) + 100;
      const nFire = Math.random() * 50 + 100;
      const color = getRandomColor();

      for (let i = 0; i < nFire; i++) {
        const particle = new Particle(xPoint, yPoint, color);
        particles.push(particle);
      }
    };

    // Create a rocket that shoots up
    const createRocket = () => {
      const rocket = new Rocket();
      rockets.push(rocket);
    };

    // Create an explosion after a rocket reaches its peak
    const createExplosion = (x, y) => {
      const nFire = Math.random() * 50 + 50;
      const color = getRandomColor();
      for (let i = 0; i < nFire; i++) {
        const particle = new Particle(x, y, color);
        particle.vx = (Math.random() - 0.5) * 10;
        particle.vy = (Math.random() - 0.5) * 10;
        particles.push(particle);
      }
    };

    // Helper function to get random color
    const getRandomColor = () => {
      const red = Math.floor(Math.random() * 255);
      const green = Math.floor(Math.random() * 255);
      const blue = Math.floor(Math.random() * 255);
      return `rgb(${red},${green},${blue})`;
    };

    // Particle class representing firework sparks
    function Particle(x, y, color) {
      this.w = this.h = Math.random() * 4 + 1;
      this.x = x - this.w / 2;
      this.y = y - this.h / 2;
      this.vx = (Math.random() - 0.5) * 10;
      this.vy = (Math.random() - 0.5) * 10;
      this.alpha = Math.random() * 0.5 + 0.5;
      this.color = color;
    }

    Particle.prototype = {
      gravity: 0.05,
      move: function () {
        this.x += this.vx;
        this.vy += this.gravity;
        this.y += this.vy;
        this.alpha -= 0.01;
        if (this.x <= -this.w || this.x >= w || this.y >= h || this.alpha <= 0) {
          return false;
        }
        return true;
      },
      draw: function (c) {
        c.save();
        c.beginPath();
        c.arc(this.x, this.y, this.w, 0, Math.PI * 2);
        c.fillStyle = this.color;
        c.globalAlpha = this.alpha;
        c.closePath();
        c.fill();
        c.restore();
      }
    };

    // Rocket class representing rockets that rise up and explode
    function Rocket() {
      this.w = this.h = 5;
      this.x = Math.random() * w;
      this.y = h;
      this.vx = (Math.random() - 0.5) * 2;
      this.vy = -(Math.random() * 10 + 15);
      this.alpha = 1;
      this.color = getRandomColor();
    }

    Rocket.prototype = {
      move: function () {
        this.x += this.vx;
        this.y += this.vy;
        this.alpha -= 0.005; // Slowly disappear
        if (this.y < h * 0.3 || this.alpha <= 0) {
          return false; // Rocket reaches its peak and disappears
        }
        return true;
      },
      draw: function (c) {
        c.save();
        c.beginPath();
        c.arc(this.x, this.y, this.w, 0, Math.PI * 2);
        c.fillStyle = this.color;
        c.globalAlpha = this.alpha;
        c.closePath();
        c.fill();
        c.restore();
      }
    };

    const init = () => {
      window.addEventListener('resize', resizeCanvas);
      resizeCanvas();
      requestAnimationFrame(updateWorld);
    };

    init();
    
    return () => {
      window.removeEventListener('resize', resizeCanvas);
    };
  }, []);

  return <canvas ref={canvasRef} style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', zIndex: 1, pointerEvents: 'none' }} />;
};

export default Animation;
