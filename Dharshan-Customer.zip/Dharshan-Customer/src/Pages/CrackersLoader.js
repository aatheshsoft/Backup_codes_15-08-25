import React, { useState, useEffect } from 'react';
import './CrackersLoader.css';

function CrackersLoader({ duration = 3000, onFinish }) {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
      if (onFinish) {
        onFinish();
      }
    }, duration);

    return () => clearTimeout(timer);
  }, [duration, onFinish]);

  if (!isLoading) return null;

  return (
    <div className="loader-container">
      {/* Large Spinner */}
      <div className="large-spinner"></div>

      {/* Animated Letters */}
      <div className="txt-loading">
        {[
          "D", "H", "A", "R", "S", "A", "N",
          "C", "R", "A", "C", "K", "E", "R", "S"
        ].map((letter, index) => (
          <span
            key={index}
            className="letters-loading"
            style={{ animationDelay: `${index * 100}ms` }}
          >
            {letter}
          </span>
        ))}
      </div>
    </div>
  );
}

export default CrackersLoader;
