import React,{useState,useEffect} from 'react'
import Header from '../Components/Header';
import Footer from '../Components/Footer';


const Contact = () => {
const [adminData, setAdminData] = useState({});
	useEffect(() => {
		  // Fetch API data
		  const fetchFooterData = async () => {
			try {
			  const response = await fetch('https://easya.in/customerapp/footer.php', {
				method: 'POST',
				headers: {
				  'Content-Type': 'application/json',
				},
			  });
	  
			  const data = await response.json();
			  if (data.head.code === 200) {
				setAdminData(data.body.admin_data || {});
			  }
			} catch (error) {
			  console.error('Error fetching footer data:', error);
			}
		  };
	  
		  fetchFooterData();
		}, []);
		  useEffect(() => {
			  window.scrollTo(0, 0);
			}, []);
  return (
    <>
    <div className="common-home res layout-home1">
      <div id="wrapper" className="wrapper-full banners-effect-7">
        <Header />
        <div class="main-container container">
		<ul class="breadcrumb">
			<li><a href="index.html"><i class="fa fa-home"></i></a></li>
			<li>Contact us</li>			
		</ul>
		
		<div class="row">
			<div id="content" class="col-sm-12">
				{/* <div class="page-title">
					<h2>Contact Us</h2>
				</div> */}
				
				
{/* 				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2948.8442639328655!2d-71.10008329902021!3d42.34584359264178!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89e379f63dc43ccb%3A0xa15d5aa87d0f0c12!2s4+Yawkey+Way%2C+Boston%2C+MA+02215!5e0!3m2!1sen!2s!4v1475081210943" width="100%" height="350" frameborder="0" style={{border:"0"}} allowfullscreen></iframe>
 */}				
 				<div class="info-contact clearfix">
					<div class="col-lg-4 col-sm-4 col-xs-12 info-store">
						<div class="row">
							<div class="name-store">
								<h3>Contact Address</h3>
							</div>
							<address>
								<div class="address clearfix form-group">
									<div class="icon">
										<i class="fa fa-home"></i>
									</div>
									<div class="text"><strong>Saravana Embassy</strong> 
									</div>
								</div>
								<div class="phone form-group">
									<div class="icon">
										<i class="fa fa-phone"></i>
									</div>
									<div class="text"><strong>Phone :</strong>{adminData.phonenumber} </div><br />
									<div class="icon">
										<i class="fa fa-envelope"></i>
									</div>
									<div class="text"><strong>Email Id: </strong>{adminData.email}</div>
									
								</div>
								
							</address>
						</div>
					</div>
					<div class="col-lg-8 col-sm-8 col-xs-12 contact-form">
						<form action="" method="post" enctype="multipart/form-data" class="form-horizontal">
							<fieldset>
								<legend>Contact Form</legend>
								<div class="form-group required">
							<label class="col-sm-2 control-label" for="input-name">Your Name</label>
							<div class="col-sm-10">
								<input type="text" name="name" value="" id="input-name" class="form-control" />
								</div>
							</div>
							<div class="form-group required">
								<label class="col-sm-2 control-label" for="input-email">E-Mail Address</label>
								<div class="col-sm-10">
									<input type="text" name="email" value="" id="input-email" class="form-control" />
									</div>
								</div>
								<div class="form-group required">
									<label class="col-sm-2 control-label" for="input-enquiry">Enquiry</label>
									<div class="col-sm-10">
										<textarea name="enquiry" rows="10" id="input-enquiry" class="form-control"></textarea>
									</div>
								</div>
							</fieldset>
							<div class="buttons">
								<div class="pull-right">
									<button class="btn btn-default buttonGray" type="submit">
										<span>Submit</span>
									</button>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
    <Footer />
      </div>
    </div>
</>
  )
}

export default Contact