import React, { useState,useEffect } from 'react';
import Header from '../Components/Header';
import Footer from '../Components/Footer';



const Aboutus = () => {

	
	  useEffect(() => {
		  window.scrollTo(0, 0);
		}, []);

  return (
    <>
    <div className="common-home res layout-home1">
      <div id="wrapper" className="wrapper-full banners-effect-7">
        <Header />
        <div class="main-container container">
		<ul class="breadcrumb">
			<li><a href="index.html"><i class="fa fa-home"></i></a></li>
			<li>About Us</li>
		</ul>
		
		<div class="row">
			<div id="content" class="col-sm-12">
			
				<div class="about-us about-demo-1">
					<div class="row">
						
						<div class="col-lg-12 col-md-12 about-info">
							<h2 class="about-title"><span>About Us</span></h2>
							<div class="about-text">
							<div className="p-6 bg-gray-100 rounded-lg shadow-lg">
									<h2 className="text-2xl font-bold text-gray-800 mb-4">About Our Company</h2>
									<p className="text-gray-700">
										Since 1983, <strong>Saravana Embassy</strong> has been the biggest home appliances showroom,
										selling top international and Indian brands in Sivakasi, Virudhunagar District, Tamilnadu.
										We showcase all major top brands of electronic products, including:
									</p>
									<ul className="list-disc list-inside mt-2 text-gray-700">
										<li>TV</li>
										<li>Refrigerator</li>
										<li>Washing Machine</li>
										<li>Air Conditioner</li>
										<li>Fans</li>
										<li>Mixie</li>
										<li>Grinder</li>
										<li>Inverter & Batteries</li>
										<li>Furniture</li>
										<li>Mattress</li>
										<li>Dining Table</li>
									</ul>
									
									<h3 className="text-xl font-semibold text-gray-800 mt-6">Why Choose Us?</h3>
									<ul className="list-disc list-inside mt-2 text-gray-700">
										<li>Top quality branded products</li>
										<li>Best customer service</li>
										<li>No.1 Showroom</li>
									</ul>
									
									<h3 className="text-xl font-semibold text-gray-800 mt-6">Customer Satisfaction</h3>
									<p className="text-gray-700">
										Customer satisfaction is one of our core mottos. We ensure customer orders, demos,
										and services are handled with utmost care by booking calls with respective
										company customer care.
									</p>
									
									<h3 className="text-xl font-semibold text-gray-800 mt-6">Our Sales Team</h3>
									<p className="text-gray-700">
										Our team has extensive knowledge about all our products. We understand customer
										requirements and explain features and specifications in detail. We also arrange EMI options
										and offer maximum discounts. We are open all weekdays from 9:30 AM to 9:00 PM.
										<br /> <strong>Happy customers are our priority!</strong>
									</p>
									</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
    <Footer />
      </div>
    </div>
    </>
  )
}

export default Aboutus