import React, { useEffect } from "react";
import Header from "../Components/Header";
import Footer from "../Components/Footer";

const CancellationPolicy = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <>
      <div className="common-home res layout-home1">
        <div id="wrapper" className="wrapper-full banners-effect-7">
          <Header />
          <div class="main-container container">
            <ul class="breadcrumb">
              <li>
                <a href="index.html">
                  <i class="fa fa-home"></i>
                </a>
              </li>
              <li>Refund Policy</li>
            </ul>
            <div class="row">
              <div id="content" class="col-sm-12">
              <div className="container mt-4">
      <h2>Returns</h2>
      <p>
        Our policy lasts <strong>7 days</strong>. If 7 days have gone by since your
        purchase, unfortunately, we can’t offer you a refund or exchange.
      </p>
      <h4>Required Documentation:</h4>
      <p>
        Please provide a video of the packing process and the courier handover.
        Submit your Government ID proof and one of the following bank documents:
      </p>
      <ul>
        <li>Bank statement</li>
        <li>Passbook front page</li>
        <li>Cancelled cheque</li>
      </ul>
      <p>Send the required documentation via email and WhatsApp.</p>
      <h4>Eligibility for Return</h4>
      <p>
        To be eligible for a return, your item must be unused and in the same
        condition that you received it. It must also be in the original packaging.
      </p>
      <h4>Non-returnable items:</h4>
      <ul>
        <li>Gift Items</li>
        <li>Breakable Products</li>
        <li>Some health and personal care items</li>
      </ul>
      <p>
        To complete your return, we require a receipt or proof of purchase. Any
        item not in its original condition, damaged, or missing parts for reasons
        not due to our error is not eligible.
      </p>
      <h2>Refunds</h2>
      <p>
        Once your return is received and inspected, we will send you an email to
        notify you of the approval or rejection of your refund.
      </p>
      <p>
        If approved, your refund will be processed, and a credit will automatically
        be applied to your Bank Account within a certain amount of days.
      </p>
      <h4>Late or missing refunds</h4>
      <p>
        If you haven’t received a refund yet, first check your bank account again.
        Then contact your Banker, as it may take some time before your refund is
        officially posted.
      </p>
      <p>
        If you’ve done all of this and still haven’t received your refund, please
        contact us at <a href="mailto:easyashopping@gmail.com">easyashopping@gmail.com </a>.
      </p>
      <h4>Sale items</h4>
      <p>Only regular priced items may be refunded, unfortunately sale items cannot be refunded.</p>
      <h2>Shipping</h2>
      <p>
        To return your product, mail it to :
       
        <strong> easyashopping@gmail.com </strong>
      </p>
      <p>
        You will be responsible for paying your own shipping costs for returning
        your item. Shipping costs are non-refundable. If you receive a refund,
        the cost of return shipping will be deducted.
      </p>
      <p>
        Depending on where you live, the time it may take for your exchanged
        product to reach you may vary.
      </p>
    </div>
    </div>
            </div>
          </div>
          <Footer />
        </div>
      </div>
    </>
  );
};

export default CancellationPolicy;
