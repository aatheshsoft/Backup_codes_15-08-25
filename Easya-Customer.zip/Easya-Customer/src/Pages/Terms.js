import React, { useEffect } from "react";
import Header from "../Components/Header";
import Footer from "../Components/Footer";

const Terms = () => {

    
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <>
      <div className="common-home res layout-home1">
        <div id="wrapper" className="wrapper-full banners-effect-7">
          <Header />
          <div class="main-container container">
            <ul class="breadcrumb">
              <li>
                <a href="index.html">
                  <i class="fa fa-home"></i>
                </a>
              </li>
              <li>Terms & Conditions</li>
            </ul>
            <div class="row">
              <div id="content" class="col-sm-12">
                <div className="container py-4">
                  <h2 className="text-center">TERMS OF SERVICE AGREEMENT</h2>
                  <p>
                    PLEASE READ THIS TERMS OF SERVICE AGREEMENT CAREFULLY. BY
                    USING THIS WEBSITE OR ORDERING PRODUCTS FROM THIS WEBSITE
                    YOU AGREE TO BE BOUND BY ALL OF THE TERMS AND CONDITIONS OF
                    THIS AGREEMENT.
                  </p>
                  <h4>I. PRODUCTS</h4>
                  <p>
                    <strong>Terms of Offer:</strong> This Website offers for
                    sale certain products (the "Products"). By placing an order
                    for Products through this Website, you agree to the terms
                    set forth in this Agreement.
                  </p>
                  <p>
                    <strong>Customer Solicitation:</strong> Unless you notify
                    our third party call center reps or direct  Saravana Emabassy sales reps,
                    while they are calling you, of your desire to opt out from
                    further direct company communications and solicitations, you
                    are agreeing to continue to receive further emails and call
                    solicitations from  Saravana Emabassy and its designated in-house or
                    third-party call team(s).
                  </p>
                  <p>
                    <strong>Opt-Out Procedure:</strong> We provide three easy
                    ways to opt out of future solicitations:
                  </p>
                  <ol>
                    <li>
                      Use the opt-out link found in any email solicitation you
                      receive.
                    </li>
                    <li>
                      Send your opt-out request via email to easyashopping@gmail.com.
                    </li>
                    <li>
                      Send a written request to  Saravana Emabassy, 39, Sivan Sannathi
                      Street, Sivakasi – 626123, Tamilnadu.
                    </li>
                  </ol>
                  <h4>II. WEBSITE</h4>
                  <p>
                    <strong>Content & Intellectual Property:</strong> This
                    Website also offers information, both directly and through
                    indirect links to third-party websites.  Saravana Emabassy does not
                    always create the information offered on this Website;
                    instead, it is often gathered from other sources.
                  </p>
                  <p>
                    <strong>Use of Website:</strong> You agree not to use the
                    Website for illegal purposes. You will abide by all
                    applicable laws, not interfere with others' use of the
                    Website, and not resell material from the Website.
                  </p>
                  <h4>III. DISCLAIMER OF WARRANTIES</h4>
                  <p>
                    YOUR USE OF THIS WEBSITE AND/OR PRODUCTS IS AT YOUR SOLE
                    RISK. THE WEBSITE AND PRODUCTS ARE OFFERED ON AN "AS IS" AND
                    "AS AVAILABLE" BASIS.
                  </p>
                  <h4>IV. LIMITATION OF LIABILITY</h4>
                  <p>
                  Saravana Emabassy WILL NOT BE LIABLE FOR ANY DIRECT, INDIRECT,
                    INCIDENTAL, SPECIAL, OR CONSEQUENTIAL DAMAGES RESULTING FROM
                    THE USE OR INABILITY TO USE THE WEBSITE OR PRODUCTS.
                  </p>
                  <h4>V. INDEMNIFICATION</h4>
                  <p>
                    You agree to indemnify and hold harmless  Saravana Emabassy, its
                    affiliates, and employees from any liabilities, claims, or
                    expenses arising from your use of the Website or purchase of
                    Products.
                  </p>
                  <h4>VI. PRIVACY</h4>
                  <p>
                  Saravana Emabassy believes strongly in protecting user privacy. Please
                    refer to our Privacy Policy posted on the Website.
                  </p>
                  <h4>VII. AGREEMENT TO BE BOUND</h4>
                  <p>
                    By using this Website or ordering Products, you acknowledge
                    that you have read and agree to be bound by this Agreement
                    and all terms and conditions on this Website.
                  </p>
                  <h4>VIII. GENERAL</h4>
                  <p>
                    <strong>Governing Law:</strong> This Agreement will be
                    governed by the laws of Tamilnadu. Any claims arising under
                    this Agreement must be brought in Tamilnadu courts.
                  </p>
                  <p>
                    <strong>Termination:</strong>  Saravana Emabassy reserves the right to
                    terminate your access to the Website if it reasonably
                    believes that you have breached any of the terms of this
                    Agreement.
                  </p>
                  <p className="text-center font-weight-bold">
                    BY USING THIS WEBSITE OR ORDERING PRODUCTS FROM THIS WEBSITE
                    YOU AGREE TO BE BOUND BY ALL OF THE TERMS AND CONDITIONS OF
                    THIS AGREEMENT.
                  </p>
                </div>
              </div>
            </div>
          </div>
          <Footer />
        </div>
      </div>
    </>
  );
};

export default Terms;
