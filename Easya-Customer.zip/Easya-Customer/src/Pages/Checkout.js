import React, { useEffect, useState,useContext } from "react";
import { Link } from 'react-router-dom'
import { useNavigate } from 'react-router-dom';
import Footer from '../Components/Footer'
import Header from '../Components/Header'
import axios from "axios";
import { CartContext } from "../Context/CartContext"; // Import the CartContext
import { ClipLoader } from "react-spinners";
import IsLoader from '../Components/IsLoader';

// ============== updated code =========================
// import { useSearchParams } from "react-router-dom";
// import { useRef } from "react";
// import { useEffect } from "react";
// ============== updated code =========================


const Checkout = () => {
	/*
	// ============== updated code =========================
  const [searchParams] = useSearchParams();
  const hasPlacedOrder = useRef(false); // ⛔ won't re-trigger renders
  // payment gateway details
  const status = searchParams.get("status");
  const orderId = searchParams.get("order_id");
  const trackingId = searchParams.get("tracking_id");
  // billing details
  const billing_name = searchParams.get("billing_name");
  const billing_address = searchParams.get("billing_address");
  const billing_city = searchParams.get("billing_city");
  const billing_state = searchParams.get("billing_state");
  const billing_zip = searchParams.get("billing_zip");
  const billing_country = searchParams.get("billing_country");
  const billing_tel = searchParams.get("billing_tel");
  const billing_email = searchParams.get("billing_email");
  // delivery details
  const delivery_name = searchParams.get("delivery_name");
  const delivery_address = searchParams.get("delivery_address");
  const delivery_city = searchParams.get("delivery_city");
  const delivery_state = searchParams.get("delivery_state");
  const delivery_zip = searchParams.get("delivery_zip");
  const delivery_country = searchParams.get("delivery_country");
  const delivery_tel = searchParams.get("delivery_tel");
  const delivery_email = searchParams.get("delivery_email");

  const note = searchParams.get("note");
  console.log(note);
  console.log(trackingId);
   console.log(billing_name);
   
// ============== updated code =========================
*/

  const [addresses, setAddresses] = useState([]);
  const userId = localStorage.getItem('user_id');
//   console.log('Retrieved User ID:', userId);
  const Email = localStorage.getItem('email');
  const [razorpayKey, setRazorpayKey] = useState(null);
  const [loading, setLoading] = useState(false);
  const [isloading1, setIsLoading1] = useState(false);

  const [isLoading, setIsLoading] = useState(true);
  const { cartItems, updateItemQuantity, removeItemFromCart,setCartItems } = useContext(CartContext);
  const [billingDetails, setBillingDetails] = useState({});
  const [deliveryDetails, setDeliveryDetails] = useState({});
  const [comments, setComments] = useState("");
  const [agree, setAgree] = useState(false);
  const navigate=useNavigate();

  const handleCheckboxChange = (e) => {
    setAgree(e.target.checked);
  };

  const subtotal = cartItems.reduce( 
	(acc, item) => (item.stock > 0 ? acc + item.onlinerate * item.qty : acc),
	0
  );
  
  const cgst = cartItems.reduce(
	(acc, item) => (item.stock > 0 ? acc + (item.tax_amt / 2) * item.qty : acc),
	0
  );
  
  const sgst = cartItems.reduce(
	(acc, item) => (item.stock > 0 ? acc + (item.tax_amt / 2) * item.qty : acc),
	0
  );
  
  const total = subtotal + cgst + sgst;
  

//   useEffect(() => {
//     // Fetch Razorpay Key from API
//     axios
//       .get("https://easya.in/customerapp/razorpay_key.php")
//       .then((response) => {
//         if (response.data.head.code === 200) {
//           setRazorpayKey(response.data.body.key);
		 
//         } 
// 		else {
//           alert("Failed to fetch Razorpay Key");
//         }
//       })
//       .catch((error) => {
//         console.error("Error fetching Razorpay Key:", error);
       
//       });
//   }, []);

 

  
  useEffect(() => {
	/*
	// ============== updated code =========================
	console.log("Payment status:", status); // ✅ Here's your response
    // Based on status, trigger next logic
    if (status === "Success" && !hasPlacedOrder.current) {
      // navigate to success screen, clear cart, etc.
	  console.log("ready to connect order API");
	  placeOrder();
	  hasPlacedOrder.current = true; // ✅ prevent second execution
    } else {
      // show error, retry, etc.
	  console.log(`NOT ready to connect order API ${status}`);
	// console.log("not ready to connect order API");
    }
	// ============== updated code =========================
	*/
    // Fetch address details
    const fetchAddresses = async () => {
      try {
        const response = await axios.post(
          "https://easya.in/customerapp/addresslist.php",
          { user_id: userId }
        );
        if (response.data.head.code === 200) {
          setAddresses(response.data.body);
        } else {
          console.error("Failed to fetch addresses:", response.data.head.msg);
        }
      } catch (error) {
        console.error("Error fetching addresses:", error);
      }
    };

    fetchAddresses();
  }, [userId]);	// ============== updated code ======([userId , status])===================


//   const loadRazorpayScript = () => {
// 	return new Promise((resolve) => {
// 	  if (window.Razorpay) {
// 		resolve(true);
// 		return;
// 	  }
// 	  const script = document.createElement("script");
// 	  script.src = "https://checkout.razorpay.com/v1/checkout.js";
// 	  script.async = true;
// 	  script.onload = () => resolve(true);
// 	  script.onerror = () => resolve(false);
// 	  document.body.appendChild(script);
// 	});
//   };
  
const handleonlineOrder = async (mode) => {
	if (!agree) {
	  alert("Please agree to the terms and conditions.");
	  return;
	}
  
	setIsLoading1(true);
  
	const availableItems = cartItems.filter((item) => item.stock > 0);
	if (availableItems.length === 0) {
	  alert("No products available in stock to place the order.");
	  setIsLoading1(false);
	  return;
	}
  
	const orderPayload = {
	  user_id: userId,
	  billing_details: {
		billing_name: billingDetails.name || addresses[0]?.name,
		billing_address: billingDetails.address || addresses[0]?.address,
		billing_city: billingDetails.city || addresses[0]?.city,
		billing_state: billingDetails.state || addresses[0]?.state,
		billing_email: Email,
		billing_phonenumber: billingDetails.phonenumber || addresses[0]?.phonenumber,
		billing_postcode: billingDetails.pincode || addresses[0]?.pincode,
	  },
	  delivery_details: {
		delivery_name: deliveryDetails.shipping_name || addresses[0]?.shipping_name,
		delivery_address: deliveryDetails.shipping_address || addresses[0]?.shipping_address,
		delivery_city: deliveryDetails.shipping_city || addresses[0]?.shipping_city,
		delivery_state: deliveryDetails.shipping_state || addresses[0]?.shipping_state,
		delivery_email: Email,
		delivery_phonenumber: deliveryDetails.shipping_phonenumber || addresses[0]?.shipping_phonenumber,
		delivery_postcode: deliveryDetails.shipping_pincode || addresses[0]?.shipping_pincode,
	  },
	  subtotal: availableItems.reduce((sum, item) => sum + item.onlinerate * item.qty, 0),
	  sgst,
	  cgst,
	  total,
	  note: comments,
	  paymentmode: mode,
	  productdetails: availableItems.map((item) => ({
		product_id: item.product_id,
		product_name: item.product_name,
		qty: item.qty,
		amount: item.onlinerate,
		totalamount: item.onlinerate * item.qty,
		image: item.image,
	  })),
	};
  
	try {
	  // Send order data to your PHP handler for encryption
	  const response = await axios.post("https://easya.in/customerapp/ccavenue_handler.php", JSON.stringify(orderPayload), {
		headers: {
		  "Content-Type": "application/json",
		},
	  });
	  
	  console.log(orderPayload)
	  console.log("payment response" ,response);


	  if (response.data?.head?.code === 200) {
		const { encRequest, accessCode } = response.data.body;
		//Create and submit a dynamic payment form to CCAvenue
		const paymentForm = document.createElement("form");
		paymentForm.method = "post";
		paymentForm.action = "https://secure.ccavenue.com/transaction/transaction.do?command=initiateTransaction";
  
		const encInput = document.createElement("input");
		encInput.type = "hidden";
		encInput.name = "encRequest";
		encInput.value = encRequest;
  
		const accessCodeInput = document.createElement("input");
		accessCodeInput.type = "hidden";
		accessCodeInput.name = "access_code";
		accessCodeInput.value = accessCode;
  
		paymentForm.appendChild(encInput);
		paymentForm.appendChild(accessCodeInput);
		document.body.appendChild(paymentForm);
		paymentForm.submit();


		// const OrderResponse = await axios.post(
		// 	"https://easya.in/customerapp/payment_response.php",
		// 	{},
		// 	{
		// 	  headers: {
		// 		"Content-Type": "application/json",
		// 		"Accept": "application/json",
		// 	  },
		// 	  withCredentials: true, // Ensure cookies are included if needed
		// 	}
		//   );
		  
		//   console.log("Order Response:", OrderResponse.data);
		  
		//   localStorage.setItem('orderresponse', JSON.stringify(OrderResponse.data));
		  
		//   // Check for a successful response
		//   if (OrderResponse.data?.head?.code === 200) {
		// 	const finalizeOrderResponse = await axios.post("https://easya.in/customerapp/order.php", orderPayload);
			
		// 	if (finalizeOrderResponse.data?.head?.code === 200) {
		// 	  alert("Order placed successfully!");
		// 	  setCartItems([]); 
		// 	  localStorage.removeItem("cartItems");
		// 	  navigate("/thanks");
		// 	} else {
		// 	  alert("Order process failed");
		// 	}
		//   } else {
		// 	alert("Payment response failed");
		//   }
		  

		
	  } else {
		alert(" payment initiation failed.");
	  }
	} catch (error) {
	  console.error("Error during payment process:", error.message);
	//   alert("Something went wrong. Please try again.");
	} finally {
	  setIsLoading1(false);
	}
  };
  
  
  




// const handleonlineOrder = async (mode) => {
// 	if (!agree) {
// 	  alert("Please agree to the terms and conditions.");
// 	  return;
// 	}
  
// 	setIsLoading1(true);
  
// 	const availableItems = cartItems.filter((item) => item.stock > 0);
// 	if (availableItems.length === 0) {
// 	  alert("No products available in stock to place the order.");
// 	  setIsLoading1(false);
// 	  return;
// 	}
  
// 	const orderPayload = {
// 	  user_id: userId,
// 	  billing_details: {
// 		billing_name: billingDetails.name || addresses[0]?.name,
// 		billing_address: billingDetails.address || addresses[0]?.address,
// 		billing_city: billingDetails.city || addresses[0]?.city,
// 		billing_state: billingDetails.state || addresses[0]?.state,
// 		billing_email: Email,
// 		billing_phonenumber: billingDetails.phonenumber || addresses[0]?.phonenumber, 
// 		billing_postcode: billingDetails.pincode || addresses[0]?.pincode,
// 	  },
// 	  delivery_details: {
// 		delivery_name: deliveryDetails.shipping_name || addresses[0]?.shipping_name, 
// 		delivery_address: deliveryDetails.shipping_address || addresses[0]?.shipping_address,
// 		delivery_city: deliveryDetails.shipping_city || addresses[0]?.shipping_city,
 // 		delivery_email: Email,
// 		delivery_phonenumber: deliveryDetails.shipping_phonenumber || addresses[0]?.shipping_phonenumber,
// 		delivery_postcode: deliveryDetails.shipping_pincode || addresses[0]?.shipping_pincode,
// 	  },
// 	  subtotal: availableItems.reduce((sum, item) => sum + item.onlinerate * item.qty, 0),
// 	  sgst: sgst,
// 	  cgst: cgst,
// 	  total: total,
// 	  note: comments,
// 	  paymentmode: mode,
// 	  productdetails: availableItems.map((item) => ({
// 		product_id: item.product_id,
// 		product_name: item.product_name,
// 		qty: item.qty,
// 		amount: item.onlinerate,
// 		totalamount: item.onlinerate * item.qty,
// 		image: item.image,
// 	  })),
// 	};
  
// 	try {
// 	  // Step 1: Initiate Payment by sending order details to ccavenue_handler.php
// 	  const response = await axios.post("https://easya.in/customerapp/ccavenue_handler.php", {
// 		amount: total,
// 		email: Email,
// 		user_name:   billingDetails.name || addresses[0]?.name,
// 		mobile:  billingDetails.phonenumber || addresses[0]?.phonenumber,
// 		order_payload: orderPayload,
// 	  });
// 	  const result = response.data.body;
// 	  console.log(result)
// 	  console.log(result.encRequest);
// 	  console.log( result.accessCode);


// 	//   const paymentForm = document.createElement('form');
// 	//   paymentForm.method = 'post';
// 	//   paymentForm.action = 'https://secure.ccavenue.com/transaction/transaction.do?command=initiateTransaction';

	
// 	//   const encInput = document.createElement('input');
// 	//   encInput.type = 'hidden';
// 	//   encInput.name = 'encRequest';
// 	//   encInput.value = result.encRequest;
	
// 	//   const accessCodeInput = document.createElement('input');
// 	//   accessCodeInput.type = 'hidden';
// 	//   accessCodeInput.name = 'access_code';
// 	//   accessCodeInput.value = result.accessCode;
	
// 	//   paymentForm.appendChild(encInput);
// 	//   paymentForm.appendChild(accessCodeInput);
// 	//   document.body.appendChild(paymentForm);
// 	//   paymentForm.submit();
	 
  
// 	} catch (error) {
// 	  console.error("Error during the order process:", error.message);
// 	  alert(error.message || "Something went wrong. Please try again.");
// 	} finally {
// 	  setIsLoading1(false);
// 	}
//   };
  

  
  const handleConfirmOrder = async (mode) => {
	if (!agree) {
	  alert("Please agree to the terms and conditions.");
	  return;
	}
	setLoading(true); // Show loading spinner
  
	// Filter out items with stock 0
	const availableItems = cartItems.filter((item) => item.stock > 0);
  
	if (availableItems.length === 0) {
	  alert("No products available in stock to place the order.");
	  setLoading(false);
	  return;
	}
  
	const orderPayload = {
	  user_id: userId, // Replace with the logged-in user ID
	  billing_details: {
		billing_name: billingDetails.name || addresses[0]?.name,
		billing_address: billingDetails.address || addresses[0]?.address,
		billing_city: billingDetails.city || addresses[0]?.city,
		billing_state: billingDetails.state || addresses[0]?.state,
		billing_email: Email, // Replace with dynamic email
		billing_phonenumber: billingDetails.phonenumber || addresses[0]?.phonenumber,
		billing_postcode: billingDetails.pincode || addresses[0]?.pincode,
	  },
	  delivery_details: {
		delivery_name: deliveryDetails.shipping_name || addresses[0]?.shipping_name,
		delivery_address: deliveryDetails.shipping_address || addresses[0]?.shipping_address,
		delivery_city: deliveryDetails.shipping_city || addresses[0]?.shipping_city,
		delivery_state: deliveryDetails.shipping_state || addresses[0]?.shipping_state,
		delivery_email: Email, // Replace with dynamic email
		delivery_phonenumber: deliveryDetails.shipping_phonenumber || addresses[0]?.shipping_phonenumber,
		delivery_postcode: deliveryDetails.shipping_pincode || addresses[0]?.shipping_pincode,
	  },
	  subtotal: availableItems.reduce((sum, item) => sum + item.onlinerate * item.qty, 0),
	  sgst: sgst,
	  cgst: cgst,
	  total: total,
	  note: comments,
	  paymentmode:mode,
	  productdetails: availableItems.map((item) => ({
		product_id: item.product_id,
		product_name: item.product_name,
		qty: item.qty,
		amount: item.onlinerate,
		totalamount: item.onlinerate * item.qty,
		image:item.image,
	  })),
	};
  
	console.log(orderPayload);
  
	try {
	  const response = await axios.post("https://easya.in/customerapp/order.php", orderPayload);
	  if (response.data?.head?.code === 200) {
		await new Promise((resolve) => setTimeout(resolve, 2000));
		alert("Order placed successfully!");
		setCartItems([]); // If cartItems is managed via state
		localStorage.removeItem("cartItems"); 
		// Navigate to the order confirmation page
		// navigate('/thanks');
		console.log("checking");
		const status = "offline"; // or "Failure", etc.
		navigate(`/thanks?status=${status}`); 
	  } else {
		alert("Failed to place the order. Please try again.");
	  }
	} catch (error) {
	  console.error("Error placing order:", error);
	  alert("An error occurred. Please try again.");
	} finally {
	  setLoading(false); // Stop the loading spinner
	}
  };

  
  useEffect(() => {

	// Simulate a network request or loading process
	const timer = setTimeout(() => setIsLoading(false), 500);
	return () => clearTimeout(timer);
  }, []);

// ===================== updated code ==========================================  

  const redirectToCcavenue = (encRequest, accessCode, actionUrl) => {
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = actionUrl;

    const encInput = document.createElement('input');
    encInput.type = 'hidden';
    encInput.name = 'encRequest';
    encInput.value = encRequest;
    form.appendChild(encInput);

    const accessInput = document.createElement('input');
    accessInput.type = 'hidden';
    accessInput.name = 'access_code';
    accessInput.value = accessCode;
    form.appendChild(accessInput);

    document.body.appendChild(form);
    form.submit();

	
  };

  const initiatePayment = async () => {
	if (!agree) {
	  alert("Please agree to the terms and conditions.");
	  return;
	}
  
	setIsLoading1(true);
  
	const availableItems = cartItems.filter((item) => item.stock > 0);
	if (availableItems.length === 0) {
	  alert("No products available in stock to place the order.");
	  setIsLoading1(false);
	  return;
	}
  
	const orderPayload = {
	  user_id: userId,
	  billing_details: {
		billing_name: billingDetails.name || addresses[0]?.name,
		billing_address: billingDetails.address || addresses[0]?.address,
		billing_city: billingDetails.city || addresses[0]?.city,
		billing_state: billingDetails.state || addresses[0]?.state,
		billing_email: Email,
		billing_phonenumber: billingDetails.phonenumber || addresses[0]?.phonenumber,
		billing_postcode: billingDetails.pincode || addresses[0]?.pincode,
	  },
	  delivery_details: {
		delivery_name: deliveryDetails.shipping_name || addresses[0]?.shipping_name,
		delivery_address: deliveryDetails.shipping_address || addresses[0]?.shipping_address,
		delivery_city: deliveryDetails.shipping_city || addresses[0]?.shipping_city,
		delivery_state: deliveryDetails.shipping_state || addresses[0]?.shipping_state,
		delivery_email: Email,
		delivery_phonenumber: deliveryDetails.shipping_phonenumber || addresses[0]?.shipping_phonenumber,
		delivery_postcode: deliveryDetails.shipping_pincode || addresses[0]?.shipping_pincode,
	  },
	  subtotal: availableItems.reduce((sum, item) => sum + item.onlinerate * item.qty, 0),
	  sgst,
	  cgst,
	  total,
	  note: comments,
	//   paymentmode: mode,
	  paymentmode: "ccavenue",
	  productdetails: availableItems.map((item) => ({
		product_id: item.product_id,
		product_name: item.product_name,
		qty: item.qty,
		amount: item.onlinerate,
		totalamount: item.onlinerate * item.qty,
		image: item.image,
	  })),
	};

    try {
      const res = await fetch('https://easya.in/customerapp/ccavenue_handler.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(orderPayload), // 🔥 FIXED HERE
      });

      const result = await res.json();
      
      if (result.head.code === 200) {
        const { encRequest, access_code, action_url } = result.body;
        // console.log(encRequest);
        // console.log(access_code);
        // console.log(action_url);
        redirectToCcavenue(encRequest, access_code, action_url);
		
      } else {
        alert(result.head.msg);
      }
    } catch (error) {
      console.error('Payment initiation failed:', error);
      alert('Something went wrong');
    }
  };

  /*
   const placeOrder = async () => {
	// if (!agree) {
	//   alert("Please agree to the terms and conditions.");
	//   return;
	// }
  
	setIsLoading1(true);
  
	const availableItems = cartItems.filter((item) => item.stock > 0);
	if (availableItems.length === 0) {
	  alert("No products available in stock to place the order.");
	  setIsLoading1(false);
	  return;
	}
  
	const orderPayload = {
	  // paymentmode: mode,
	  paymentmode: "ccavenue",
	  payment_status:status,
	  payment_orderId:orderId,
	  payment_trackingId:trackingId,
	  user_id: userId,
	  billing_details: {
		billing_name: billing_name,
		billing_address: billing_address,
		billing_city: billing_city,
		billing_state: billing_state,
		billing_email: Email,
		billing_phonenumber: billing_tel,
		billing_postcode: billing_zip,
	  },
	  delivery_details: {
		delivery_name: delivery_name,
		delivery_address: delivery_address,
		delivery_city: delivery_city,
		delivery_state: delivery_state,
		delivery_email: Email,
		delivery_phonenumber: delivery_tel,
		delivery_postcode: delivery_zip,
	  },
	  subtotal: availableItems.reduce((sum, item) => sum + item.onlinerate * item.qty, 0),
	  sgst,
	  cgst,
	  total,
	  // note: comments,
	  note: note,
	
	  productdetails: availableItems.map((item) => ({
		product_id: item.product_id,
		product_name: item.product_name,
		qty: item.qty,
		amount: item.onlinerate,
		totalamount: item.onlinerate * item.qty,
		image: item.image,
	  })),
	};
	console.log(orderPayload);
	
    try {
      const res = await fetch('https://easya.in/customerapp/order.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(orderPayload), // 🔥 FIXED HERE
      });

      const result = await res.json();
      
      if (result.head.code === 200) {
		setCartItems([]); // If cartItems is managed via state
		localStorage.removeItem("cartItems"); 
        // need navigation to thanks page.
		 navigate(`/thanks?status=${status}`); 
		// clear the cart page 
      } else {
        alert(result.head.msg);
		// navigate('/thanks'); 
		console.log(result.head.code);
		console.log(result.head.msg);
      }
    } catch (error) {
      console.error('order placed failed:', error);
      alert('Something went wrong');
    }
	
  };
  */
  
// ===================== updated code end ==========================================
  return (
    <>
	 {isLoading ? (
        <IsLoader />
      ) : (
        <>
<div class="common-home res layout-home1">
  <div id="wrapper" class="wrapper-full banners-effect-7">
    <Header />
    <div class="main-container container">
		<ul class="breadcrumb">
			<li><Link to= '/' ><i class="fa fa-home"></i></Link></li>
			<li><a >Checkout</a></li>
			
		</ul>
		
		<div class="row">
			{/* <!--Middle Part Start--> */}
			<div id="content" class="col-sm-12">
				
			  <h2 class="title">Checkout </h2> 	{/* // ======= updated code (-- Payment {status})======= */}
			  <div class="so-onepagecheckout ">
				  <div class="col-right col-sm-12">
				  <div class="row">
					<div class="col-sm-12">
						<div class="panel panel-default no-padding">
							
							<div className="checkout-addresses">
							{addresses.length > 0 ? (
									addresses.map((address, index) => (
										<div className="row" key={address.address_id}>
										{/* Billing Address */}
										{index === 0 && (
											<div className="col-sm-6 checkout-shipping-methods">
											<div className="panel-heading">
												<h4 className="panel-title">
												<i className="fa fa-book"></i> Billing Address
												</h4>
											</div>
											<div className="panel-body">
												<Link to="/myaccount">
												<div className="buttons">
													<div className="pull-right">
													<button
														type="button"
														className="btn btn-primary"
														id="button-confirm"
													>
														Edit Address 
													</button>
													</div>
												</div>
												</Link>
												<p>{address.name}</p>
												<p>{address.address}</p>
												<p>{address.city}</p>
												<p>{`${address.state} - ${address.pincode}`}</p>
												<p>{address.phonenumber}</p>
											</div>
											</div>
										)}

										{/* Shipping Address */}
										{index === 0 && (
											<div className="col-sm-6 checkout-payment-methods">
											<div className="panel-heading">
												<h4 className="panel-title">
												<i className="fa fa-building"></i> Shipping Address
												</h4>
											</div>
											<div className="panel-body">
												<Link to="/myaccount">
												<div className="buttons">
													<div className="pull-right">
													<button
														type="button"
														className="btn btn-primary"
														id="button-confirm"
													>
														Edit Address
													</button>
													</div>
												</div>
												</Link>
												<p>{address.shipping_name}</p>
												<p>{address.shipping_address}</p>
												<p>{address.shipping_city}</p>
												<p>{`${address.shipping_state} - ${address.shipping_pincode}`}</p>
												<p>{address.shipping_phonenumber}</p>
											</div>
											</div>
										)}
										</div>
									))
									) : (
									<div className="row">
										<div className="col-sm-6 checkout-shipping-methods">
										<div className="panel-heading">
											<h4 className="panel-title">
											<i className="fa fa-book"></i> Billing Address
											</h4>
										</div>
										<div className="panel-body">
											<Link to="/myaccount">
											<div className="buttons">
												<div className="pull-right">
												<button
													type="button"
													className="btn btn-primary"
													id="button-confirm"
												>
													Add Address
												</button>
												</div>
											</div>
											</Link>
										</div>
										</div>
										<div className="col-sm-6 checkout-payment-methods">
										<div className="panel-heading">
											<h4 className="panel-title">
											<i className="fa fa-building"></i> Shipping Address
											</h4>
										</div>
										<div className="panel-body">
											<Link to="/myaccount">
											<div className="buttons">
												<div className="pull-right">
												<button
													type="button"
													className="btn btn-primary"
													id="button-confirm"
												>
													Add Address
												</button>
												</div>
											</div>
											</Link>
										</div>
										</div>
									</div>
									)}

							</div>
						</div>
						
						</div>
					 
												
						<div className="col-md-12">
							<div className="panel panel-default">
								<div className="panel-heading">
								<h4 className="panel-title">
									<i className="fa fa-shopping-cart"></i> Shopping Cart
								</h4>
								</div>
								<div className="panel-body">
								<div className="table-responsive">
									<table className="table table-bordered">
									<thead>
										<tr>
										<td className="text-center">Image</td>
										<td className="text-left">Product Name</td>
										<td className="text-left">Product Code</td>
										<td className="text-left">Quantity</td>
										<td className="text-right">Unit Price</td>
										<td className="text-right">Total</td>
										</tr>
									</thead>
									<tbody>
											{cartItems.length > 0 ? (
												cartItems
												.filter((item) => item.stock > 0) // Filter out items with stock 0
												.map((item) => (
													<tr key={`${item.product_id}-${item.image}`}>
													<td className="text-center">
														<img
														width="60px"
														src={item.image}
														alt={item.product_name}
														className="img-thumbnail"
														/>
													</td>
													<td className="text-left">{item.product_name}</td>
													<td className="text-left">{item.product_code}</td>
													<td className="text-left">
														<div className="input-group btn-block" style={{ minWidth: "100px" }}>
														{item.qty}
														</div>
													</td>
													<td className="text-right">
														<>
														<i className="bi bi-currency-rupee"></i>
														{Number(item.onlinerate || 0).toFixed(2)}
														</>
													</td>
													<td className="text-right">
														<>
														<i className="bi bi-currency-rupee"></i>
														{Number(item.onlinerate * item.qty || 0).toFixed(2)}
														</>
													</td>
													</tr>
												))
											) : (
												<tr>
												<td colSpan="5" className="text-center">
													No items in the cart.
												</td>
												</tr>
											)}
											</tbody>

									<tfoot>
										<tr>
										<td className="text-right" colSpan="5">
											<strong>Sub-Total:</strong>
										</td>
										<td className="text-right">
											<i className="bi bi-currency-rupee"></i>
											{subtotal.toFixed(2)}
										</td>
										</tr>
										<tr>
										<td className="text-right" colSpan="5">
											<strong>CGST :</strong>
										</td>
										<td className="text-right">
											<i className="bi bi-currency-rupee"></i>{cgst.toFixed(2)}
										</td>
										</tr>
										<tr>
										<td className="text-right" colSpan="5">
											<strong>SGST :</strong>
										</td>
										<td className="text-right">
											<i className="bi bi-currency-rupee"></i>{sgst.toFixed(2)}
										</td>
										</tr>
										<tr>
										{/* <td className="text-right" colSpan="4">
											<strong>VAT (20%):</strong>
										</td>
										<td className="text-right">
											<i className="bi bi-currency-rupee"></i>
											{calculateVAT()}
										</td> */}
										</tr>
										<tr>
										<td className="text-right" colSpan="5">
											<strong>Total:</strong>
										</td>
										<td className="text-right">
										<strong>	<i className="bi bi-currency-rupee"></i>
											{total.toFixed(2)}</strong>
										</td>
										</tr>
									</tfoot>
									</table>
								</div>
								</div>
							</div>
							</div>
					<div class="col-sm-12">
					  <div class="panel panel-default">
						<div class="panel-heading">
						  <h4 class="panel-title"><i class="fa fa-pencil"></i> Add Comments About Your Order</h4>
						</div>
						  <div class="panel-body">
							<textarea rows="4" class="form-control" id="confirm_comment" name="comments" onChange={(e) => setComments(e.target.value)}></textarea>
							<br />
							<label class="control-label" for="confirm_agree">

							  <input type="checkbox"  value="0" required="" 
							  class="validate required" id="confirm_agree" 
							  checked={agree} // Bind the state to checked
                              onChange={handleCheckboxChange} 
							   name="confirm agree" />


							  <span> I have read and agree to the <Link class="agree" to="/terms"><b>Terms &amp; Conditions</b></Link></span> </label>
							  <div className="buttons">
								{/* <div className="pull-right">
									<button
									className="btn btn-primary"
									id="button-confirm"
									onClick={() => handleConfirmOrder("offline")}
									disabled={loading || isloading1} // Prevent multiple clicks while loading
									style={{
										display: "inline-flex",
										alignItems: "center",
										justifyContent: "center",
										minWidth: "120px", // Ensures consistent button width
										height: "38px", // Matches Bootstrap button size
									}}
									>
									{loading ? (
										<ClipLoader color="#fff" size={16} />
									) : (
										"Offline Order"
									)}
									</button> &nbsp;
								</div> */}
								</div>

								<div className="buttons">
								<div className="pull-right">
									<button
									className="btn btn-primary"
									id="button-confirm"
									// onClick={() => handleonlineOrder("ccavenue")}
									onClick={initiatePayment}
									// onClick={placeOrder}
									disabled={isloading1 || loading}
									style={{
										display: "inline-flex",
										alignItems: "center",
										justifyContent: "center",
										minWidth: "120px", // Ensures consistent button width
										height: "38px", // Matches Bootstrap button size
									}}
									>
									
									{isloading1 ? (
										<ClipLoader color="#fff" size={16} />
									) : (
										"Proceed to payment"
									)}
									</button> 
									
									 &nbsp;
								</div>
								</div>
	
						  </div>
					  </div>
					</div>
				  </div>
				</div>
			  </div>
			</div>
			{/* <!--Middle Part End --> */}
			
		</div>
	</div>
  </div>
</div>
<Footer />
</>
	  )}
	  </>
  )
}

export default Checkout