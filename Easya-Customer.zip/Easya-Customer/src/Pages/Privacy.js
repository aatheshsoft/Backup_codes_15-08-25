import React, { useEffect } from "react";
import Header from "../Components/Header";
import Footer from "../Components/Footer";

const Privacy = () => {
    
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <>
      <div className="common-home res layout-home1">
        <div id="wrapper" className="wrapper-full banners-effect-7">
          <Header />
          <div class="main-container container">
            <ul class="breadcrumb">
              <li>
                <a href="index.html">
                  <i class="fa fa-home"></i>
                </a>
              </li>
              <li>Privacy Policy</li>
            </ul>
            <div class="row">
              <div id="content" class="col-sm-12">
                <div className="p-6 bg-gray-100 rounded-lg shadow-lg">
                  <h2 className="text-2xl font-bold text-gray-800 mb-4">
                    Privacy Policy for Saravana Emabassy
                  </h2>
                  <p className="text-gray-700">
                    At  Saravana Emabassy, accessible from https://easya.in, one of our main
                    priorities is the privacy of our visitors. This Privacy
                    Policy document contains types of information that is
                    collected and recorded by  Saravana Emabassy and how we use it.
                  </p>
                  <p className="text-gray-700">
                    If you have additional questions or require more information
                    about our Privacy Policy, do not hesitate to contact us.
                  </p>
                  <p className="text-gray-700">
                    This Privacy Policy applies only to our online activities
                    and is valid for visitors to our website with regards to the
                    information that they shared and/or collect in  Saravana Emabassy. This
                    policy is not applicable to any information collected
                    offline or via channels other than this website.
                  </p>

                  <h3 className="text-xl font-semibold text-gray-800 mt-6">
                    Consent
                  </h3>
                  <p className="text-gray-700">
                    By using our website, you hereby consent to our Privacy
                    Policy and agree to its terms.
                  </p>

                  <h3 className="text-xl font-semibold text-gray-800 mt-6">
                    Information We Collect
                  </h3>
                  <p className="text-gray-700">
                    The personal information that you are asked to provide, and
                    the reasons why you are asked to provide it, will be made
                    clear to you at the point we ask you to provide your
                    personal information.
                  </p>
                  <p className="text-gray-700">
                    If you contact us directly, we may receive additional
                    information about you such as your name, email address,
                    phone number, the contents of the message and/or attachments
                    you may send us, and any other information you may choose to
                    provide.
                  </p>
                  <p className="text-gray-700">
                    When you register for an Account, we may ask for your
                    contact information, including items such as name, company
                    name, address, email address, and telephone number.
                  </p>

                  <h3 className="text-xl font-semibold text-gray-800 mt-6">
                    How We Use Your Information
                  </h3>
                  <p className="text-gray-700">
                    We use the information we collect in various ways, including
                    to:
                  </p>
                  <ul className="list-disc list-inside mt-2 text-gray-700">
                    <li>Provide, operate, and maintain our website</li>
                    <li>Improve, personalize, and expand our website</li>
                    <li>Understand and analyze how you use our website</li>
                    <li>
                      Develop new products, services, features, and
                      functionality
                    </li>
                    <li>
                      Communicate with you, either directly or through one of
                      our partners, including for customer service, to provide
                      you with updates and other information relating to the
                      website, and for marketing and promotional purposes
                    </li>
                    <li>Send you emails</li>
                    <li>Find and prevent fraud</li>
                  </ul>

                  <h3 className="text-xl font-semibold text-gray-800 mt-6">
                    Log Files
                  </h3>
                  <p className="text-gray-700">
                    Saravana Emabassy follows a standard procedure of using log files. These
                    files log visitors when they visit websites. All hosting
                    companies do this as part of hosting services' analytics.
                    The information collected by log files includes internet
                    protocol (IP) addresses, browser type, Internet Service
                    Provider (ISP), date and time stamp, referring/exit pages,
                    and possibly the number of clicks. These are not linked to
                    any information that is personally identifiable. The purpose
                    of the information is for analyzing trends, administering
                    the site, tracking users' movement on the website, and
                    gathering demographic information.
                  </p>

                  <h3 className="text-xl font-semibold text-gray-800 mt-6">
                    Children's Information
                  </h3>
                  <p className="text-gray-700">
                    Another part of our priority is adding protection for
                    children while using the internet. We encourage parents and
                    guardians to observe, participate in, and/or monitor and
                    guide their online activity.
                  </p>
                  <p className="text-gray-700">
                  Saravana Emabassy does not knowingly collect any Personal Identifiable
                    Information from children under the age of 13. If you think
                    that your child provided this kind of information on our
                    website, we strongly encourage you to contact us immediately
                    and we will do our best efforts to promptly remove such
                    information from our records.
                  </p>
                </div>
              </div>
            </div>
          </div>
          <Footer />
        </div>
      </div>
    </>
  );
};

export default Privacy;
