// ======================== working code ================================================
/*
import { useSearchParams } from "react-router-dom";
import { useEffect } from "react";


const Thanks = () => {
  const [searchParams] = useSearchParams();
  const status = searchParams.get("status");
  const orderId = searchParams.get("order_id");

  useEffect(() => {
    console.log("Payment status:", status); // ✅ Here's your response
    // Based on status, trigger next logic
    if (status === "Success") {
      // navigate to success screen, clear cart, etc.
    } else {
      // show error, retry, etc.
    }
  }, [status]);

  return (
    <div>
      <h2>Payment {status}</h2>
      <p>Order ID: {orderId}</p>
    </div>
  );
};

export default Thanks;
*/
// ========================================= working code =====================================

/* */
import React, { useEffect ,useContext,useState} from 'react';
import { useLocation } from 'react-router-dom';
import { CheckCircle , XCircle} from "lucide-react";
import { Link } from "react-router-dom";
import Footer from "../Components/Footer";
import Header from "../Components/Header";

 // ============== updated code ========================= 
 
import { useSearchParams } from "react-router-dom";
// import { useEffect } from "react";

import { CartContext } from "../Context/CartContext"; // Import the CartContext
import { useRef } from "react";
import IsLoader from '../Components/IsLoader';
// ============== updated code ========================= 

const Thanks = () => {
  // ============== updated code ========================= 
  const { cartItems, updateItemQuantity, removeItemFromCart,setCartItems } = useContext(CartContext);
   
  const [searchParams] = useSearchParams();
  const [isLoading, setIsLoading] = useState(true);
  
    const [isloading1, setIsLoading1] = useState(false);
     const userId = localStorage.getItem('user_id');
     const Email = localStorage.getItem('email');

     const subtotal = cartItems.reduce( 
	(acc, item) => (item.stock > 0 ? acc + item.onlinerate * item.qty : acc),
	0
  );
  
  const cgst = cartItems.reduce(
	(acc, item) => (item.stock > 0 ? acc + (item.tax_amt / 2) * item.qty : acc),
	0
  );
  
  const sgst = cartItems.reduce(
	(acc, item) => (item.stock > 0 ? acc + (item.tax_amt / 2) * item.qty : acc),
	0
  );
  
  const total = subtotal + cgst + sgst;
  // const status = searchParams.get("status");
  // const orderId = searchParams.get("order_id");

  // ============== updated code =========================
    // const [searchParams] = useSearchParams();
    const hasPlacedOrder = useRef(false); // ⛔ won't re-trigger renders
    // payment gateway details
    const status = searchParams.get("status");
    const orderId = searchParams.get("order_id");
    const trackingId = searchParams.get("tracking_id");
    // billing details
    const billing_name = searchParams.get("billing_name");
    const billing_address = searchParams.get("billing_address");
    const billing_city = searchParams.get("billing_city");
    const billing_state = searchParams.get("billing_state");
    const billing_zip = searchParams.get("billing_zip");
    const billing_country = searchParams.get("billing_country");
    const billing_tel = searchParams.get("billing_tel");
    const billing_email = searchParams.get("billing_email");
    // delivery details
    const delivery_name = searchParams.get("delivery_name");
    const delivery_address = searchParams.get("delivery_address");
    const delivery_city = searchParams.get("delivery_city");
    const delivery_state = searchParams.get("delivery_state");
    const delivery_zip = searchParams.get("delivery_zip");
    const delivery_country = searchParams.get("delivery_country");
    const delivery_tel = searchParams.get("delivery_tel");
    const delivery_email = searchParams.get("delivery_email");
  
    const note = searchParams.get("note");
    console.log(note);
    console.log(trackingId);
     console.log(billing_name);
     
  // ============== updated code =========================
  // ============== updated code ========================= 

    // const savedResponse = JSON.parse(localStorage.getItem('orderresponse'));
    // console.log(savedResponse);
    const location = useLocation();

  useEffect(() => {
    // ============== updated code ========================= 
    console.log("Payment status:", status); // ✅ Here's your response
    // Based on status, trigger next logic
    if (status === "Success" && !hasPlacedOrder.current) {
      // navigate to success screen, clear cart, etc.
       placeOrder();
        hasPlacedOrder.current = true; // ✅ prevent second execution
    } else {
      // show error, retry, etc.
    }
    // ============== updated code ========================= 

    // Extracting query parameters from the URL
    const searchParams = new URLSearchParams(location.search);

    // Get encResp and order_id from URL parameters
    const encResp = searchParams.get("encResp");
    const orderId = searchParams.get("order_id");

    // Print values to the console
    // console.log("Encrypted Response (encResp):", encResp);
    // console.log("Order ID:", orderId);

    // if (encResp && orderId) {
    //   alert(`Payment Response Received:\nOrder ID: ${orderId}\nEncrypted Data: ${encResp}`);
    // } else {
    //   alert("Payment response not found.");
    // }

  }, [location , status]);  // ============== updated code ========================= 

  // ===================== updated code end ==========================================
    const placeOrder = async () => {
	// if (!agree) {
	//   alert("Please agree to the terms and conditions.");
	//   return;
	// }
  
	// setIsLoading1(true);
  
	const availableItems = cartItems.filter((item) => item.stock > 0);
	if (availableItems.length === 0) {
	  alert("No products available in stock to place the order.");
	  setIsLoading1(false);
	  return;
	}
  
	const orderPayload = {
	  // paymentmode: mode,
	  paymentmode: "ccavenue",
	  payment_status:status,
	  payment_orderId:orderId,
	  payment_trackingId:trackingId,
	  user_id: userId,
	  billing_details: {
		billing_name: billing_name,
		billing_address: billing_address,
		billing_city: billing_city,
		billing_state: billing_state,
		billing_email: Email,
		billing_phonenumber: billing_tel,
		billing_postcode: billing_zip,
	  },
	  delivery_details: {
		delivery_name: delivery_name,
		delivery_address: delivery_address,
		delivery_city: delivery_city,
		delivery_state: delivery_state,
		delivery_email: Email,
		delivery_phonenumber: delivery_tel,
		delivery_postcode: delivery_zip,
	  },
	  subtotal: availableItems.reduce((sum, item) => sum + item.onlinerate * item.qty, 0),
	  sgst,
	  cgst,
	  total,
	  // note: comments,
	  note: note,
	
	  productdetails: availableItems.map((item) => ({
		product_id: item.product_id,
		product_name: item.product_name,
		qty: item.qty,
		amount: item.onlinerate,
		totalamount: item.onlinerate * item.qty,
		image: item.image,
	  })),
	};
	console.log(orderPayload);
	/* */
    try {
      const res = await fetch('https://easya.in/customerapp/order.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(orderPayload), // 🔥 FIXED HERE
      });

      const result = await res.json();
      
      if (result.head.code === 200) {
		setCartItems([]); // If cartItems is managed via state
		localStorage.removeItem("cartItems"); 
        // need navigation to thanks page.

		//  navigate(`/thanks?status=${status}`); 

		// clear the cart page 
     setIsLoading(false);
      } else {
        alert(result.head.msg);
		// navigate('/thanks'); 
		console.log(result.head.code);
		console.log(result.head.msg);
      }
    } catch (error) {
      console.error('order placed failed:', error);
      alert('Something went wrong');
    }
	
  };
  // ===================== updated code end ==========================================
  return (
    <>
     {isLoading ? (
        <IsLoader />
      ) : (
        <>
      <div class="common-home res layout-home1">
        <div id="wrapper" class="wrapper-full banners-effect-7">
          <Header />
          <div class="main-container container">
            <ul class="breadcrumb">  
              <li>
                <Link to="/">
                  <i class="fa fa-home"></i>
                </Link>
              </li>
              <li>
                <a>Checkout</a>
              </li>
            </ul>
            <div className="flex flex-col items-center justify-center min-h-screen bg-green-50 text-center p-4">
              {/* <CheckCircle className="text-green-600 w-24 h-24 mb-4" /> */}
               {/*// ============== updated code ========================= */}
              {status === "Success" || status === "offline" ? (
                  <CheckCircle className="text-green-600 w-24 h-24 mb-4" />
                ) : (
                  <XCircle className="text-red-600 w-24 h-24 mb-4" />
                )}
              <h1 className="text-3xl font-bold text-green-800 mb-2">
                {/* {status == "Success" }Thank You for Your Purchase! */}
                 {status === "Success" || status === "offline"
                      ? "Thank You for Your Purchase!"
                      : `Your payment is ${status}`}
              </h1>
              <p className="text-lg text-gray-700">
                 {status === "Success" || status === "offline"
                      ? "Your order has been placed successfully."
                      : `Your Order is not placed`}
              </p>
               {/*// ============== updated code ========================= */}
            </div>
          </div>
        </div>
      </div>
      <Footer />
      </>
	  )}
    </>
  );
};

export default Thanks;
/*
import React, { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import { useSearchParams } from 'react-router-dom';

const Thanks = () => {
  const [searchParams] = useSearchParams();

  useEffect(() => {
      const orderId = searchParams.get('order_id');
      const tracking_id = searchParams.get('tracking_id');
      const order_status = searchParams.get('order_status');
      const payment_mode = searchParams.get('payment_mode');
      console.log("Payment Successful!");
      console.log("Order ID:", orderId);
      console.log("tracking_id:", tracking_id);
      console.log("Status:", order_status);
      console.log("payment_mode:", payment_mode);
      // Handle your success logic here
  }, [searchParams]);

    return (
        <div>
          <p></p>
        </div>
    );
};

export default Thanks;
*/
