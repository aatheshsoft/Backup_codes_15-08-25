import React, { useState } from 'react';

const PaymentButton = () => {
  const handlePayment = async () => {
    try {
      const response = await fetch('https://easya.in/customerapp/create_payment.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ amount: 100.00 })  // Pass the required amount or data
      });

      const paymentData = await response.json();

      // Redirect to CCAvenue payment page
      if (paymentData && paymentData.url) {
        window.location.href = paymentData.url;
      }
    } catch (error) {
      console.error("Error initiating payment:", error);
    }
  };

  return (
    <button onClick={handlePayment}>Pay Here</button>
  );
};

export default PaymentButton;