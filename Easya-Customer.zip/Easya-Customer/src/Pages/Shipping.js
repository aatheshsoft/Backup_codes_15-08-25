import React, { useEffect } from "react";
import Header from "../Components/Header";
import Footer from "../Components/Footer";

const Shipping = () => {
     useEffect(() => {
        window.scrollTo(0, 0);
      }, []);
      
  return (
    <>
      <div className="common-home res layout-home1">
        <div id="wrapper" className="wrapper-full banners-effect-7">
          <Header />
          <div class="main-container container">
            <ul class="breadcrumb">
              <li>
                <a href="index.html">
                  <i class="fa fa-home"></i>
                </a>
              </li>
              <li>Shipping Policy</li>
            </ul>
            <div class="row">
              <div id="content" class="col-sm-12">
              <div className="container mt-4">
      <h2>Shipping Policy</h2>
      <p>
        All orders are processed within <strong>2 to 3 business days</strong> (excluding
        weekends and holidays) after receiving your order confirmation email. You
        will receive another notification when your order has shipped.
      </p>
      <p>
        Please note that there might be delays due to a high volume of orders or
        postal service issues that are outside of our control.
      </p>
      <h4>Domestic Shipping Rates and Estimates</h4>
      <p>
        For calculated shipping rates: Shipping charges for your order will be
        calculated and displayed at checkout.
      </p>
      <h4>Local Delivery</h4>
      <p>
        Local delivery is available for orders over <strong>Rs.1500</strong> within a 
        <strong> 5km</strong> area of coverage. For orders under <strong>Rs.1000</strong>, we charge
        <strong>Rs.50</strong> for local delivery.
      </p>
      <p>
        Deliveries are made within <strong>24 hours</strong> on available days. We will contact you
        via text message with the phone number you provided at checkout to notify
        you on the day of our arrival.
      </p>
      <h4>Import Duties and Taxes</h4> 
      <p>
        Your order may be subject to import duties and taxes (including VAT), which
        are incurred once a shipment reaches your destination country.
      </p>
      <p>
        <strong>Saravana Emabassy</strong> is not responsible for these charges if they are applied and are
        your responsibility as the customer.
      </p>
    </div>
    </div>
            </div>
          </div>
          <Footer />
        </div>
      </div>
    </>
  );
};

export default Shipping;
