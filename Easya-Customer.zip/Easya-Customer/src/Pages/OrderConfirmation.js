import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";import Header from '../Components/Header';
import Footer from '../Components/Footer';
import { useParams } from 'react-router-dom';
import { FiX } from "react-icons/fi";
import Loader from '../Components/Loader';


const OrderConfirmation = () => {
  const { order_id } = useParams();
	const [isLoading, setIsLoading] = useState(true);
  const [orderData, setOrderData] = useState(null);

	useEffect(() => {
	  // Fetching order data
	  axios
		.post("https://easya.in/customerapp/order_detail_history.php", {
		  order_id: order_id, // Example input
		})
		.then((response) => {
		  if (response.data.head.code === 200) {
			setOrderData(response.data.body);
      console.log("orderdata" , response.data.body)
		  } else {
			console.error("Error fetching data:", response.data.head.msg);
		  }
		})
		.catch((error) => console.error("API Error:", error));
	}, []);
  
	if (!orderData) {
	  return <p> </p>;
	}
  
	const { address, order_information, order_detail_history } = orderData;

  const cancelOrder = async (orderNo) => {
    try {
      const response = await axios.post("https://easya.in/customerapp/cancel_product.php", {
        order_no: orderNo,
      });
      if (response.data.head && response.data.head.code === 200) {
        alert("Order canceled successfully!");
        window.location.reload();
        return true; // Success
      } else {
        alert("Failed to cancel the order. Please try again.");
        return false; // Failure
      }
    } catch (error) {
      console.error("Error canceling order:", error);
      alert("An error occurred while canceling the order.");
      return false;
    }
  };

  return (
    <>
    <div class="common-home res layout-home1">
        <div id="wrapper" class="wrapper-full banners-effect-7">
            <Header />
            <div class="main-container container">
		<ul class="breadcrumb">
			<li><a href="#"><i class="fa fa-home"></i></a></li>
			<li><a href="#">Order Infomation</a></li>
		</ul>
		
		<div class="row">
			{/* <!--Middle Part Start--> */}
			<div id="content" class="col-sm-12">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <h2 className="title">Order Information</h2>
        <button className="btn btn-primary" id="button-confirm" onClick={() => window.history.back()}>
          Back
        </button>
      </div>

				
				 <table className="table table-bordered table-hover">
        <thead>
          <tr>
            <td colSpan="2" className="text-left">Order Details</td>
          </tr>
        </thead>
        <tbody>
          {order_information.map((order) => (
            <tr key={order.order_id}>
              <td style={{ width: "50%" }} className="text-left">
                <b>Order ID:</b> #{order.order_id}
                <br />
               
              </td>
              <td style={{ width: "50%" }} className="text-left">
              {/*   <b>Payment Method:</b> Cash On Delivery
                <br />
                <b>Shipping Method:</b> Flat Shipping Rate */}
                 <b>Date Added : </b>
  {(() => {
    const dateObj = new Date(order.orderdate);
    const day = String(dateObj.getDate()).padStart(2, "0");
    const month = String(dateObj.getMonth() + 1).padStart(2, "0");
    const year = dateObj.getFullYear();
    return `${day}/${month}/${year}`;
  })()}


              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Address Table */}
      <table className="table table-bordered table-hover">
        <thead>
          <tr>
            <td className="text-left">Payment Address</td>
            <td className="text-left">Shipping Address</td>
          </tr>
        </thead>
        <tbody>
          {address.map((addr, index) => (
            <tr key={index}>
              <td className="text-left">
                {addr.billing_name}
                <br />
                {addr.billing_address}, {addr.billing_city}, {addr.billing_state}
                <br />
                {addr.billing_pincode}
                <br />
                {addr.billing_mobile}
                <br />
                {addr.billing_email}
              </td>
              <td className="text-left">
                {addr.delivery_name}
                <br />
                {addr.delivery_address}, {addr.delivery_city}, {addr.delivery_state}
                <br />
                {addr.delivery_pincode}
                <br />
                {addr.delivery_mobile}
                <br />
                {addr.delivery_email}
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Order Items Table */}
      <div className="table-responsive">
        <table className="table table-bordered table-hover">
          <thead>
            <tr>
            <td className="text-left">Order No</td>
              <td className="text-left">Product Name</td>
              <td className="text-right">Quantity</td>
              <td className="text-right">Price</td>
              <td className="text-right">Total</td>
              <td className="text-right" >Order Cancel</td>
             
            </tr>
          </thead>
          <tbody>
            {order_detail_history.map((item, index) => (
              <tr key={index}>
                 <td className="text-left">{item.order_no}</td>
                <td className="text-left">{item.product_name}</td>
                <td className="text-right">{item.qty}</td>
                <td className="text-right"><i className="bi bi-currency-rupee"></i>{item.amount}</td>
                <td className="text-right"><i className="bi bi-currency-rupee"></i>{item.totalamount}</td>
                <td className="text-right">
  {item.cancel === "0" && item.orderstatus.toLowerCase() === "processing" ? (
    // Show the cancel button if order is in processing and not yet cancelled
    <>
      <span
        className="btn btn-primary"
        title="Cancel Order"
        style={{ marginRight: "10px" }}
        onClick={async () => {
          const confirmed = window.confirm(
            `Are you sure you want to cancel order #${item.order_no}?`
          );
          if (confirmed) {
            const success = await cancelOrder(item.order_no);
            if (success) {
              alert(`Order #${item.order_no} has been canceled.`);
              // Optionally update the UI or state to reflect the canceled status
            }
          }
        }}
      >
        <FiX color="red" />
      </span>
    </>
  ) : item.cancel === "1" ? (
    // Show 'Cancelled' text if order is already cancelled
    <span style={{ color: "red" }}>
      <b>Cancelled</b>
    </span>
  ) : (
    // Show 'Your Item Is Shipped' if order is not in processing state
    <span style={{ color: "green" }}>
      <b>Your Item Is Already Shipped</b>
    </span>
  )}
</td>


              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr>
              <td colSpan="4"></td>
              <td className="text-right"><b>Sub-Total</b></td>
              <td className="text-right"><b><i className="bi bi-currency-rupee"></i>{order_information[0].sub_total}</b></td>
            </tr>
            <tr>
              <td colSpan="4"></td>
              <td className="text-right"><b>CGST</b></td>
              <td className="text-right"><i className="bi bi-currency-rupee"></i>{order_information[0].cgst_amt}</td>
            </tr>
            <tr>
              <td colSpan="4"></td>
              <td className="text-right"><b>SGST</b></td>
              <td className="text-right"><i className="bi bi-currency-rupee"></i>{order_information[0].sgst_amt}</td>
            </tr>
            <tr>
              <td colSpan="4"></td>
              <td className="text-right"><b>Total</b></td>
              <td className="text-right"><b><i className="bi bi-currency-rupee"></i>{order_information[0].total}</b></td>
            </tr>
          </tfoot>
        </table>
				</div>
				<h3>Order History</h3>
				<table class="table table-bordered table-hover">
					<thead>
						<tr>
              <td class="text-left">Order No</td>
							<td class="text-left">Date Added</td>
							<td class="text-left">Order Status</td>
						</tr>
					</thead>
          
        <tbody>
          {order_information.map((item, index) => (
            <React.Fragment key={index}>
              {/* Always display order details */}
              <tr>
                <td>{item.order_id}</td>
                <td className="text-left">
  {(() => {
    const dateObj = new Date(item.orderdate);
    const day = String(dateObj.getDate()).padStart(2, "0");
    const month = String(dateObj.getMonth() + 1).padStart(2, "0");
    const year = dateObj.getFullYear();
    return `${day}/${month}/${year}`;
  })()}
</td>

                <td className="text-left"><b>{item.orderstatus}</b></td>
              </tr>

              {/* Display shipped row only if shipped data exists */}
                {item.shipped_date && item.shipped_status && (
                <tr>
                  <td>{item.order_id}</td>
                  <td className="text-left">{item.shipped_date}</td>
                  <td className="text-left"><strong>{item.shipped_status}</strong></td>
                </tr>
              )}

              {/* Display out-for-delivery row only if data exists */}
              {item.out_for_delivery_date && item.out_for_delivery_status && (
                <tr>
                  <td>{item.order_id}</td>
                  <td className="text-left">{item.out_for_delivery_date}</td>
                  <td className="text-left"><b>{item.out_for_delivery_status}</b></td>
                </tr>
              )}
            </React.Fragment>
          ))}
        </tbody>

				</table>
				{/* <div class="buttons clearfix">
					<div class="pull-right"><a class="btn btn-primary" href="#">Continue</a>
					</div>
				</div> */}



			</div>
			{/* <!--Middle Part End-->
			
			<!--Right Part End --> */}
		</div>
	</div>
        </div>
    </div>
    <Footer />
    </>
  )
}

export default OrderConfirmation