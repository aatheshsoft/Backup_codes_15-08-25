import React, { useState } from 'react';
import axios from 'axios';

const Test = () => {
//   const handlePayment = () => {
//     // Redirect to the PHP endpoint that handles payment initiation
//     window.location.href = 'https://www.easya.in/customerapp/ccavenue_handler.php';
//   };

//   return (
//     <button onClick={handlePayment}>
//       Pay Now
//     </button>
//   );
// const [formData, setFormData] = useState({
//     name: 'asdfg',
//     amount: "100.00",
//     address: ',hguyjft',
//     city: 'vjgft',
//     state: 'fjgtfj',
//     pincode: '354354',
//     country: 'fdt',
//     mobile: 'jfjtf',
//     email: 'hvyik'
//   });

//   const handleChange = (e) => {
//     const { name, value } = e.target;
//     setFormData(prev => ({ ...prev, [name]: value }));
//   };

  const handleSubmit = async (e) => {
    e.preventDefault();


    const orderPayload = {
      user_id: "8",
      billing_details: {
      billing_name: "asfg",
      billing_address: "sdfef",
      billing_city:"sdfdfg",
      billing_state: "dfvdfg",
      billing_email: "dfgdfg",
      billing_phonenumber: "dfgdf",
      billing_postcode: "dfgdrfgdrf",
      },
      delivery_details: {
      delivery_name: "zsdfvdf",
      delivery_address:"dfgdfg",
      delivery_city: "dfgdf",
      delivery_state:"dfg",
      delivery_email:"dfg",
      delivery_phonenumber:"njmhj",
      delivery_postcode:"tyttf",
      },
      subtotal: "1500",
      sgst:"250",
      cgst:"254",
      total:"5879",
      note: "",
      paymentmode: "ccavenue",
      product_id:"15",
      product_name:"test",
      qty: "4",
      amount: "1500",
      totalamount: "250",
      // image: item.image,
    };
          console.log(orderPayload);
    try {
      const response = await axios.post("https://easya.in/customerapp/ccavenue_handler.php", (orderPayload), {
		headers: {
		  "Content-Type": "application/json",
		},
	  });


      const data = response.data;
      console.log(data);
      if (data.head.code === 200) {
        // Create and submit form to CCAvenue
        // const form = document.createElement('form');
        // form.method = 'POST';
        // form.action = 'https://secure.ccavenue.com/transaction/transaction.do?command=initiateTransaction';

        // const encRequestInput = document.createElement('input');
        // encRequestInput.type = 'hidden';
        // encRequestInput.name = 'encRequest';
        // encRequestInput.value = data.body.encRequest;

        // const accessCodeInput = document.createElement('input');
        // accessCodeInput.type = 'hidden';
        // accessCodeInput.name = 'access_code';
        // accessCodeInput.value = data.body.accessCode;

        // form.appendChild(encRequestInput);
        // form.appendChild(accessCodeInput);
        // document.body.appendChild(form);
        // form.submit();
      } else {
        alert('Failed to get payment data: ' + data.head.msg);
      }
    } catch (error) {
      console.error('Error in payment request:', error);
      alert('Something went wrong. Check console for details.');
    }
  };

  return (
      <form onSubmit={handleSubmit}>
       {/* <input type="hidden" name="name" placeholder="Name" onChange={handleChange} required />
      <input type="hidden" name="amount" placeholder="Amount" onChange={handleChange} required />
      <input type="hidden" name="address" placeholder="Address" onChange={handleChange} />
      <input type="hidden" name="city" placeholder="City" onChange={handleChange} />
      <input type="hidden" name="state" placeholder="State" onChange={handleChange} />
      <input type="hidden" name="pincode" placeholder="Pincode" onChange={handleChange} />
      <input type="hidden" name="country" placeholder="Country" onChange={handleChange} />
      <input type="hidden" name="mobile" placeholder="Mobile" onChange={handleChange} required />
      <input type="hidden" name="email" placeholder="Email" onChange={handleChange} required />  */}
      <button type="submit">Pay Now</button>
    </form> 
  );

};

export default Test;
