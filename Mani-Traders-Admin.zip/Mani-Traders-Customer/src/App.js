import React from 'react';
import './App.css'
import { BrowserRouter, Route, Routes, Navigate, useLocation } from 'react-router-dom';
import SideBar from './Components/SideBar';
import Home from './Pages/Home';
// import Customerlist from './Pages/Customerlist';
import OrderList from './Pages/OrderList';
import OrderDetails from './Pages/OrderDetails';
import BannerList from './Pages/BannerList';
import AddBanner from './Pages/AddBanner';
import Discount from './Pages/Discount';
import AddDiscount from './Pages/AddDiscount';
import SubCategory from './Pages/SubCategory';
import AddSubcategory from './Pages/AddSubcategory';
import Products from './Pages/Products';
import AddProducts from './Pages/AddProducts';
import Login from './Components/Login';
import Settings from './Components/Settings';
// import Users from './Components/Users';
// import Previlage from './Components/Previlage';
// import Addusers from './Components/Addusers';
import Stock from './Pages/Stock';
import Brand from './Pages/Brand';
import AddBrand from './Pages/AddBrand';
// import CanceOrder from './Pages/CanceOrder';
// import CancelOrderDetails from './Pages/CancelOrderDetails';
import EditDiscount from './Pages/EditDiscount';
import EditSubcategory from './Pages/EditSubcategory';
import EditProducts from './Pages/EditProducts';
import EditBrand from './Pages/EditBrand';
import Content from './Components/Content';
import ContentEdit from './Components/ContentEdit';
// import ViewCustomer from './Pages/ViewCustomer';
// import Editusers from './Components/Editusers';
import Invoice from './Pages/Invoice';
// import Pos from './Pages/Pos';
// import CustomOrderList from './Pages/CustomOrderLIst';
// import CustomOrderDetails from './Pages/CustomOrderDetails';
import EditBanner from './Pages/EditBanner';
import Footer from './Components/Footer'
import ScrollList from './Pages/ScrollList';
import AddScroll from './Pages/AddScroll';
import EditScoll from './Pages/EditScroll';
import GalleryList from './Pages/GalleryList';
import AddGallery from './Pages/AddGallery';
import EditGallery from './Pages/EditGallery';
import ImportProducts from './Pages/ImportProducts';
import ClientLogo from './Pages/ClientLogo';
import AddClientLogo from './Pages/AddClientLogo';
import EditClientLogo from './Pages/EditClientLogo';
import ShopOrder from './Pages/ShopOrder';
import UpdateList from './Pages/UpdateList';
const AppLayout = () => {
    const location = useLocation();
    const isLoginPage = location.pathname === '/login';
    const isInvoicePage = location.pathname === "/invoice"; 
    const isPosPage = location.pathname === "/pos"; 

    return (
        <div>
            {!isLoginPage &&!isInvoicePage && !isPosPage &&  <SideBar />}
            

            <Routes>
                <Route path="/" element={<Navigate to="/login" />} />
                <Route path="/login" element={<Login />} />
                <Route path="/home" element={<Home />} />
                {/* <Route path="/customerlist" element={<Customerlist />} /> */}
                <Route path="/orderlist" element={<OrderList />} />
                <Route path="/orderdetails/:order_id" element={<OrderDetails />} />
                <Route path="/bannerlist" element={<BannerList />} />
                <Route path="/addbanner" element={<AddBanner />} />
                <Route path="/editbanner/:banner_id" element={<EditBanner />} />
                <Route path="/discount" element={<Discount />} />
                <Route path="/adddiscount" element={<AddDiscount />} />
                <Route path="/subcategory" element={<SubCategory />} />
                <Route path="/addsubcategory" element={<AddSubcategory />} />
                <Route path="/products/:category_id" element={<Products />} />   
                <Route path="/addproducts" element={<AddProducts />} />
                <Route path="/settings" element={<Settings />} />
                {/* <Route path="/users" element={<Users />} />
                <Route path="/previlage/:employee_id" element={<Previlage />} /> */}
                {/* <Route path="/addusers" element={<Addusers />} /> */}
                {/* <Route path="/editusers/:user_id" element={<Editusers />} /> */}
                <Route path="/stock" element={<Stock />} />
                <Route path="/brand" element ={<Brand />} />
                <Route path="/editbrand" element ={<EditBrand />} />
                <Route path="/addbrand" element = {<AddBrand />} />
                <Route path="/editdiscount/:discount_id" element = {<EditDiscount />} />
                <Route path="/editsubcategory/:category_id" element = {<EditSubcategory />} />
                <Route path="/editproducts/:product_id" element = {<EditProducts />} />
                <Route path="/clientlogo" element = {<ClientLogo />} />
                <Route path="/addclientlogo" element = {<AddClientLogo />} />
                <Route path="/editclientlogo/:id" element = {<EditClientLogo />} />
                {/* <Route path="/cancelorder" element = {<CanceOrder />} />
                <Route path="/cancelorderdetails/:order_id" element = {<CancelOrderDetails />} /> */}
                <Route path="/content" element = {<Content />} />
                <Route path = "/scrolllist" element ={<ScrollList/>} />
                <Route path ="/addscroll" element = {<AddScroll />} />
                <Route path = "/editscroll/:id" element = {<EditScoll />} />
                <Route path="/contentedit/:id" element = {<ContentEdit />} />
                <Route path="/gallerylist" element = {<GalleryList />} />
                <Route path="/addgallery" element = {<AddGallery />} />
                <Route path="/editgallery/:gallery_id" element={<EditGallery />} />
                <Route path="/importproducts" element = {<ImportProducts />} />
                {/* <Route path="/viewcustomer/:user_id" element = {<ViewCustomer />} /> */}
                <Route path="/invoice" element = {<Invoice />} />
                <Route path="shoporder" element={<ShopOrder />} />
                 <Route path="updatelist" element={<UpdateList />} />
                {/* <Route path="/customorderlist/:user_id" element = {<CustomOrderList />} />
                <Route path="/customorderdetails/:order_id" element = {<CustomOrderDetails />} />
                <Route path="/pos" element = {<Pos />} />            */}

            </Routes>
            {!isLoginPage &&!isInvoicePage && !isPosPage &&  <Footer />}
        </div>
    );
};

const App = () => {
    return (
        <BrowserRouter  basename="/mftadmin">
            <AppLayout />
        </BrowserRouter>
    );
};

export default App;
