import React, { useState,useEffect } from 'react';
import { Link } from 'react-router-dom';
import { FaPencilAlt, FaTrash } from 'react-icons/fa';
import axios from 'axios';
import Header from "../Components/Header";

const ScrollList = () => {
  const [messages, setMessages] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [selectedmsgId, setSelectedMsgId] = useState(null);
  const [loading, setLoading] = useState(true);
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

  const openDeleteModal = (id) => {
    setSelectedMsgId(id);
    setShowModal(true);
  };
  const closeModal = () => {
    setSelectedMsgId(null);
    setShowModal(false);
  };



  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);

      try {
        const response = await axios.post(`${API_BASE_URL}scroll_news_list.php`);

        if (response.data && response.data.head && response.data.head.code === 200) {
          const sortmessages = response.data.body.sort(
            (a,b) =>  a.rank - b.rank
          )
          setMessages(sortmessages);
        } else {
          console.error("Error:", response.data?.head?.msg || "Unexpected response format");
        }
      } catch (error) {
        console.error("API Error:", error);
      }finally{
        setLoading(false);

      }
    };

    fetchData();
  }, []);


  const handleDelete = async () => {
    if (!selectedmsgId) return; 
    setLoading(true);
    try {
      const response = await axios.post(
        `${API_BASE_URL}scroll_list_delete.php`,
        { id: selectedmsgId }
      );
  
      if (response.data?.head?.code === 200) {
        setMessages((prevMessages) => prevMessages.filter((msg) => msg.id !== selectedmsgId));
        alert("Deleted successfully!");
        closeModal();
      } else {
        alert(response.data?.head?.msg || "Failed to delete.");
      }
    } catch (error) {
      console.error("Delete API Error:", error);
      alert("Failed to delete.");
    }finally{
      setLoading(false);
    }
  };
  
  
  
  const handleInputChange = (id, field, value) => {
    setMessages((prevMessages) =>
      prevMessages.map((msg) =>
        msg.id === id ? { ...msg, [field]: value } : msg
      )
    );
  };

  const handleUpdate = async () => {
   
    try {
      
      const updatePromises = messages.map(async (msg) => {
        return axios.post(`${API_BASE_URL}scroll_list_update.php`, {
          id: msg.id,
          active: msg.active === "1" ? "1" : "0",
          rank: msg.rank
        });
      });

      await Promise.all(updatePromises);
      alert("Updated Successfully");
      window.location.reload();
    } catch (error) {
      console.error("Update Error:", error);
      alert("Failed to update. Try again.");
    }
  };
  return (
    <>
     <Header />
    <div class="page-wrapper compact-wrapper" id="pageWrapper">
        <div class="page-body-wrapper">
    <div className="page-body">
      <div className="container-fluid">
        <div className="row">
          <div className="col-sm-12">
            <div className="card card-table">
              <div className="card-body">
                <form name="Team" action="flash_msg.php" method="post">
                  <div className="title-header option-title d-sm-flex d-block">
                    <h5>Scroll Message Management</h5>
                    <div className="right-options">
                      <ul>
                        <li>
                          <Link className="btn btn-solid" to="/addscroll">Add</Link>
                        </li>
                      </ul>
                    </div>
                  </div>
                  {loading ? (
                         <div style={{ display: "flex", justifyContent: "center", marginTop: "50px" }}>
                         <div className="loader"></div>
                       </div>
                        ) : (
                          <>
                  <div className="table-responsive">
                    <table className="table all-package theme-table table-product">
                      <thead>
                        <tr>
                          <th>Title</th>
                          <th>Rank</th>
                          <th>Active</th>
                          <th style={{textAlign:"center"}}>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                      {messages.map((msg) => (
                              <tr key={msg.id}>
                                <td align="left">{msg.scroll_message}</td>
                                <td align="left">
                                  <input
                                    type="text"
                                    name="rank"
                                    value={msg.rank}
                                    className="frmelem"
                                    size="4"
                                    onChange={(e) => handleInputChange(msg.id, "rank", e.target.value)}
                                  />
                                </td>
                                <td align="left">
                                  <input
                                    className="checkbox_animated check-it"
                                    type="checkbox"
                                    checked={msg.active === "1"}
                                    onChange={(e) =>
                                      handleInputChange(msg.id, "active", e.target.checked ? "1" : "0")
                                    }
                                  />
                                </td>
                                <td align="left">
                                  <ul>
                                    <li>
                                      <Link 
                                      to={`/editscroll/${msg.id}`}
                                      
                                      >
                                        <i className="ri-pencil-line"></i>
                                      </Link>
                                    </li>
                                    <li>
                                      <a href="#"
                                       onClick={(e) => {
                                        e.preventDefault();
                                        openDeleteModal(
                                          msg.id
                                        );
                                      }}>
                                     
                                        <i className="ri-delete-bin-line"></i>
                                      </a>
                                    </li>
                                  </ul>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                      </>
                        )}
                      <div className="card-footer border-0 pb-0 d-flex justify-content-end">
                        <button
                          type="button"
                          onClick={handleUpdate}
                          className="btn btn-primary"
                        >
                          Update
                        </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    </div>
    </div>
    {showModal && (
        <div className="modal fade show" style={{ display: "block" }}>
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-body">
                <h5>Confirm Delete</h5>
                <p>Are you sure you want to delete this product?</p>
                <button
                  type="button"
                  className="btn-close"
                  onClick={closeModal}
                ></button>
              </div>
              <div className="modal-footer">
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={closeModal}
                >
                  No
                </button>
                <button
                  type="button"
                  className="btn btn-danger"
                  onClick={handleDelete}
                >
                  Yes, Delete
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default ScrollList;
