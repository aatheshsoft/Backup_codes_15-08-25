import React,{useState} from "react";
import Header from "../Components/Header";
import { Link } from "react-router-dom";

const Brand = () => {
    const [brands, setBrands] = useState([
        {
          id: 1,
          subCategoryType: 'Rita',
          rank: 1,
          active: true,
        },
      ]);
    
      const handleSubmit = (event) => {
        event.preventDefault();
        // Handle form submission (e.g., call API to update brand data)
      };
  return (
    <>
      <Header />
      <div class="page-wrapper compact-wrapper" id="pageWrapper">
        <div class="page-body-wrapper">
        <div className="page-body">
      <div className="container-fluid">
        <div className="row">
          <div className="col-sm-12">
            <div className="card card-table">
              <div className="card-body">
                <div className="title-header option-title d-sm-flex d-block">
                  <h5>List of Brand</h5>
                  <div className="right-options">
                    <ul>
                      <li>
                        <Link className="btn btn-solid" to="/subcategory">
                          Back
                        </Link>
                      </li>
                      <li>
                        <Link className="btn btn-solid" to="/addbrand">
                          Add Brand
                        </Link>
                      </li>
                    </ul>
                  </div>
                </div>

                <form onSubmit={handleSubmit}>
                  <div className="table-responsive">
                    <table className="table all-package theme-table table-product" id="table_id">
                      <thead>
                        <tr>
                          <th>S.No.</th>
                          <th>Sub Category Type</th>
                          <th style={{ textAlign: 'center' }}>Rank</th>
                          <th style={{ textAlign: 'center' }}>Active</th>
                          <th style={{ textAlign: 'center' }}>Action</th>
                        </tr>
                      </thead>

                      <tbody>
                        {brands.map((brand, index) => (
                          <tr key={brand.id}>
                            <td>{index + 1}</td>
                            <td>{brand.subCategoryType}</td>
                            <td style={{ textAlign: 'center' }}>
                              <input
                                className="checkbox_animated check-it"
                                type="text"
                                size="4"
                                name={`rank_${brand.id}`}
                                value={brand.rank}
                              />
                            </td>
                            <td style={{ textAlign: 'center' }}>
                              <input
                                className="checkbox_animated check-it"
                                type="checkbox"
                                name={`act_${brand.id}`}
                                checked={brand.active}
                                onChange={(e) => {
                                  setBrands((prevBrands) =>
                                    prevBrands.map((b) =>
                                      b.id === brand.id ? { ...b, active: e.target.checked } : b
                                    )
                                  );
                                }}
                              />
                            </td>
                            <td style={{ textAlign: 'center' }}>
                              <ul>
                                <li>
                                  <Link to='/editbrand'>
                                    <i className="ri-pencil-line"></i>
                                  </Link>
                                </li>
                                <li>
                                  <a href={`/brand/${brand.id}/1/32?del=delete`}>
                                    <i className="ri-delete-bin-line"></i>
                                  </a>
                                </li>
                              </ul>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  <div className="card-footer border-0 pb-0 d-flex justify-content-end">
                    <button className="btn btn-primary me-3" type="submit" name="update" value="Update">
                      Update
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>





        </div>
      </div>
    </>
  );
};

export default Brand;
