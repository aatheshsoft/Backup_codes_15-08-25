import React, { useEffect, useState } from "react";
import Header from "../Components/Header";
import { Link, useParams, useNavigate } from "react-router-dom";
import axios from "axios";

const EditScroll = () => {
  const [scrollMessage, setScrollMessage] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const { id } = useParams();
  const navigate = useNavigate();
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

  const detailApiUrl = `${API_BASE_URL}scroll_news_detail.php`;
  const updateApiUrl = `${API_BASE_URL}scroll_detail_update.php`;

  useEffect(() => {
    const fetchScroll = async () => {
      try {
        const response = await axios.post(detailApiUrl, { id });
        console.log("API Response:", response.data);
        if (response.data && response.data.body.length > 0) {
          setScrollMessage(response.data.body[0].scroll_message); // Set the message
        } else {
          setError("No data found");
        }
      } catch (error) {
        setError("Failed to fetch data");
      } finally {
        setLoading(false);
      }
    };

    fetchScroll();
  }, [id]);

  const handleSubmit = async (event) => {
    event.preventDefault();
    const formData = {
      id: id, // Ensure the ID is sent
      scroll_message: scrollMessage, // Use the updated state value
    };
    try {
      const response = await axios.post(updateApiUrl, formData);
      if (response.data.head.code === 200) {
        alert("Scroll message updated successfully");
        navigate("/scrolllist"); // Redirect after success
      } else {
        setError("Failed to update scroll message");
      }
    } catch (error) {
      setError("Error updating scroll message");
    }
  };

  if (loading) return <p>Loading...</p>;
  if (error) return <p className="text-danger">{error}</p>;

  return (
    <>
      <Header />
      <div className="page-wrapper compact-wrapper" id="pageWrapper">
        <div className="page-body-wrapper">
          <div className="page-body">
            <div className="container-fluid">
              <div className="row">
                <div className="col-12">
                  <div className="row">
                    <div className="col-sm-12 m-auto">
                      <div className="card">
                        <div className="card-body">
                          <div className="title-header option-title d-sm-flex d-block">
                            <h5>Edit Scroll Message</h5>
                            <div className="right-options">
                              <ul>
                                <li>
                                  <Link className="btn btn-solid" to="/scrolllist">
                                    Back
                                  </Link>
                                </li>
                              </ul>
                            </div>
                          </div>

                          <form className="theme-form theme-form-2 mega-form" onSubmit={handleSubmit}>
                            <div className="mb-4 row align-items-center">
                              <label className="form-label-title col-sm-3 mb-0">Scroll Message</label>
                              <div className="col-sm-9">
                                <input
                                  className="form-control"
                                  type="text"
                                  name="scroll_message"
                                  autoComplete="off"
                                  placeholder="Enter Scroll Message"
                                  value={scrollMessage}
                                  onChange={(e) => setScrollMessage(e.target.value)}
                                />
                              </div>
                            </div>

                            <div className="card-footer border-0 pb-0 d-flex justify-content-end">
                              <button className="btn btn-primary me-3" type="submit">
                                Submit
                              </button>
                              <button className="btn btn-outline" type="button" onClick={() => navigate(-1)}>
                                Cancel
                              </button>
                            </div>
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default EditScroll;
