import React, { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import axios from 'axios';
import Header from '../Components/Header';
import Skeleton from 'react-loading-skeleton';
import 'react-loading-skeleton/dist/skeleton.css';


const EditGallery = () => {
    const { gallery_id } = useParams(); 
    const navigate = useNavigate();
    const [oldImage, setOldImage] = useState(""); 
    const [newImageBase64, setNewImageBase64] = useState(""); 
    const [loading, setLoading] = useState(false);
    const [loading1, setLoading1] = useState(false);
    const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

    // Fetch old banner details
    useEffect(() => {
        setLoading1(true);
        axios.post(`${API_BASE_URL}gallery_detail.php`, { gallery_id })
            .then((response) => {
                if (response.data.head.code === 200) {
                    setOldImage(response.data.body.image); 
                    setLoading1(false);
                } else {
                    alert("Error fetching banner details: " + response.data.head.msg);
                }
            })
            .catch((error) => {
                console.error("API Error:", error);
                alert("Failed to load banner details!");
            });
    }, [gallery_id]);

    // Convert selected file to Base64
    const handleFileChange = (e) => {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onloadend = () => {
                setNewImageBase64(reader.result); 
            };
        }
    };

    // Submit updated banner
    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!newImageBase64) {
            alert("Please select an image to update!");
            return;
        }

        setLoading(true);
        try {
            const response = await axios.post(
                `${API_BASE_URL}gallery_detail_update.php`,
                { gallery_id, image: newImageBase64 } 
            );

            if (response.data.head.code === 200) {
                alert("Image updated successfully!");
                navigate("/gallerylist"); 
            } else {
                alert("Error: " + response.data.head.msg);
            }
        } catch (error) {
            console.error("API Error:", error);
            alert("Something went wrong! Please try again.");
        } finally {
            setLoading(false);
        }
    };

    return (
        <>
            <Header />
            <div className="page-wrapper compact-wrapper" id="pageWrapper">
                <div className="page-body-wrapper">
                    <div className="page-body">
                        <div className="container-fluid">
                            <div className="row">
                                <div className="col-12">
                                    <div className="row">
                                        <div className="col-sm-12 m-auto">
                                            <div className="card">
                                                <div className="card-body">
                                                    <div className="title-header option-title d-sm-flex d-block">
                                                        <h5>Edit Gallery Images</h5>
                                                        <div className="right-options">
                                                            <ul>
                                                                <li>
                                                                    <Link className="btn btn-solid" to="/gallerylist">Back</Link>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>

                                                    <form className="theme-form theme-form-2 mega-form" onSubmit={handleSubmit}>
                                                        {/* Display Old Image (Small Size) */}
                                                        <div className="mb-4 row align-items-center">
                                                            <label className="form-label-title col-sm-3 mb-0">Current Image</label>
                                                            <div className="col-sm-9">
                                                            {loading1 ? (
                                                                 <Skeleton width={200} height={200} />
                                                            ) : (
                                                                oldImage && (
                                                                <img
                                                                    src={oldImage}
                                                                    alt="Old Banner"
                                                                    width="200px"
                                                                    height="100px"
                                                                    style={{ borderRadius: "4px" }}
                                                                />
                                                                )
                                                            )}
                                                            </div>
                                                        </div>

                                                        {/* Upload New Image or Skeleton */}
                                                        <div className="mb-4 row align-items-center">
                                                            <label className="form-label-title col-sm-3 mb-0">Upload New Image</label>
                                                            <div className="col-sm-9">
                                                            {loading1? (
                                                                 <Skeleton width={600} height={40} />
                                                            ) : (
                                                                <>
                                                                <input
                                                                className="form-control form-choose"
                                                                type="file"
                                                                accept="image/*"
                                                                onChange={handleFileChange}
                                                                />
                                                                <p>Width 300px x 400px</p>
                                                                </>
                                                            )}
                                                            </div>
                                                        </div>

                                                        <div className="card-footer border-0 pb-0 d-flex justify-content-end">
                                                            <button type="submit" className="btn btn-primary me-3" disabled={loading}>
                                                                {loading ? "Updating..." : "Update"}
                                                            </button>
                                                            <button type="button" className="btn btn-outline" onClick={() => navigate("/gallerylist")}>Cancel</button>
                                                        </div>
                                                    </form>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </>
    );
};

export default EditGallery;
