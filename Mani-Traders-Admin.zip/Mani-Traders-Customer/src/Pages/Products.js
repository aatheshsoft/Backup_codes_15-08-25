import React, { useEffect, useState } from "react";
import Header from "../Components/Header";
import { Link, useParams } from "react-router-dom";
import axios from "axios";

const Products = () => {
  const { category_id} = useParams();
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [categories, setCategories] = useState([]);
  const [updateSuccess, setUpdateSuccess] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [selectedproductId, setSelectedProductId] = useState(null);
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

  const openDeleteModal = (product_id) => {
    setSelectedProductId(product_id);
    setShowModal(true);
  };
  const closeModal = () => {
    setSelectedProductId(null);
    setShowModal(false);
  };

  useEffect(() => {
   
    console.log(category_id);
    

    setLoading(true);

    axios
      .post(`${API_BASE_URL}product_list.php`, {
       
        category_id: category_id,
      })
      .then((response) => {
        console.log("API Response:", response.data); // Debugging

        if (response.data?.head?.code === 200) {
          const sortedProducts = response.data.body.sort(
            (a, b) => a.rank - b.rank
          );
          setProducts(sortedProducts);
        } else {
          console.error(
            "Error Fetching Data:",
            response.data?.head?.msg || "Unknown Error"
          );
        }
      })
      .catch((error) => {
        console.error("API Error:", error);
      })
      .finally(() => {
        setLoading(false);
      });
  }, [category_id]); // ✅ Dependencies added

  const handleChange = (product_id, field, value) => {
    setProducts((prevProducts) =>
      prevProducts.map((product) =>
        product.product_id === product_id
          ? { ...product, [field]: value }
          : product
      )
    );
  };

  const handleupdate = async (product_id, rank, day, night, kids,stock_close, active) => {
    try {
      const response = await axios.post(`${API_BASE_URL}product_list_update.php`, {
        product_id,
        rank,
        day,
        night,
        kids,
        stock_close,
        active,
      });

      if (response.data.head.code !== 200) {
        console.error("Error updating product:", response.data.head.msg);
      } else {
        setUpdateSuccess(true);
      }
    } catch (error) {
      console.error("Error updating product:", error);
    }
  };

  useEffect(() => {
    if (updateSuccess) {
      alert("Product Updated Successfully");
      setUpdateSuccess(false);
      window.location.reload();
    }
  }, [updateSuccess]);

  const handleDelete = async () => {
    if (!selectedproductId) return;

    try {
      const response = await axios.post(
        `${API_BASE_URL}product_list_delete.php`,
        {
          product_id: selectedproductId,
        }
      );
      if (response.data.head.code === 200) {
        alert("Product Deleted Successfully");
        closeModal();
        window.location.reload();
      } else {
        alert(response.head?.msg || "Failed To Delete Product");
      }
    } catch (error) {
      console.error("Error Deleting Product", error);
    }
  };

  return (
    <>
      <Header />
      <div class="page-wrapper compact-wrapper" id="pageWrapper">
        <div class="page-body-wrapper">
          <div className="page-body">
            <div className="container-fluid">
              <div className="row">
                <div className="col-sm-12">
                  <div className="card card-table">
                    <div className="card-body">
                      <div className="title-header option-title d-sm-flex d-block">
                        <h5>List of Product</h5>
                        <div className="right-options">
                          <ul>
                            <li>
                              <Link
                                className="btn btn-solid"
                                to="/subcategory"
                              >
                                Back
                              </Link>
                            </li>

                            <li>
                              <Link
                                className="btn btn-solid"
                                to="/addproducts"
                                state={{ category_id}}
                              >
                                Add Product
                              </Link>
                            </li>
                          </ul>
                        </div>
                      </div>

                      <div class="row">
                        <div class="col-sm-6">
                          <form
                            method="post"
                            
                            class="theme-form theme-form-2 mega-form"
                          >
                            <div class="mb-4 row align-items-center">
                              {/* <!-- Search Box --> */}
                              <label
                                for="search"
                                class="col-sm-2 col-form-label"
                              >
                                Search:
                              </label>
                              <div class="col-sm-10">
                                <input
                                  type="text"
                                  id="search"
                                  name="search"
                                  class="form-control"
                                  placeholder="Search Products"
                                />
                              </div>
                            </div>
                          </form>
                        </div>
                      </div>
                      
                      <form>
                        {loading ? (
                          <div style={{ display: "flex", justifyContent: "center", marginTop: "50px" }}>
                          <div className="loader"></div>
                        </div>
                        ) : (
                          <>
                            <div className="table-responsive">
                              <table
                                className="table all-package theme-table table-product"
                                id="table_id"
                              >
                                <thead>
                                  <tr>
                                    <th>S.No.</th>
                                    <th>Product Name</th>
                                    <th style={{ textAlign: "center" }}>
                                      Rank
                                    </th>
                                    {/* <th>Day</th>
                                    <th>Night   </th>
                                    <th>Kids   </th> */}
                                    <th>Stock Close </th>
                                    <th>Active</th>
                                    
                                    <th style={{ textAlign: "center" }}>
                                      Action
                                    </th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {products.map((product, index) => (
                                    <tr key={product.id}>
                                      <td>{index + 1}</td>
                                      
                                      
                                      <td>{product.product_name}</td>
                                      <td style={{ textAlign: "center" }}>
                                        <input
                                          className="checkbox_animated check-it"
                                          type="text"
                                          size="4"
                                          name={`rank_${product.product_id}`}
                                          value={product.rank ?? ""}
                                          onChange={(e) =>
                                            handleChange(
                                              product.product_id,
                                              "rank",
                                              e.target.value
                                            )
                                          }
                                        />
                                      </td>
                                      {/* <td style={{ textAlign: "center" }}>
                                                    <input
                                                      className="checkbox_animated check-it"
                                                      type="checkbox"
                                                      name={`day_${product.product_id}`}
                                                      checked={product.day === "1"}
                                                      onChange={(e) =>
                                                        handleChange(
                                                          product.product_id,
                                                          "day",
                                                          e.target.checked ? "1" : "0"
                                                        )
                                                      }
                                                    />
                                                  </td>

                                                  <td style={{ textAlign: "center" }}>
                                                    <input
                                                      className="checkbox_animated check-it"
                                                      type="checkbox"
                                                      name={`night_${product.product_id}`}
                                                      checked={product.night === "1"}
                                                      onChange={(e) =>
                                                        handleChange(
                                                          product.product_id,
                                                          "night",
                                                          e.target.checked ? "1" : "0"
                                                        )
                                                      }
                                                    />
                                                  </td>

                                                  <td style={{ textAlign: "center" }}>
                                                    <input
                                                      className="checkbox_animated check-it"
                                                      type="checkbox"
                                                      name={`kids_${product.product_id}`}
                                                      checked={product.kids === "1"}
                                                      onChange={(e) =>
                                                        handleChange(
                                                          product.product_id,
                                                          "kids",
                                                          e.target.checked ? "1" : "0"
                                                        )
                                                      }
                                                    />
                                                  </td> */}
                                                  <td style={{ textAlign: "center" }}>
                                                    <input
                                                      className="checkbox_animated check-it"
                                                      type="checkbox"
                                                      name={`stock_close_${product.product_id}`}
                                                      checked={product.stock_close === "1"}
                                                      onChange={(e) =>
                                                        handleChange(
                                                          product.product_id,
                                                          "stock_close",
                                                          e.target.checked ? "1" : "0"
                                                        )
                                                      }
                                                    />
                                                  </td>
                                                  <td style={{ textAlign: "center" }}>
                                                    <input
                                                      className="checkbox_animated check-it"
                                                      type="checkbox"
                                                      name={`active_${product.product_id}`}
                                                      checked={product.active === "1"}
                                                      onChange={(e) =>
                                                        handleChange(
                                                          product.product_id,
                                                          "active",
                                                          e.target.checked ? "1" : "0"
                                                        )
                                                      }
                                                    />
                                                  </td>



                                      <td style={{ textAlign: "center" }}>
                                        <ul>
                                          <li>
                                            <Link
                                              to={`/editproducts/${product.product_id}`}
                                              state={{
                                                category_id,
                                              
                                              }}
                                            >
                                              <i className="ri-pencil-line"></i>
                                            </Link>
                                          </li>
                                          <li>
                                            <a
                                              href="#"
                                              onClick={(e) => {
                                                e.preventDefault();
                                                openDeleteModal(
                                                  product.product_id
                                                );
                                              }}
                                            >
                                              <i className="ri-delete-bin-line"></i>
                                            </a>
                                          </li>
                                        </ul>
                                      </td>
                                    </tr>
                                  ))}
                                </tbody>
                              </table>
                            </div>
                            <div className="card-footer border-0 pb-0 d-flex justify-content-end">
                              <ul>
                              <li>
                              <Link
                                className="btn btn-solid"
                                to="/addproducts"
                                state={{ category_id}}
                              >
                                Add Product
                              </Link>
                            </li>
                              </ul>&nbsp;&nbsp;
                              <button
                                className="btn btn-primary me-3"
                                type="button"
                                onClick={() => {
                                  products.forEach((product) => {
                                    handleupdate(
                                      product.product_id,
                                      product.rank,
                                      product.day,
                                      product.night,
                                      product.kids,
                                      product.stock_close,
                                      product.active,
                                    );
                                  });
                                }}
                              >
                                Update
                              </button>
                            </div>
                          </>
                        )}
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {showModal && (
        <div className="modal fade show" style={{ display: "block" }}>
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-body">
                <h5>Confirm Delete</h5>
                <p>Are you sure you want to delete this product?</p>
                <button
                  type="button"
                  className="btn-close"
                  onClick={closeModal}
                ></button>
              </div>
              <div className="modal-footer">
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={closeModal}
                >
                  No
                </button>
                <button
                  type="button"
                  className="btn btn-danger"
                  onClick={handleDelete}
                >
                  Yes, Delete
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default Products;
