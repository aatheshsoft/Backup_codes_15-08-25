import React, { useEffect, useState } from "react";
import Header from "../Components/Header";
import { Link, useParams, useLocation, useNavigate } from "react-router-dom";
import axios from "axios";
import Skeleton from "react-loading-skeleton";
import "react-loading-skeleton/dist/skeleton.css";

const EditSubcategory = () => {
  const [subcategory, setSubcategory] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [image, setImage] = useState(null); // for newly selected image (Base64)
  const [previousImage, setPreviousImage] = useState(null); // store old image separately
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

  const location = useLocation();
  const navigate = useNavigate();
  const { category_id } = useParams(); // Get category_id from URL

  const apiUrl = `${API_BASE_URL}category_detail.php`;

  useEffect(() => {
    const fetchSubcategory = async () => {
      try {
        const response = await axios.post(apiUrl, { category_id: category_id });
        if (response.data && response.data.body) {
          setSubcategory(response.data.body);
          setPreviousImage(response.data.body.image); // set old image separately
        } else {
          setError("No data found");
        }
      } catch (error) {
        setError("Failed to fetch data");
      } finally {
        setLoading(false);
      }
    };

    fetchSubcategory();
  }, [category_id]);

  const handleImageChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result); // New Base64 image
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    const formData = {
      category_id: category_id,
      category_name: event.target.name.value,
      image: image || previousImage || "", // Use new image if available, otherwise old image
    };

    try {
      const response = await axios.post(`${API_BASE_URL}category_detail_update.php`, formData);
      if (response.data.head.code === 200) {
        alert('Category detail updated successfully');
        navigate("/subcategory");
      } else {
        setError("Failed to update category");
      }
    } catch (error) {
      setError("Error updating category");
    }
  };

  const handleDeleteImage = () => {
    setPreviousImage(null); // Delete old image
    setImage(null); // Also clear new image if already uploaded
  };

  if (error) return <p className="text-danger">{error}</p>;

  return (
    <>
      <Header />
      <div className="page-wrapper compact-wrapper" id="pageWrapper">
        <div className="page-body-wrapper">
          <div className="page-body">
            <div className="container-fluid">
              <div className="row">
                <div className="col-12">
                  <div className="row">
                    <div className="col-sm-12 m-auto">
                      <div className="card">
                        <div className="card-body">
                          <div className="title-header option-title d-sm-flex d-block">
                            <h5>Edit Category</h5>
                            <div className="right-options">
                              <ul>
                                <li>
                                  <Link className="btn btn-solid" to="/subcategory">
                                    Back
                                  </Link>
                                </li>
                              </ul>
                            </div>
                          </div>

                          {loading ? (
                            <div className="p-4">
                              <div className="mb-4 row align-items-center">
                                <label className="form-label-title col-sm-3 mb-0">Category</label>
                                <div className="col-sm-9">
                                  <Skeleton height={40} />
                                </div>
                              </div>

                              <div className="mb-4 row align-items-center">
                                <label className="form-label-title col-sm-3 mb-0">Image</label>
                                <div className="col-sm-9">
                                  <Skeleton height={100} width={100} />
                                </div>
                              </div>

                              <div className="card-footer border-0 pb-0 d-flex justify-content-end">
                                <Skeleton width={100} height={40} className="me-3" />
                                <Skeleton width={100} height={40} />
                              </div>
                            </div>
                          ) : (
                            <form className="theme-form theme-form-2 mega-form" onSubmit={handleSubmit}>
                              <div className="mb-4 row align-items-center">
                                <label className="form-label-title col-sm-3 mb-0">Category</label>
                                <div className="col-sm-9">
                                  <input
                                    className="form-control"
                                    type="text"
                                    name="name"
                                    autoComplete="off"
                                    defaultValue={subcategory.category_name}
                                    placeholder="Enter Category"
                                  />
                                </div>
                              </div>

                              {previousImage ? (
                                <div className="mb-4 row align-items-center">
                                  <label className="form-label-title col-sm-3 mb-0">Current Image</label>
                                  <div className="col-sm-9">
                                    <img
                                      src={previousImage}
                                      alt="Subcategory"
                                      style={{ width: "100px", height: "100px", objectFit: "contain" }}
                                    />
                                    <button className="btn btn-danger mt-2" type="button" onClick={handleDeleteImage}>
                                      Delete Image
                                    </button>
                                  </div>
                                </div>
                              ) : (
                                <div className="mb-4 row align-items-center">
                                  <label className="form-label-title col-sm-3 mb-0">Upload Image</label>
                                  <div className="col-sm-9">
                                    <input
                                      type="file"
                                      className="form-control"
                                      name="image"
                                      onChange={handleImageChange}
                                    />
                                    <p>Width 500px x 500px</p>
                                  </div>
                                </div>
                              )}

                              <div className="card-footer border-0 pb-0 d-flex justify-content-end">
                                <button className="btn btn-primary me-3" type="submit">
                                  Submit
                                </button>
                                <button className="btn btn-outline" type="button" onClick={() => window.history.back()}>
                                  Cancel
                                </button>
                              </div>
                            </form>
                          )}

                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default EditSubcategory;
