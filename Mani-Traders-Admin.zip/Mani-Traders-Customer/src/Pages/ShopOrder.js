import React, { useEffect, useState } from "react";
import {
  Container,
  Row,
  Col,
  Button,
  Table,
  Form,
  InputGroup,
  Card,
  Modal,
} from "react-bootstrap";
import { FaPlus, FaSearch, FaShoppingCart, FaTrash } from "react-icons/fa";
import { BiRupee } from "react-icons/bi";
import { RiSave3Line } from "react-icons/ri";
import { LuPrinter } from "react-icons/lu";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";
import Spinner from "react-bootstrap/Spinner";
import Header from "../Components/Header";

const ShopOrder = () => {
  const [cart, setCart] = useState([]);
  const [filteredCodes, setFilteredCodes] = useState([]);
  const [products, setProducts] = useState([]);
  const [fullproducts, setFullProducts] = useState([]);
  const [productCode, setProductCode] = useState("");
  const [productName, setProductName] = useState("");
  const [selectedCustomer, setSelectedCustomer] = useState("");
  const [loading, setLoading] = useState(true);
  const [Loading1, setLoading1] = useState();
  const [Loading2, setLoading2] = useState();
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
  const [sellPrice, setSellPrice] = useState("");
  const [supplierlist, setSupplierList] = useState("")
  const [customer, setCustomer] = useState([]);
  const [show, setShow] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const navigate = useNavigate();
    const [discount, setDiscount] = useState(""); // Discount in %
    const[cgst, setCgst] = useState("");
    const[sgst, setSgst] = useState("");

  const [formData, setFormData] = useState({
    supplier_name: "",
    address: "",
    mobile: "",
    creditlimit: "",
    gstin: "",
     firstName: "",
    mobileNumber: "",
    email: "",
    
    city: "",
    state: "",
    pincode: "",
  });
  console.log(searchTerm);
  const handleShow = () => setShow(true);
  const handleClose = () => setShow(false);

  // Handle Form Input Change
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };


  
  const handlePriceChange = (productId, newPrice) => {
    setSellPrice((prevPrices) => ({
      ...prevPrices,
      [productId]: newPrice, // Store price based on product ID
    }));
  };
  

  const handleSubmit = async (e) => {
    e.preventDefault();

    const payload = {
      supplier_name: formData.supplier_name,

      gst_number: formData.gst_number,      // FIXED
      mobile: formData.mobile,        // FIXED
      address: formData.address,
      
    };

    console.log("Payload:", payload);

    try {
      const response = await fetch(`${API_BASE_URL}supplier_add.php`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }

      const data = await response.json();
      console.log("API Response:", data);

      if (data.head.code === 200) {
        alert("Supplier added successfully!");
        setShow(false);
        window.location.reload();
      } else {
        alert("Failed to add Supplier. Error: " + data.head.msg);
      }
    } catch (error) {
      console.error("Network/API Error:", error);
      alert("Required field is empty");
    }
  };

  // useEffect(() => {
  //       axios.post(`${API_BASE_URL}supplier_list.php`)
  //         .then(response => {
  //           if (response.data.head.code === 200) {
  //             setSupplierList(response.data.body);
  //           } else {
  //             console.error("Error fetching categories:", response.data.head.msg);
  //           }
  //         })
  //         .catch(error => console.error("API Error:", error));
  //     }, []);
    



 useEffect(() => {
  setLoading(true);
  axios
    .post("https://manifriendstraders.com/customer_api/quick_buy.php")
     .then((response) => {
    if (response.data.head.code === 200) {
      const categories = response.data.body.category;
      const allProducts = categories.flatMap(cat => cat.product || []);
      setSgst(response.data.body.gst_percentage[0].sgst_per);
      setCgst(response.data.body.gst_percentage[0].cgst_per);

      setProducts(allProducts); // full product list
      setFilteredProducts(allProducts); // initialize filtered list
    }
  });

   
}, []);


  // Handle product code input with dropdown suggestion
  const handleCodeInput = (event) => {
    const code = event.target.value.trim().toUpperCase();
    setProductCode(code);

    if (code.length === 0) {
      setFilteredCodes([]);
      setProductName("");
      return;
    }

    // Filter products for dropdown suggestions
    const filtered = filteredProducts.filter((p) => p.product_code.includes(code));
    setFilteredCodes(filtered);

    // Find exact match when full code is entered
    const product = filteredProducts.find((p) => p.product_code === code);

    if (product) {
      setFilteredCodes([]); // Close dropdow

      setProductName(product.product_name);
      addToCart(product); // ✅ Add only if in stock
    } else {
      setProductName(""); // Clear if no exact match
    }
  };

  // Handle dropdown selection
  const handleDropdownSelect = (product) => {
    setFilteredCodes([]); // Close dropdown

    // Ensure product is valid
    if (!product || !product.product_code || !product.product_name) {
      alert("Invalid product selection!");
      return;
    }
    setProductCode(product.product_code);
    setProductName(product.product_name);
    addToCart(product); // ✅ Add to cart only if in stock
  };

  // Handle Product Name Input
  
const [filteredProducts, setFilteredProducts] = useState([]);

// Handle supplier selection
const handleSupplierChange = (e) => {
  const selectedId = e.target.value;

  // Find selected supplier
  const supplier = supplierlist.find((s) => String(s.id) === String(selectedId));

  setSelectedCustomer(supplier || null); // Update selected supplier

  if (supplier) {
    // Filter products related to the selected supplier
    const supplierProducts = products.filter(
      (product) => String(product.supplier_id) === String(supplier.id)
    );
    setFilteredProducts(supplierProducts);
  } else {
    setFilteredProducts([]); // Reset if no supplier is selected
  }
};



// Handle product selection
const handleNameInput = (event) => {
  const name = event.target.value.trim();
  setProductName(name);

  if (!filteredProducts.length) return; // Ensure products are loaded

  const product = filteredProducts.find(
    (p) => p.product_name.trim().toLowerCase() === name.toLowerCase()
  );

  console.log("Selected Name:", name);
  console.log("Matching Product:", product);

  if (product) {
   if (product) {
  // Remove this block if product_code is not mandatory
  // if (!product.product_code) {
  //   alert("Invalid product details!");
  //   setProductCode("");
  //   setProductName("");
  //   return;
  // }

  // If you still want to track it, set it as undefined or fallback
  setProductCode(product.product_code || ""); 
  addToCart(product);
}


    setProductCode(product.product_code);
    addToCart(product);
  } else {
    setProductCode("");
  }
};


const [price, setPrice] = useState({});

  // Initialize price state when cart data is available
  useEffect(() => {
    if (cart.length > 0) {
      setPrice(
        cart.reduce((acc, item) => ({ ...acc, [item.product_id]: item.old_price }), {})
      );
    }
  }, [cart]); // Runs when cart updates

  // Handle input change
  const handleBuyPriceChange = (e, productId) => {
    const newPrice = parseFloat(e.target.value) || 0;
  
    setCart((prevCart) =>
      prevCart.map((item) =>
        item.product_id === productId
          ? { ...item, old_price: newPrice }
          : item
      )
    );
  };





  // Add Product to Cart
 const addToCart = (product) => {
  setCart((prevCart) => {
    const existingProduct = prevCart.find(
      (item) => item.product_id === product.product_id
    );

    if (existingProduct) {
      // 🛑 Prevent duplicate add on selection (do not increment)
      return prevCart;
    }

    // ✅ Add with initial qty = 1
    return [...prevCart, { ...product, qty: 1 }];
  });
};


  const handleQtyChange = (e, product) => {
    let prevQty = product.qty; // Store previous quantity
    let newQty = e.target.value.replace(/^0+/, ""); // Remove leading zeros

    if (newQty === "" || isNaN(newQty)) {
      newQty = "";
    } else {
      newQty = parseInt(newQty, 10);

      // ✅ Ensure new quantity is not less than 1
      if (newQty < 1) {
        newQty = 1;
      }

      // // ✅ Handle stock limit and show alert correctly
      // if (newQty > product.stock) {
      //     alert(`Only ${product.stock} items available in stock!`);
      //     newQty = product.stock; // Reset to max stock
      // }
    }

    // ✅ Update state correctly
    setCart((prevCart) =>
      prevCart.map((item) =>
        item.product_id === product.product_id ? { ...item, qty: newQty } : item
      )
    );
  };

  // ✅ Ensure Minimum Quantity = 1 on Blur
  const handleQtyBlur = (e, product) => {
    let newQty = parseInt(e.target.value, 10) || 1;
    if (newQty < 1) newQty = 1;

    setCart((prevCart) =>
      prevCart.map((item) =>
        item.product_id === product.product_id ? { ...item, qty: newQty } : item
      )
    );
  };

 const calculateTotal = () => {
    return (
      cart.reduce((total, item) => {
        const basePrice = price[item.product_id]
          ? parseFloat(price[item.product_id])
          : item.oldprice;
        return total + basePrice * item.qty;
      }, 0) || 0
    );
  };

  const total = calculateTotal(); // base amount before discount
const discountamount = (total * discount) / 100;
const discountedTotal = total - discountamount;

// convert sgst and cgst to float
const cgstValue = parseFloat(cgst);
const sgstValue = parseFloat(sgst);

// calculate tax amounts
const cgstamount = (discountedTotal * cgstValue) / 100;
const sgstamount = (discountedTotal * sgstValue) / 100;

const grandTotal = discountedTotal + cgstamount + sgstamount;


  

  const removeItem = (id) => {
    setCart(cart.filter((item) => item.product_id !== id));
  };
  const extractSellPrice = (sellPrice, productId) => {
    if (!sellPrice) return "0";
    if (typeof sellPrice === "object") {
      return sellPrice[productId] ? String(sellPrice[productId]) : "0"; 
    }
    return String(sellPrice); 
  };
  
  const handleSave = () => {
  if (
  !formData.firstName ||
  !formData.mobileNumber ||
  !formData.address
) {
  alert("Please fill in all customer details.");
  return;
}

    setLoading1(true);
    if (!cart || cart.length === 0) {
      setLoading1(false);
      alert("Please select a product");
      return;
    }
   const orderData = {
        name: formData.firstName,
        email: formData.email,
        phonenumber: formData.mobileNumber,
        address: formData.address,
        city: formData.city,
        state: formData.state,
        pincode: formData.pincode,
        subtotal: total,
        discount_percentage:discount,
        discount:discountamount,
        totalcgst_amt:cgstamount,
        totalsgst_amt:sgstamount,
        // coupon_discount:coupondiscountamount,
        total: grandTotal,
        // coupen_code: isCouponApplied ? couponCode : "",
        product: cart.map((item) => ({
          product_id: item.product_id,
          category_id: item.category_id || "",
          product_name: item.product_name,
          unit_price: item.oldprice,
          quantity: item.qty,
          final_price: parseFloat(item.oldprice) * item.qty, 
        })),
    };
    
    console.log(orderData);
   axios
  .post("https://manifriendstraders.com/admin_api/shop_order.php", orderData)
  .then((response) => {
    try {
      if (response.data.head.code === 200) {
        console.log("Order Saved:", response.data);
        alert("Order saved successfully!");
        setCart([]);
        window.location.reload();
      } else {
        console.log("Error", response.data.head.msg);
        alert("Order failed: " + response.data.head.msg);
      }
    } catch (error) {
      console.error("Then block error:", error);
      alert("An unexpected error occurred while processing the order.");
    }
  })
  .catch((error) => {
    console.error("Save Order Error:", error);
    alert("Failed to save order.");
  })
  .finally(() => {
    setLoading1(false);
  });

  };

 const [formErrors, setFormErrors] = useState({});

 const validate = () => {
    const errors = {};
    if (!formData.firstName.trim()) errors.firstName = "First name is required";
    if (!formData.mobileNumber.match(/^\d{10}$/))
      errors.mobileNumber = "Mobile number must be 10 digits";
    if (formData.email && !/\S+@\S+\.\S+/.test(formData.email))
      errors.email = "Email is invalid";
    if (!formData.address.trim()) errors.address = "Address is required";
    if (!formData.city.trim()) errors.city = "City is required";
    if (!formData.pincode.match(/^\d{6}$/))
      errors.pincode = "Pincode must be 6 digits";

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };
 

  return (
    <>
      <Header />
      <div className="page-wrapper compact-wrapper" id="pageWrapper">
        <div className="page-body-wrapper">
          <div className="page-body">
            <div className="container-fluid">
              <div className="row">
                <div className="col-12">
                  <div className="row">
                    <div className="col-sm-12 m-auto">
                      <div className="card">
                        <div className="card-body">
                          <div className="title-header option-title d-sm-flex d-block">
                            <h5>Shop Order</h5>
                            <div className="right-options">
                              <ul>
                                <li>
                                  <button
                                    className="btn btn-solid"
                                    onClick={() => window.history.back()}
                                  >
                                    Back
                                  </button>
                                </li>
                              </ul>
                            </div>
                          </div>
                          <Container
                            fluid
                            className="p-3"
                            style={{ minHeight: "100vh" }}
                          >
                            <Row>
                              <Col
                                md={12}
                                sm={12}
                                className="border-end mt-2"
                                style={{
                                  height: "95vh",
                                  display: "flex",
                                  flexDirection: "column",
                                }}
                              >
                                


                                <Row>


                                  <Col md={6}>
                                    <InputGroup className="mb-3">
                                    <Form.Select value={productName} onChange={handleNameInput}>
                                        <option value="">Select Product</option>
                                        {filteredProducts.map((product) => (
                                         <option key={product.product_id} value={product.product_name || ""}>
                                          {product.product_name || "Unnamed Product"}
                                        </option>

                                        ))}
                                      </Form.Select>

                                    </InputGroup>
                                  </Col>
                                </Row>

                                {/* Table to Display Selected Products */}
                                <div
                                  style={{
                                    flexGrow: 1,
                                    overflowY: "auto",
                                    border: "1px solid #ddd",
                                  }}
                                >
                                  <Table bordered responsive>
                                    <thead>
                                      <tr>
                                        <th style={{ width: "5%" }}>S.No</th>
                                    
                                        <th style={{ width: "20%" }}>Item</th>
                                     
                                        <th
                                          style={{
                                            width: "10%",
                                            textAlign: "right",
                                          }}
                                        >
                                           Price
                                        </th>
                                        
                                        <th style={{ width: "10%" }}>Qty</th>
                                        <th
                                          style={{
                                            width: "10%",
                                            textAlign: "right",
                                          }}
                                        >
                                          Total
                                        </th>
                                        <th style={{ width: "5%" }}>Del</th>
                                      </tr>
                                    </thead>

                                    <tbody>
                                      {cart.map((item, index) => (
                                        <tr key={item.product_id}>
                                          <td>{index + 1}</td>
                                          {/* <td>{item.category_name}</td> */}
                                          <td>{item.product_name}</td>
                                          {/* <td>{item.box_contents}</td> */}
                                          <td style={{ textAlign: "right" }}>
                                                <BiRupee />
                                               
                                                  {item.oldprice}
                                                 
                                              </td>



                                       
                                          <td>
                                            <input
                                              type="number"
                                              value={item.qty}
                                              min="1"
                                              // max={item.stock}
                                              className="form-control text-center"
                                              style={{ width: "60px" }}
                                              onInput={(e) =>
                                                handleQtyChange(e, item)
                                              } // ✅ Works for both typing & button clicks
                                              onBlur={(e) =>
                                                handleQtyBlur(e, item)
                                              }
                                            />
                                          </td>

                                          <td style={{ textAlign: "right" }}>
                                            <BiRupee />
                                            {(
                                              (price[item.product_id] ? parseFloat(price[item.product_id]) : item.oldprice) * item.qty
                                            ).toFixed(2)}
                                          </td>

                                          <td>
                                            <Button
                                              variant="danger"
                                              size="sm"
                                              onClick={() =>
                                                removeItem(item.product_id)
                                              }
                                            >
                                              <FaTrash />
                                            </Button>
                                          </td>
                                        </tr>
                                      ))}
                                    </tbody>
                                  </Table>
                                </div>

                                <div className="bg-light p-3 border rounded d-flex justify-content-between print-btn-group"  >
                                 <div className="print-btn"></div>

                                  <div
                                    style={{
                                      display: "flex",
                                      flexDirection: "column",
                                      gap: "5px",
                                      justifyContent:"flex-end"
                                    }}
                                  >
                                    <div
                                  style={{
                                    display: "flex",
                                    flexDirection: "column",
                                    gap: "10px",
                                    width: "250px",
                                    
                                  }}
                                >
                                  {/* Sub-Total */}
                                  <div style={{ display: "flex", justifyContent: "space-between" }}>
                                    <h5 style={{ color: "black", fontWeight: "bold" }}>Sub-Total:</h5>
                                    <h5 style={{ color: "black", fontWeight: "bold" }}>
                                      <BiRupee />
                                      {total.toFixed(2)}
                                    </h5>
                                  </div>

                                  {/* Discount Input */}
                                  <input
                                    type="text"
                                    placeholder="Enter discount %"
                                    value={discount}
                                    onChange={(e) => setDiscount(Number(e.target.value))}
                                    style={{
                                      padding: "6px",
                                      fontSize: "14px",
                                      borderRadius: "4px",
                                      border: "1px solid #ccc",
                                    }}
                                  />
                                        <div style={{ display: "flex", justifyContent: "space-between" }}>
                                    <h5 style={{ color: "black", fontWeight: "bold" }}>Discount:</h5>
                                    <h5 style={{ color: "black", fontWeight: "bold" }}>
                                      <BiRupee />
                                      {discountamount.toFixed(2)}
                                    </h5>
                                  </div>
                                  <div style={{ display: "flex", justifyContent: "space-between" }}>
                                    <h5 style={{ color: "black", fontWeight: "bold" }}>CGST:</h5>
                                    <h5 style={{ color: "black", fontWeight: "bold" }}>
                                      <BiRupee />
                                      {cgstamount.toFixed(2)}
                                    </h5>
                                  </div>
                                   <div style={{ display: "flex", justifyContent: "space-between" }}>
                                    <h5 style={{ color: "black", fontWeight: "bold" }}>SGST:</h5>
                                    <h5 style={{ color: "black", fontWeight: "bold" }}>
                                      <BiRupee />
                                      {sgstamount.toFixed(2)}
                                    </h5>
                                  </div>
                                  {/* Grand Total */}
                                  <div style={{ display: "flex", justifyContent: "space-between" }}>
                                    <h5 style={{ color: "black", fontWeight: "bold" }}>Grand Total:</h5>
                                    <h5 style={{ color: "black", fontWeight: "bold" }}>
                                      <BiRupee />
                                      {grandTotal.toFixed(2)}
                                    </h5>
                                  </div>
                                </div>

                                   
                                  </div>
                                </div>
                            


                              </Col>
<form>
      <h5 className="fw-bold mb-4">Customer Details</h5>

      {/* First Name */}
      <div className="row mb-3 align-items-center">
        <label className="col-md-4 col-sm-4 form-label-title">First Name</label>
        <div className="col-md-8 col-sm-8">
          <input
            className={`form-control ${formErrors.firstName ? "is-invalid" : ""}`}
            type="text"
            name="firstName"
            placeholder="Enter First Name"
            value={formData.firstName}
            onChange={handleChange}
            required
          />
          <div className="invalid-feedback">{formErrors.firstName}</div>
        </div>
      </div>

      {/* Mobile Number */}
      <div className="row mb-3 align-items-center">
        <label className="col-md-4 col-sm-4 form-label-title">Mobile Number</label>
        <div className="col-md-8 col-sm-8">
          <input
            className={`form-control ${formErrors.mobileNumber ? "is-invalid" : ""}`}
            type="tel"
            name="mobileNumber"
            placeholder="Enter Mobile Number"
            value={formData.mobileNumber}
            onChange={handleChange}
            maxLength={10}
            pattern="[0-9]*"
            required
          />
          <div className="invalid-feedback">{formErrors.mobileNumber}</div>
        </div>
      </div>

      {/* Email */}
      <div className="row mb-3 align-items-center">
        <label className="col-md-4 col-sm-4 form-label-title">Email</label>
        <div className="col-md-8 col-sm-8">
          <input
            className={`form-control ${formErrors.email ? "is-invalid" : ""}`}
            type="email"
            name="email"
            placeholder="Enter Email"
            value={formData.email}
            onChange={handleChange}
          />
          <div className="invalid-feedback">{formErrors.email}</div>
        </div>
      </div>

      {/* Address */}
      <div className="row mb-3 align-items-center">
        <label className="col-md-4 col-sm-4 form-label-title">Address</label>
        <div className="col-md-8 col-sm-8">
          <textarea
            className={`form-control ${formErrors.address ? "is-invalid" : ""}`}
            name="address"
            placeholder="Enter Address"
            rows="3"
            value={formData.address}
            onChange={handleChange}
            
          />
          <div className="invalid-feedback">{formErrors.address}</div>
        </div>
      </div>

      {/* City */}
      <div className="row mb-3 align-items-center">
        <label className="col-md-4 col-sm-4 form-label-title">City</label>
        <div className="col-md-8 col-sm-8">
          <input
            className={`form-control ${formErrors.city ? "is-invalid" : ""}`}
            type="text"
            name="city"
            placeholder="Enter City"
            value={formData.city}
            onChange={handleChange}
            
          />
          <div className="invalid-feedback">{formErrors.city}</div>
        </div>
      </div>

      {/* State */}
      <div className="row mb-3 align-items-center">
        <label className="col-md-4 col-sm-4 form-label-title">State</label>
        <div className="col-md-8 col-sm-8">
          <input
            className="form-control"
            type="text"
            name="state"
            placeholder="Enter State"
            value={formData.state}
            onChange={handleChange}
          />
        </div>
      </div>

      {/* Pincode */}
      <div className="row mb-4 align-items-center">
        <label className="col-md-4 col-sm-4 form-label-title">Pincode</label>
        <div className="col-md-8 col-sm-8">
          <input
            className={`form-control ${formErrors.pincode ? "is-invalid" : ""}`}
            type="text"
            name="pincode"
            placeholder="Enter Pincode"
            value={formData.pincode}
            onChange={handleChange}
             maxLength={6}
          />
          <div className="invalid-feedback">{formErrors.pincode}</div>
        </div>
      </div>

      {/* Submit Button */}
      <div className="print-btn" style={{display:"flex",justifyContent:"flex-end"}}>
                                        <Button
                                          variant="dark"
                                          onClick={handleSave}
                                          style={{
                                            width: "80px",
                                            height: "40px",
                                           
                                          }}
                                        >
                                          {Loading1 ? (
                                            <Spinner
                                              animation="border"
                                              size="sm"
                                            />
                                          ) : (
                                            <>
                                              Submit
                                            </>
                                          )}
                                        </Button>
                                        &nbsp;&nbsp;
                                        
                                      </div>
                                      </form>
                             
                            </Row>
                            {/* -------------Customer Add Modal  Start --------------- */}
                            <Modal show={show} onHide={handleClose} centered>
                              <Modal.Header closeButton>
                                <Modal.Title>Add Supplier</Modal.Title>
                              </Modal.Header>
                              <Modal.Body>
                                <Form onSubmit={handleSubmit}>
                                  {/* Customer Name */}
                                  <Form.Group className="mb-3">
                                    <Form.Label>Supplier Name</Form.Label>
                                    <Form.Control
                                      type="text"
                                      name="supplier_name"
                                      value={formData.supplier_name}
                                      onChange={handleChange}
                                      placeholder="Enter Supplier Name"
                                      required
                                    />
                                  </Form.Group>

                                  <Form.Group className="mb-3">
                                    <Form.Label>Phone Number</Form.Label>
                                    <Form.Control
                                      type="text"
                                      name="mobile"
                                      value={formData.mobile}
                                      onChange={handleChange}
                                      placeholder="Enter Phone Number"
                                      required
                                      maxLength={10}
                                    />
                                  </Form.Group>

                                 {/*  <Form.Group className="mb-3">
                                    <Form.Label>Credit Limit</Form.Label>
                                    <Form.Control
                                      type="text"
                                      name="creditlimit"
                                      value={formData.creditlimit}
                                      onChange={handleChange}
                                      placeholder="Enter Credit Limit"
                                    />
                                  </Form.Group> */}

                                  {/* Address */}
                                  <Form.Group className="mb-3">
                                    <Form.Label>Address</Form.Label>
                                    <Form.Control
                                      as="textarea"
                                      name="address"
                                      value={formData.address}
                                      onChange={handleChange}
                                      placeholder="Enter Address"
                                      rows={3}
                                    />
                                  </Form.Group>

                                  {/* GSTIN/UIN */}
                                  <Form.Group className="mb-3">
                                    <Form.Label>GSTIN/UIN</Form.Label>
                                    <Form.Control
                                      type="text"
                                      name="gstin"
                                      value={formData.gstin}
                                      onChange={handleChange}
                                      placeholder="Enter GSTIN/UIN"
                                      maxLength={15}
                                    />
                                  </Form.Group>

                                  {/* Submit Button */}
                                  <Button variant="success" type="submit">
                                    Submit
                                  </Button>
                                </Form>
                              </Modal.Body>
                            </Modal>
                            {/* -------------Customer Add Modal  End --------------- */}
                          </Container>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ShopOrder;
