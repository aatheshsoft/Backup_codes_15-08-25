import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import Header from "../Components/Header";
import axios from "axios";

const OrderList = () => {
  const [orders, setOrders] = useState([]);
  const [filteredOrders, setFilteredOrders] = useState([]);
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [loading, setLoading] = useState(true); 
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
  const [showModal, setShowModal] = useState(false);
    const [selectedorderId, setSelectedOrderId] = useState(null);
  
  
  const openDeleteModal = (order_id) =>{
    setSelectedOrderId(order_id)
    setShowModal(true);
  }
  const closeModal = () => {
    setSelectedOrderId(null);
    setShowModal(false);
};

  useEffect(() => {
    setLoading(true);
    axios.post(`${API_BASE_URL}order.php`)
      .then((response) => {
        if (response.data.head.code === 200 && Array.isArray(response.data.body)) {
          setOrders(response.data.body);
          setFilteredOrders(response.data.body);
        } else {
          console.error("Error Fetching Data:", response.data.head.msg);
          setOrders([]);
          setFilteredOrders([]);
        }
      })
      .catch((error) => {
        console.error("API Error:", error);
        setOrders([]);
        setFilteredOrders([]);
      }) .finally(() => {
        setLoading(false); // Set loading to false after API call
      });
  }, []);

  // ✅ Convert DD/MM/YYYY → YYYY-MM-DD for correct comparison
  const convertDate = (dateString) => {
    if (!dateString) return null; // Handle empty or null dates
    const parts = dateString.split("/"); // Split "DD/MM/YYYY"
    if (parts.length !== 3) return null; // Ensure valid format
    return `${parts[2]}-${parts[1]}-${parts[0]}`; // Convert to "YYYY-MM-DD"
  };

  // ✅ Date Filter with Safe Date Handling
  const handleFilter = (e) => {
    e.preventDefault();
    if (!fromDate || !toDate) {
      console.error("Date fields are empty");
      return;
    }

    const startDate = new Date(fromDate);
    const endDate = new Date(toDate);

    if (isNaN(startDate) || isNaN(endDate)) {
      console.error("Invalid date range");
      return;
    }

    const filtered = orders.filter((order) => {
      const orderDateFormatted = convertDate(order.orderdate); // Convert API date format
      const orderDate = orderDateFormatted ? new Date(orderDateFormatted) : null;
      return orderDate && orderDate >= startDate && orderDate <= endDate;
    });

    setFilteredOrders(filtered);
  };

  // ✅ Search Function with Safe Property Access
  const handleSearch = (e) => {
    const query = e.target.value.toLowerCase();
    setSearchQuery(query);

    const searchedOrders = orders.filter((order) => {
      return (
        order.name?.toLowerCase().includes(query) ||
        order.mobile?.includes(query) ||
        order.order_id?.includes(query)
      );
    });

    setFilteredOrders(searchedOrders);
  };
  const handleDelete = async () => {
    if(!selectedorderId) return;

    try{
      const response = await axios.post(`${API_BASE_URL}order_list_delete.php`,{
        order_id:selectedorderId,
      });
      if(response.data.head.code === 200){
        alert('Order Deleted Successfully')
        closeModal();
        window.location.reload();
      }else{
        alert(response.head?.msg || 'Failed To Delete  order')
      }
    }catch(error){
      console.error("Error Deleting order", error)
    }
  }
  return (
    <>
      <Header />
      <div className="page-wrapper compact-wrapper" id="pageWrapper">
        <div className="page-body-wrapper">
          <div className="page-body">
            <div className="container-fluid">
              <div className="row">
                <div className="col-sm-12">
                  <div className="card card-table">
                    <div className="card-body">
                      <div className="title-header option-title d-sm-flex d-block">
                        <h5>List of Orders</h5>
                      </div>

                      {/* Date Filter */}
                      <div className="row">
                        <div className="col-sm-12">
                          <form onSubmit={handleFilter} className="theme-form theme-form-2 mega-form">
                            <div className="mb-4 row align-items-center">
                              <label className="col-sm-2 col-form-label form-label-title">
                                From Date:
                              </label>
                              <div className="col-md-2">
                                <input
                                  className="form-control"
                                  type="date"
                                  value={fromDate}
                                  onChange={(e) => setFromDate(e.target.value)}
                                />
                              </div>
                              <label className="col-sm-2 col-form-label form-label-title">
                                To Date:
                              </label>
                              <div className="col-md-2">
                                <input
                                  className="form-control"
                                  type="date"
                                  value={toDate}
                                  onChange={(e) => setToDate(e.target.value)} 
                                       
                                />
                              </div>
                              <div className="col-md-2">
                                <button type="submit" className="btn btn-primary me-3">
                                  Submit
                                </button>
                              </div>
                            </div>
                          </form>
                        </div>
                      </div>

                      {/* Search Box */}
                      <div className="row">
                        <div className="col-sm-6">
                          <form className="theme-form theme-form-2 mega-form">
                            <div className="mb-4 row align-items-center">
                              <label htmlFor="search" className="col-sm-2 col-form-label">
                                Search:
                              </label>
                              <div className="col-sm-10">
                                <input
                                  type="text"
                                  id="search"
                                  name="search"
                                  className="form-control"
                                  placeholder="Search Order"
                                  value={searchQuery}
                                  onChange={handleSearch}
                                />
                              </div>
                            </div>
                          </form>
                        </div>
                      </div>

                      {/* Order Table */}
                      {loading ? (
       <div style={{ display: "flex", justifyContent: "center", marginTop: "50px" }}>
       <div className="loader"></div>
     </div>
      ) : (
        <>
                      <div className="table-responsive">
                        <table className="table all-package theme-table table-product">
                          <thead>
                            <tr>
                              <th>Order ID</th>
                              <th>Date</th>
                              <th>Customer Name</th>
                              <th>Amount</th>
                              <th>Paymant Status</th>
                              <th>View</th>
                              <th>Action</th>
                            </tr>
                          </thead>
                          <tbody>
                            {filteredOrders.length > 0 ? (
                              filteredOrders.map((order) => ( 
                                <tr key={order.order_id}>
                                  <td>{order.order_id}</td>
                                  <td>{order.orderdate || "N/A"}</td>
                                  <td>{order.name || "N/A"}</td>
                                  <td>
                                    <i className="fas fa-rupee-sign"></i> {parseFloat(order.amount.replace(/,/g, "") || 0).toFixed(2)}
                                  </td>
                                  <td style={{ color: order.status == "Pending" ? "red" : "green" }}>{order.status == "Pending" ? "Pending" : "Paid"}</td>
                                  <td>
                                    <Link to={`/orderdetails/${order.order_id}`}>
                                      <i className="ri-eye-line"></i>
                                    </Link>
                                  </td>
                                  <td>
                                    <ul>
                                  <li>
                                  <a
                                   href="#" onClick={(e) => { e.preventDefault(); openDeleteModal(order.order_id); }}
                                  >
                                    <i className="ri-delete-bin-line"></i>
                                  </a>
                                </li>
                                </ul>
                                  </td>
                                </tr>
                              ))
                            ) : (
                              <tr>
                                <td colSpan="5" className="text-center">
                                  No orders found
                                </td>
                              </tr>
                            )}
                          </tbody>
                        </table>
                      </div>
                      </>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {showModal && (
                <div className="modal fade show" style={{ display: "block" }}>
                    <div className="modal-dialog modal-dialog-centered">
                        <div className="modal-content">
                            <div className="modal-body">
                                <h5>Confirm Delete</h5>
                                <p>Are you sure you want to delete this order?</p>
                                <button type="button" className="btn-close" onClick={closeModal}></button>
                            </div>
                            <div className="modal-footer">
                                <button type="button" className="btn btn-secondary" onClick={closeModal}>
                                    No
                                </button>
                                <button type="button" className="btn btn-danger" onClick={handleDelete}>
                                    Yes, Delete
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}
    </>
  );
};

export default OrderList;
