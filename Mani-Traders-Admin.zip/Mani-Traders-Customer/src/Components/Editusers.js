import React, { useEffect, useState } from "react";
import { Link, useParams,useNavigate } from "react-router-dom";
import Header from "../Components/Header";
import axios from "axios";
import { FaEye, FaEyeSlash } from "react-icons/fa"; // Import eye icons
import Skeleton from "react-loading-skeleton";
import "react-loading-skeleton/dist/skeleton.css";



const Editusers = () => {
  const { user_id } = useParams();
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate()
  const [loading, setLoading] = useState(true);
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;


  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    password: "",
    cid: "",
  });



  useEffect(() => {
    console.log(user_id)
    axios
      .post(`${API_BASE_URL}employe_detail.php`, {
        user_id:user_id, // Ensure correct user_id is passed
        
      })
      
      .then((response) => {
        console.log("API Response:", response.data); // Debugging
        
        if (response.data.head.code === 200 && response.data.body.length > 0) {
          const userData = response.data.body[0]; // Extract first object from array
  
          setFormData({
            user_id: userData.user_id || "1",
            name: userData.name || "",
            email: userData.email || "",
            phone: userData.phone || "",
            password: userData.password || "",
          });
          setLoading(false);
        } else {
          console.error("Error Fetching Data:", response.data.head.msg);
          setLoading(false);
        }
      })
      .catch((error) => {
        console.error("API Error:", error);
        setLoading(false);
      });
  }, []);
  



  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.post(`${API_BASE_URL}employe_detail_update.php`, formData)
    .then ((response) => {
      if(response.data.head.code === 200){
        alert('Employee detail Updated Succeefully')
        navigate('/users')
      }else{
        alert('update failed',response.data.head.msg)
        console.log('update failed',response.data.head.msg)
        
      }
    })
    .catch((error) => {
      console.error("Update API Error",error)
    })
  };

  return (
    <>
      <Header />
      <div class="page-wrapper compact-wrapper" id="pageWrapper">
        <div class="page-body-wrapper">
          <div className="page-body">
            <div className="container-fluid">
              <div className="row">
                <div className="col-12">
                  <div className="row">
                    <div className="col-sm-12 m-auto">
                      <div className="card">
                        <div className="card-body">
                          <div className="title-header option-title d-sm-flex d-block">
                            <h5>Edit Employee</h5>
                            <div className="right-options">
                              <ul>
                                <li>
                                  <Link className="btn btn-solid" to="/users">
                                    Back
                                  </Link>
                                </li>
                              </ul>
                            </div>
                          </div>
                          
                          <form className="theme-form theme-form-2 mega-form" onSubmit={handleSubmit}>
                                  {loading ? (
                                    <div>
                                      {/* Skeleton for Name */}
                                      <div className="mb-4 row align-items-center">
                                        <label className="form-label-title col-sm-3 mb-0">
                                          <Skeleton width={100} height={20} />
                                        </label>
                                        <div className="col-sm-9">
                                          <Skeleton height={40} />
                                        </div>
                                      </div>

                                      {/* Skeleton for Email */}
                                      <div className="mb-4 row align-items-center">
                                        <label className="form-label-title col-sm-3 mb-0">
                                          <Skeleton width={100} height={20} />
                                        </label>
                                        <div className="col-sm-9">
                                          <Skeleton height={40} />
                                        </div>
                                      </div>

                                      {/* Skeleton for Mobile Number */}
                                      <div className="mb-4 row align-items-center">
                                        <label className="form-label-title col-sm-3 mb-0">
                                          <Skeleton width={120} height={20} />
                                        </label>
                                        <div className="col-sm-9">
                                          <Skeleton height={40} />
                                        </div>
                                      </div>

                                      {/* Skeleton for Password */}
                                      <div className="mb-4 row align-items-center">
                                        <label className="col-sm-3 col-form-label form-label-title">
                                          <Skeleton width={100} height={20} />
                                        </label>
                                        <div className="col-md-9">
                                          <Skeleton height={40} />
                                        </div>
                                      </div>

                                      {/* Skeleton for Buttons */}
                                      <div className="card-footer border-0 pb-0 d-flex justify-content-end">
                                        <Skeleton width={100} height={40} />
                                        <Skeleton width={100} height={40} style={{ marginLeft: "10px" }} />
                                      </div>
                                    </div>
                                  ) : (
                                    <>
                                      {/* Name Field */}
                                      <div className="mb-4 row align-items-center">
                                        <label className="form-label-title col-sm-3 mb-0">Name</label>
                                        <div className="col-sm-9">
                                          <input
                                            className="form-control"
                                            type="text"
                                            name="name"
                                            value={formData.name}
                                            onChange={handleChange}
                                            placeholder="Enter Name"
                                          />
                                        </div>
                                      </div>

                                      {/* Email Field */}
                                      <div className="mb-4 row align-items-center">
                                        <label className="form-label-title col-sm-3 mb-0">Email</label>
                                        <div className="col-sm-9">
                                          <input
                                            className="form-control"
                                            type="email"
                                            name="email"
                                            value={formData.email}
                                            onChange={handleChange}
                                            placeholder="Enter Email"
                                          />
                                        </div>
                                      </div>

                                      {/* Mobile Number Field */}
                                      <div className="mb-4 row align-items-center">
                                        <label className="form-label-title col-sm-3 mb-0">
                                          Mobile Number
                                        </label>
                                        <div className="col-sm-9">
                                          <input
                                            className="form-control"
                                            type="text"
                                            name="phone"
                                            value={formData.phone}
                                            onChange={handleChange}
                                            placeholder="Enter Mobile Number"
                                          />
                                        </div>
                                      </div>

                                      {/* Password Field */}
                                      <div className="mb-4 row align-items-center">
                                        <label className="col-sm-3 col-form-label form-label-title">
                                          Password
                                        </label>
                                        <div className="col-md-9 position-relative">
                                          <input
                                            className="form-control"
                                            type={showPassword ? "text" : "password"}
                                            name="password"
                                            value={formData.password}
                                            onChange={handleChange}
                                            placeholder="Enter Password"
                                          />
                                          <span
                                            className="position-absolute end-0 top-50 translate-middle-y me-4"
                                            onClick={() => setShowPassword(!showPassword)}
                                            style={{ cursor: "pointer", color: "#035c87", fontSize: "18px" }}
                                          >
                                            {showPassword ? <FaEyeSlash /> : <FaEye />}
                                          </span>
                                        </div>
                                      </div>

                                      {/* Buttons */}
                                      <div className="card-footer border-0 pb-0 d-flex justify-content-end">
                                        <button
                                          className="btn btn-primary me-3"
                                          type="submit"
                                          name="submit"
                                          value="Update"
                                        >
                                          Submit
                                        </button>
                                        <button
                                          className="btn btn-outline"
                                          type="button"
                                          onClick={() => (window.location.href = "users")}
                                        >
                                          Cancel
                                        </button>
                                      </div>

                                      {/* Hidden Input */}
                                      <input type="hidden" name="cid" value={formData.cid} />
                                    </>
                                  )}
                                </form>

                          
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Editusers;
