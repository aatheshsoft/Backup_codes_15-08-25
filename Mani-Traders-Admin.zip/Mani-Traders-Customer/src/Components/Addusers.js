import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import Header from "../Components/Header";
import axios from "axios";

const Addusers = () => {
  const navigate = useNavigate();
  const [error, setError] = useState(null);
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    telephone: "",
    password: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.post(
        `${API_BASE_URL}register.php`,
        {
          name: formData.name,
          phone: formData.telephone,
          email: formData.email,
          password: formData.password,
        }
      );

      console.log("Raw API Response:", response.data);

      // ✅ Remove unexpected "testdata" prefix if present
      let responseData = response.data;
      if (typeof responseData === "string" && responseData.startsWith("testdata")) {
        responseData = responseData.replace(/^testdata/, ""); // Remove "testdata" from the start
        responseData = JSON.parse(responseData); // Convert string to JSON
      }

      console.log("Parsed API Response:", responseData);

      // ✅ Correct success check
      if (responseData.head && responseData.head.msg === "success") {
        alert("User registered successfully!");
        navigate("/users"); // Redirect to users page after success
      } else {
        setError(responseData.head?.msg || "Registration failed!");
      }
    } catch (error) {
      console.error("Error Details:", error.response?.data || error.message);
      setError(error.response?.data?.head?.msg || "An error occurred while registering.");
    }
  };

  return (
    <>
      <Header />
      <div className="page-wrapper compact-wrapper" id="pageWrapper">
        <div className="page-body-wrapper">
          <div className="page-body">
            <div className="container-fluid">
              <div className="row">
                <div className="col-12">
                  <div className="row">
                    <div className="col-sm-12 m-auto">
                      <div className="card">
                        <div className="card-body">
                          <div className="title-header option-title d-sm-flex d-block">
                            <h5>Add Employee</h5>
                            <div className="right-options">
                              <ul>
                                <li>
                                  <Link className="btn btn-solid" to="/users">
                                    Back
                                  </Link>
                                </li>
                              </ul>
                            </div>
                          </div>

                          {error && <p className="text-danger">{error}</p>}

                          <form className="theme-form theme-form-2 mega-form" onSubmit={handleSubmit}>
                            <div className="mb-4 row align-items-center">
                              <label className="form-label-title col-sm-3 mb-0">Name</label>
                              <div className="col-sm-9">
                                <input
                                  className="form-control"
                                  type="text"
                                  name="name"
                                  value={formData.name}
                                  onChange={handleChange}
                                  placeholder="Enter Name"
                                  required
                                />
                              </div>
                            </div>

                            <div className="mb-4 row align-items-center">
                              <label className="form-label-title col-sm-3 mb-0">Email</label>
                              <div className="col-sm-9">
                                <input
                                  className="form-control"
                                  type="email"
                                  name="email"
                                  value={formData.email}
                                  onChange={handleChange}
                                  placeholder="Enter Email"
                                  required
                                />
                              </div>
                            </div>

                            <div className="mb-4 row align-items-center">
                              <label className="form-label-title col-sm-3 mb-0">Mobile Number</label>
                              <div className="col-sm-9">
                                <input
                                  className="form-control"
                                  type="text"
                                  name="telephone"
                                  value={formData.telephone}
                                  onChange={handleChange}
                                  placeholder="Enter Mobile Number"
                                  required
                                />
                              </div>
                            </div>

                            <div className="mb-4 row align-items-center">
                              <label className="col-sm-3 col-form-label form-label-title">Password</label>
                              <div className="col-md-9">
                                <input
                                  className="form-control"
                                  type="password"
                                  name="password"
                                  value={formData.password}
                                  onChange={handleChange}
                                  placeholder="Enter Password"
                                  required
                                />
                              </div>
                            </div>

                            <div className="card-footer border-0 pb-0 d-flex justify-content-end">
                              <button className="btn btn-primary me-3" type="submit">
                                Submit
                              </button>
                              <button className="btn btn-outline" type="button" onClick={() => navigate("/users")}>
                                Cancel
                              </button>
                            </div>
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Addusers;
