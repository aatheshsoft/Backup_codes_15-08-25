import React, { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import Header from '../Components/Header';
import axios from 'axios';

const Previlage = () => {
  const { employee_id } = useParams();
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
  const [privileges, setPrivileges] = useState({
    banner: false,
    product: false,
    orders: false,
    employee: false,
    content: false,
    settings: false,
    cancel_orders: false,
    customer: false,
  });
   console.log(privileges)
  // Fetch existing privileges
  useEffect(() => {
    if (!employee_id) return;

    axios.post(`${API_BASE_URL}employe_previllage_list.php`, { employee_id })
      .then(response => {
        if (response.data.head.code === 200) {
          const data = response.data.body[0];
          setPrivileges({
            banner: data.banner === "1",
            product: data.product === "1",
            orders: data.orders === "1",
            employee: data.employee === "1",
            content: data.content === "1",
            settings: data.settings === "1",
            cancel_orders: data.cancel_orders === "1",
            customer: data.customer === "1",
          });
        }
      })
      .catch(error => console.error("Error fetching privileges:", error));
  }, [employee_id]);

  // Handle checkbox changes
  const handleCheckboxChange = (e) => {
    const { name, checked } = e.target;
    setPrivileges(prevState => ({
      ...prevState,
      [name]: checked,
    }));
  };

  // Handle form submission (Update API)
  const handleSubmit = async (e) => {
    e.preventDefault();

    // Convert boolean values to "1" or "0"
    const updatedPrivileges = {
      employee_id,
      ...Object.fromEntries(
        Object.entries(privileges).map(([key, value]) => [key, value ? "1" : "0"])
      ),
    };

    console.log("Updating with data:", updatedPrivileges); // Debugging

    try {
      const response = await axios.post(
        `${API_BASE_URL}employe_previllage_update.php`,
        updatedPrivileges
      );

      console.log("API Response:", response.data); // Debugging

      if (response.data.head.code === 200) {
        alert("Privileges updated successfully!");
        window.location.reload(); // Refresh the page after success
      } else {
        alert("Update Failed");
      }
    } catch (error) {
      console.error("Error updating privileges:", error);
    }
  };

  return (
    <>
      <Header />
      <div className="page-wrapper compact-wrapper" id="pageWrapper">
        <div className="page-body-wrapper">
          <div className="page-body">
            <div className="container-fluid">
              <div className="row">
                <div className="col-12">
                  <div className="row">
                    <div className="col-sm-12 m-auto">
                      <div className="card">
                        <div className="card-body">
                          <div className="title-header option-title d-sm-flex d-block">
                            <h5>User Privilege Management</h5>
                            <div className="right-options">
                              <ul>
                                <li>
                                  <Link className="btn btn-solid" to="/users">Back</Link>
                                </li>
                              </ul>
                            </div>
                          </div>

                          <form className="theme-form theme-form-2 mega-form" onSubmit={handleSubmit}>
                            {Object.keys(privileges).map((key, index) => (
                              <div className="mb-4 row align-items-center" key={index}>
                                <label className="form-label-title col-sm-3 mb-0">{key.replace('_', ' ')}</label>
                                <div className="col-sm-9">
                                  <input
                                    className="checkbox_animated check-it"
                                    type="checkbox"
                                    name={key}
                                    checked={privileges[key]}
                                    onChange={handleCheckboxChange}
                                  />
                                </div>
                              </div>
                            ))}

                            <div className="card-footer border-0 pb-0 d-flex justify-content-end">
                              <button className="btn btn-primary me-3" type="submit">Submit</button>
                              <button className="btn btn-outline" type="button" onClick={() => window.location.href = 'lookje.php'}>Cancel</button>
                            </div>
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Previlage;
