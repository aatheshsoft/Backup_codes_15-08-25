import React, { useEffect, useState } from 'react';
import Header from '../Components/Header';
import axios from 'axios';
import Skeleton from 'react-loading-skeleton';
import 'react-loading-skeleton/dist/skeleton.css';
import { FaEye, FaEyeSlash } from "react-icons/fa";

const Settings = () => {
  const [loading, setLoading] = useState(true);
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
  const [selectedLogo, setSelectedLogo] = useState(null);
  const [logoPreview, setLogoPreview] = useState('');
  const [pricelistPreview, setPricelistPreview] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const [formData, setFormData] = useState({
    Admin_Email: '',
    user_name:'',
    password:'',
    Instruction_to_send_the_customer_in_order_confirmation_email:'',
    phone_number: '',
    whatsapp_phone_number: '',
    address: '',
    city: '',
    state: '',
    pincode: '',
    youtube_url: '',
    instagram_url: '',
    facebook_url: '',
    sgst: '',
    cgst: '',
    minimum_order: '',
    gst_number:'',
    logo: '',
    id: '',
    store_close: '0',
    order_close:'0',
    pricelist: '',
  });

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
  
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? (checked ? '1' : '0') : value,
    });
  };
  

  const handleLogoChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setLogoPreview(reader.result);
        setFormData((prev) => ({
          ...prev,
          logo: reader.result, // Store Base64 image
        }));
        setSelectedLogo(file);
      };
      reader.readAsDataURL(file);
    }
  };
  const handlePriceListChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData((prev) => ({
          ...prev,
          pricelist: reader.result, // base64 encoded file
        }));
        setPricelistPreview(file.name);
      };
      reader.readAsDataURL(file);
    }
  };
  
  const handleLogoDelete = () => {
    setSelectedLogo(null);
    setLogoPreview('');
  
    setFormData((prev) => ({ 
      ...prev,
      logo: '',
    }));
  };

  useEffect(() => {
    axios.post(`${API_BASE_URL}setting_detail.php`)
      .then((response) => {
        const { head, body } = response.data;
  
        if (head.code === 200) {
          const data = body;
  
          setFormData({
            id: data.id,
            user_name:data.user_name || '',
            password:data.password || '',
            Admin_Email: data.email || '',
            phone_number: data.phone || '',
           
            
            whatsapp_phone_number: data.whatsapp || '',
            address: data.address || '',
            city: data.city || '',
            state: data.state || '',
            pincode: data.pincode || '',
            youtube_url: data.youtube_url || '',
            instagram_url: data.instagram_url || '',
            facebook_url: data.facebook_url || '',
            sgst: data.sgst || '',
            cgst: data.cgst || '',
            minimum_order: data.minimum_order_amount || '',
            gst_number:data.gst_number || '',
            logo: data.logo || '',
            store_close: data.store_close || '0',
            order_close: data.order_close || '0',
            Instruction_to_send_the_customer_in_order_confirmation_email:data.email_info || '',
          });
  
          if (data.logo) {
            console.log("Base64 logo detected");
            setLogoPreview(data.logo);
          }
  
          setLoading(false);
        } else {
          console.error("Error Fetching Data:", head.msg);
        }
      })
      .catch((error) => {
        console.error("API Error:", error);
      });
  }, [API_BASE_URL]);
  
  
  
  

  const handleSubmit = (e) => {
    e.preventDefault();

    const payload = {
      id: formData.id,
      whatsapp: formData.whatsapp_phone_number,
      email: formData.Admin_Email,
      user_name:formData.user_name,
      password:formData.password,
      email_info:formData.Instruction_to_send_the_customer_in_order_confirmation_email,
      phone: formData.phone_number,
      city: formData.city,
      state: formData.state,
      pincode: formData.pincode,
      youtube_url: formData.youtube_url,
      instagram_url: formData.instagram_url,  
      facebook_url: formData.facebook_url,
      cgst: formData.cgst,
      sgst: formData.sgst,
      minimum_order_amount: formData.minimum_order,
      gst_number:formData.gst_number,
      address: formData.address,
      logo: formData.logo, // base64 image or empty
      store_close: formData.store_close,
      order_close: formData.order_close,
    };

    axios.post(`${API_BASE_URL}setting_update.php`, payload)
      .then((response) => {
        if (response.data.head.code === 200) {
          alert('Details Updated Successfully');
          window.location.href = window.location.href;
        } else {
          alert("Update failed: " + response.data.head.msg);
        }
      })
      .catch((error) => {
        console.error("Update API Error", error);
      });
  };

  return (
    <>
      <Header />
      <div className="page-wrapper compact-wrapper" id="pageWrapper">
        <div className="page-body-wrapper">
          <div className="page-body">
            <div className="container-fluid">
              <div className="row">
                <div className="col-12">
                  <div className="row">
                    <div className="col-sm-12 m-auto">
                      <div className="card">
                        <div className="card-body">
                          <div className="card-header-2">
                            <h5>Settings</h5>
                          </div>
                          <form onSubmit={handleSubmit} encType="multipart/form-data">
                            {loading ? (
                              <>
                                {Object.entries(formData).map(([key]) => (
                                  <div className="mb-4 row align-items-center" key={key}>
                                    <label className="form-label-title col-sm-3 mb-0">
                                      {key.replace(/_/g, " ").replace(/\b\w/g, (l) => l.toUpperCase())}
                                    </label>
                                    <div className="col-sm-9">
                                      <Skeleton height={30} />
                                    </div>
                                  </div>
                                ))}
                              </>
                            ) : (
                              <>
                                {Object.entries(formData)
  .filter(([key]) => key !== 'logo' && key !== 'id' && key !== 'store_close' && key !== 'order_close')
  .map(([key, value]) => (
    <div className="mb-4 row align-items-center" key={key}>
      <label className="form-label-title col-sm-3 mb-0">
        {key.replace(/_/g, " ").replace(/\b\w/g, (l) => l.toUpperCase())}
      </label>
      <div className="col-sm-9 position-relative">
        {key === 'Instruction_to_send_the_customer_in_order_confirmation_email' ? (
          <textarea
            name={key}
            className="form-control"
            rows="4"
            value={value}
            onChange={handleChange}
          />
        ) : key === 'password' ? (
          <>
            <input
              type={showPassword ? 'text' : 'password'}
              name={key}
              className="form-control pe-5"
              value={value}
              size="30"
              onChange={handleChange}
            />
           <span
      className="position-absolute top-50 end-0 translate-middle-y me-3"
      style={{ cursor: 'pointer' }}
      onClick={() => setShowPassword(!showPassword)}
    >
      {showPassword ? <FaEyeSlash /> : <FaEye />}
    </span>
          </>
        ) : (
          <input
            type="text"
            name={key}
            className="form-control"
            value={value}
            size="30"
            onChange={handleChange}
          />
        )}
      </div>
    </div>
))}


                                {/* Logo Upload Section */}
                                <div className="mb-4 row align-items-center">
                                  <label className="form-label-title col-sm-3 mb-0">Upload Logo</label>
                                  <div className="col-sm-9">
                                    {logoPreview ? (
                                      <div>
                                        <img
                                          src={logoPreview}
                                          alt="Logo"
                                          style={{
                                            width: "100px",
                                            height: "100px",
                                            objectFit: "contain",
                                            borderRadius: "5px",
                                            marginBottom: "10px"
                                          }}
                                        />
                                        <br />
                                        <button type="button" className="btn btn-danger" onClick={handleLogoDelete}>
                                          Delete Image
                                        </button>
                                      </div>
                                    ) : (
                                      <div>
                                        <input
                                          type="file"
                                          className="form-control"
                                          accept="image/*"
                                          onChange={handleLogoChange}
                                        />
                                         <p>Width 230px x 110px</p>
                                      </div>
                                    )}
                                  </div>
                                </div>
                              </>
                            )}
                            <div className="mb-4 row align-items-center">
                              <label className="form-label-title col-sm-3 mb-0">Store Close</label>
                              <div className="col-sm-6">
                                <input
                                  type="checkbox"
                                  name="store_close" 
                                  checked={formData.store_close === '1'}
                                  className="form-check-input"
                                  onChange={handleChange}
                                /> Tick to close the store. Online order will be disabled.
                              </div>
                            </div>

                            <div className="mb-4 row align-items-center">
                              <label className="form-label-title col-sm-3 mb-0">Order Close</label>
                              <div className="col-sm-6">
                                <input
                                  type="checkbox"
                                  name="order_close" 
                                  checked={formData.order_close === '1'}
                                  className="form-check-input"
                                  onChange={handleChange}
                                /> Tick to close the order.
                              </div>
                            </div>

                            <div className="card-footer border-0 pb-0 d-flex justify-content-center">
                              <button
                                type="submit"
                                name="submit"
                                value="Commit Changes"
                                className="btn btn-primary me-3"
                              >
                                Commit Changes
                              </button>
                            </div>
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Settings;
  