import React, { useEffect, useState } from "react";
import Header from "../Components/Header";
import { Link } from "react-router-dom";
import axios from "axios";

const Content = () => {
  const [contentList, setContentList] = useState([]);
  const [loading, setLoading] = useState(true);
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

  const apiUrl =  `${API_BASE_URL}content_list.php`;

  useEffect(() => {
    setLoading(true)
    const fetchContent = async () => {
      try {
        const response = await axios.get(apiUrl);
        if (response.data.head.code === 200) {
          setContentList(response.data.body); // Store the response data
          console.log(response.data.body);
        } else {
          console.error("Failed to fetch content list.");
          alert("Failed to fetch content list.");
        }
      } catch (error) {
        console.error("Error fetching data. Please try again.");
      } finally {
        setLoading(false);
      }
    };

    fetchContent();
  }, []);


  return (
    <>
      <Header />
      <div className="page-wrapper compact-wrapper" id="pageWrapper"> 
        <div className="page-body-wrapper">
          <div className="page-body">
            {/* Container-fluid starts */}
            <div className="container-fluid">
              <div className="row">
                <div className="col-sm-12">
                  <div className="card card-table">
                    <div className="card-body">
                      <div className="title-header option-title d-sm-flex d-block">
                        <h5>Contents Management</h5>
                      </div>
                      <div>
                      {loading ? (
                       <div style={{ display: "flex", justifyContent: "center", marginTop: "50px" }}>
                       <div className="loader"></div>
                     </div>
                      ) : (
                        <>
                        <div className="table-responsive">
                          <br />
                          <table className="table all-package theme-table table-product" id="table_id">
                            <thead>
                              <tr>
                                <th className="hilites">Title</th>
                                <th width="18%" className="hilites" align="center">Action</th>
                              </tr>
                            </thead>
                            <tbody>
                              {contentList.length > 0 ? (
                                contentList.map((item) => (
                                  <tr key={item.id}>
                                    <td align="left">{item.name}</td>
                                    <td align="center">
                                      <Link to={`/contentedit/${item.id}`} title="Edit">
                                        <i className="ri-pencil-line"></i>
                                      </Link>
                                    </td>
                                  </tr>
                                ))
                              ) : (
                                <tr>
                                  <td colSpan="2" align="center">No content available</td>
                                </tr>
                              )}
                            </tbody>
                          </table>
                        </div>
                        </>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            {/* Container-fluid ends */}
          </div>
        </div>
      </div>
    </>
  );
};

export default Content;
