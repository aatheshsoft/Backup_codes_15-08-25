import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Logo from'../Assets/dharshan-logo.png'
import axios from 'axios';
import logo from '../Assets/log-in.png'

const Login = () => {
    const navigate = useNavigate();

    // State for email, password, and error message
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError(''); // Clear previous errors

        try {
            const response = await axios.post(
                `${API_BASE_URL}login.php`,
                {
                    email: email,
                    password: password,
                },
                {
                    headers: {
                        'Content-Type': 'application/json',
                    },
                }
            );

            console.log('Raw API Response:', response.data);

            // ✅ Handle API response properly
            let responseData = response.data;
            if (typeof responseData === 'string' && responseData.startsWith('testdata')) {
                responseData = responseData.replace(/^testdata/, ''); // Remove "testdata" if present
                responseData = JSON.parse(responseData);
            }

            console.log('Parsed API Response:', responseData);

            // ✅ Check if login was successful
            if (responseData.head && responseData.head.msg === 'success') {
                // alert('Login Successful!');
                
                // Store user session (optional)
                localStorage.setItem('user_id', JSON.stringify(responseData.body.user_id));
                localStorage.setItem('user_name', JSON.stringify(responseData.body.name));
                // localStorage.setItem('logo', JSON.stringify(responseData.body.logo));
                // Redirect to Home
                navigate('/home');
            } else {
                setError(responseData.head?.msg || 'Invalid email or password');
            }
        } catch (error) {
            console.error('Login Error:', error.response?.data || error.message);
            setError(error.response?.data?.head?.msg || 'An error occurred while logging in.');
        }
    };

    return (
        <section className="log-in-section background-image-2 section-b-space">
            <a href="#" className="logo-login">
                <img src={Logo} className="img-fluid" alt="Logo" />
            </a>

            <div className="container w-100">
                <div className="row">
                    <div className="col-xxl-6 col-xl-5 col-lg-6 d-lg-block d-none ms-auto">
                        <div className="image-contain">
                            <img src={logo} className="img-fluid" alt="Login Visual" />
                        </div>
                    </div>

                    <div className="col-xxl-4 col-xl-5 col-lg-6 col-sm-8 mx-auto">
                        <div className="log-in-box">
                            <div className="log-in-title">
                                <h3>Welcome To Dharshan Crackers</h3>
                                <h4>Log In Your Account</h4>
                            </div>

                            <div className="input-box">
                                <form className="row g-4" onSubmit={handleSubmit}>
                                    <div className="col-12">
                                        <div className="form-floating theme-form-floating log-in-form">
                                            <input
                                                type="text"
                                                className="form-control"
                                                id="email"
                                                placeholder="User Name / Phone Number"
                                                value={email}
                                                onChange={(e) => setEmail(e.target.value)}
                                                required
                                            />
                                            <label htmlFor="email">User Name</label>
                                        </div>
                                    </div>

                                    <div className="col-12">
                                        <div className="form-floating theme-form-floating log-in-form">
                                            <input
                                                type="password"
                                                className="form-control"
                                                id="password"
                                                placeholder="Password"
                                                value={password}
                                                onChange={(e) => setPassword(e.target.value)}
                                                required
                                            />
                                            <label htmlFor="password">Password</label>
                                        </div>
                                    </div>

                                    {error && (
                                        <div className="col-12">
                                            <p style={{ color: 'red', textAlign: 'center' }}>{error}</p>
                                        </div>
                                    )}

                                    <div className="col-12">
                                        <button
                                            className="btn btn-animation w-100 justify-content-center"
                                            type="submit"
                                        >
                                            Log In
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default Login;
