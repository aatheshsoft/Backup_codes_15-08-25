import React, { useState, useEffect } from "react";
import { NavLink, Link, useNavigate } from "react-router-dom";
import { FaUser, FaBox, FaClipboardList, FaShoppingCart, FaSignOutAlt } from "react-icons/fa";
import { Offcanvas, Button } from "react-bootstrap";
import usericon from '../Assets/4.jpg'
import "../Pages/Sidebar.css";
import axios from "axios";
import { LuUsers } from "react-icons/lu";
import { FiImage } from "react-icons/fi";
import { IoSettingsOutline } from "react-icons/io5";
import { LuLogOut } from "react-icons/lu";
import { RiShoppingBag4Fill } from "react-icons/ri";
import { ImCancelCircle } from "react-icons/im";
import { MdOutlineDashboard } from "react-icons/md";
import { BiSolidOffer } from "react-icons/bi";
import { GrGallery } from "react-icons/gr";
import { RiGalleryLine } from "react-icons/ri";
import { AiOutlineStock } from "react-icons/ai";
import { PiNewspaperClipping } from "react-icons/pi";
import { TiShoppingCart } from "react-icons/ti";
import Logo from '../Assets/dharshan-logo.png'
const initializeFeatherIcons = () => {
    if (window.feather) {
        window.feather.replace();
    }
};

const Header = () => {
  const [permissions, setPermissions] = useState({});
  const [show, setShow] = useState(false);
  const navigate = useNavigate(); 
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    const [showModal, setShowModal] = useState(false);

    // Show the modal
    const openModal = () => {
      setShowModal(true);
    };
  
    // Hide the modal
    const closeModal = () => {
      setShowModal(false);
    };
   
    useEffect(() => {
        initializeFeatherIcons();
    }, []);


    const userId = localStorage.getItem("user_id");
    const userName = JSON.parse(localStorage.getItem('user_name'));

  const handleLogout = () => {
    localStorage.removeItem("user_id"); // Remove userId from localStorage
    navigate("/login"); // Redirect to login page
  };

  // useEffect(() => {
  //   let userId = localStorage.getItem("user_id");
  
  //   if (!userId) {
  //     console.error("No user ID found. Please log in again.");
  //     return;
  //   }
  
  //   userId = userId.replace(/^"|"$/g, ''); // Remove extra double quotes if they exist
  
  //   const fetchPermissions = async () => {
  //     try {
  //       console.log("Sending API request with user_id:", userId);
  
  //       const response = await axios.post(
  //         `${API_BASE_URL}employee_login_previllage.php`,
  //         { user_id: userId }, // Ensure correct format
  //         {
  //           headers: {
  //             "Content-Type": "application/json",
  //             "Accept": "application/json",
  //           },
  //         }
  //       );
  
  //       console.log("API Fixed Response:", response.data);
  
  //       if (response.data.head.code === 200 && response.data.body.length > 0) {
  //         setPermissions(response.data.body[0]);
  //       } else {
  //         alert("Invalid Username and Password. Please check your credentials.");
  //       }
  //     } catch (error) {
  //       alert("API Error: Unable to fetch permissions.");
  //       console.error("API Error:", error);
  //     }
  //   };
  
  //   fetchPermissions();
  // }, []);


 


    return (
        <>
            <div className="page-wrapper compact-wrapper" id="pageWrapper">
                <div className="page-header">
                    <div className="header-wrapper m-0">

                        <div className="header-logo-wrapper p-0">
                            {/* <div className="logo-wrapper">
                                <Link to="/home">
                                    <img src={usericon} />
                                </Link>
                            </div> */}
                            <h3 className="company-name">DHARSHAN CRACKERS</h3>
                           
                            <div className="toggle-sidebar">
                                <i
                                    className="status_toggle middle sidebar-toggle"
                                    onClick={handleShow}
                                    style={{ cursor: "pointer" }}
                                >
                                    &#9776; {/* Menu icon */}
                                </i>
                            </div>
                             
                        </div>
                        <NavLink to="/home" title="">
                          <img className="header-logo" src={Logo} alt="" />
                        </NavLink>
                        <div className="nav-right col-6 pull-right right-header p-0">
                        <div className="header-username">
                        <span className="username">
                                    {userName ? userName.charAt(0).toUpperCase() + userName.slice(1) : ""}
                                  </span>

                                            {/* <p className="mb-0 font-roboto">
                                                Admin <i className="middle ri-arrow-down-s-line"></i>
                                            </p> */}
                        </div> 
                            <ul className="nav-menus">
                                {/* <li>
                                    <div className="mode">
                                        <i className="ri-moon-line"></i>
                                    </div>
                                </li> */}
                                <li className="profile-nav onhover-dropdown pe-0 me-0">
                                    <div className="media profile-media">
                                        <img
                                            className="user-profile rounded-circle"
                                            src={usericon}
                                            alt="User"
                                        />
                                        {/* <div className="user-name-hide media-body">
                                            <span>Emay Walter</span>
                                            <p className="mb-0 font-roboto">
                                                Admin <i className="middle ri-arrow-down-s-line"></i>
                                            </p>
                                        </div> */}
                                    </div>
                                    <ul className="profile-dropdown onhover-show-div">
                                    
                                        <li>
                                            <Link to="/bannerlist">
                                            <FiImage style={{fontSize:"18px"}}/>
                                            <span>Banners</span>
                                            </Link>
                                        </li>
                                    
                                  
                                        <li>
                                            <Link to="/settings">
                                            <IoSettingsOutline style={{fontSize:"18px"}}/>
                                            <span>Settings</span>
                                            </Link>
                                        </li>
                                    
                                        <li>
                                            <a  href="#" onClick={(openModal)}>
                                            <LuLogOut  style={{fontSize:"18px"}}/>
                                            <span>Log out</span>
                                            </a>
                                        </li>

     
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>

                </div>
            </div>

            {/* Offcanvas Sidebar */}
            <Offcanvas 
                        show={show} 
                        onHide={handleClose} 
                        placement="start" 
                        style={{ width: '250px' }} // Set width to 200px
                    >
                        <Offcanvas.Header closeButton>
                            <Offcanvas.Title> Menu</Offcanvas.Title>
                        </Offcanvas.Header>
                        <Offcanvas.Body>
                            <ul className="offcanvas-menu">
                                            <NavLink to="/home" className={({ isActive }) => (isActive ? "active" : "")}>
                                              <li>
                                                <MdOutlineDashboard />&nbsp;&nbsp;
                                                 <span>Dashboard</span>
                                              </li>
                                            </NavLink>

                                            <NavLink to="/content" className={({ isActive }) => (isActive ? "active" : "")}>
                                                <li>
                                                  <FaClipboardList />&nbsp;&nbsp;
                                                   <span>Content</span>
                                                </li>
                                              </NavLink>
                                            {/* {console.log(" Rendering with permissions:", permissions)} */}
                            
                                            {/* {permissions.customer === "1" && (
                                              <NavLink to="/customerlist" className={({ isActive }) => (isActive ? "active" : "")}>
                                                <li>
                                                  <FaUser />
                                                  {isOpen && <span>Customer</span>}
                                                </li>
                                              </NavLink>
                                            )} */}
                                              <NavLink to="/scrolllist" className={({ isActive }) => (isActive ? "active" : "")}>
                                                <li>
                                                <PiNewspaperClipping />&nbsp;&nbsp;
                                                 <span>Scroll News</span>
                                                </li>
                                              </NavLink>
                                            <NavLink to="/discount" className={({ isActive }) => (isActive ? "active" : "")}>
                                                <li>
                                                <BiSolidOffer />&nbsp;&nbsp;
                                                  <span>Discount</span>
                                                </li>
                                              </NavLink>
                                              <NavLink to="/subcategory" className={({ isActive }) => (isActive ? "active" : "")}>
                                                <li>
                                                  <RiShoppingBag4Fill />&nbsp;&nbsp;
                                                   <span>Products</span>
                                                </li>
                                              </NavLink>
                                            
                            
                            
                                            
                                              <NavLink to="/orderlist" className={({ isActive }) => (isActive ? "active" : "")}>
                                                <li>
                                                  <FaShoppingCart />&nbsp;&nbsp;
                                                <span>Orders</span>
                                                </li>
                                              </NavLink>
                                            
                                            {/* {permissions.cancel_orders === "1" && (
                                              <NavLink to="/cancelorder" className={({ isActive }) => (isActive ? "active" : "")}>
                                                <li>
                                                  <ImCancelCircle />
                                                  {isOpen && <span>Cancel Order</span>}
                                                </li>
                                              </NavLink>
                                            )} */}
                                             
                                             <NavLink to="/clientlogo" className={({ isActive }) => (isActive ? "active" : "")}>
                                                <li>
                                                <RiGalleryLine />&nbsp;&nbsp;
                            
                                                   <span>Client Logo</span>
                                                </li>
                                              </NavLink>
                                          
                            
                                              <NavLink to="/gallerylist" className={({ isActive }) => (isActive ? "active" : "")}>
                                                <li>
                                                <GrGallery />&nbsp;&nbsp;
                                                   <span>Shop Gallery</span>
                                                </li>
                                              </NavLink>
                            
                                              
                                              <NavLink to="/shoporder" className={({ isActive }) => (isActive ? "active" : "")}>
                                                <li>
                                                <TiShoppingCart />&nbsp;&nbsp;
                            
                                                   <span>Shop Order</span>
                                                </li>
                                              </NavLink>

                                              <NavLink to="/stock" className={({ isActive }) => (isActive ? "active" : "")}>
                                                <li>
                                                <AiOutlineStock />&nbsp;&nbsp;
                            
                                                   <span>Stock Report</span>
                                                </li>
                                              </NavLink>
                            
                                          </ul>
                        </Offcanvas.Body>
                    </Offcanvas>

                    {showModal && (
                        <div className="modal fade show d-block" tabIndex="-1" role="dialog">
                        <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-body">
                <h5 className="modal-title" id="staticBackdropLabel">Logging Out</h5>
                <p>Are you sure you want to log out?</p>
                <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close" onClick={closeModal}></button>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" data-bs-dismiss="modal" onClick={closeModal}>
                  No
                </button>
                <button type="button" className="btn btn-primary" onClick={handleLogout}>
                  Yes
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
        </>
    );
};

export default Header;
