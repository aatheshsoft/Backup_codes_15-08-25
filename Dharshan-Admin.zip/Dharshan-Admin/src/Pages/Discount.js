import React,{useState,useEffect} from 'react'
import Header from '../Components/Header';
import { Link } from "react-router-dom";
import axios from "axios";

const Discount = () => {
  const [discount, setDiscount] = useState([]);
  const [loading, setLoading] = useState(true); 
  const [showModal, setShowModal] = useState(false);
  const [selecteddiscountId, setSelectedDiscountId] = useState(null);
  const [updateSuccess, setUpdateSuccess] = useState(false); 
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;


  const openDeleteModal = (discount_id) =>{
    setSelectedDiscountId(discount_id)
    setShowModal(true);
  }
  
  const closeModal = () => {
    setSelectedDiscountId(null);
    setShowModal(false);
};
    useEffect(() => {
      setLoading(true); // Set loading to true before fetching data
      axios
        .post(`${API_BASE_URL}discount_list.php`)
        .then((response) => {
          if (response.data.head.code === 200) {
            // Sort categories by rank after fetching data
            const sortedCDiscount = response.data.body.sort((a, b) => a.rank - b.rank);
            setDiscount(sortedCDiscount); // Store sorted categories in state
          } else {
            console.error("Error Fetching Data:", response.data.head.msg);
          }
        })
        .catch((error) => {
          console.error("API Error:", error);
        })
        .finally(() => {
          setLoading(false); // Set loading to false after API call
        });
    }, []);

    
    
    // Display the success alert once
    useEffect(() => {
      if (updateSuccess) {
        alert("Category Updated Successfully");
        setUpdateSuccess(false); 
        window.location.reload();
      }
    }, [updateSuccess]); // Trigger effect when updateSuccess state changes
    
    


        
      const handleDelete = async () => {
        if(!selecteddiscountId) return;

        try {
          const response = await axios.post(`${API_BASE_URL}discount_list_delete.php`,{
            discount_id:selecteddiscountId,
          });

          if(response.data.head.code === 200) {
            alert('Discount Deleted Successfully')
            closeModal();
            window.location.reload();

          } else{
            alert(response.data.head?.msg || "Failed to delete category");
          }
         
        }
        catch(error) {
          console.error("Error Deleting Category", error)
          }

      };


    
  return (
    <>
    <Header/>
    <div class="page-wrapper compact-wrapper" id="pageWrapper">
        <div class="page-body-wrapper">
        <div className="page-body">
      <div className="container-fluid">
        <div className="row">
          <div className="col-sm-12">
            <div className="card card-table">
              <div className="card-body">
                <div className="title-header option-title d-sm-flex d-block">
                  <h5>Discount Management</h5>
                  <div className="right-options">
                    <ul>
                      <li>
                        <Link className="btn btn-solid" to="/adddiscount">
                          Add
                        </Link>
                      </li>
                    </ul>
                  </div>
                </div>
                <div>
                <form>
      {loading ? (
        <div style={{ display: "flex", justifyContent: "center", marginTop: "50px" }}>
        <div className="loader"></div>
      </div>
      ) : (
        <>
          <div className="table-responsive">
            <table className="table all-package theme-table table-product">
              <thead>
                <tr>
                  <th>S.No.</th>
                  <th>Start Amount</th>
                  <th style={{ textAlign: 'left' }}>End Amount</th>
                  <th style={{ textAlign: 'left' }}>Discount %</th>
                  <th style={{ textAlign: 'center' }}>Action</th>
                </tr>
              </thead>
              <tbody>
                {discount.length > 0 ? (
                  discount.map((discount, index) => (
                    <tr key={discount.discount_id}>
                      <td>{index + 1}</td>
                      <td>{discount.start_amt}</td>
                      <td style={{ textAlign: 'left' }}>{discount.end_amt}</td>
                      <td style={{ textAlign: 'left' }}> {discount.discount_amt}</td>
                      <td style={{ textAlign: 'center' }}>
                        <ul>
                          <li>
                            <Link to={`/editdiscount/${discount.discount_id}`}>
                              <i className="ri-pencil-line"></i>
                            </Link>
                          </li>
                          <li>
                            <a href="#" onClick={(e) => { e.preventDefault(); openDeleteModal(discount.discount_id); }}>
                              <i className="ri-delete-bin-line"></i>
                            </a>
                          </li>
                        </ul>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="7" style={{ textAlign: 'center' }}>
                      No categories found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
         
        </>
      )}
    </form>    
        </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

        </div>
     </div>
     {showModal && (
                <div className="modal fade show" style={{ display: "block" }}>
                    <div className="modal-dialog modal-dialog-centered">
                        <div className="modal-content">
                            <div className="modal-body">
                                <h5>Confirm Delete</h5>
                                <p>Are you sure you want to delete ?</p>
                                <button type="button" className="btn-close" onClick={closeModal}></button>
                            </div>
                            <div className="modal-footer">
                                <button type="button" className="btn btn-secondary" onClick={closeModal}>
                                    No
                                </button>
                                <button type="button" className="btn btn-danger" onClick={handleDelete}>
                                    Yes, Delete
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}

    </>
  )
}

export default Discount;