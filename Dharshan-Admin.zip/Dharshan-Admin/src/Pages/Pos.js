import React, { useState } from "react";
import { Container, Row, Col, Button, Table, Form, InputGroup, Card } from "react-bootstrap";
import { FaPlus, FaSearch, FaShoppingCart, FaTrash } from "react-icons/fa";
import { BiRupee } from "react-icons/bi";
import { RiSave3Line } from "react-icons/ri";
import { LuPrinter } from "react-icons/lu";

const POS = () => {
  const [cart, setCart] = useState([]);
  const [filteredCodes, setFilteredCodes] = useState([]);

  const products = [
    { id: 1, name: "Vacum Cleaner", stock: 30, price: 2200, code: "AAA123" },
    { id: 2, name: "Nikon Dslr Camera", stock: 130, price: 48000, code: "BBB123" },
    { id: 3, name: "LG Refrigerator", stock: 150, price: 21000, code: "ASDF55" },
    { id: 4, name: "Duracell Battery Medium", stock: 40, price: 50, code: "CDEW78" },
    { id: 5, name: "Water Heater", stock: 40, price: 7400, code: "CDEW79" },
    { id: 6, name: "Water Purifier", stock: 40, price: 10999, code: "CDFW48" },
    { id: 7, name: "Sewing Machine", stock: 40, price: 15400, code: "CDGW98" },
    { id: 8, name: "Bajaj Iron Box", stock: 40, price: 799, code: "CDVX08" },
    { id: 9, name: "Samsung Mobile", stock: 40, price: 52400, code: "CEW48" },
    { id: 10, name: "Panasonic LED Tv", stock: 40, price: 39999, code: "CDW68" },
    { id: 11, name: "Washing Machine", stock: 40, price: 18499, code: "CDMN35" },
  ];

  const [productCode, setProductCode] = useState("");
  const [productName, setProductName] = useState("");

  // Handle product code input with dropdown suggestion
  const handleCodeInput = (event) => {
    const code = event.target.value.toUpperCase();
    setProductCode(code);

    if (code.length > 0) {
      setFilteredCodes(products.filter((p) => p.code.includes(code)));
    } else {
      setFilteredCodes([]);
    }

    const product = products.find((p) => p.code === code);
    if (product) {
      setProductName(product.name);
      addToCart(product);
    } else {
      setProductName("");
    }
  };

  // Handle product name selection from dropdown
  const handleNameInput = (event) => {
    const name = event.target.value;
    setProductName(name);

    const product = products.find((p) => p.name === name);
    if (product) {
      setProductCode(product.code);
      addToCart(product);
    } else {
      setProductCode("");
    }
  };

  // Add product to cart
  const addToCart = (product) => {
    setCart((prevCart) => {
      const existingProduct = prevCart.find((item) => item.id === product.id);
      if (existingProduct) {
        return prevCart.map((item) =>
          item.id === product.id ? { ...item, qty: item.qty + 1 } : item
        );
      } else {
        return [...prevCart, { ...product, qty: 1 }];
      }
    });
  };

  const calculateTotal = () => {
    return cart.reduce((total, item) => total + item.price * item.qty, 0) || 0;
  };

  const removeItem = (id) => {
    setCart(cart.filter((item) => item.id !== id));
  };
  

  return (
    <Container fluid className="p-3">
      <Row>
        <Col md={5} className="border-end" style={{ height: "100vh", overflowY: "auto" }}>
          <InputGroup className="mb-3">
            <Form.Select>
              <option>Walk-in Customer</option>
            </Form.Select>&nbsp; &nbsp;
            <Button variant="primary">
              <FaPlus />
            </Button>
          </InputGroup>

          <Row>
            <Col md={6}>
              <InputGroup className="mb-3">
                <Form.Control
                  type="text"
                  placeholder="Enter Product Code"
                  value={productCode}
                  onChange={handleCodeInput}
                  autoComplete="off"
                />
                {filteredCodes.length > 0 && (
                  <div className="dropdown-menu show" style={{ width: "100%" }}>
                    {filteredCodes.map((product) => (
                      <div
                        key={product.id}
                        className="dropdown-item"
                        onClick={() => {
                          setProductCode(product.code);
                          setProductName(product.name);
                          setFilteredCodes([]);
                          addToCart(product);
                        }}
                      >
                        {product.code} - {product.name}
                      </div>
                    ))}
                  </div>
                )}
              </InputGroup>
            </Col>

            <Col md={6}>
              <InputGroup className="mb-3">
                <Form.Select value={productName} onChange={handleNameInput}>
                  <option value="">Select Product</option>
                  {products.map((product) => (
                    <option key={product.id} value={product.name}>
                      {product.name}
                    </option>
                  ))}
                </Form.Select>
              </InputGroup>
            </Col>
          </Row>

          {/* Table to Display Selected Products */}
          <div style={{ maxHeight: "60vh", overflowY: "auto", border: "1px solid #ddd" }}>
            <Table bordered responsive>
              <thead>
                <tr>
                  <th>S.NO</th>
                  <th>Item</th>
                  <th>Price</th>
                  <th>Qty</th>
                  <th>Total</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {cart.map((item, index) => (
                  <tr key={item.id}>
                    <td>{index + 1}</td>
                    <td>{item.name}</td>
                    <td><BiRupee />{item.price.toFixed(2)}</td>
                    <td>
                        <input
                          type="number"
                          value={item.qty}
                          min="1"
                          className="form-control text-center"
                          style={{ width: "60px" }}
                          onChange={(e) => {
                            let newQty = e.target.value;

                            // Allow empty input or zero
                            if (newQty === "" || newQty === "0") {
                              // If it's empty or zero, set it to 1
                              newQty = "";
                            }

                            // Update the cart with the new quantity value
                            setCart((prevCart) =>
                              prevCart.map((i) =>
                                i.id === item.id ? { ...i, qty: parseInt(newQty, 10) } : i
                              )
                            );
                          }}
                          onBlur={(e) => {
                            // When the input loses focus, ensure it's at least 1
                            let newQty = e.target.value;
                            if (newQty === "" || newQty === "0" || newQty < 1) {
                              setCart((prevCart) =>
                                prevCart.map((i) =>
                                  i.id === item.id ? { ...i, qty: 1 } : i
                                )
                              );
                            }
                          }}
                        />
                      </td>


                    <td><BiRupee />{(item.price * item.qty || 0).toFixed(2)} </td>
                    <td>
                      <Button variant="danger" size="sm" onClick={() => removeItem(item.id)}>
                        <FaTrash />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </div>

          <div className="bg-light p-3 border rounded d-flex justify-content-between">
            <Button variant="dark"><RiSave3Line /> Save</Button>
            <Button variant="dark"><LuPrinter /> Save & Print</Button>
            <h5 style={{color:"black"}}>Total: <BiRupee />{calculateTotal().toFixed(2)} </h5>
            {/* <Button variant="dark"><FaShoppingCart /> Payment</Button> */}
          </div>
        </Col>
        <Col md={7}>
          <InputGroup className="mb-3">
            <Form.Control placeholder="Type product name or scan barcode" /> &nbsp; &nbsp;
            <Button variant="primary">
              <FaSearch />
            </Button>
          </InputGroup>
          <Row className="g-3">
            {products.map((product) => (
              <Col md={3} key={product.id}>
                <Card className="text-center border">
                  <Card.Body>
                    <Card.Title style={{fontSize:"12px"}}>{product.name}</Card.Title>
                    <Card.Title style={{fontSize:"12px"}}>{product.code}</Card.Title>
                    <Card.Text style={{fontSize:"11px"}}>
                      Price: <BiRupee />{product.price.toFixed(2)} <br />
                      Stock: <span className="badge bg-success">{product.stock}</span>
                    </Card.Text>
                  </Card.Body>
                </Card>
              </Col>
            ))}
          </Row>
        </Col>
      </Row>
    </Container>
  );
};

export default POS;
