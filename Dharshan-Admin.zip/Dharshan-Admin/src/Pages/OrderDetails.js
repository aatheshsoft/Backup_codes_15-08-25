import React, { useEffect, useState } from 'react'
import { Link,useParams,useNavigate } from 'react-router-dom';
import Header from '../Components/Header';
import Image from '../Assets/print.gif'
import axios from 'axios';



const OrderDetails = () => {
const {order_id} = useParams();
const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
const [status, setStatus] = useState("");
const[orderdetails,setOrderDetails] = useState([])
 const navigate = useNavigate();


useEffect(() => {
  axios.post(`${API_BASE_URL}order_details.php`, { order_id })
    .then((response) => {
      if (response.data.head.code === 200) {
        setOrderDetails(response.data.body);
        setStatus(response.data.body.status);
      } else {
        console.error("Error Fetching Data:", response.data.head.msg);
      }
    })
    .catch((error) => {
      console.error("API Error:", error);
    });
}, [API_BASE_URL, order_id]); // ✅ dependency array to prevent infinite calls




const Handleupdate = async (e) => {
  e.preventDefault();

  try {
    const response = await axios.post(`${API_BASE_URL}update_paid_status.php`,
      {
        order_id: order_id,
        status: status === "Paid" ? "Paid" : "Pending",
      }
    );

    console.log("Response:", response.data);

    if (response.data.head.code === 200) {
      alert("Status updated successfully!");
      navigate('/orderlist');
    } else {
      alert("Update failed!");
    }
  } catch (error) {
    console.error("Error updating status:", error);
    alert("An error occurred!");
  }
};
  return (
    <>
    <Header />
    <div class="page-wrapper compact-wrapper" id="pageWrapper">
      <div class="page-body-wrapper">
        <div class="page-body">
          <div class="container-fluid">
            <div class="row">
              <div class="col-sm-12">
                <div class="card card-table">
                  <div class="card-body">
                    <div class="title-header option-title d-sm-flex d-block">
                      <h5> Order Details</h5>
                      <div class="right-options">
                        <ul>
                          <li>
                            <Link class="btn btn-solid" to="/orderlist">Back</Link>
                          </li>
                        </ul>
                      </div>
                    </div>
                    <div class="table-responsive">
                      <table class="table theme-table table-product" id="table_id">
                       {/*  <!-- Order Summary --> */}
                        <tr>
                          <td>
                            <table width="100%" cellspacing="0" cellpadding="0" border="0">
                              <tr>
                                <td class="blacktext"><b>Order ID:</b> {orderdetails.order_id}</td>
                                <td rowspan="2" align="right">
                               <a
                                    href={`/Dadmin/invoice/${orderdetails.order_id}`}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                  >
                                    <img src={Image} alt="Print" border="0" />
                                  </a>



                                </td>
                              </tr>
                              <tr>
                                <td class="blacktext"><b>Customer Name:</b>{orderdetails.billing_name}</td>
                              </tr>
                            </table>
                          </td>
                        </tr>
                        <tr>
                          <td class="blacktext"><b>Email:</b> {orderdetails.email}</td>
                        </tr>
                        <tr>
                          <td class="blacktext"><b>Mobile Number:</b> {orderdetails.mobile}</td>
                        </tr>
                        <tr>
                          <td class="blacktext"><b>Order Date:</b> {orderdetails.orderdate}</td>
                        </tr>
                      {/*   <!-- Billing & Shipping Information --> */}
                        <tr>
                          <td>
                            <table width="100%" align="center" border="0" cellpadding="2" cellspacing="3">
                              <tr>
                                <td class="hilites" align="center" colspan="2"  style={{width:"100%"}}><b>Billing Information</b></td>
                                {/* <td>-</td>
                                <td class="hilites" align="center" colspan="2" style={{width:"50%"}}><b>Shipping Information</b></td> */}
                              </tr>
                              <tr>
                                <td class="frmlefttb" >Name:</td>
                                <td class="frmrighttb">{orderdetails.billing_name}</td>
                                {/* <td>-</td>
                                <td class="frmlefttb">Name:</td>
                                <td class="frmrighttb">{orderdetails.delivery_name}</td> */}
                              </tr>
                              <tr>
                                <td class="frmlefttb">Address:</td>
                                <td class="frmrighttb">{orderdetails.billing_address}</td>
                                {/* <td>-</td>
                                <td class="frmlefttb">Address:</td>
                                <td class="frmrighttb">{orderdetails.delivery_address}</td> */}
                              </tr>
                              <tr>
                                <td class="frmlefttb">City:</td>
                                <td class="frmrighttb">{orderdetails.billing_city}</td>
                                {/* <td>-</td>
                                <td class="frmlefttb">City:</td>
                                <td class="frmrighttb">{orderdetails.delivery_city}</td> */}
                              </tr>
                              <tr>
                                <td class="frmlefttb">State:</td>
                                <td class="frmrighttb">{orderdetails.billing_state}</td>
                                {/* <td>-</td>
                                <td class="frmlefttb">State:</td>
                                <td class="frmrighttb">{orderdetails.delivery_state}</td> */}
                              </tr>
                              <tr>
                                <td class="frmlefttb">Postcode:</td>
                                <td class="frmrighttb">{orderdetails.billing_pincode}</td>
                                {/* <td>-</td>
                                <td class="frmlefttb">Postcode:</td>
                                <td class="frmrighttb">{orderdetails.delivery_pincode}</td> */}
                              </tr>
                            </table>
                          </td>
                        </tr>
                        {/* <!-- Product Details --> */}
                        <tr>
                          <td>
                            <table width="100%" align="center" cellspacing="1" cellpadding="5" border="0">
                              <tr>
                                <td class="hilites"><b>S.No</b></td>
                                <td class="hilites"><b></b></td>
                                <td class="hilites"><b>Product Name</b></td>
                                <td class="hilites"><b>Qty</b></td>
                                <td class="hilites"><b>Price</b></td>
                                <td class="hilites" align="right"><b>Total</b></td>
                                {/* <td class="hilites" align="center"><b>Cancel</b></td> */}
                              </tr>
                              {orderdetails.order_details?.map((product, index) => (
                                  <tr key={product.order_detail_id}>
                                    <td>{index + 1}</td>
                                    <td></td>
                                    <td>
                                   
                                    {product.product_name}
                                      {parseInt(product.cancel) === 1 && (
                                        <div style={{ color: "red", fontSize: "12px",fontWeight:"bold" }}>(Cancelled)</div>
                                      )}
                                    </td>
                                    <td>{product.qty}</td>
                                    <td>₹{parseFloat(product.amount).toFixed(2)}</td>
                                    <td align="right">₹{parseFloat(product.totalamount).toFixed(2)}</td>
                                    {/* <td align="center">
                                    {parseInt(product.cancel) !== 1 ? ( // Hide cancel button if already canceled
                                        <button
                                          onClick={() => handleCancel(product.order_no)}
                                          title="Cancel Product"
                                          style={{ background: "none", border: "none", cursor: "pointer" }}
                                        >
                                          <i className="ri-close-circle-line" style={{ color: "red" }}></i>
                                        </button>
                                      ):(
                                        <div style={{ color: "red", fontSize: "12px",fontWeight:"bold" }}>(Cancelled)</div>
                                      )
                                    }
                                    </td> */}
                                  </tr>
                                ))}
                              
                              <tr>
                                <td colspan="5" align="right"><b>Sub-Total</b></td>
                                <td align="right">₹{orderdetails.subtotal}</td>
                                <td></td>
                              </tr>
                             {/*  <tr>
                                <td colspan="5" align="right"><b>Discount</b></td>
                                <td align="right">₹0.00</td>
                                <td></td>
                              </tr> */}
                              <tr>
                                <td colspan="5" align="right"><b>Discount ({orderdetails.discount_percentage} %)</b></td>
                                <td align="right">₹{orderdetails.discount_amt}</td>
                                <td></td>
                              </tr>
                               <tr>
                                <td colspan="5" align="right"><b>PackingCharge ({orderdetails.packing_percentage} %) </b></td>
                                <td align="right">₹{orderdetails.packing_amount}</td>
                                <td></td>
                              </tr>
                              {/* <tr>
                                <td colspan="5" align="right"><b>CGST </b></td>
                                <td align="right">₹{orderdetails.cgst_amt}</td>
                                <td></td>
                              </tr>
                              <tr>
                                <td colspan="5" align="right"><b>SGST </b></td>
                                <td align="right">₹{orderdetails.sgst_amt}</td>
                                <td></td>
                              </tr> */}
                              <tr>
                                <td colspan="5" align="right"><b>Grand Total</b></td>
                                <td align="right">₹{orderdetails.total}</td>
                                <td></td>
                              </tr>
                             
                          
                               
                            </table>
                          </td>
                        </tr>
                        <tr>
                    <td>
                      <form className="theme-form" onSubmit={Handleupdate}>
                      
                        <div className="row mb-3">
                        <div className="row mb-3 col-sm-6"></div>
                          <label className="col-sm-2 col-form-label">Payment Status:</label>
                          <div className="col-sm-4">
                            <select
                              className="form-select"
                              name="status"
                              value={status}
                              onChange={(e) => setStatus(e.target.value)}
                              required
                            >
                              <option value="" disabled>Select Status</option>
                              <option value="Pending">Pending</option>
                              <option value="Paid">Paid</option>
                             
                            </select>
                          </div>
                        </div>

                        <div className="d-flex justify-content-end">
                          <button type="submit" className="btn btn-primary">Update</button>
                        </div>
                      </form>
                    </td>
                  </tr>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    </>
  );
};

export default OrderDetails;
