import React, { useEffect, useState } from 'react'
import { Link,useParams } from 'react-router-dom';
import Header from '../Components/Header';
import Image from '../Assets/print.gif'
import axios from 'axios';



const CustomOrderDetails = () => {
const {order_id} = useParams();
const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

const[orderdetails,setOrderDetails] = useState([])
 
useEffect(() =>{
  axios.post(`${API_BASE_URL}order_details.php`,{order_id})
  .then((response) =>{
    if(response.data.head.code === 200){
      setOrderDetails(response.data.body)
    }else{
      console.error("Error Fetching Data:", response.data.head.msg);
    }
  })
  
  .catch((error) => {
    console.error("API Error:", error);
  });
})
  return (
    <>
    <Header />
    <div class="page-wrapper compact-wrapper" id="pageWrapper">
      <div class="page-body-wrapper">
        <div class="page-body">
          <div class="container-fluid">
            <div class="row">
              <div class="col-sm-12">
                <div class="card card-table">
                  <div class="card-body">
                    <div class="title-header option-title d-sm-flex d-block">
                      <h5> Order Details</h5>
                      <div class="right-options">
                        <ul>
                          <li>
                            <Link class="btn btn-solid" to="/orderlist">Back</Link>
                          </li>
                        </ul>
                      </div>
                    </div>
                    <div class="table-responsive">
                      <table class="table theme-table table-product" id="table_id">
                       {/*  <!-- Order Summary --> */}
                        <tr>
                          <td>
                            <table width="100%" cellspacing="0" cellpadding="0" border="0">
                              <tr>
                                <td class="blacktext"><b>Order ID:</b> {orderdetails.order_id}</td>
                                <td rowspan="2" align="right">
                                <Link to="/invoice"  state={{ order_id: orderdetails.order_id }}>
                                  <img src={Image} alt="Print" border="0" />
                                </Link>

                                </td>
                              </tr>
                              <tr>
                                <td class="blacktext"><b>Customer Name:</b>{orderdetails.billing_name}</td>
                              </tr>
                            </table>
                          </td>
                        </tr>
                        <tr>
                          <td class="blacktext"><b>Email:</b> {orderdetails.email}</td>
                        </tr>
                        <tr>
                          <td class="blacktext"><b>Mobile Number:</b> {orderdetails.mobile}</td>
                        </tr>
                        <tr>
                          <td class="blacktext"><b>Order Date:</b> {orderdetails.orderdate}</td>
                        </tr>
                      {/*   <!-- Billing & Shipping Information --> */}
                        <tr>
                          <td>
                            <table width="100%" align="center" border="0" cellpadding="2" cellspacing="3">
                              <tr>
                                <td class="hilites" align="center" colspan="2"  style={{width:"50%"}}><b>Billing Information</b></td>
                                <td>-</td>
                                <td class="hilites" align="center" colspan="2" style={{width:"50%"}}><b>Shipping Information</b></td>
                              </tr>
                              <tr>
                                <td class="frmlefttb" >Name:</td>
                                <td class="frmrighttb">{orderdetails.billing_name}</td>
                                <td>-</td>
                                <td class="frmlefttb">Name:</td>
                                <td class="frmrighttb">{orderdetails.delivery_name}</td>
                              </tr>
                              <tr>
                                <td class="frmlefttb">Address:</td>
                                <td class="frmrighttb">{orderdetails.billing_address}</td>
                                <td>-</td>
                                <td class="frmlefttb">Address:</td>
                                <td class="frmrighttb">{orderdetails.delivery_address}</td>
                              </tr>
                              <tr>
                                <td class="frmlefttb">City:</td>
                                <td class="frmrighttb">{orderdetails.billing_city}</td>
                                <td>-</td>
                                <td class="frmlefttb">City:</td>
                                <td class="frmrighttb">{orderdetails.delivery_city}</td>
                              </tr>
                              <tr>
                                <td class="frmlefttb">State:</td>
                                <td class="frmrighttb">{orderdetails.billing_state}</td>
                                <td>-</td>
                                <td class="frmlefttb">State:</td>
                                <td class="frmrighttb">{orderdetails.delivery_state}</td>
                              </tr>
                              <tr>
                                <td class="frmlefttb">Postcode:</td>
                                <td class="frmrighttb">{orderdetails.billing_pincode}</td>
                                <td>-</td>
                                <td class="frmlefttb">Postcode:</td>
                                <td class="frmrighttb">{orderdetails.delivery_pincode}</td>
                              </tr>
                            </table>
                          </td>
                        </tr>
                        {/* <!-- Product Details --> */}
                        <tr>
                          <td>
                            <table width="100%" align="center" cellspacing="1" cellpadding="5" border="0">
                              <tr>
                                <td class="hilites"><b>S.No</b></td>
                                <td class="hilites"><b>Image</b></td>
                                <td class="hilites"><b>Product Name</b></td>
                                <td class="hilites"><b>Qty</b></td>
                                <td class="hilites"><b>Price</b></td>
                                <td class="hilites" align="right"><b>Total</b></td>
                               
                              </tr>
                              {orderdetails.order_details?.map((product, index) => (
                                  <tr key={product.order_detail_id}>
                                    <td>{index + 1}</td>
                                    <td></td>
                                    <td>
                                   
                                    {product.product_name}
                                     
                                    </td>
                                    <td>{product.qty}</td>
                                    <td>₹{parseFloat(product.amount).toFixed(2)}</td>
                                    <td align="right">₹{parseFloat(product.totalamount).toFixed(2)}</td>
                                  </tr>
                                ))}
                              
                              <tr>
                                <td colspan="5" align="right"><b>Sub-Total</b></td>
                                <td align="right">₹{orderdetails.subtotal}</td>
                                <td></td>
                              </tr>
                             {/*  <tr>
                                <td colspan="5" align="right"><b>Discount</b></td>
                                <td align="right">₹0.00</td>
                                <td></td>
                              </tr> */}
                              <tr>
                                <td colspan="5" align="right"><b>CGST</b></td>
                                <td align="right">₹{orderdetails.cgst_amt}</td>
                                <td></td>
                              </tr>
                              <tr>
                                <td colspan="5" align="right"><b>SGST </b></td>
                                <td align="right">₹{orderdetails.sgst_amt}</td>
                                <td></td>
                              </tr>
                              <tr>
                                <td colspan="5" align="right"><b>Grand Total</b></td>
                                <td align="right">₹{orderdetails.total}</td>
                                <td></td>
                              </tr>
                            </table>
                          </td>
                        </tr>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    </>
  );
};

export default CustomOrderDetails;
