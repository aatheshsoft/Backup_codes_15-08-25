import React, { useEffect, useState } from 'react';
import Header from '../Components/Header';
import { Link } from 'react-router-dom';
import axios from 'axios';

const Customerlist = () => {

    const[customerlist, setCustomerList] = useState([]);
    const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

    useEffect (() =>{
    axios.post(`${API_BASE_URL}customer_list.php`)
    .then((response) => {
        if(response.data.head.code === 200){
        setCustomerList(response.data.body)
       /*  console.log(response.data.body); */
        }else{
            console.error("Error Fetching Data",response.data.head.msg)
        }
    })
    .catch((error) =>{
        console.error("API Error:", error);
    })
    },[])

    const [selectedUserId, setSelectedUserId] = useState(null);

    const handleDelete = async () => {
      if (!selectedUserId) {
        alert("Invalid User ID");
        return;
      }
  
     
      try {
        const response = await axios.post(`${API_BASE_URL}customer_list_delete.php`, { user_id: selectedUserId });
  
        if (response.data.head.code === 200) {
        //   alert("Customer deleted successfully!");
         window.location.reload();
        } else {
          alert("Error: " + response.data.head.msg);
        }
      } catch (error) {
        console.error("Delete API Error:", error);
        alert("Failed to delete customer. Please try again.");
      }
    };

    return (
        <>
        <Header/>
        <div class="page-wrapper compact-wrapper" id="pageWrapper">
        <div class="page-body-wrapper">
        <div class="page-body">
        
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card card-table">
                                <div class="card-body">
                                    <div class="title-header option-title d-sm-flex d-block">
                                        <h5><i class="ri-file-user-fill"></i> List Member Management</h5>                                        
                                    </div>
                                    <div>
                                        <div class="table-responsive">
                                            <table class="table all-package theme-table table-product" id="table_id">
                                                <thead>
                                                    <tr>
                                                        <th>S.No.</th>
                                                        <th>Customer Name</th>
														<th>Email</th>
														<th>Phone Number</th>
														<th>Orders History</th>
														<th style={{ textAlign: 'center' }}>Action</th>
                                                    </tr>
                                                </thead>

                                                <tbody>
                                                    {customerlist.length > 0 ? (
                                                        customerlist.map((item,index) =>(
                                                        <tr key={item.user_id}>
                                                        <td>{index+1}</td>                                                        
														<td>{item.name}</td>
														<td>{item.email}</td>
														<td>{item.mobile}</td>
														<td style={{ textAlign: 'center' }}>
                                                            <Link to={`/customorderlist/${item.user_id}`}><i class="ri-order-play-fill"></i></Link></td>
														<td>
                                                            <ul>                                                               
																<li><Link to={`/viewcustomer/${item.user_id}`}><i class="ri-eye-line"></i></Link></li>
                                                                <li>  <a href="javascript:void(0)" 
                                                                    data-bs-toggle="modal" 
                                                                    data-bs-target="#deleteModal"
                                                                    onClick={() => setSelectedUserId(item.user_id)}>
                                                                    <i className="ri-delete-bin-line"></i>
                                                                </a>
                                                                </li>
                                                            </ul>
                                                        </td>
                                                    </tr>
                                                        ))

                                                    ):(
                                                        <tr>
                                                            <td colSpan="5" className="text-center">
                                                            No Record found
                                                            </td>
                                                        </tr>
                                                    )}
                                                    
																						
                                                </tbody>
                                            </table>											
                                        </div>
										
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
            </div>
            </div>
            <div className="modal fade" id="deleteModal" tabIndex="-1" aria-hidden="true">
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title">Confirm Delete</h5>
              <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div className="modal-body">
              Are you sure you want to delete this customer?
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" data-bs-dismiss="modal">
                Cancel
              </button>
              <button type="button" className="btn btn-danger" onClick={handleDelete} >
                Delete
              </button>
            </div>
          </div>
        </div>
      </div>
        </>
    );
};

export default Customerlist;
