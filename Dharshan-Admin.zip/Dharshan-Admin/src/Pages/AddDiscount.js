import React,{useState} from "react";
import Header from "../Components/Header";
import { Link,useNavigate } from "react-router-dom";
import axios from "axios";

const AddDiscount = () => {
    const navigate = useNavigate();
    const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

    const [formData, setFormData] = useState({
        start_amt: "",
        end_amt: "",
        discount_amt:"",
      });
    
      const [loading, setLoading] = useState(false); // Loader state
      const [message, setMessage] = useState(""); // Success/Error message
    
      // Handle input changes
      const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
      };
    
      // Handle form submission
      const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        setMessage("");
      
        try {
          const response = await axios.post(`${API_BASE_URL}discount_add.php`, formData);
          
          console.log("API Response:", response.data); 
      
          // Check if response.data exists and has the expected structure
          if (response.data && response.data.head && response.data.head.code === 200) {
            setMessage("discount added successfully!");
            setFormData({ start_amt: "", end_amt: "", discount_amt:"",}); // Reset form
            navigate('/discount')
          } else {
            setMessage(`Error: ${response.data?.head?.msg || "Unexpected response format"}`);
          }
        } catch (error) {
          console.error("API Error:", error);
          setMessage("API Error: Unable to add discount.");
        } finally {
          setLoading(false);
        }
      };
      
  return (
    <>
      <Header />
      <div class="page-wrapper compact-wrapper" id="pageWrapper">
        <div class="page-body-wrapper">
          <div class="page-body">
          <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="row">
                                <div class="col-sm-12 m-auto">
                                    <div class="card">
                                        <div class="card-body">
                                      <div class="title-header option-title d-sm-flex d-block">
                                        <h5>Add Discount</h5>
                                        <div class="right-options">
                                            <ul>                                               
                                                <li>
                                                    <Link class="btn btn-solid" to="/discount">Back</Link>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                    <form className="theme-form theme-form-2 mega-form" onSubmit={handleSubmit}>

                                            {/* Category Name Input */}
                                            <div className="mb-4 row align-items-center">
                                                <label className="form-label-title col-sm-3 mb-0">Start Amount</label>
                                                <div className="col-sm-9">
                                                <input
                                                    className="form-control"
                                                    type="text"
                                                    name="start_amt"
                                                    value={formData.start_amt}
                                                    onChange={handleChange}
                                                    placeholder="Enter Start Amount"
                                                    required
                                                />
                                                </div>
                                            </div>

                                            <div className="mb-4 row align-items-center">
                                                <label className="form-label-title col-sm-3 mb-0">End Amount</label>
                                                <div className="col-sm-9">
                                                <input
                                                    className="form-control"
                                                    type="text"
                                                    name="end_amt"
                                                    value={formData.end_amt}
                                                    onChange={handleChange}
                                                    placeholder="Enter End Amount"
                                                    required
                                                />
                                                </div>
                                            </div>


                                            <div className="mb-4 row align-items-center">
                                                <label className="form-label-title col-sm-3 mb-0">Discount Percentage</label>
                                                <div className="col-sm-9">
                                                <input
                                                    className="form-control"
                                                    type="text"
                                                    name="discount_amt"
                                                    value={formData.discount_amt}
                                                    onChange={handleChange}
                                                    placeholder="Enter Discount Percentage"
                                                    required
                                                />
                                                </div>
                                            </div>

                                           

                                            {/* Submit & Cancel Buttons */}
                                            <div className="card-footer border-0 pb-0 d-flex justify-content-end">
                                                <button className="btn btn-primary me-3" type="submit" disabled={loading}>
                                                {loading ? "Submitting..." : "Submit"}
                                                </button>
                                                <button className="btn btn-outline" type="button" onClick={() => {navigate("/discount") }}>
                                                Cancel
                                                </button>
                                            </div>

                                            {/* Success/Error Message */}
                                            {message && <p className="text-center mt-3">{message}</p>}
                                            </form>
                                      </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </div>
    </>
  );
};

export default AddDiscount;
