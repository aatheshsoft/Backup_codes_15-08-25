import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import Header from "../Components/Header";
import axios from "axios";

const GalleryList = () => {
  const [loading, setLoading] = useState(true);
  const [gallerylist, setGalleryList] = useState([]);
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

  useEffect(() => {
    setLoading(true);
    axios
      .post(`${API_BASE_URL}gallery_list.php`)
      .then((response) => {
        if (response.data.head.code === 200) {
          const sortedBanners = response.data.body.sort((a, b) => a.rank - b.rank );
          setGalleryList(sortedBanners);
        } else {
          console.error("Error Fetching Data", response.data.head.msg);  
        }
      })
      .catch((error) => {
        console.error("API Error:", error);
      })
      .finally(() => {
        setLoading(false);
      });
  }, []);

  const handleChange = (gallery_id, field, value) => {
    setGalleryList((prevBanners) =>
      prevBanners.map((gallery) =>
        gallery.gallery_id === gallery_id ? { ...gallery, [field]: value } : gallery
      )
    );
  };

  const handleUpdate = async () => {
    
    try {
      const updates = gallerylist.map(async (gallery) => {
        const response = await axios.post(
          `${API_BASE_URL}gallery_list_update.php`,
          {
            gallery_id: gallery.gallery_id,
            rank: gallery.rank,
            active: gallery.active, 
          }
        );
          if (response.data.head.code !== 200) {
            alert("Error updating image:", response.data.head.msg);
          console.error("Error updating image:", response.data.head.msg);
          
          return false;
        }
        return true;
      });

      const results = await Promise.all(updates);
      if (results.every((res) => res === true)) {
        alert("Updated Successfully");
       window.location.reload();
         
      }
    } catch (error) {
      console.error("Error updating banners:", error);
    }
  };


  const handleDelete = async (gallery_id) => {
    if (window.confirm("Are you sure you want to delete this image?")) {
    
      try {
        const response = await axios.post(`${API_BASE_URL}gallery_list_delete.php`, {
          gallery_id
        });
  
        if (response.data.head.code === 200) {
          alert("image deleted successfully");
          window.location.reload();

          
        } else {
          console.error("Error deleting image:", response.data.head.msg);
        }
      } catch (error) {
        console.error("API Error:", error);
      }
    }
  };
  

  return (
    <>
      <Header />
      <div className="page-wrapper compact-wrapper" id="pageWrapper">
        <div className="page-body-wrapper">
          <div className="page-body">
            <div className="container-fluid">
              <div className="row">
                <div className="col-sm-12">
                  <div className="card card-table">
                    <div className="card-body">
                      <div className="title-header option-title d-sm-flex d-block">
                        <h5>List of Gallery</h5>
                        <div className="right-options">
                          <ul>
                            <li>
                              <Link className="btn btn-solid" to="/addgallery">
                                Add 
                              </Link>
                            </li>
                          </ul>
                        </div>
                      </div>
                      <div>
                        {loading ? (
                          <div style={{ display: "flex", justifyContent: "center", marginTop: "50px" }}>
                          <div className="loader"></div>
                        </div>
                        ) : (
                          <>
                            <div className="table-responsive">
                              <table
                                className="table all-package theme-table table-product"
                                id="table_id"
                              >
                                <thead>
                                  <tr>
                                    <th>S.No.</th>
                                    <th>Images</th>
                                    <th>Rank</th>
                                    <th style={{ textAlign: "center" }}>
                                      Active
                                    </th>
                                    <th style={{ textAlign: "center" }}>
                                      Action
                                    </th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {gallerylist.length > 0 ? (
                                    gallerylist.map((gallery, index) => (
                                      <tr key={gallery.gallery_id}>
                                        <td>{index + 1}</td>
                                        <td>
                                          <div>
                                            <img
                                              src={gallery.image}
                                              className="img-fluid"
                                              alt=""
                                             style={{width:"300px",height:"350px",objectFit:"contain"}}
                                            />
                                          </div>
                                        </td>
                                        <td style={{ width: "2px" }}>
                                          <input
                                            className="form-control"
                                            type="text"
                                            value={gallery.rank}
                                            name={`rank_${gallery.gallery_id}`}
                                            onChange={(e) =>
                                              handleChange(
                                                gallery.gallery_id,
                                                "rank",
                                                e.target.value
                                              )
                                            }
                                          />
                                        </td>
                                        <td style={{ textAlign: "center" }}>
                                          <input
                                            className="checkbox_animated check-it"
                                            type="checkbox"
                                            value="1"
                                            name={`act_${gallery.gallery_id}`}
                                            checked={gallery.active === "1"}
                                            onChange={(e) =>
                                              handleChange(
                                                gallery.gallery_id,
                                                "active",
                                                e.target.checked ? "1" : "0"
                                              )
                                            }
                                          />
                                        </td>
                                        <td>
                                          <ul>
                                            <li>
                                              <Link
                                                to={`/editgallery/${gallery.gallery_id}`}
                                              >
                                                <i className="ri-pencil-line"></i>
                                              </Link>
                                            </li>
                                            <li>
                                                <a href="javascript:void(0)" onClick={() => handleDelete(gallery.gallery_id)}>
                                                    <i className="ri-delete-bin-line"></i>
                                                </a>
                                                </li>

                                          </ul>
                                        </td>
                                      </tr>
                                    ))
                                  ) : (
                                    <tr>
                                      <td colSpan="5" className="text-center">
                                        No Banners Found
                                      </td>
                                    </tr>
                                  )}
                                </tbody>
                              </table>
                            </div>
                          </>
                        )}
                        <div className="card-footer border-0 pb-0 d-flex justify-content-end">
                          <button
                            className="btn btn-primary me-3"
                            onClick={handleUpdate}
                          >
                            Update
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default GalleryList;
