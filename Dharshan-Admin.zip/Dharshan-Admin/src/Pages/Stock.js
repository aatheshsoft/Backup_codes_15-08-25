import React, { useState, useEffect } from "react";
import Header from "../Components/Header";
import axios from "axios";

const Stock = () => {
  const [stock, setStock] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);

  const recordsPerPage = 25;
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

  useEffect(() => {
    setLoading(true);
    axios
      .post(`${API_BASE_URL}report_stock.php`)
      .then((response) => {
        const res = response.data;
        if (res.head.code === 200 && res.body && res.body.stock_report) {
          setStock(res.body.stock_report);
          setFilteredProducts(res.body.stock_report);
        } else {
          console.error("Invalid response data");
        }
      })
      .catch((error) => console.error("API Error:", error))
      .finally(() => setLoading(false));
  }, []);

  const handleSearch = (e) => {
    const query = e.target.value.toLowerCase();
    setSearchQuery(query);

    const filtered = stock
      .map((category) => {
        const filteredProducts = category.product.filter(
          (p) =>
            p.product_name.toLowerCase().includes(query) ||
            p.product_code?.toLowerCase().includes(query)
        );
        return { ...category, product: filteredProducts };
      })
      .filter((cat) => cat.product.length > 0);

    setFilteredProducts(filtered);
    setCurrentPage(1);
  };

  const flattenProducts = (data) => {
    let result = [];
    data.forEach((category) => {
      category.product.forEach((product) => {
        result.push({ ...product, category_name: category.category_name });
      });
    });
    return result;
  };

  const allFlatProducts = flattenProducts(filteredProducts);
  const totalItems = allFlatProducts.length;
  const totalPages = Math.ceil(totalItems / recordsPerPage);

  const indexOfLastRecord = currentPage * recordsPerPage;
  const indexOfFirstRecord = indexOfLastRecord - recordsPerPage;
  const paginatedProducts = allFlatProducts.slice(indexOfFirstRecord, indexOfLastRecord);

  // Re-group paginated flat data by category
  const groupedPaginatedData = paginatedProducts.reduce((acc, product) => {
    const category = product.category_name;
    if (!acc[category]) acc[category] = [];
    acc[category].push(product);
    return acc;
  }, {});

  const paginate = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  return (
    <>
      <Header />
      <div className="page-wrapper compact-wrapper" id="pageWrapper">
        <div className="page-body-wrapper">
          <div className="page-body">
            <div className="container-fluid">
              <div className="row">
                <div className="col-sm-12">
                  <div className="card card-table">
                    <div className="card-body">
                      <div className="title-header option-title d-sm-flex d-block">
                        <h5>List of Stock</h5>
                        <div className="col-sm-8">
                          <form className="theme-form theme-form-2 mega-form">
                            <div className="mb-4 row align-items-center">
                              <label className="col-sm-2 col-form-label" style={{ fontSize: "14px" }}>
                                Search:
                              </label>
                              <div className="col-sm-10">
                                <input
                                  type="text"
                                  className="form-control"
                                  placeholder="Search"
                                  value={searchQuery}
                                  onChange={handleSearch}
                                />
                              </div>
                            </div>
                          </form>
                        </div>
                      </div>

                      {loading ? (
                       <div style={{ display: "flex", justifyContent: "center", marginTop: "50px" }}>
                       <div className="loader"></div>
                     </div>
                      ) : (
                        <div className="table-responsive">
                          <table className="table all-package theme-table table-product" id="table_id">
                            <thead>
                              <tr>
                                <th>S.No.</th>
                                {/* <th>Product Code</th> */}
                                <th>Product</th>
                                <th style={{ textAlign: "center" }}>Stock</th>
                              </tr>
                            </thead>
                            <tbody>
                            {Object.keys(groupedPaginatedData).length > 0 ? (
                                  (() => {
                                    let serialNumber = indexOfFirstRecord + 1; // Initialize serial number
                                    return Object.entries(groupedPaginatedData).map(([categoryName, products], catIdx) => (
                                      <React.Fragment key={catIdx}>
                                        <tr>
                                          <td colSpan="4" style={{ fontWeight: "bold", background: "rgb(255 95 87 / 94%)", textAlign: "center", color: "white" }}>
                                            {categoryName}
                                          </td>
                                        </tr>
                                        {products.map((item, idx) => (
                                          <tr key={idx}>
                                            <td>{serialNumber++}</td> {/* Increment serial number */}
                                            <td>{item.product_name}</td>
                                            <td style={{ textAlign: "center" }}>{item.stock}</td>
                                          </tr>
                                        ))}
                                      </React.Fragment>
                                    ));
                                  })()
                                ) : (
                                  <tr>
                                    <td colSpan="4" className="text-center">
                                      No stock found
                                    </td>
                                  </tr>
                                )}


                              <tr>
                                <td colSpan="4">
                                  <div className="d-flex justify-content-between">
                                    <div>Page {currentPage} of {totalPages}</div>
                                    <div>
                                      {currentPage > 1 && (
                                        <a href="#" onClick={(e) => { e.preventDefault(); paginate(currentPage - 1); }}>
                                          &laquo; Prev
                                        </a>
                                      )}
                                      {Array.from({ length: totalPages }, (_, i) => i + 1)
                                        .filter(page =>
                                          page === 1 ||
                                          page === totalPages ||
                                          (page >= currentPage - 1 && page <= currentPage + 1)
                                        )
                                        .map((page, i, array) => (
                                          <React.Fragment key={page}>
                                            {i > 0 && page !== array[i - 1] + 1 && <span className="mx-1">...</span>}
                                            <a
                                              href="#"
                                              className={`mx-1 ${currentPage === page ? "fw-bold" : ""}`}
                                              onClick={(e) => { e.preventDefault(); paginate(page); }}
                                            >
                                              {page}
                                            </a>
                                          </React.Fragment>
                                        ))}
                                      {currentPage < totalPages && (
                                        <a href="#" onClick={(e) => { e.preventDefault(); paginate(currentPage + 1); }}>
                                          Next &raquo;
                                        </a>
                                      )}
                                    </div>
                                  </div>
                                </td>
                              </tr>

                            </tbody>
                          </table>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Stock;
