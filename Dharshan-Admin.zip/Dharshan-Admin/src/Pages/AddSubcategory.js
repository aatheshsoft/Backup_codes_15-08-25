import React, { useState } from "react";
import Header from "../Components/Header";
import { Link, useLocation, useNavigate } from "react-router-dom";
import axios from "axios";

const AddSubcategory = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const category_id = location.state?.category_id;
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
  const [subcategoryName, setSubcategoryName] = useState("");
  const [image, setImage] = useState(null);

  const handleImageChange = (e) => {
    const file = e.target.files[0]; 
    if (file) {
      setImage(file); 
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
 
    const toBase64 = (file) => 
      new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result);
        reader.onerror = (error) => reject(error);
      });
  
    try {
      
          let base64Image = "";

              if (image) {
                base64Image = await toBase64(image);
              }  
        const data = {
        
          category_name: subcategoryName,
          image: base64Image, 
        };
  
      console.log("Sending Data:", data);
  
      const response = await axios.post(
        `${API_BASE_URL}category_add.php`,
        data,
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
  
      console.log(response.data);
      if (response.data.head.code === 200) {
        console.log("✅ Subcategory added successfully!");
        navigate("/subcategory");
      } else {
        console.error("❌ Error adding subcategory:", response.data.head.msg);
      }
    } catch (error) {
      console.error("❌ API error:", error);
    }
  };
  
  

return (
    <>
      <Header />
      <div class="page-wrapper compact-wrapper" id="pageWrapper">
        <div class="page-body-wrapper">
          <div className="page-body">
            <div className="container-fluid">
              <div className="row">
                <div className="col-12">
                  <div className="row">
                    <div className="col-sm-12 m-auto">
                      <div className="card">
                        <div className="card-body">
                          <div className="title-header option-title d-sm-flex d-block">
                            <h5>Add Category </h5>
                            <div className="right-options">
                              <ul>
                                <li>
                                  <Link
                                    className="btn btn-solid"
                                    to="/subcategory"
                                  >
                                    Back
                                  </Link>
                                </li>
                              </ul>
                            </div>
                          </div>

                          <form
                            class="theme-form theme-form-2 mega-form"
                            onSubmit={handleSubmit}
                          >
                            <div class="mb-4 row align-items-center">
                              <label class="form-label-title col-sm-3 mb-0">
                                Category Name
                              </label>
                              <div class="col-sm-9">
                                <input
                                  class="form-control"
                                  type="text"
                                  placeholder="Enter Category Name"
                                  value={subcategoryName}
                                  onChange={(e) => setSubcategoryName(e.target.value)}
                                  required
                                />
                              </div>
                            </div>

                            <div class="mb-4 row align-items-center">
                              <label class="form-label-title col-sm-3 mb-0">
                                Upload Image
                              </label>
                              <div class="col-sm-9">
                                <input
                                  class="form-control form-choose"
                                  type="file"
                                  id="formFile"
                                  multiple
                                  onChange={handleImageChange}
                                 
                                />
                               <p>Width 500px x 500px</p>
                              </div>
                            </div>

                            <div class="card-footer border-0 pb-0 d-flex justify-content-end">
                              <button class="btn btn-primary me-3" type="submit">
                                Submit
                              </button>
                              <button class="btn btn-outline" type="button"  onClick={() => navigate("/subcategory")}>
                                Cancel
                              </button>
                            </div>
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default AddSubcategory;
