import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faShoppingCart } from "@fortawesome/free-solid-svg-icons";
import { Offcanvas } from "react-bootstrap";
import "./Header.css";
import Mainlogo from "../Assets/shasti-logo.png";
import axios from 'axios';
import Button from 'react-bootstrap/Button';

function Header() {
  const [cartCount, setCartCount] = useState(0);
  const [showOffcanvas, setShowOffcanvas] = useState(false);
  const [contactData, setContactData] = useState(null);
  const [priceListUrl, setPriceListUrl] = useState(""); // New state for price list URL
  const [orderclose, setOrdeClose] =useState(0);
  
  useEffect(() => {
    const fetchContactData = async () => {
      try {
        const response = await axios.get("https://www.shasticrackers.com/customerapi/content.php");
        const { body } = response.data;
        
        setContactData(body.contact);
       
      } catch (error) {
        console.error("Error fetching the contact data", error);
      }
    };

    fetchContactData();
  }, []);

  useEffect(() => {
      const fetchData = async () => {
        try {
          const response = await axios.post(
            "https://www.shasticrackers.com/customerapi/home.php"
          );
          const { body } = response.data;
  
         
          
          setOrdeClose(Number(body.minimum_order_store_closed[0].store_closed))

        } catch (error) {
          console.error("There was an error fetching the data!", error);
        } 
      };
  
      fetchData();
    }, []);

  useEffect(() => {
    // Retrieve cart count from local storage
    const count = parseInt(localStorage.getItem("cartCount")) || 0;
    setCartCount(count);

    // Optionally, listen for changes in local storage (if using multiple tabs)
    const handleStorageChange = () => {
      const count = parseInt(localStorage.getItem("cartCount")) || 0;
      setCartCount(count);
    };

    window.addEventListener('storage', handleStorageChange);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
    };
  }, []);

  const handleClose = () => setShowOffcanvas(false);
  const handleShow = () => setShowOffcanvas(true);


  const handleDownloadPriceList = async () => {
    try {
      const response = await axios.post(
        'https://shasticrackers.com/customerapi/download_pricelist.php',
        {}, // body if needed
        {
          responseType: 'blob',
        }
      );
  
      const blob = new Blob([response.data], { type: 'application/pdf' });
      const url = window.URL.createObjectURL(blob);
  
      const a = document.createElement('a');
      a.href = url;
      a.download = 'PriceList.pdf';
      document.body.appendChild(a);
      a.click();
      a.remove();
  
      setTimeout(() => window.URL.revokeObjectURL(url), 100);
    } catch (error) {
      console.error('Download failed:', error);
      alert('Failed to download price list. Please try again later.');
    }
  };
  

  return (
    <div className="nav-main">
      <div id="header" className="header sticky-top">
        <div className="topbar d-flex align-items-center">
          <div className="container d-flex justify-content-md-between">
            <div className="contact-info d-flex align-items-center">
              <i className="bi bi-envelope">
               <strong> <span>{contactData?.email || ""}</span></strong>
              </i>
              <i className="bi bi-phone">
              <strong><span>{contactData?.phonenumber || ""}</span></strong>
              </i>
            </div>
            <div className="social-links d-none d-md-flex align-items-center">
              <Link to="/" className="social">
                <i className="bi bi-facebook"></i>
              </Link>
              <Link to="/" className="social"><i className="bi bi-instagram"></i></Link>
              <Link to="/" className="social">
                <i className="bi bi-youtube"></i>
              </Link>
            </div>
          </div>
        </div>

        <div className="branding d-flex align-items-center">
          <div className="container position-relative d-flex align-items-center justify-content-between">
            <Link to="/" className="logo d-flex align-items-center me-auto">
              <div className="logo d-flex align-items-center me-auto">
                <img src={Mainlogo} alt="Logo" />
              </div>
            </Link>

            <nav id="navmenu" className="navmenu d-none d-xl-block">
              <ul>
                <li>
                  <Link to="/" className="nav-link">
                    Home
                  </Link>
                </li>
                <li>
                  <Link to="/quick" className="nav-link">
                    Enquiry
                  </Link>
                </li>
                <li>
                  <Link to="/about" className="nav-link">
                    About Us
                  </Link>
                </li>
                <li>
                  <Link to="/contact" className="nav-link">
                    Contact Us
                  </Link>
                </li>
              </ul>
            </nav>

            <Button className="cta-btn d-none d-sm-block blink"  onClick={handleDownloadPriceList}>
              Download Price List
            </Button>
          </div>
          {orderclose === 0 && (
          <div className="cart">
            <Link to="/cart">
              <FontAwesomeIcon icon={faShoppingCart}  style={{color:"#662d91"}}/>
              {cartCount > 0 && <span className="badge">{cartCount}</span>}
            </Link>
          </div>
          )}
          <i
            className="mobile-nav-toggle bi bi-list"
            onClick={handleShow}
          ></i>
        </div>
      </div>

      {/* Offcanvas Menu */}
      <Offcanvas show={showOffcanvas} onHide={handleClose} placement="start">
        <Offcanvas.Header closeButton>
          <Offcanvas.Title>
            <img src={Mainlogo} alt="Logo" style={{ width: "150px" }} />
          </Offcanvas.Title>
        </Offcanvas.Header>
        <Offcanvas.Body>
          <ul className="offcanvas-menu">
            <li>
              <Link to="/" className="nav-link" onClick={handleClose}>
                <i className="bi bi-house-fill officon"></i> Home
              </Link>
            </li>
            <hr />
            <li>
              <Link to="/about" className="nav-link" onClick={handleClose}>
                <i className="bi bi-journal-text officon"></i> About Us
              </Link>
            </li>
            <hr />
            <li>
              <Link to="/quick" className="nav-link" onClick={handleClose}>
                <i className="bi bi-bag-fill officon"></i> Enquiry
              </Link>
            </li>
            <hr />
            <li>
              <Link to="/contact" className="nav-link" onClick={handleClose}>
                <i className="bi bi-telephone-fill officon"></i> Contact Us
              </Link>
            </li>
            <hr />
          </ul>
        </Offcanvas.Body>
      </Offcanvas>
    </div>
  );
}

export default Header;
