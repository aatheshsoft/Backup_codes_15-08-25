import './App.css';
import 'bootstrap-icons/font/bootstrap-icons.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import {BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Home from './Pages/Home';
import Quick from './Pages/Quick';
import About from './Pages/About';
import Contact from './Pages/Contact';
import Privacy from './Pages/Privacy';
import Cart from './Pages/Cart';
import Terms from './Pages/Terms';
import ShippingPolicy from './Pages/ShippingPolicy';
import Thanks from './Pages/Thanks';
import React, {  useEffect } from "react";

function App() {
  useEffect(() => {
    
    const handleContextMenu = (e) => {
      e.preventDefault();
    };

    // Disable F12, Ctrl+Shift+I, Ctrl+Shift+C, Ctrl+U
    const handleKeyDown = (e) => {
      // F12
      if (e.keyCode === 123) {
        e.preventDefault();
      }
      // Ctrl+Shift+I or Ctrl+Shift+C or Ctrl+Shift+J (DevTools shortcuts)
      if ((e.ctrlKey && e.shiftKey && (e.keyCode === 73 || e.keyCode === 74 || e.keyCode === 67)) ||
          // Ctrl+U (View Source)
          (e.ctrlKey && e.keyCode === 85)) {
        e.preventDefault();
      }
    };

    document.addEventListener('contextmenu', handleContextMenu);
    document.addEventListener('keydown', handleKeyDown);

   
    return () => {
      document.removeEventListener('contextmenu', handleContextMenu);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, []);


  
  return (
    <Router basename='/shasti'>
      <Routes>
      <Route path="/" element={<Home />} />
      <Route path='/quick' element={<Quick />} />
      <Route path='/about' element={<About />} />
      <Route path='/contact' element={<Contact />} />
      <Route path='/privacy' element={<Privacy />} />
      <Route path='/cart' element={<Cart />} />
      <Route path='/terms' element={<Terms />} />
      <Route path='/shippingpolicy' element={<ShippingPolicy />} />
      <Route path='/thanks' element={<Thanks />} />
      </Routes>
    </Router>
  );
}

export default App;
