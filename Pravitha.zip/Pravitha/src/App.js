// src/App.js
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter as Router, Route, Routes, Navigate,useLocation } from 'react-router-dom';
import CustomNav from './CustomNav';
import Home from './Pages/Home';
import Shop from './Pages/Shop';
import Cart from './Pages/Cart';
import ProductDetail from './Pages/ProductDetail';
import Detailing from './Pages/Detailing';
import CheckOut from './Pages/CheckOut';
import About from './Pages/About';
import Contact from './Pages/Contact';
import OrderHistory from './Pages/OrderHistory';
import MyAccount from './Pages/MyAccount';
import SignIn from './Pages/SignIn';  // Ensure that the case matches the actual file name
import SignUp from './Pages/SignUp';
import { useEffect, useState } from 'react';
import WhyChoose from './Components/WhyChoose';
import ReturnPolicy from './Pages/ReturnPolicy';
import CancellationPolicy from './Pages/CancellationPolicy';
import TermsConditions from './Pages/TermsConditions';
import Whyus from './Components/Whyus';
import PrivacyPolicy from './Pages/PrivacyPolicy';
import ShippingPolicy from './Pages/ShippingPolicy';
import Footer from './Components/Footer';
import ShopByCategory from './Pages/ShopByCategory'
import Silver from './Pages/Silver';



function App() {
    const location = useLocation();
 
  return (
    
    <div>
      {/* Conditionally render CustomNav */}
      {location.pathname !== "/checkout" && <CustomNav />}

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/signin" element={<SignIn />} />
        <Route path="/signup" element={<SignUp />} />
        <Route path="/home" element={<Home />} />
        <Route path="/shop/:main_category_name/:sub_category_name" element={<Shop />} />
        <Route path="/silver/:main_category_name" element={<Silver />} />
        <Route path="/shopbycategory/:main_category_id/:sub_category_id" element={<ShopByCategory />} />
        <Route path="/cart" element={<Cart />} />
        <Route path="/detailing" element={<Detailing />} />
        <Route path="/about" element={<About />} />
        <Route path="/productdetail/:product_id" element={<ProductDetail />} />
        <Route path="/orderhistory" element={<OrderHistory />} />
        <Route path="/checkout" element={<CheckOut />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/whychoose" element={<WhyChoose />} />
        <Route path="/whyus" element={<Whyus />} />
        <Route path="/returnpolicy" element={<ReturnPolicy />} />
        <Route path="/privacypolicy" element={<PrivacyPolicy />} />
        <Route path="/shippingpolicy" element={<ShippingPolicy />} />

        <Route path="/TermsConditions" element={<TermsConditions />} />
        <Route path="/cancellationpolicy" element={<CancellationPolicy />} />
        <Route path="/myaccount" element={<MyAccount />} />
      </Routes>

      <Footer />
    </div>
  );
};

export default function AppWithRouter() {
  return (
    <Router>
      <App />
    </Router>
  );
}
