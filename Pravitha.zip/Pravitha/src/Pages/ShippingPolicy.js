import React, { useEffect, useState } from "react";
import backgroundImage from '../Assets/background.png';
import PuffLoader from "react-spinners/PuffLoader";

const ShippingPolicy = () => {
  const [loading, setLoading] = useState(true); // Loading state
  useEffect(() => {
    // Simulate data fetching or delay for loader
    const timer = setTimeout(() => {
      setLoading(false); // Stop loading after 3 seconds
    }, 3000);

    return () => clearTimeout(timer); // Cleanup timeout
  }, []);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className='mainpage'>
      {loading ? (
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            height: "100vh",
          }}
        >
          <PuffLoader color="#D0C743" size={100} />
        </div>
      ) : (
        <>
          <div
            style={{
              backgroundImage: `url(${backgroundImage})`,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
              backgroundRepeat: 'no-repeat',
              padding: '20px',
              color: '#333',
            }}
          >
            <h1 className="cancellation-policy-title">Shipping & Delivery</h1>
          </div>
          <div className="terms-container">
            <p><strong>Order Processing & Shipping Times</strong></p>
            <p>
            It's important to start by clarifying that your order processing times are separate from the shipping times you see at checkout.
</p>
            <p>
            All orders are processed with 2 to 3 business days (excluding weekends and holidays) after receiving your order confirmation email. You will receive another notification when your order has shipped.</p>
            <p>
            Please note that there might be delays due to a high Volume of orders or postal service issues that are outside of our control.
            </p>

            <h3>Domestic Shipping Rates and Estimates</h3>
            <p><strong>For calculated shipping rates:</strong> Shipping charges for your order will be calculated and displayed at checkout.</p>
            <p>Currently there is No local delivery and In-store pickup.</p>
            <p>At present all orders accepted in-side India only. International orders are not accepted.</p>

            {/* <h4>Shipping options</h4>
            <table className="shipping-table">
              <thead>
                <tr>
                  <th>Shipping Option</th>
                  <th>Estimated Delivery Time</th>
                  <th>Price</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>Option 1</td>
                  <td>X to X business days</td>
                  <td>X</td>
                </tr>
                <tr>
                  <td>Option 2</td>
                  <td>X to X business days</td>
                  <td>X</td>
                </tr>
                <tr>
                  <td>Option 3</td>
                  <td>X to X business days</td>
                  <td>X</td>
                </tr>
              </tbody>
            </table>

            <h3>Local Delivery</h3>
            <p>If you offer local delivery or in-store pickup to customers in your area, you can dedicate a section of your shipping policy page to explain the process.</p>
            <p>Free local delivery is available for orders over $X within [area of coverage]. For orders under $X, we charge $X for local delivery.</p>
            <p>Deliveries are made from [delivery hours] on [available days]. We will contact you via text message with the phone number you provided at checkout to notify you on the day of our arrival.</p>

            <h3>In-Store Pickup</h3>
            <p>You can skip the shipping fees with free local pickup at [list the locations where in-store pickup is available]. After placing your order and selecting local pickup at checkout, your order will be prepared and ready for pickup within X to X business days. We will send you an email when your order is ready along with instructions.</p>
            <p>Our in-store pickup hours are [store hours] on [available days of the week]. Please have your order confirmation email with you when you come.</p>

            <h3>International Shipping</h3>
            <p>We offer international shipping to the following countries: [list of countries].</p>
            <p>At this time, we do not ship to [list of countries].</p>
            <p>If you're using calculated shipping rates: Shipping charges for your order will be calculated and displayed at checkout.</p>

            <h4>Shipping options</h4>
            <table className="shipping-table">
              <thead>
                <tr>
                  <th>Shipping Option</th>
                  <th>Estimated Delivery Time</th>
                  <th>Price</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>Option 1</td>
                  <td>X to X business days</td>
                  <td>X</td>
                </tr>
                <tr>
                  <td>Option 2</td>
                  <td>X to X business days</td>
                  <td>X</td>
                </tr>
                <tr>
                  <td>Option 3</td>
                  <td>X to X business days</td>
                  <td>X</td>
                </tr>
              </tbody>
            </table>

            <p>Your order may be subject to import duties and taxes (including VAT), which are incurred once a shipment reaches your destination country. [Your Company] is not responsible for these charges if they are applied and are your responsibility as the customer.</p> */}
          </div>
        </>
      )}
    </div>
  );
};

export default ShippingPolicy;
