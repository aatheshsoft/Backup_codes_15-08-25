import React, { useEffect } from "react";
import Logo from "../Assets/grocery.jpg";
import Logo1 from "../Assets/electronic-devices.jpg";
import Logo2 from "../Assets/dress1.jpg";
import PureCounter from "@srexi/purecounterjs";

function About() {
  useEffect(() => {
    new PureCounter();
  }, []);

  return (
    <div>
      <div id="values" class="values section">
        <div class="container section-title" data-aos="fade-up">
          
          <h2 className="">Our Products</h2>
          </div>
          <div className="section-title1">
          <p>
            What we value most
          </p>
          </div>
        

        <div class="container">
          <div class="row gy-4">
            <div class="col-lg-4" data-aos="fade-up" data-aos-delay="100">
              <div class="card">
                <img src={Logo} alt="Banner 1" className="d-block w-100" />
                <h3> GROCERIES </h3>
                <p>All type And All Brands Of Products Available </p>
              </div>
            </div>
            {/* <!-- End Card Item --> */}

            <div class="col-lg-4" data-aos="fade-up" data-aos-delay="200">
              <div class="card">
                <img src={Logo1} alt="Banner 1" className="d-block w-100" />
                <h3>ELECTRONICS</h3>
                <p>All Variants And All Brands Available</p>
              </div>
            </div>
            {/* <!-- End Card Item --> */}

            <div class="col-lg-4" data-aos="fade-up" data-aos-delay="300">
              <div class="card">
                <img src={Logo2} alt="Banner 1" className="d-block w-100" />
                <h3>MEN & WOMEN DRESSES</h3>
                <p>All Brands Are Available</p>
              </div>
            </div>
            {/* <!-- End Card Item --> */}
          </div>
        </div>
      </div>
      {/* <!-- End Card Item --> */}

      {/* <!-- Stats Start  --> */}

      <div id="stats-counter" className="stats-counter section">
        <div className="container section-title " data-aos="fade-up">
          <h2 >Company Info</h2>
          {/* <p style={{marginLeft:"365px"}}>Necessitatibus eius consequatur ex aliquid fuga eum quidem sint consectetur velit</p> */}
        </div>

        <div className="container123" data-aos="fade-up" data-aos-delay="100">
          <div className="row gy-4">
            <div className="col-lg-3 col-md-6">
              <div className="stats-item d-flex align-items-center w-100 h-100">
                <i className="bi bi-emoji-smile color-blue flex-shrink-0 sticon"></i>
                <div>
                  <span
                    data-purecounter-start="0"
                    data-purecounter-end="14322"
                    data-purecounter-duration="1"
                    className="purecounter"
                  ></span>
                  <p>Happy Clients</p>
                </div>
              </div>
            </div>

            <div className="col-lg-3 col-md-6">
              <div className="stats-item d-flex align-items-center w-100 h-100">
                <i className="bi bi-journal-richtext color-orange flex-shrink-0 sticon"></i>
                <div>
                  <span
                    data-purecounter-start="0"
                    data-purecounter-end="150"
                    data-purecounter-duration="1"
                    className="purecounter"
                  ></span>
                  <p>Projects</p>
                </div>
              </div>
            </div>

            <div className="col-lg-3 col-md-6">
              <div className="stats-item d-flex align-items-center w-100 h-100">
                <i className="bi bi-headset color-green flex-shrink-0 sticon"></i>
                <div>
                  <span
                    data-purecounter-start="0"
                    data-purecounter-end="24"
                    data-purecounter-duration="1"
                    className="purecounter"
                  ></span>
                  <p>Hours Of Support</p>
                </div>
              </div>
            </div>

            <div className="col-lg-3 col-md-6">
              <div className="stats-item d-flex align-items-center w-100 h-100">
                <i className="bi bi-people color-pink flex-shrink-0 sticon"></i>
                <div>
                  <span
                    data-purecounter-start="0"
                    data-purecounter-end="345"
                    data-purecounter-duration="1"
                    className="purecounter"
                  ></span>
                  <p>Hard Workers</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      
    </div>
  );
}

export default About;
