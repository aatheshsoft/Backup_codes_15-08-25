import React, { useState, useContext, useEffect } from 'react';
import { NavLink, useLocation } from "react-router-dom";
import { Link } from 'react-router-dom';
import 'bootstrap-icons/font/bootstrap-icons.css';
import { Badge, Offcanvas, NavDropdown } from 'react-bootstrap';
import { CiShoppingCart } from "react-icons/ci";
import { CgProfile } from "react-icons/cg";
import { CartContext } from '../Context/CartContext';
import logo from "../Assets/pravitha-logo.png";
import icon from "../Assets/Group 33.png";
import { useNavigate } from 'react-router-dom';
import Select from "react-select";


function CustomNav() {
  const UserID =  localStorage.getItem('userID');
  console.log(UserID)
  const UserName =  localStorage.getItem('username');
  console.log(UserName)
  const navigate = useNavigate();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { cartCount } = useContext(CartContext);
  const [searchQuery, setSearchQuery] = useState('');
  const [goldRate, setGoldRate] = useState('per gram');
  const [silverRate, setSilverRate] = useState('per gram');
  const [showOffcanvas, setShowOffcanvas] = useState(false);
  const [goldOpen, setGoldOpen] = useState(false);
  const [silverOpen, setSilverOpen] = useState(false);
  const location = useLocation();
  const [activeLink, setActiveLink] = useState("");

  const [categories, setCategories] = useState({ gold: [], silver: [], goldLabels: [],silverLabels: [] });
  const [selectedGoldRate, setSelectedGoldRate] = useState(categories.goldLabels[0]?.rate || 'per gram');
  const [selectedSilverRate, setSelectedSilverRate] = useState(categories.silverLabels[0]?.rate || 'per gram');
  const [selectedAddress, setSelectedAddress] = useState(null);
  // Update active link on route change
  const [dropdownOpen, setDropdownOpen] = useState(true);

  const [animate, setAnimate] = useState(false);
const [isGoldDropdownOpen, setIsGoldDropdownOpen] = useState(false);
const [isSilverDropdownOpen, setIsSilverDropdownOpen] = useState(false);

// Custom Styles for React-Select
const customStyles = {
  control: (base) => ({
    ...base,
    border: "none",
    outline: "none",
    backgroundColor: "#ffff",
    color: "black",
    opacity: "60%",
    padding: "4px",
    borderRadius: "4px",
    boxShadow: "none",
    cursor:"pointer"
  }),
  option: (base, state) => ({
    ...base,
    backgroundColor: state.isFocused ? "#f0f0f0" : "#fff",
    color: "black",
    cursor: "pointer",
  }),
  singleValue: (base) => ({
    ...base,
    color: "black",
  }),
  input: (provided) => ({
    ...provided,
    display: 'none', // Hide the input
  }),
};




  // Trigger the jump animation when the cartCount changes
  useEffect(() => {
    if (cartCount > 0) {
      setAnimate(true);
      const timer = setTimeout(() => {
        setAnimate(false); // Reset animation after it completes
      }, 3000); // Reset animation after 500ms (duration of jump)
      return () => clearTimeout(timer); // Clean up the timeout
    }
  }, [cartCount]);
  
  useEffect(() => {
    // Directly set active link to the current path on route change
    setActiveLink(location.pathname);
  }, [location.pathname]);

  // useEffect(() => {
  //   // Retrieve address from local storage
    // const address = JSON.parse(localStorage.getItem('selectedAddress'));
    // setSelectedAddress(address);
  // }, []);

const handleLogout = () => {
  // Remove the user ID from localStorage
  localStorage.removeItem('userID');
  const address = (localStorage.removeItem('selectedAddress'));
  setSelectedAddress(address);
  // Use the navigate hook to navigate to the login page
 
  navigate('/home');  // Redirect to login page
};


  useEffect(() => {
    if (categories.goldLabels && categories.goldLabels.length > 0) {
      setSelectedGoldRate(categories.goldLabels[0].rate);  // Set initial gold rate
    }
    if (categories.silverLabels && categories.silverLabels.length > 0) {
      setSelectedSilverRate(categories.silverLabels[0].rate);  // Set initial silver rate
    }
  }, [categories]);



  const toggleGoldDropdown = () => {
    setGoldOpen(!goldOpen);
  };

  // Handle Silver dropdown toggle
  const toggleSilverDropdown = () => {
    setSilverOpen(!silverOpen);
  };


  const handleGoldRateChange = (e) => {
    setGoldRate(e.target.value);
  };

  const handleSilverRateChange = (e) => {
    setSilverRate(e.target.value);
  };

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
  };

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    console.log('Searching for:', searchQuery);
  };

  const handleOffcanvasToggle = () => {
    setShowOffcanvas(!showOffcanvas);
  };

  useEffect(() => {
    const fetchCategories = async () => {
        try {
            const response = await fetch("https://pravithajewels.com/customerapp/header.php");
            const data = await response.json();

            // Merge the gold and silver categories from both sources
            setCategories({
                gold: data.body.gold || [], // Keeping this for other purposes
                silver: data.body.silver || [], // Keeping this for other purposes
                goldLabels: data.body.goldlabel || [], // Accessing gold labels from body
                    silverLabels: data.body.silverlabel || []  // New labels data for silver
            });

            // Debugging logs to check API response
            console.log("Gold Rates:", data.body.gold);
            console.log("Silver Rates:", data.body.silver);
            console.log("Gold Labels:", data.body.goldlabel);
            console.log("Silver Labels:", data.body.silverlabel);
        } catch (error) {
            console.error("Error fetching categories:", error);
        }
    };

    fetchCategories();
}, []);
  
  
/* header sticky when scrolling  */
  useEffect(() => {
    const header = document.querySelector('.sticky-top');

    if (!header) {
      console.log("Header with '.sticky-top' class not found.");
      return;
    }

    let lastScroll = 0;

    const handleScroll = () => {
      const currentScroll = window.pageYOffset;

      if (currentScroll > lastScroll) {
        header.classList.add('hide');
      } else {
        header.classList.remove('hide');
      }

      lastScroll = currentScroll;
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);



 return (


  
    <header id="header" className="header d-flex align-items-center sticky-top">
      <div className="container position-relative d-flex align-items-center justify-content-between">
        <Link className="logo d-flex align-items-center me-auto me-xl-0" to="/">
          <img src={logo} alt="Logo" className="d-block logo" />
        </Link>

        {/* Large Screen Navigation */}
        <nav id="navmenu" className={`navmenu ${isMenuOpen ? 'show' : ''} d-none d-xl-block`}>
          <ul>
<div style={{marginLeft:"400px"}}></div>
                  <div className="vertical-divider"></div>


                  <div className="rate-container">
      <div style={{ padding: "0px" }}>
        <div
          style={{ display: "flex", justifyContent: "space-between", width: "100%" }}
        >
          {/* Gold Dropdown */}
         {/*  <div
            style={{ width: "180px" }}
            onMouseEnter={() => setIsGoldDropdownOpen(true)}
            onMouseLeave={() => setIsGoldDropdownOpen(false)}
          >
            <Select
              options={categories.goldLabels.map((item) => ({
                value: item.rate,
                label: item.label,
              }))}
              styles={customStyles}
              onChange={(selectedOption) =>
                setSelectedGoldRate(selectedOption.value)
              }
              value={{
                value: selectedGoldRate,
                label:
                  categories.goldLabels.find(
                    (item) => item.rate === selectedGoldRate
                  )?.label || "",
              }}
              menuIsOpen={isGoldDropdownOpen} // Open/close based on hover state
              placeholder={null} // Ensure there's no placeholder
            />
            <div style={{ marginTop: "0px" }}>
              <span className="rate-display">₹ {selectedGoldRate}</span>
            </div>
          </div> */}

          {/* Silver Dropdown */}
          <div
            style={{ width: "110%" }}
            onMouseEnter={() => setIsSilverDropdownOpen(true)}
            onMouseLeave={() => setIsSilverDropdownOpen(false)}
          >
            <Select
              options={categories.silverLabels.map((item) => ({
                value: item.rate,
                label: item.label,
              }))}
              styles={customStyles}
              onChange={(selectedOption) =>
                setSelectedSilverRate(selectedOption.value)
              }
              value={{
                value: selectedSilverRate,
                label:
                  categories.silverLabels.find(
                    (item) => item.rate === selectedSilverRate
                  )?.label || "",
              }}
              menuIsOpen={isSilverDropdownOpen} // Open/close based on hover state
              placeholder={null} // Ensure there's no placeholder
            />
            <div style={{ marginTop: "0px" }}>
              <span className="rate-display">₹ {selectedSilverRate}</span>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div className="vertical-divider"></div>
    </ul>
        </nav>

        {/* Small Screen Toggle Button */}
        <i className="mobile-nav-toggle d-xl-none bi bi-list" onClick={handleOffcanvasToggle}></i>

        {/* Offcanvas for Small Screens */}
        <Offcanvas show={showOffcanvas} onHide={handleOffcanvasToggle} placement="start" style={{ width: '250px' }}>
  <Offcanvas.Header closeButton>
    <Offcanvas.Title>Menu</Offcanvas.Title>
  </Offcanvas.Header>
  <Offcanvas.Body>
    <ul style={{ listStyleType: 'none', padding: 0 }} className='offcanvas-menu'>
      {/* Home Link */}
      <li>
        <Link to="/Home" onClick={handleOffcanvasToggle}>Home</Link>
      </li>

      {/* Gold Dropdown */}
      {/* <li>
        <div onClick={toggleGoldDropdown} style={{ cursor: 'pointer' }} className="offcanvas-dropdown-container">
          Gold <span className='offcanvas-dropdown'>{goldOpen ? '-' : '+'}</span>
        </div>
        {goldOpen && (
          <ul style={{ listStyleType: 'none', paddingLeft: '20px' }}>
            {categories.gold.map((category) => (
              <li key={category.gold_id} style={{marginTop:"-20px"}}>
                <span >{category.gold_name}</span>
                <ul style={{ listStyleType: 'none', paddingLeft: '10px' }}>
                  {category.sub_gold.map((subCategory) => (
                    <li key={subCategory.sub_gold_id} style={{marginTop:"-25px"}}>
                      <Link 
                        to={`/shop/${category.main_category_id}/${subCategory.sub_gold_id}`} 
                        onClick={handleOffcanvasToggle}
                      >
                        {subCategory.sub_gold_name}
                      </Link>
                    </li>
                  ))}
                </ul>
              </li>
            ))}
          </ul>
        )}
      </li> */}

      {/* Silver Dropdown */}
      <li>
        <div onClick={toggleSilverDropdown} style={{ cursor: 'pointer' }} className="offcanvas-dropdown-container">
          Silver <span className='offcanvas-dropdown'>{silverOpen ? '-' : '+'}</span>
        </div>
        {silverOpen && (
          <ul style={{ listStyleType: 'none', paddingLeft: '20px' }}>
            {categories.silver.map((category) => (
              <li key={category.silver_id} style={{marginTop:"-20px"}}>
                <span>{category.silver_name}</span>
                <ul style={{ listStyleType: 'none', paddingLeft: '10px' }}>
                  {category.sub_silver.map((subCategory) => (
                    <li key={subCategory.sub_silver_id} style={{marginTop:"-25px"}}>
                      <Link 
                        to={`/shop/${category.main_category_id}/${subCategory.sub_silver_id}`} 
                        onClick={handleOffcanvasToggle}
                      >
                        {subCategory.sub_silver_name}
                      </Link>
                    </li>
                  ))}
                </ul>
              </li>
            ))}
          </ul>
        )}
      </li>

      {/* Why Us Link */}
      <li>
        <Link to="/whychoose" onClick={handleOffcanvasToggle}>Why us</Link>
      </li>
    </ul>
  </Offcanvas.Body>
</Offcanvas>


        {/* Cart and Profile Icons */}  
        <div className='iconalign d-flex align-items-center'>
          {/* <Link to="/cart" className="cart-icon ms-3 position-relative">
          <i class="bi bi-cart2 " style={{ color: "grey", fontSize: "36px" }}></i>
          <Badge
      bg="danger"
      className={`position-absolute top-0 start-100 translate-middle badge12 ${animate ? "jump-rotate" : ""}`}
    >
      <span style={{ margin: "-5px" }}>{cartCount}</span>
    </Badge>
          </Link> */}

          
          <NavDropdown title={<CgProfile  className='profile-icon' style={{ color: "grey", width: "65px", height: "34px",marginLeft:"15px",marginRight:"-30px" }} />} id="collapsible-nav-dropdown">
            
           

            {UserID ? (
              <>
              <NavDropdown.Item style={{pointerEvents: "none"}} ><b>{UserName}</b></NavDropdown.Item>
              <NavDropdown.Divider />
            <Link to = '/myaccount'>
              <NavDropdown.Item href="#action/3.1">My Account</NavDropdown.Item>
            </Link>
            <NavDropdown.Divider />
              <NavDropdown.Item href="#action/3.4" onClick={handleLogout}>
  Sign Out <i className="bi bi-box-arrow-right logout"></i>
  </NavDropdown.Item>
            
 
            </>
            ):(
<>
<Link to = '/signin'>
<NavDropdown.Item href="#action/3.4">
Sign In 
  </NavDropdown.Item>
  </Link>
  <NavDropdown.Divider />
<Link to = '/signup'>
<NavDropdown.Item href="#action/3.4">
Sign Up 
  </NavDropdown.Item>
  </Link>

  </>
            )}
            </NavDropdown>
        </div>
      </div>
    </header>
  );
}

export default CustomNav;
