import React, { useState, useEffect, useContext } from "react";
import Logo from "../Assets/figma1.png";
import { Container, Row, Col, Button, Form, Modal } from "react-bootstrap";
import { FaEdit, FaTrash } from "react-icons/fa"; // Import icons
import { Link } from "react-router-dom";
import { CartContext } from "../Context/CartContext";
import axios from "axios";
import Spinner from "react-bootstrap/Spinner";
import { useNavigate, useLocation } from "react-router-dom";
import CheckoutHeader from "./CheckoutHeader";
import PuffLoader from "react-spinners/PuffLoader";

const CheckoutPage = () => {
  const { clearCart } = useContext(CartContext);
  const navigate = useNavigate();
  const userID = localStorage.getItem("userID");
  const Email = localStorage.getItem("Email");
  const { cartItems, setCartItems } = useContext(CartContext);
  const [quantity, setQuantity] = useState(1);
  const [useSameAddress, setUseSameAddress] = useState(false);
  const [selectedBillingAddress, setSelectedBillingAddress] = useState(null);
  const [selectedShippingAddress, setSelectedShippingAddress] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [isDisabled, setIsDisabled] = useState(false);

  const [buyNowItem, setBuyNowItem] = useState(null);
  const [product, setProduct] = useState(null);
  const [totalAmount, setTotalAmount] = useState(0);
  const [selectedAddress, setSelectedAddress] = useState(null);
  const [useThisAddress, setUseThisAddress] = useState(false);
  const [loading, setLoading] = useState(true);
  const [gst, setGst] = useState(0);
  const [shipping, setShipping] = useState(0);
  const [cgstPer, setCgstPer] = useState(0); // gst percent, can be fetched from the API
  const [sgstPer, setSgstPer] = useState(0); // gst percent, can be fetched from the API
  const [deliveryCharges, setDeliveryCharges] = useState([]);
  const [itemsToDisplay, setItemsToDisplay] = useState([]);
  const [buyNowProduct, setBuyNowProduct] = useState(null);
  const [addresses, setAddresses] = useState(null);
  const [error, setError] = useState(null);
  const isEmptyAddress1 = !selectedAddress && (!addresses || addresses.length === 0);
  const location = useLocation();
  const [success, setSuccess] = useState(false);
  const [paymentid,setPaymentId]= useState("");
  const [orderid,setOrderId]= useState("");
  const [signature,setSignature]= useState("");




  useEffect(() => {
    // Simulate data fetching or delay for loader
    const timer = setTimeout(() => {
      setLoading(false); // Stop loading after 2 seconds
    }, 2000);

    return () => clearTimeout(timer); // Cleanup timeout
  }, []);






  const [formData, setFormData] = useState({
    name: "",
    phonenumber: "",
    address: "",
    city: "",
    state: "",
    pincode: "",
    label: "",
    landmark: "",
  });
  const [addFormData, setAddFormData] = useState({
    name: "",
    phonenumber: "",
    address: "",
    city: "",
    state: "",
    pincode: "",
    label: "",
    landmark: "",
  });

  useEffect(() => {
    const fetchAddresses = async () => {
      try {
        const response = await axios.post(
          "https://pravithajewels.com/customerapp/first_addresslist.php",
          { user_id: userID }
        );

        if (response.data.head.code === 200) {
          setAddresses(response.data.body);
          console.log(response.data.body);
        } else {
          setError("Failed to fetch addresses");
        }
      } catch (err) {
        setError("An error occurred while fetching data");
      }
    };

    fetchAddresses();
  }, []);

  useEffect(() => {
    // Fetch GST and shipping details from the API
    axios
      .get("https://pravithajewels.com/customerapp/gst.php")
      .then((response) => {
        const { sgstper, cgstper, delivery_charges } = response.data.body;

        setCgstPer(cgstper);
        setSgstPer(sgstper);
        setDeliveryCharges(delivery_charges);
      })
      .catch((error) =>
        console.error("Error fetching GST and shipping info", error)
      );
  }, []);

  // Calculate CGST and SGST based on the given price
  const calculateCgstSgst = (price) => ({
    CgstAmount: (price * cgstPer) / 100,
    SgstAmount: (price * sgstPer) / 100,
  });

  // Calculate Initial Total (either from Buy Now product or cart items)
  const calculateInitialTotal = () => {
    if (product) {
      return parseFloat(product.price);
    } else {
      return cartItems.reduce(
        (total, item) => total + parseFloat(item.price) * (item.quantity || 1),
        0
      );
    }
  };

  // Calculate Shipping based on Adjusted Total (Initial Total + CGST + SGST)
  const calculateShippingCharge = (adjustedTotal) => {
    let shippingCharge = 0;
    for (let charge of deliveryCharges) {
      if (
        adjustedTotal >= parseFloat(charge.start_amt) &&
        adjustedTotal <= parseFloat(charge.end_amt)
      ) {
        shippingCharge = parseFloat(charge.charge);
        break;
      }
    }
    return shippingCharge;
  };

  // Calculate and Set Final Total Amount
  useEffect(() => {
    const initialTotal = calculateInitialTotal();
    const { CgstAmount, SgstAmount } = calculateCgstSgst(initialTotal);
    const adjustedTotal = initialTotal + CgstAmount + SgstAmount; // Initial Total + CGST + SGST

    const calculatedShipping = calculateShippingCharge(adjustedTotal);
    setShipping(calculatedShipping);

    const finalTotal = adjustedTotal + calculatedShipping; // Adjusted Total + Shipping
    setTotalAmount(finalTotal);
  }, [product, cartItems, cgstPer, sgstPer, deliveryCharges]);

  // useEffect(() => {
  //   // Retrieve Buy Now product if it exists
  //   const buyNowProduct = sessionStorage.getItem('buyNowProduct');
  //   console.log(sessionStorage.getItem('buyNowProduct'));
  //   if (buyNowProduct) {
  //     setProduct(JSON.parse(buyNowProduct));
  //     sessionStorage.removeItem('buyNowProduct');
  //   }
  // }, []);

  useEffect(() => {
    // Retrieve the selected address from local storage on component mount
    const storedAddress = localStorage.getItem("selectedAddress");
    if (storedAddress) {
      setSelectedAddress(JSON.parse(storedAddress));
    } else if (addresses && addresses.length > 0) {
      // Default to addresses[0] if no selected address exists
      setSelectedAddress(addresses[0]);
    }
  }, [addresses]);
  useEffect(() => {
    // Fetch Buy Now product from sessionStorage
    const savedBuyNowProduct = sessionStorage.getItem('buyNowProduct');
    const parsedBuyNowProduct = savedBuyNowProduct
      ? JSON.parse(savedBuyNowProduct)
      : null;

    // Get Buy Now product from location.state or sessionStorage
    const buyNow = location.state?.buyNowProduct || parsedBuyNowProduct;

    if (buyNow) {
      setBuyNowProduct(buyNow);
      setItemsToDisplay([buyNow]); // Display only the Buy Now product
    } else {
      // Fallback to cart items if no Buy Now product
      const cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
      setItemsToDisplay(cartItems);
    }
  }, [location.state]);

  localStorage.setItem("itemsToDisplay", itemsToDisplay);

  // Effect to handle product and user ID
  useEffect(() => {
    const userID = localStorage.getItem("userID");
    if (!userID) {
      // Redirect to login if not logged in
      navigate("/signin", { state: { redirectTo: location.pathname } });
    } else {
      // Try to retrieve the "Buy Now" product from sessionStorage
      let buyNowProduct = sessionStorage.getItem("buyNowProduct");
      console.log(
        "Retrieved buyNowProduct from sessionStorage:",
        buyNowProduct
      );

      if (buyNowProduct) {
        setProduct(JSON.parse(buyNowProduct)); // Set the product state
      } else {
        console.log("No buyNowProduct found.");
      }
    }



    // Clear the "Buy Now" product when navigating away
    return () => {
      setProduct(null);
    };
  }, [location, navigate]);

  // useEffect(() => {
  //   const buyNowProduct = sessionStorage.getItem("buyNowProduct");

  //   // Clear product when cart items are added and "Buy Now" product is empty
  //   if (cartItems.length > 0 && !buyNowProduct) {
  //     console.log("comes to if line 203");
  //     setProduct(null); // Clear the "Buy Now" product when there are cart items and no "Buy Now" product
  //   } else {
  //     console.log("comes to else line 205");
  //   }
  // }, [cartItems]);
  console.log(cartItems);

  const [modalType, setModalType] = useState({
    action: "add",
    type: "billing",
  });

  const [addressForm, setAddressForm] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phoneNumber: "",
    address: "",
    city: "",
    state: "",
    landmark: "",
    pincode: "",
  });

  // const handleAddBillingAddress = () => {
  //   setModalType({ action: "add", type: "billing" });
  //   setShowModal(true);
  // };

  // const handleAddShippingAddress = () => {
  //   setModalType({ action: "add", type: "shipping" });
  //   setShowModal(true);
  // };

  // const handleEditBillingAddress = () => {
  //   setModalType({ action: "edit", type: "billing" });
  //   setShowModal(true);
  // };
  const handleEditShippingAddress = () => {
    console.log("Selected Address:", selectedAddress);  // Log the selected address
    console.log("All Addresses:", addresses[0].name);  // Log all available addresses
  
    // Proceed with setting formData
    setModalType({ action: "edit", type: "shipping" });
  
    setFormData({
      name: selectedAddress?.name || addresses[0]?.name || "kjijbi",
      phonenumber: selectedAddress?.phonenumber || addresses[0]?.phonenumber || "",
      address: selectedAddress?.address || addresses[0]?.address || "",
      city: selectedAddress?.city || addresses[0]?.city || "",
      state: selectedAddress?.state || addresses[0]?.state || "",
      pincode: selectedAddress?.pincode || addresses[0]?.pincode || "",
      landmark: selectedAddress?.landmark || addresses[0]?.landmark || "",
      label: selectedAddress?.label || addresses[0]?.label || "",
    });
  
    setShowModal(true);
  };
  
  
  // const handleAddressCheckbox = () => {
  //   setUseSameAddress(!useSameAddress);
  // };

  // const handleSelectBillingAddress = (address) => {
  //   setSelectedBillingAddress(address);
  // };

  // const handleSelectShippingAddress = (address) => {
  //   setSelectedShippingAddress(address);
  // };

  const handleShowAddModal = () => {
    setAddFormData({
      name: "",
      phonenumber: "",
      address: "",
      city: "",
      state: "",
      pincode: "",
      label: "",
      landmark: "",
    });
    setShowAddModal(true);
  };
  const handleCloseAddModal = () => setShowAddModal(false);
  const handleAddInputChange = (e) => {
    const { name, value } = e.target;
    setAddFormData({ ...addFormData, [name]: value });
  };
  const handleAddSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(
        "https://pravithajewels.com/customerapp/addresslistadd.php",
        {
          user_id: userID,
          ...addFormData,
        }
      );
      if (response.data.head.code === 200) {
        setAddresses([...addresses, response.data.body]); // Add new address to the list
        setShowAddModal(false);
        // alert("Address added successfully!");
        window.location.reload();
      } else {
        alert("Failed to add address");
      }
    } catch (error) {
      console.error("Error adding address:", error);
    }
  };

  const handleShowModal = () => setShowModal(true);
  const handleCloseModal = () => setShowModal(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setAddressForm({ ...addressForm, [name]: value });
  };
  
  const handleSubmit = async (e) => {
    console.log("asfcaefge")
    e.preventDefault();

    // Validate that address_id is available
  
    if ((!selectedAddress || !selectedAddress.address_id) && (!addresses || !addresses[0].address_id)) {
      alert("Address ID not found. Please select an address before editing.");
      return;
    }

    // Basic validation for form fields
    if (!formData.name || !formData.phonenumber || !formData.address) {
      alert("Please fill in all required fields");
      return;
    }
 
    try {
      
      const payload = {
        user_id: userID,
        address_id: selectedAddress?.address_id || (addresses && addresses[0]?.address_id), // Use selectedAddress.address_id if available, otherwise fall back to addresses[0].address_id
        ...formData,  // Include the rest of the form data
      };
      
      console.log("Payload:", payload);

      const response = await axios.post(
        "https://pravithajewels.com/customerapp/addresslistupdate.php",
        payload
      );

      if (response.data.head && response.data.head.code === 200) {
        // alert("Address edited successfully!");
       
        setSelectedAddress(payload);
        localStorage.setItem("selectedAddress", JSON.stringify(payload));
        setAddresses(payload); // Update the displayed address
        setShowModal(false); // Close modal
        window.location.reload();
      } else {
        alert("Error updating address");
      }
    } catch (error) {
      console.error("Error updating address:", error);
      alert("Failed to update address. Please try again later.");
    }
  };

  // Handle input change in form
  const handleInputChange = (e) => {
    const { name, value } = e.target;
  
    // Dynamic validation
    if (name === "name" && !/^[a-zA-Z\s]*$/.test(value)) {
      return; // Prevent non-letter and non-space characters
    }
  
    if (name === "phonenumber" && (!/^\d*$/.test(value) || value.length > 10)) {
      return; // Prevent non-numeric characters and limit length to 10
    }
  
    if (name === "pincode" && (!/^\d*$/.test(value) || value.length > 6)) {
      return; // Prevent non-numeric characters and limit length to 6
    }
  
    setFormData((prevData) => ({ ...prevData, [name]: value }));
  };
  
  

  const handleOfflineOrder = async (mode) => {
    if (!useThisAddress) {
      alert("Please Tick the use this Address")
      return;
    }
    if  (selectedAddress && !isEmptyAddress(selectedAddress) || addresses &&
      addresses.length > 0 &&
      !isEmptyAddress(addresses[0]) && useThisAddress) {
      console.log("line378")
      setLoading(true);
      // Dynamically extract product details from the items in the cart


      const isFromCart = !product; // If no single product is set, the order is from the cart
      const itemsToDisplay = isFromCart ? cartItems : [product];


      const productDetails = itemsToDisplay.map((item) => ({
        main_category_id: item.main_category_id, // Replace with actual value
        sub_category_id: item.sub_category_id, // Replace with actual value
        product_id: item.product_id,
        product_code:item.product_code || item.code,
        image: item.image[0].length < 2 ? item.image : item.image[0],
        product_name: item.product_name || item.name,
        qty: item.quantity,
        weight:item.product_weight || item.weight,
        purity:item.product_purity || item.purity, // Default to 1 if no quantity is set
        amount: item.singleprice || item.price, // Default to 0 if no price is set
        totalamount: (item.singleprice || item.price) * item.quantity || "0", // Calculate total amount
      }));
      
      console.log(productDetails);

      const orderData = {
        user_id: userID, // Replace with the actual user ID
        billing_details: {
          billing_name: selectedAddress ?.name || addresses[0]?.name,
          billing_address: selectedAddress?.address || addresses[0]?.address,
          billing_city: selectedAddress?.city || addresses[0]?.city,
          billing_state: selectedAddress?.state || addresses[0]?.state,
          billing_email: Email || addresses[0]?.email, // Replace with actual email
          billing_phonenumber: selectedAddress?.phonenumber || addresses[0]?.phonenumber,
          billing_postcode: selectedAddress?.pincode || addresses[0]?.pincode,
          billing_landmark: selectedAddress?.landmark || addresses[0]?.landmark,
        },
        delivery_details: {
          delivery_name: selectedAddress?.name || addresses[0]?.name,
          delivery_address: selectedAddress?.address || addresses[0]?.address,
          delivery_city: selectedAddress?.city || addresses[0]?.city,
          delivery_state: selectedAddress?.state || addresses[0]?.state,
          delivery_email: Email || addresses[0]?.email, // Replace with actual email
          delivery_phonenumber: selectedAddress?.phonenumber || addresses[0]?.phonenumber,
          delivery_postcode: selectedAddress?.pincode || addresses[0]?.pincode,
          delivery_landmark: selectedAddress?.landmark || addresses[0]?.landmark,
        },
        subtotal: calculateInitialTotal().toFixed(2),
        sgst: calculateCgstSgst(calculateInitialTotal()).SgstAmount.toFixed(2), // Adjust SGST dynamically if needed
        cgst: calculateCgstSgst(calculateInitialTotal()).CgstAmount.toFixed(2), // Adjust CGST dynamically if needed
        shipping: shipping.toFixed(2),
        total: totalAmount.toFixed(2),
        paymentmode: mode, // Use the dynamic totalAmount
        productdetails: productDetails,
      };

      console.log("orderdata" + JSON.stringify(orderData));
      try {
        const response = await axios.post(
          "https://pravithajewels.com/customerapp/order.php",
          orderData
        );
        if (response.data) {
          console.log("Order placed successfully:", response.data);
          
          // Handle successful order placement (e.g., show a confirmation or redirect)
          // Store the entire API response in local storage
          localStorage.setItem("orderData", JSON.stringify(response.data));

          // Retrieve and print the order data from local storage
          const storedOrderData = JSON.parse(localStorage.getItem("orderData"));
          console.log("Stored Order Data:", storedOrderData);
          // localStorage.removeItem("cartItems"); 
          // clearCart();
          if (isFromCart) {
            clearCart();
          }
          setLoading(false); // Ensure loader stops after the request
        }
      } catch (error) {
        console.error("Error placing the order:", error);
        // Handle error (e.g., show an error message)
      } finally {
        navigate("/orderhistory");
       
      }
    } else {
      console.log("Please select an address before placing the order.");
    }
  };

  const handleOnlineOrder = async (mode) => {
    if (!useThisAddress) {
      alert("Please Tick the use this Address");
      return;
    }
  
    setLoading(true);
    const isFromCart = !product;
    const itemsToDisplay = isFromCart ? cartItems : [product];
  
    const productDetails = itemsToDisplay.map((item) => ({
      main_category_id: item.main_category_id,
      sub_category_id: item.sub_category_id,
      product_id: item.product_id,
      product_code: item.product_code || item.code,
      image: item.image[0].length < 2 ? item.image : item.image[0],
      product_name: item.product_name || item.name,
      qty: item.quantity,
      weight: item.product_weight || item.weight,
      purity: item.product_purity || item.purity,
      amount: item.singleprice || item.price,
      totalamount: (item.singleprice || item.price) * item.quantity || "0",
    }));
  
    const orderData = {
      user_id: userID,
      billing_details: {
        billing_name: selectedAddress?.name || addresses[0]?.name,
        billing_address: selectedAddress?.address || addresses[0]?.address,
        billing_city: selectedAddress?.city || addresses[0]?.city,
        billing_state: selectedAddress?.state || addresses[0]?.state,
        billing_email: Email || addresses[0]?.email, 
        billing_phonenumber: selectedAddress?.phonenumber || addresses[0]?.phonenumber,
        billing_postcode: selectedAddress?.pincode || addresses[0]?.pincode,
        billing_landmark: selectedAddress?.landmark || addresses[0]?.landmark,
      },
      delivery_details: {
        delivery_name: selectedAddress?.name || addresses[0]?.name,
        delivery_address: selectedAddress?.address || addresses[0]?.address,
        delivery_city: selectedAddress?.city || addresses[0]?.city,
        delivery_state: selectedAddress?.state || addresses[0]?.state,
        delivery_email: Email || addresses[0]?.email, 
        delivery_phonenumber: selectedAddress?.phonenumber || addresses[0]?.phonenumber,
        delivery_postcode: selectedAddress?.pincode || addresses[0]?.pincode,
        delivery_landmark: selectedAddress?.landmark || addresses[0]?.landmark,
      },
      subtotal: calculateInitialTotal().toFixed(2),
      sgst: calculateCgstSgst(calculateInitialTotal()).SgstAmount.toFixed(2),
      cgst: calculateCgstSgst(calculateInitialTotal()).CgstAmount.toFixed(2),
      shipping: shipping.toFixed(2),
      total: totalAmount.toFixed(2),
      paymentmode: mode,
      // razorpay_payment_id: "",
      // razorpay_order_id: "",
      // razorpay_signature: "",
      // payment_status: false,
      productdetails: productDetails,
    };
  
    try {
      // Step 1: Create Order
      const createOrderResponse = await axios.post(
        "https://pravithajewels.com/customerapp/create_order.php",
        {
          /* amount: Math.round(totalAmount * 100), */
          amount: (totalAmount * 100),
          currency: "INR",
        }
      );
      console.log("Create Order Response:", createOrderResponse.data);
      const { id: order_id } = createOrderResponse.data;
      if (!order_id) {
        throw new Error("Failed to create order.");
      }
  
      if (mode === "razorpay") {
        // Step 2: Razorpay Options
        const options = {
          key: "rzp_live_x9HucibFE7Kcwz", // Replace with your Razorpay test key
          // amount: Math.round(totalAmount * 100),
          amount: (totalAmount * 100),
          currency: "INR",
          name: "Pravitha Jewels",
          description: "Order Payment",
          image: "https://example.com/your-logo.png",
          order_id, // Generated order_id
          handler: async (response) => {
            console.log("Payment Response:", response);
  
            // Step 3: Verify Payment
            const verifyResponse = await axios.post(
              "https://pravithajewels.com/customerapp/verify_payment.php",
              {
                razorpay_order_id: response.razorpay_order_id,
                razorpay_payment_id: response.razorpay_payment_id,
                razorpay_signature: response.razorpay_signature,
              }
            );
  
            setPaymentId(verifyResponse.data.razorpay_payment_id)
            setOrderId(verifyResponse.data.razorpay_order_id)
            setSuccess(verifyResponse.data.success)
            setSignature(verifyResponse.data.razorpay_signature)
  
            console.log(verifyResponse.data?.status)
            if (!verifyResponse.data?.status) {
              alert("Payment verification failed.");
              throw new Error("Payment verification failed.");
            }
            setLoading(true)
            // Step 4: Finalize Order
            if (verifyResponse.data.success) {
             
              console.log("Finalizing Order with:", orderData);
              orderData.razorpay_order_id = response.razorpay_order_id;
              orderData.razorpay_payment_id = response.razorpay_payment_id;
              orderData.razorpay_signature = response.razorpay_signature;

              orderData.payment_status = verifyResponse.data.success ? "Success" : "Failed";

  
              const finalizeOrderResponse = await axios.post(
                "https://pravithajewels.com/customerapp/order.php",
                orderData
              );
  
              if (finalizeOrderResponse.data) {
                console.log("Order placed successfully:", finalizeOrderResponse.data);
                localStorage.setItem("orderData", JSON.stringify(finalizeOrderResponse.data));
                if (!product) clearCart();
  
                navigate("/orderhistory");
              }
            } else {
              alert("Order process failed");
            }
          },
          prefill: {
            name: selectedAddress?.name || addresses[0]?.name,
            email: Email || addresses[0]?.email,
            contact: selectedAddress?.phonenumber || addresses[0]?.phonenumber,
          },
          theme: { color: "#F37254" },
          method: 'UPI',
          modal: {
            ondismiss: function () {
              alert("Payment process cancelled by the user.");
              setLoading(false);
            },
          },
        };
  
        const razorpay = new window.Razorpay(options);
        razorpay.open();
      } else {
        // // Handle COD or other payment modes here
        // const response = await axios.post(
        //   "https://pravithajewels.com/customerapp/order.php",
        //   orderData
        // );
  
        // if (response.data) {
        //   console.log("Order placed successfully:", response.data);
        //   localStorage.setItem("orderData", JSON.stringify(response.data));
        //   if (!product) clearCart();
        //   navigate("/orderhistory");
        // }
      }
    } catch (error) {
      console.error("Error during the order process:", error.message);
      alert(error.message || "Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  };
  

  const handleCheckboxChange = () => {
    setUseThisAddress(!useThisAddress);
    console.log(useThisAddress);
  };

  const isEmptyAddress = (address) => {
    // Check if all address fields are empty or null
    return (
      !address ||
      (!address.name &&
        !address.address &&
        !address.phonenumber &&
        !address.landmark &&
        !address.city &&
        !address.state &&
        !address.pincode)
    );
  };

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <>
     {loading ? (
        <div
        style={{
          display: "flex",
          flexDirection: "column", // Align items vertically
          justifyContent: "center",
          alignItems: "center",
          height: "100vh",
        }}
      >
        <PuffLoader color="#D0C743" size={100} />
        <p style={{ marginTop: "20px", fontSize: "18px", color: "#D0C743" }}>
          Please Wait...
        </p>
      </div>
      
      ) : (
        <>
      <CheckoutHeader />
      <div className="mainpage">
        {userID ? (
          <>
            <Container className="cart-page mt-5">
              <Row>
                {/* Left Section: Product Image & Details */}
                <Col lg={8} xs={12}>
                  {itemsToDisplay.length > 0 ? (
                    itemsToDisplay.map((item) => (
                      <Row
                        key={item.product_id}
                        className="align-items-center product-details"
                      >
                        <Col xs={4} md={4} className="mb-3 mb-md-0 cart-detail-card">
                          <img
                            src={
                              Array.isArray(item.image)
                                ? item.image[0]
                                : item.image || "defaultImage.jpg"
                            }
                            alt={
                              item.product_name ||
                              item.name ||
                              "Unnamed Product"
                            }
                            className="img-fluid12"
                            style={{ borderRadius: "5px" }}
                          />
                        </Col>
                        <Col xs={8} md={8} className="cart-name-align">
                          <p className="proname">
                            {item.product_name ||
                              item.name ||
                              "Unnamed Product"}
                          </p>
                          <p
                            className="checkout-procode cart12"
                            style={{ color: "darkgrey" }}
                          >
                            Product Code:{" "}
                            <span style={{ color: "black" }}>
                              {item.product_code || item.code || "N/A"}
                            </span>
                          </p>
                          <p className="weight">
                            Weight:<span>{item.product_weight || item.weight || "N/A"}</span>
                            &nbsp;-&nbsp;Purity: <span>{item.purity}</span>
                          </p>
                          <nobr>
                            <div className="d-flex align-items-center price-quantity-button">
                            <p className="checkout-price">
                                      <i className="bi bi-currency-rupee"></i>
                                      {item.singleprice && !isNaN(item.singleprice)
                                        ? new Intl.NumberFormat("en-IN").format(item.singleprice)
                                        : item.price && !isNaN(item.price)
                                        ? new Intl.NumberFormat("en-IN").format(item.price)
                                        : "0.00"}
                                    </p>


                              &nbsp; &nbsp;
                              <div
                                className="d-flex align-items-center"
                                style={{ marginTop: "-8px" }}
                              >
                                <p className="mb-0  checkout-qty-text">
                                  Qty :
                                </p>
                                <p style={{ marginTop: "7px" }}>
                                  {item.quantity}
                                </p>
                              </div>
                            </div>
                          </nobr>
                        </Col>
                      </Row>
                    ))
                  ) : (
                    <p>Your cart is empty.</p>
                  )}
                </Col>

                {/* Right Section: Order Summary */}
                <Col lg={4} xs={12} className="order-summary">
                  <div
                    className="summary-box p-3"
                    style={{ border: "1px solid #ccc", borderRadius: "8px" }}
                  >
                    <h5 className="mb-3 checkout-ordersummary-head">
                      Order Summary
                    </h5>

                    <div className="d-flex justify-content-between checkout-ordersummary-totaltext">
                      <span>Cart Total:</span>
                      <span><i className="bi bi-currency-rupee "  style={{fontSize:"16px"}}></i>{new Intl.NumberFormat("en-IN").format(calculateInitialTotal())}
                      </span>
                    </div>

                    <div className="d-flex justify-content-between checkout-ordersummary-totaltext">
                      <span>CGST ({cgstPer}%):</span>
                      <span>
                      <i className="bi bi-currency-rupee" style={{fontSize:"16px"}}></i>
                        {new Intl.NumberFormat("en-IN").format(calculateCgstSgst(calculateInitialTotal()).CgstAmount)}
                      </span>
                    </div>

                    <div className="d-flex justify-content-between checkout-ordersummary-totaltext">
                      <span>SGST ({sgstPer}%):</span>
                      <span>
                      <i className="bi bi-currency-rupee" style={{fontSize:"16px"}}></i>
                        {new Intl.NumberFormat("en-IN").format(calculateCgstSgst(
                          calculateInitialTotal()
                        ).SgstAmount)}
                      </span>
                    </div>

                    <div className="d-flex justify-content-between checkout-ordersummary-totaltext">
                      <span>Shipping:</span>
                      <span><i className="bi bi-currency-rupee" style={{fontSize:"16px"}}></i>{new Intl.NumberFormat("en-IN").format(shipping)}</span>
                    </div>

                    <hr />

                    <div className="d-flex justify-content-between mt-3 checkout-ordersummary-totaltext-bold">
                      <strong>Order Total:</strong>
                      <strong><i className="bi bi-currency-rupee" style={{fontSize:"16px"}}></i>{new Intl.NumberFormat("en-IN").format(totalAmount)}</strong>
                    </div>
                  </div>
                </Col>
              </Row>

              {/* Shipping Address Section */}
              <Row className="mt-4">
                <Col md={12}>
                  <h5 className="shipping-text">Shipping Address</h5>
                  <div style={{ border: "1px solid #ccc" }}>
                    {selectedAddress && !isEmptyAddress(selectedAddress) ? (
                      // Display selected address if it has valid data
                      <div className="address-section ">
                        <p className="checkout-address ">
                          {selectedAddress.name}, <br />
                          {selectedAddress.address}, <br />
                          {selectedAddress.phonenumber}, <br />
                          {selectedAddress.landmark}, <br />
                          {/* {selectedAddress.label}, <br /> */}
                          {selectedAddress.city}, 
                          {selectedAddress.state},{" "}
                          {selectedAddress.pincode}
                        </p>
                      </div>
                    ) : addresses &&
                      addresses.length > 0 &&
                      !isEmptyAddress(addresses[0]) ? (
                      // Display list of addresses if no selected address and addresses are valid
                      addresses.map((address) => (
                        <div
                          key={address.address_id}
                          className="address-section mb-3"
                        >
                          <p className="checkout-address">
                            {address.name}, <br />
                            {address.address}, <br />
                            {address.phonenumber}, <br />
                            {address.landmark}, <br />
                            {address.label}, <br />
                            {address.city}, {address.state}, {address.pincode}
                          </p>
                        </div>
                      ))
                    ) : (
                      // Display "Not found" if both selectedAddress and addresses are empty or null
                      <p>Address not found.</p>
                    )}
                      {selectedAddress && !isEmptyAddress(selectedAddress) || addresses &&
                      addresses.length > 0 &&
                      !isEmptyAddress(addresses[0]) ? (
                        <>
                    <input
                      type="checkbox"
                      id="useThisAddress"
                      checked={useThisAddress}
                      onChange={handleCheckboxChange}
                      className="me-2 checkout-checkbox"
                    />
                    <label
                      htmlFor="useThisAddress"
                      className="me-2 checkout-checkbox-text"
                    >
                      Use this address
                    </label>
                    </>
                      ) : ("")}

                    {selectedAddress && !isEmptyAddress(selectedAddress) || addresses &&
                      addresses.length > 0 &&
                      !isEmptyAddress(addresses[0]) ? (
                        <button
                          className="checkout-edit-btn"
                          onClick={handleEditShippingAddress}
                          style={{
                            background: "transparent",
                            color: "blue",
                            borderRadius: "5px",
                            padding: "4px 8px",
                          }}
                        >
                          Edit the address
                        </button>
                      ): (
                          <button
                            className="checkout-edit-btn"
                            onClick={handleShowAddModal}
                            style={{
                              background: "transparent",
                              color: "blue",
                              borderRadius: "5px",
                              padding: "4px 8px",
                            }}
                          >
                            Add address
                          </button>
                        )}
                  </div>
                </Col>
              </Row>

              <Row>
                <Col md={6}>
                  <div className="checkout-actions">
                    <div className="checkout-pay-button">
                    <button
      className="payment-button"
      disabled={isDisabled}
      style={{ cursor: isDisabled ? "not-allowed" : "pointer" }}
      onClick={() => handleOnlineOrder("razorpay")}
    >
      Proceed to Payment
    </button>

                    </div>
                    <div>
                      <button
                        className="offline-order-button" //offline-order-button
                        onClick={() => handleOfflineOrder("offline")} // Wrap in an anonymous function
                      >
                        {loading ? (
                          <Spinner animation="border" size="md" />
                        ) : (
                          <span className="offline-button-content">
                            Offline Order
                          </span>
                        )}
                      </button>
                    </div>
                  </div>
                </Col>
              </Row>
            </Container>

            <Modal show={showAddModal} onHide={handleCloseAddModal}>
              <Modal.Header closeButton>Add Address</Modal.Header>
              <Modal.Body>
                <form onSubmit={handleAddSubmit} className="address-form">
                  {[
                    "name",
                    "phonenumber",
                    "address",
                    "city",
                    "state",
                    "pincode",
                    // "label",
                    "landmark",
                  ].map((field) => (
                    <div className="form-group" key={field}>
                      <label htmlFor={field}>
                      {field === "phonenumber" ? ("Phone Number" ):(
                        field.charAt(0).toUpperCase() + field.slice(1))}
                      </label>
                      <input
                        type={field === "phonenumber" ? "tel" : "text"}
                        id={field}
                        name={field}
                        value={addFormData[field]}
                        onChange={handleAddInputChange}
                        className="input-field"
                        required
                      />
                    </div>
                  ))}
                  <button type="submit" className="submit-button">
                    Submit
                  </button>
                </form>
              </Modal.Body>
            </Modal>

            {/* Address Modal */}
            <Modal show={showModal} onHide={handleCloseModal}>
  <Modal.Header closeButton>
    {modalType.action === "add"
      ? `Add ${
          modalType.type.charAt(0).toUpperCase() + modalType.type.slice(1)
        } Address`
      : `Edit ${
          modalType.type.charAt(0).toUpperCase() + modalType.type.slice(1)
        } Address`}
  </Modal.Header>
  <Modal.Body>
    <form onSubmit={handleSubmit} className="address-form">
      {[
        "name",
        "phonenumber",
        "address",
        "city",
        "state",
        "pincode",
        "landmark",
      ].map((field) => (
        <div className="form-group" key={field}>
          <label htmlFor={field}>
            {field === "phonenumber"
              ? "Phone Number"
              : field.charAt(0).toUpperCase() + field.slice(1)}
          </label>
          <input
            type={field === "phonenumber" || field === "pincode" ? "tel" : "text"}
            id={field}
            name={field}
            value={formData[field]}
            onChange={handleInputChange}
            className="input-field"
            required
          />
        </div>
      ))}
      <button type="submit" className="submit-button">
        Submit
      </button>
    </form>
  </Modal.Body>
</Modal>

          </>
        ) : (
          <></>
        )}
      </div>
      </>
      )}
    </>
  );
};

export default CheckoutPage;
