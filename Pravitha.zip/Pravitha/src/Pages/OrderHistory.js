import React, { useState,useEffect,useRef } from 'react';
import Logo from "../Assets/figma1.png";
import { Link } from 'react-router-dom';
import { Container, Row, Col, Button, Form } from 'react-bootstrap';
import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation, Pagination, Autoplay  } from "swiper/modules"; // Import navigation module
import "swiper/css"; // Core Swiper styles
import "swiper/css/navigation"; // Navigation styles
import { useNavigate } from "react-router-dom";
import Image from '../Assets/tick-circle_svgrepo.com.png'
import axios from 'axios';



const OrderHistory = () => {
  const [quantity, setQuantity] = useState(1);
  // const [orderData, setOrderData] = useState(null);
  const [trendings, setTrendings] = useState([]);
  const navigate = useNavigate();
  const swiperRef = useRef(null);
   const [cgstPer, setCgstPer] = useState(0); // gst percent, can be fetched from the API
   const [sgstPer, setSgstPer] = useState(0);

  useEffect(() => {
    if (swiperRef.current) {
      swiperRef.current.navigation.update(); // Update navigation status
      swiperRef.current.allowSlideNext = true; // Unlock next slide
      swiperRef.current.allowSlidePrev = true; // Unlock previous slide
      if (swiperRef.current.isLocked) {
        swiperRef.current.isLocked = false; // Ensure Swiper is unlocked
      }
    }
  }, []);
  // Retrieve the data from local storage and parse it
const orderData = JSON.parse(localStorage.getItem("orderData")) || {};

console.log("orderdata: " + JSON.stringify(orderData));

// Check if orderData and body exist to avoid errors
if (!orderData || !orderData.body) {
  console.log("Order data not found or invalid.");
  // You may want to add a redirect or show a message to the user here
} else {
  console.log("Order ID:", orderData.body.order_id);
  console.log("Order Details:", orderData.body.order_details);
  console.log("Shipping Address:", orderData.body.shipping_address);
}
const handleSubCategoryClick = (trending) => {
  const { product_id } = trending;
  localStorage.setItem('selectedProductId', 0);

  localStorage.setItem('selectedProductId1', 0);
  localStorage.setItem('selectedProductId2', 0);
  localStorage.setItem('selectedProductId3', 0);
  localStorage.setItem('selectedProductId4', product_id);
  navigate(`/productdetail/${product_id}`);  // Navigate to Product Detail page with product_id
};




useEffect(() => {
  // Fetch categories from API
  fetch('https://pravithajewels.com/customerapp/home.php', {
    method: 'POST',
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.head.msg === 'Success') {
        
        setTrendings(data.body.trending);
      }
    })

    .catch((error) => console.error('Error fetching categories:', error));
}, []);

useEffect(() => {


  // Fetch GST and delivery charges data from the API
  axios.get('https://pravithajewels.com/customerapp/gst.php')
    .then(response => {
      const data = response.data.body;
    
      setCgstPer(data.cgstper);
      setSgstPer(data.sgstper);

      // Calculate CGST and SGST amounts
      // const CgstAmount = (total * data.cgstper) / 100;
      // const SgstAmount = (total * data.sgstper) / 100;
      
      // // Calculate the total amount including CGST and SGST
      // const totalWithGST = total + CgstAmount + SgstAmount;

      // // Determine the applicable shipping charge based on total with GST
      // const shippingCharge = data.delivery_charges.find(
      //   charge => totalWithGST >= parseFloat(charge.start_amt) && totalWithGST <= parseFloat(charge.end_amt)
      // )?.charge || 0;

      // // Set calculated values
      // setShipping(parseFloat(shippingCharge));
      // console.log("Total amount with GST: ", totalWithGST);
      // console.log("Shipping Charge: ", shippingCharge);
    })
    .catch(error => console.error('Error fetching data:', error));
}, [ ]);
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="mainpage">
    <Container className="cart-page mt-5">
        <div className='orderhistory-heading'>
  <h5><img src ={Image} className='tick-icon' /> Thank you, your order has been placed</h5>
  <h4 className='orderhistory-heading1'>An  email confirmation has been sent to you. </h4>
</div>
<Row>
  {/* Left Section: Product Image & Details */}
  <Col lg={8} xs={11.3}>
  {orderData?.body?.order_details?.map((item, index) => (
  <Row key={index} className="align-items-center product-details">
    <div style={{display:"flex"}}>
    <div >
      <p className="productdetail-para1-orderdetail">
        <span style={{color:"grey"}}>ordered on </span> {item .order_date || "N/A"}
      </p>
    </div>
    <div style={{marginLeft:"15px"}} className="productdetail-para1-orderdetail">
      <span style={{color:"grey"}}> order# </span> {item. order_no || "N/A"}
    </div>
  </div>
    <Col xs={4} md={4} className="mb-3 mb-md-0 cart-detail-card">
      <img
        src={item.image || "fallback-image-url.jpg"} // Replace with actual fallback image path
        alt={item.name || "Product"}
        className="img-fluid12"
        style={{ borderRadius: "5px" }}
      />
    </Col>
    <Col xs={8} md={8} className='cart-name-align'>
      <p className="proname">{item.name || "N/A"}</p>
      <p className="checkout-procode cart12" style={{ color: "darkgrey" }}>
        Product Code: <span style={{ color: "black" }}>{item.code || "N/A"}</span>
      </p>
      <p className='weight'>
        Weight:<span>{item.weight || "N/A"}</span>
        &nbsp;-&nbsp;Purity: <span>{item.purity}</span>
      </p>
      <div className="d-flex align-items-center  price-quantity-button">
      <p className="checkout-price">
  <i className="bi bi-currency-rupee"></i>
  {
    !isNaN(Number(item.price)) && Number(item.price) !== 0 
      ? new Intl.NumberFormat("en-IN").format(Number(item.price)) 
      : "0.00"
  }
</p>

        <div className="d-flex align-items-center" style={{ marginTop: "-8px" }}>
          <p className="mb-0 me-2 checkout-qty-text">Qty :</p>
          <p style={{ marginTop: "7px" }}>{item.qty || "0"}</p>
        </div>
      </div>
    </Col>
  </Row>
))}

  </Col>

  {/* Right Section: Order Summary */}
  <Col lg={4} xs={12} className="order-summary">
    <div className="summary-box p-3" style={{ border: '1px solid #ccc', borderRadius: '8px' }}>
      <h5 className="mb-3 checkout-ordersummary-head">Order Summary</h5>
      <div className="d-flex justify-content-between checkout-ordersummary-totaltext">
        <span className="checkout-ordersummary-totaltext">Cart Total:</span>
        <span><i className="bi bi-currency-rupee" style={{fontSize:"16px"}}></i>{new Intl.NumberFormat("en-IN").format(orderData?.body?.order_summary.subtotal)}</span>
      </div>
      <div className="d-flex justify-content-between checkout-ordersummary-totaltext">
        <span>Cgst({cgstPer}%):</span>
        <span><i className="bi bi-currency-rupee" style={{fontSize:"16px"}}></i>{new Intl.NumberFormat("en-IN").format(orderData?.body?.order_summary.cgst)}</span>
      </div>
      <div className="d-flex justify-content-between checkout-ordersummary-totaltext">
        <span>Sgst({sgstPer}%):</span>
        <span><i className="bi bi-currency-rupee" style={{fontSize:"16px"}}></i>{new Intl.NumberFormat("en-IN").format(orderData?.body?.order_summary.sgst)}</span>
      </div>
      <div className="d-flex justify-content-between checkout-ordersummary-totaltext">
        <span>Shipping:</span>
        <span><i className="bi bi-currency-rupee" style={{fontSize:"16px"}}></i>{new Intl.NumberFormat("en-IN").format(orderData?.body?.order_summary.shipping)}</span>
      </div>
      <hr />
      <div className="d-flex justify-content-between mt-3 checkout-ordersummary-totaltext-bold">
        <strong>Order Total:</strong>
        <strong><i className="bi bi-currency-rupee" style={{fontSize:"16px"}}></i>{new Intl.NumberFormat("en-IN").format(orderData?.body?.order_summary.total)}</strong>
      </div>
    </div>
  </Col>

  {/* Shipping Address */}
  <Col md={12}>
  <br />
    <h5 className='shipping-text'>Shipping Address</h5>
    
    <Col lg={8} md={12}>
      <div style={{  border: "1px solid #ccc",  backgroundColor: "#FCFCFC", height: "200px" }}>
        <p className="shipping-content">
        {orderData?.body?.shipping_address?.name || "Address not available"}<br />
          {orderData?.body?.shipping_address?.address || "Address not available"} <br />
          {/* {orderData?.body?.shipping_address?.mobile || ""} <br /> */}
          {orderData?.body?.shipping_address?.landmark || ""} <br />
          {orderData?.body?.shipping_address?.city || ""}, {orderData?.body?.shipping_address?.state || ""}, {orderData?.body?.shipping_address?.pincode || ""}
          <br />
          {orderData?.body?.shipping_address?.mobile || "Address not available"}
        </p>
      </div>
    </Col>
  </Col>
</Row>
      <div className="product-swiper">
      <h2 className="section-title order-history-title">You may be interested in this product as well</h2>
      <Swiper
       onSwiper={(swiper) => {
        console.log('Current Breakpoint:', swiper.currentBreakpoint);
        swiperRef.current = swiper; // Assign swiper instance
      }}
        modules={[Autoplay, Pagination, Navigation]}
        navigation={{
          prevEl: '.custom-prev',
          nextEl: '.custom-next',
        }} // Attach custom buttons
        slidesPerView={5}
        spaceBetween={5}
        loop={trendings.length > 1}
        
        autoplay={{
        delay: 1000,           // Delay in milliseconds for the auto swipe
        disableOnInteraction: false,  // Allows autoplay to continue after user interaction
      }}
        pagination={{ clickable: true }}
        breakpoints={{
          320: { slidesPerView: 1 },
          375: { slidesPerView: 1.4 },
          480: { slidesPerView: 2 },
        768: { slidesPerView: 3 },
        1024: { slidesPerView: 4},
      }}
    >
         {/* Custom Navigation Buttons */}
         <button className="custom-prev">❮</button>
      <button className="custom-next">❯</button>
    {trendings.map((trending) => (
          <SwiperSlide key={trending.product_id}> 
            <div  key={trending.product_id}
            onClick={() => handleSubCategoryClick(trending)}
            style={{ cursor: "pointer" }}
            >
            <div className="productdetail-product-card">
              
              <div className="productdetail-product-image-section ">
                <img
                  src={trending.image}
                  alt={trending.product_name}
                  className="product-image"
                />
              </div>
              <div className="product-info-section">
                <h3 className="product-name">{trending.product_name}</h3>
                <p className="product-price">
                <i class="bi bi-currency-rupee" style={{fontSize:"15px"}}></i>{new Intl.NumberFormat("en-IN").format(trending.price)}{' '}
                  <span className="product-discount">
                  
                  {trending.discount !== "0" ? `[${trending.discount} % Off]` : ""}
                    {/* [{trending.discount} %Off] */}
                  </span>
                </p>
              </div>
            </div>
            </div>
          </SwiperSlide>
        ))}
      </Swiper>
    </div>
    </Container>
    </div>
  );
};

export default OrderHistory;
