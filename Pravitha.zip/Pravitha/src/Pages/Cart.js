import React, { useState,useEffect,useContext } from 'react';
import Logo from "../Assets/figma1.png";
import { Link } from 'react-router-dom';
import { Container, Row, Col, Button, Form } from 'react-bootstrap';
import { CartContext } from "../Context/CartContext";
import axios from 'axios';
import PuffLoader from "react-spinners/PuffLoader";


const Cart = () => {
  const [quantity, setQuantity] = useState(1);
  const { cartItems, addItemToCart, removeItemFromCart } = useContext(CartContext);
  console.log("Cart Items" + cartItems)
  const [gst, setGst] = useState(0);
  const [deliveryCharges, setDeliveryCharges] = useState([]);
  const [shipping, setShipping] = useState(0);
  const [cartTotal, setCartTotal] = useState(0);
  const [cgstPer, setCgstPer] = useState(0); // gst percent, can be fetched from the API
  const [sgstPer, setSgstPer] = useState(0); // gst percent, can be fetched from the API
  const [loading, setLoading] = useState(true); // Loading state

  useEffect(() => {
    // Simulate data fetching or delay for loader
    const timer = setTimeout(() => {
      setLoading(false); // Stop loading after 3 seconds
    }, 3000);

    return () => clearTimeout(timer); // Cleanup timeout
  }, []);

   localStorage.getItem("main_category_id");
   localStorage.getItem("sub_category_type_id");



   useEffect(() => {
    // Calculate Cart Total based on quantity and product price
    const total = cartItems.reduce((acc, item) => acc + item.quantity * item.price, 0);
    setCartTotal(total);

    // Fetch GST and delivery charges data from the API
    axios.get('https://pravithajewels.com/customerapp/gst.php')
      .then(response => {
        const data = response.data.body;
        setGst(data.gst);
        setDeliveryCharges(data.delivery_charges);
        setCgstPer(data.cgstper);
        setSgstPer(data.sgstper);

        // Calculate CGST and SGST amounts
        const CgstAmount = (total * data.cgstper) / 100;
        const SgstAmount = (total * data.sgstper) / 100;
        
        // Calculate the total amount including CGST and SGST
        const totalWithGST = total + CgstAmount + SgstAmount;

        // Determine the applicable shipping charge based on total with GST
        const shippingCharge = data.delivery_charges.find(
          charge => totalWithGST >= parseFloat(charge.start_amt) && totalWithGST <= parseFloat(charge.end_amt)
        )?.charge || 0;

        // Set calculated values
        setShipping(parseFloat(shippingCharge));
        console.log("Total amount with GST: ", totalWithGST);
        console.log("Shipping Charge: ", shippingCharge);
      })
      .catch(error => console.error('Error fetching data:', error));
  }, [cartItems]);

  // Calculate CGST and SGST amounts based on the cartTotal
  const CgstAmount = (cartTotal * cgstPer) / 100;
  const SgstAmount = (cartTotal * sgstPer) / 100;
  const orderTotal = cartTotal + CgstAmount + SgstAmount + shipping;
  // Calculate Order Total



  const handleIncrease = (item) => {
    const productId = item.product_id; // Get the product ID from the item
    const stock = item.stock; // Retrieve the stock for the product from localStorage
    
    if (stock && item.quantity < parseInt(stock, 10)) {
      // Increase quantity only if it's below the stock limit
      addItemToCart({ ...item, quantity: 1 });
    } else {
      // If the quantity reaches the stock limit, log or show a message
      console.log("Cannot increase quantity beyond available stock");
    }
  };
  
  
  const handleDecrease = (item) => {
    if (item.quantity > 1) {
      // Decrease the quantity if it's greater than 1
      addItemToCart({ ...item, quantity: -1 });
    } else {
      // If quantity is 1, remove the item from the cart
      removeItemFromCart(item.product_id, item.weight, item.purity);
    }
  };
  
  
  
 
  
  const handleQuantityChange = (item, e) => {
    const value = parseInt(e.target.value, 10);
    if (value >= 1) {
      addItemToCart({ ...item, quantity: value - item.quantity }); // Update cart with difference in quantity
    }
  };
  
  const handleCheckoutClick = () => {
    sessionStorage.setItem('buyNowProduct', null);
  };

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  

  return (
    <div className="mainpage">
      {loading ? (
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            height: "100vh",
          }}
        >
          <PuffLoader color="#D0C743" size={100} />
        </div>
      ) : (
        <>
    <Container className="cart-page mt-5">
      <Row>
        <Col  lg={8} xs= {12} >
        {/* Left Section: Product Image & Details */}
        {cartItems.length > 0 ? (
        cartItems.map((item) => (
          <Row key={item.product_id} className="align-items-center product-details mb-4">
            <Col xs={4} lg={4} className="mb-3 mb-md-0 cart-detail-card">
              <img
                src={item.image || Logo} // Use item image or fallback
                alt={item.name}
                className="img-fluid-cart"
                style={{ borderRadius: "5px" }}
                loading="lazy"
              />
            </Col>
            <Col xs={8} md={8} className="cart-name-align">
              <p className="proname12">{item.name}</p>
              <p className="checkout-procode" style={{ color: "darkgrey" }}>
                Product Code: <span style={{ color: "black" }}>{item.product_code}</span>
              </p>
              <span
                  className="productdetail-qty"
                  style={{
                    color: parseInt(item.stock, 10) === 0 ? 'red' : parseInt(item.stock, 10) < 10 ? 'red' : 'green',marginTop:"-10px"
                  }}
                >
                  {parseInt(item.stock, 10) === 0 ? 'No stock' : `In stock: ${item.stock}`}
                </span>
                <p className="weight">Weight:<span>{item.weight}</span>&nbsp;-&nbsp;Purity: <span>{item.purity}</span> <span></span></p>
              <div className="d-flex align-items-center  price-quantity-button cart123">
                <nobr><p className="checkout-price"> <i className="bi bi-currency-rupee"></i>{(new Intl.NumberFormat("en-IN").format(item.price || 0))}</p></nobr>
                <div className="d-flex align-items-center checkout-qty-text cart123" style={{ color: "black" }}>
                  <Button variant="secondary" className="in-dec-button" onClick={() => handleDecrease(item)}>
                    -
                  </Button>
                  <span className="mx-2"  value={item.quantity}
              onChange={(e) => handleQuantityChange(item, e)}
              min="1">{item.quantity}</span>
                  <Button variant="secondary" className="in-dec-button" onClick={() => handleIncrease(item)}>
                    +
                  </Button>
                </div>
              </div>
              <button
                variant="link"
                className="text ml-3 cart-remove cart12"
                style={{
                  border: "none",
                  backgroundColor: "transparent",
                  color: "#126CF4",
                  fontFamily: "PF Handbook Pro",
                  fontSize: "24px"
                }}
                onClick={() => removeItemFromCart(item.product_id, item.weight, item.purity)}
              >
                Remove
              </button>
            </Col>
          </Row>
         
        ))
      ) : (
        <p>Your cart is empty.</p>
      )}
 </Col>
        {/* Right Section: Order Summary */}
        <Col lg={4} xs={12} className="order-summary">
      <div className="summary-box p-3" style={{ border: '1px solid #ccc', borderRadius: '8px' }}>
        <h5 className="mb-3 checkout-ordersummary-head">Order Summary</h5>
        <div className="d-flex justify-content-between checkout-ordersummary-totaltext">
          <span>Cart Total:</span>
          <span><i className="bi bi-currency-rupee" style={{fontSize:"16px"}}></i>{new Intl.NumberFormat("en-IN").format(cartTotal || 0)}</span>
        </div>
       
        <div className="d-flex justify-content-between checkout-ordersummary-totaltext">
      <span>CGST ({cgstPer}%):</span>
      <span><i className="bi bi-currency-rupee" style={{fontSize:"16px"}}></i>{new Intl.NumberFormat("en-IN").format(CgstAmount || 0)}</span>
    </div>

    <div className="d-flex justify-content-between checkout-ordersummary-totaltext">
      <span>SGST ({sgstPer}%):</span>
      <span><i className="bi bi-currency-rupee" style={{fontSize:"16px"}}></i>{new Intl.NumberFormat("en-IN").format(SgstAmount || 0)}</span>
    </div>
    <div className="d-flex justify-content-between checkout-ordersummary-totaltext">
          <span>Shipping:</span>
          <span><i className="bi bi-currency-rupee" style={{fontSize:"16px"}}></i>{new Intl.NumberFormat("en-IN").format(shipping || 0)}</span>
        </div>
        <hr />
        <div className="d-flex justify-content-between mt-3 checkout-ordersummary-totaltext-bold">
          <strong>Order Total:</strong>
          <strong><i className="bi bi-currency-rupee" style={{fontSize:"16px"}}></i>{new Intl.NumberFormat("en-IN").format(orderTotal || 0)}</strong>
        </div>
        
        <div className='cart-checkout-parent'>
        {cartItems.length > 0 ? (
          <Link to='/checkout'onClick={() => handleCheckoutClick()}>
            <Button variant="warning" className="mt-4 cart-checkout-button">Checkout</Button>
          </Link>
        ):(
          ""
        )}
          <Link
            // key={main_category_id}
            to={`/shop/${   localStorage.getItem("main_category_id")
            }/${   localStorage.getItem("sub_category_type_id")
            }`} // Pass the appropriate subcategory ID
            style={{
              textDecoration: "none",
            }}
          >
          <button variant="link" className="w-100 mt-2 text-primary cart-continue-button">
            Continue Shopping
          </button>
</Link>

        </div>
      </div>
    </Col>
      </Row>
    </Container>
    </>
      )}
    </div>
  );
};

export default Cart;
