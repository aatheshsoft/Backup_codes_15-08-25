import React, { useState,useEffect,useRef } from "react";
import { Button, Container, Row, Col, Breadcrumb, Modal } from "react-bootstrap";
import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation,Autoplay, Pagination } from "swiper/modules"; // Import navigation module
import "swiper/css"; // Core Swiper styles
import "swiper/css/navigation"; // Navigation styles
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faShoppingCart } from "@fortawesome/free-solid-svg-icons";
import { useContext } from 'react';
import { CartContext } from "../Context/CartContext";
import { Link } from "react-router-dom";
import Logo from '../Assets/figma1.png';
import { useParams } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';
import { FaShoppingCart } from 'react-icons/fa';
import {  useHistory } from 'react-router-dom';
import PuffLoader from "react-spinners/PuffLoader";
import axios from 'axios';



const ProductDetail = () => {
  // const { product_id } = useParams();
  const swiperRef = useRef(null);
  const navigate = useNavigate();
  const [quantity, setQuantity] = useState(1);
  const [product, setProduct] = useState(null);
  const [discount, setDiscount] = useState(0);
  const [selectedImage, setSelectedImage] = useState(Logo); // Default large image
  const { cartItems, cartCount, addItemToCart, removeItemFromCart } = useContext (CartContext);
  const [selectedWeight, setSelectedWeight] = useState(null);
  const [selectedPurity, setSelectedPurity] = useState(null);
  const [productPrice, setProductPrice] = useState(0);
  const [category, setCategory] = useState("");
  const [categoryrate, setCategoryRate] = useState(0);
  const[weight,setWeight] =useState(0);
  const [gst, setGst] = useState(0);
  const [cart, setCart] = useState(0);
  const [recommended, setRecommended] = useState([]);
  const [title, setTitle] = useState("");
  const [subtitle, setSubTitle] = useState("");
  const [subtypetitle, setSubTypeTitle] = useState("");
  const [message, setMessage] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [filteredPurityOptions, setFilteredPurityOptions] = useState([]);
  const [loading, setLoading] = useState(false); 
   const[stock,setStock]= useState(0);
   const [makingcharge, setMakingCharge] = useState(0);
   const [wastage, setWastage] = useState(0);
   const [shipping, setShipping] = useState(0);
   const[grandtotal1, setGrandTotal1]= useState(0);
   const[subid, setSubId] = useState();
   const[mainid, setMainId] = useState();
   const[subtypeid, setSubtypeId] = useState();



  
  // useNavigate
  
  useEffect(() => {
    if (swiperRef.current) {
      swiperRef.current.navigation.update(); // Update navigation status
      swiperRef.current.allowSlideNext = true; // Unlock next slide
      swiperRef.current.allowSlidePrev = true; // Unlock previous slide
      if (swiperRef.current.isLocked) {
        swiperRef.current.isLocked = false; // Ensure Swiper is unlocked
      }
    }
  }, []);
  const handleImageClick = (image) => {
    setSelectedImage(image);
    setShowModal(true); // Show modal on image click
  };

  const handleCloseModal = () => setShowModal(false);



  const handleSubCategoryClick = (recommended) => {
    const { product_id } = recommended;
    localStorage.setItem('selectedProductId1', 0);
    localStorage.setItem('selectedProductId2', 0);
    localStorage.setItem('selectedProductId', 0);
    localStorage.setItem('selectedProductId4', 0);

    localStorage.setItem('selectedProductId3', product_id);


    
    navigate(`/productdetail/${product_id}`);  // Navigate to Product Detail page with product_id
    window.location.reload(); 
  };
    // Set default weight and price when product is loaded
   // Set default weight and purity when the product is loaded
   useEffect(() => {
    if (product?.weight_price_list && product.weight_price_list.length > 0) {
      const defaultWeight = product.weight_price_list[0].weight;
      setSelectedWeight(defaultWeight);

      const purityOptions = product.weight_price_list.filter(
        (item) => item.weight === defaultWeight
      );
      setFilteredPurityOptions(purityOptions);

      if (purityOptions.length > 0) {
        const defaultPurity = purityOptions[0].purity;
        setSelectedPurity(defaultPurity);
        setProductPrice(purityOptions[0].price);
      }
    }
  }, [product]);

  // Handle weight change and update purity options
  const handleWeightChange = (event) => {
    const newWeight = event.target.value;
    setSelectedWeight(newWeight);

    const purityOptions = product.weight_price_list.filter(
      (item) => item.weight.toString() === newWeight.toString()
    );
    setFilteredPurityOptions(purityOptions);

    if (purityOptions.length > 0) {
      const defaultPurity = purityOptions[0].purity;
      setSelectedPurity(defaultPurity);
      setProductPrice(purityOptions[0].price);
      setStock(purityOptions[0].stock);
      setDiscount(purityOptions[0].discount);
      setMakingCharge(purityOptions[0].making_charge);
      setWastage(purityOptions[0].wastage);
    } else {
      setSelectedPurity("");
      setProductPrice(0);
      setStock(0);
      setDiscount(0);
      setMakingCharge(0);
      setWastage(0);
    }
  };

  // Handle purity change and update price
  const handlePurityChange = (event) => {
    const newPurity = event.target.value;
    setSelectedPurity(newPurity);
  
    const selectedOption = filteredPurityOptions.find(
      (item) => item.purity.toString() === newPurity.toString()
    );
  
    if (selectedOption) {
      setProductPrice(selectedOption.price);
      setStock(selectedOption.stock); // Assuming `stock` is directly on `selectedOption`
      setDiscount(selectedOption.discount); // Correcting to access as an object
      setMakingCharge(selectedOption.making_charge);
      setWastage(selectedOption.wastage);
    } else {
      setProductPrice(0);
      setStock(0);
      setDiscount(0);
      setMakingCharge(0);
      setWastage(0);
    }
  };
  


  

  const selectedProductId1 = localStorage.getItem('selectedProductId1');
  const selectedProductId = localStorage.getItem('selectedProductId');
  const selectedProductId2 = localStorage.getItem('selectedProductId2');
  const selectedProductId3 = localStorage.getItem('selectedProductId3');
  const selectedProductId4 = localStorage.getItem('selectedProductId4');


  
  const product_id = (selectedProductId1 && selectedProductId1 !== '0') ? selectedProductId1 :(selectedProductId2 && selectedProductId2 !== '0') ? selectedProductId2: (selectedProductId3 && selectedProductId3 !== '0') ?selectedProductId3:(selectedProductId4 && selectedProductId4 !== '0') ?selectedProductId4:selectedProductId;
    // console.log(product_id);

  useEffect(() => {
    const fetchProductDetails = async () => {
      setLoading(true);
      try {
        const response = await fetch(`https://pravithajewels.com/customerapp/product_details.php`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ product_id }),  // Pass product_id in the request body
        });

        const data = await response.json();
        

        if (data.head.code === 200) {
          const productDetails = data.body.product_detail[0];
          setProduct(productDetails);
          setCategory(productDetails.price_breakup.category);
          setCategoryRate(productDetails.price_breakup.category_rate);
          setWeight(productDetails.weight);
          setStock(productDetails.weight_price_list[0].stock);
          setMakingCharge(productDetails.weight_price_list[0].making_charge);
          setWastage(productDetails.weight_price_list[0].wastage);
          console.log(productDetails.weight);
          setDiscount(productDetails.weight_price_list[0].discount);
          setSelectedImage(productDetails.image[0]);
          setSelectedWeight(productDetails.weight_price_list[0].weight);
          setProductPrice(productDetails.weight_price_list[0].price);
          setGst(productDetails.price_breakup.gst_percentage);
          setRecommended(productDetails.recomended);
          setTitle(`${productDetails.top_title.main_category_name}`);
          setSubTitle(productDetails.top_title.sub_category_name)
          setSubTypeTitle(productDetails.top_title.sub_category_type_name)
          setMainId(productDetails.top_title.main_category_id);
          setSubId(productDetails.top_title.sub_category_id);
          setSubtypeId(productDetails.top_title.sub_category_type_id);
          console.log((`${productDetails.top_title.main_category_name} /   ${productDetails.top_title.sub_category_name} /   ${productDetails.top_title.sub_category_type_name}`));
          const mainCategoryId1 = productDetails.main_category_id;
          const subCategoryTypeId1 = productDetails.sub_category_type_id;

    localStorage.setItem("main_category_id", mainCategoryId1);
    localStorage.setItem("sub_category_type_id", subCategoryTypeId1);

    console.log("Main Category ID:", localStorage.getItem("main_category_id"));
    console.log("Sub Category Type ID:", localStorage.getItem("sub_category_type_id"));
    // window.location.reload(); 
        } else {
          console.error('Error fetching product details:', data.head.msg);
        }
      } catch (error) {
        console.error('Fetch error:', error);
      }
      setLoading(false);
    };

    if (product_id) {  // Only fetch if product_id is available
      fetchProductDetails();
    }
  }, [product_id]);

  // console.log(product_id);

  // Check if the item is already in the cart and set the initial quantity
  useEffect(() => {
    if (product) {
      const existingItem = cartItems.find((item) => item.product_id === product.product_id);
      if (existingItem) {
        setQuantity(existingItem.quantity);
      }
    }
  }, [cartItems, product]);

  
  useEffect(() => {
    if (product) {
      const existingItem = cartItems.find(
        (item) =>
          item.product_id === product.product_id &&
          item.weight === selectedWeight &&
          item.purity === selectedPurity // Ensure purity comparison
      );
  
      if (existingItem) {
        setQuantity(existingItem.quantity); // Sync quantity for matching weight and purity
      } else {
        setQuantity(1); // Default to 1 for new selections
      }
    }
  }, [cartItems, product, selectedWeight, selectedPurity]);
  
  
  
  const handleIncrease = () => {
    if (quantity < parseInt(stock, 10)) {
      // Ensure quantity doesn't exceed stock
      setQuantity((prevQuantity) => prevQuantity + 1);
  
      // Update cart with increased quantity
      const existingItem = cartItems.find(
        (item) =>
          item.product_id === product.product_id &&
          item.weight === selectedWeight &&
          item.purity === selectedPurity // Match both weight and purity
      );
  
      if (existingItem) {
        addItemToCart({
          ...product,
          quantity: 1, // Increment by 1 (you can adjust this logic based on stock)
          weight: selectedWeight,
          purity: selectedPurity,
        });
      } else {
        console.error("Item not found in cart for increase");
      }
    } else {
      console.log("Cannot increase quantity beyond available stock");
    }
  };
  
  const handleDecrease = () => {
    if (quantity > 1) {
      setQuantity((prevQuantity) => prevQuantity - 1);
  
      // Update cart with decreased quantity
      const existingItem = cartItems.find(
        (item) =>
          item.product_id === product.product_id &&
          item.weight === selectedWeight &&
          item.purity === selectedPurity // Match both weight and purity
      );
  
      if (existingItem) {
        addItemToCart({
          ...product,
          quantity: -1, // Decrement by 1
          weight: selectedWeight,
          purity: selectedPurity,
        });
      } else {
        console.error("Item not found in cart for decrease");
      }
    } else {
      console.log("Quantity cannot go below 1");
    }
  };
  
  if (product && product.product_id) {
    const productId = product.product_id; // Get the product ID safely
   
  
    // Store stock in localStorage using the product_id as the key
    localStorage.setItem(`productStock_${productId}`, stock);
  } else {
    console.error('Product object is not available');
  }
  
  
const handleAddToCart = () => {
    const item = {
      product_id: product.product_id,
      product_code: product.code,
      name: product.product_name,
      image: selectedImage,
      price: discountprice,
      quantity: quantity,
      weight: selectedWeight,
      purity: selectedPurity, 
      stock:  stock,
    };
  
    const existingCartItem = cartItems.find(
      (cartItem) =>
        cartItem.product_id === product.product_id &&
        cartItem.weight === selectedWeight &&
        cartItem.purity === selectedPurity // Check purity as well
    );
  
    if (existingCartItem) {
      const updatedCartItems = cartItems.map((cartItem) =>
        cartItem.product_id === product.product_id &&
        cartItem.weight === selectedWeight &&
        cartItem.purity === selectedPurity // Check purity as well
          ? {
              ...cartItem,
              quantity: cartItem.quantity + quantity,
              total: cartItem.price * (cartItem.quantity + quantity),
            }
          : cartItem
      );
      setCart(updatedCartItems);
    } else {
      addItemToCart(item);
      setMessage('Item added to cart!');
      setTimeout(() => {
        setMessage('');
      }, 2500);
    }
  };
  
  

  const handleBuyNow = () => {
    const item = {
      product_id: product.product_id,
      product_code: product.code,
      product_name: product.product_name,
      price: discountprice * quantity,
      product_weight:selectedWeight,
      purity:selectedPurity,
      singleprice: discountprice,
      image: product.image,
      quantity: quantity,
      total: grandTotal,
    };
  
    console.log("Navigating with item:", item);
  
    // Save to sessionStorage with added debug log
    try {
      sessionStorage.setItem('buyNowProduct', JSON.stringify(item));
      console.log("Saved buyNowProduct to sessionStorage:", item);
    } catch (error) {
      console.error("Error saving to sessionStorage:", error);
    }
  
    navigate('/checkout', { state: { buyNowProduct: item } });
  };
  
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);


  
 // Fetching values safely with fallbacks
 const categoryRate = parseFloat(product?.price_breakup?.category_rate) || 0;
//  const makingCharge = parseFloat(product?.price_breakup?.making_charge) || 0;
 const wastagePercentage = parseFloat(wastage) || 0;
 console.log("wastagepercentage" ,wastagePercentage );
 const discountPercentage = parseFloat(discount) || 0;
 const total = parseFloat(product?.price_breakup?.total) || 0;
 const price = parseFloat(product?.productPrice) || 0;

 
 const metalrate= Number(categoryrate) * parseInt(selectedWeight);

 // Calculate each value after parsing as a float
 const wastageCharges = Number(wastage / 100) * metalrate;

 const discountAmount = (discountPercentage / 100)* productPrice; // Use `price`, not `productPrice`
 const discountprice = productPrice - discountAmount; // Again, use `price`, not `productPrice`
const makingcharge1 = Number(makingcharge)

console.log("weight",selectedWeight);
 /* metalrate based on weight */

const rate = metalrate + makingcharge1 + wastageCharges;
 const discountAmount12 =  Number(rate)*(discount / 100); 

 const totalamount1 = (metalrate+makingcharge1 + wastageCharges - discountAmount12 );

 const totalamount = (totalamount1 );

 
 const gstAmount = ((gst/100) * totalamount);
 const grandTotal = totalamount + gstAmount;





 const goBack = () => {
  // history.goBack(); // Go back to the previous page
  navigate(-1);
};
 const [hovering, setHovering] = useState(false);
 const [zoomPosition, setZoomPosition] = useState({ x: 50, y: 50 });

 const handleMouseMove = (e) => {
   const { left, top, width, height } = e.target.getBoundingClientRect();
   const x = ((e.clientX - left) / width) * 100;
   const y = ((e.clientY - top) / height) * 100;
   setZoomPosition({ x, y });
 };


 useEffect(() => {
  

  // Fetch GST and delivery charges data from the API
  axios.get('https://pravithajewels.com/customerapp/gst.php')
    .then(response => {
      const data = response.data.body;
      
      
     // Determine the applicable shipping charge based on total with GST
      const shippingCharge = data.delivery_charges.find(
        charge => grandTotal >= parseFloat(charge.start_amt) && grandTotal <= parseFloat(charge.end_amt)
      )?.charge || 0;
  console.log("grandTotal", grandTotal)
      // Set calculated values
      setShipping(parseFloat(shippingCharge));
     
      console.log("Shipping Charge: ", shippingCharge);

    })
    .catch(error => console.error('Error fetching data:', error));
}, [totalamount, gstAmount]);
//  console.log("Shipping Charge: ", shipping);



useEffect(() => {
  
  // Update grand total when shipping changes
  setGrandTotal1(totalamount + gstAmount + shipping);
}, [totalamount, gstAmount, shipping]); 



  return (
    <div className="mainpage">
        {loading ? (
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            height: "100vh",
          }}
        >
          <PuffLoader color="#D0C743" size={100} />
        </div>
      ) : (
        <>
     
    <Container className="mt-1">
    <Row>
    <Breadcrumb className="mt-3 productdetail-breadcrumb" >
        <Breadcrumb.Item  className="productdetail-para1"><Link to="/">Home</Link> /<Link to={`/silver/${mainid}`}>{title}</Link>
        / <span style = {{color:"black",cursor:"default"}}>{subtitle}</span> /<Link to = {`/shop/${mainid}/${subtypeid}`}>{subtypetitle}</Link></Breadcrumb.Item>
       
      </Breadcrumb>
  {/* Large Image Section */}
  <Col md={6}>
      {product && product.product_name ? (
        <>
          <h5 className="productdetail-p1 pdetail-container-main">
            {product.product_name}
          </h5>
          <div
            className="zoom-container"
            style={{ 
              position: "relative", overflow: "hidden" 
            }}
          >
          <img
            src={selectedImage || product.image[0]}
            alt={product.product_name}
            className="img-fluid product-image-section-large"
            style={{ 
              maxHeight: "600px",  objectFit: "fill",
              cursor: "zoom-in", 
            }}
            // onClick={() => handleImageClick(selectedImage)}
            onMouseEnter={() => setHovering(true)}
            onMouseLeave={() => setHovering(false)}
            onMouseMove={handleMouseMove}
            loading="lazy"
          />
          {hovering && (
              <div
                className="zoomed-image"
                style={{
                  position: "absolute",
                  top: 0,
                  left: 0,
                  width: "100%",
                  height: "100%",
                  transformOrigin: `${zoomPosition.x}% ${zoomPosition.y}%`,
                  transform: "scale(2)",
                  backgroundImage: `url(${selectedImage})`,
                  backgroundPosition: `${zoomPosition.x}% ${zoomPosition.y}%`,
                  backgroundSize: "contain",
                  pointerEvents: "none",
                  zIndex: 10,
                }}
              ></div>
            )}
          </div>
          
          <div className="small-image-gallery mt-3">
            <Swiper
              spaceBetween={10}
              slidesPerView={3}
              navigation={true}
              modules={[Navigation]}
            >
              {product.image.map((image, index) => (
                image && (
                  <SwiperSlide key={index}>
                    <img
                      src={image}
                      alt={`Thumbnail ${index + 1}`}
                      className={`img-thumbnail product-image-section ${
                        selectedImage === image ? "selected-thumbnail" : ""
                      }`}
                      loading="lazy"
                      style={{
                        cursor: "pointer",
                        // border: selectedImage === image ? "2px solid blue" : "none",
                      }}
                      onClick={() => handleImageClick(image)} // Update selected image
                    />
                  </SwiperSlide>
                )
              ))}
            </Swiper>
          </div>
        </>
      ) : (
        <p>Loading product details...</p>
      )}
    </Col>

  {/* Product Info Section */}
  <Col md={6} style={{ marginTop: "55px" }} className="productdetail-details">
    {product && product.product_name ? (
      <>
        <h5 className="productdetail-p1">{product.product_name}</h5>
      <p style={{ marginTop: "-18px" }}>
        <span className="productdetail-p-detail" style={{ color: "grey" }}>
          Product Code: 
        </span>
        <span className="productdetail-p-detail">{product.code}</span>
      </p>
    {discount > 0 ? (
      <p className="productdetail-p">
        <span className="productdetail-p">
          <i className="bi bi-currency-rupee" ></i>
          {new Intl.NumberFormat("en-IN").format(discountprice)} {/* Display the dynamic price */}
        </span>
        <del style={{ color: "red", fontSize: "24px" }}>
          <i className="bi bi-currency-rupee" ></i>
          {new Intl.NumberFormat("en-IN").format(productPrice)}
        </del>&nbsp;&nbsp;&nbsp;
      </p>
    ):(
      <p className="productdetail-p">
      <span className="productdetail-p">
        <i className="bi bi-currency-rupee"></i>
        {new Intl.NumberFormat("en-IN").format(productPrice)} {/* Display the dynamic price */}
      </span>
      
    </p>
    
    )
  }
  <p className="productdetail-qty" style={{color:"grey",marginTop:"-20px"}}>
  (Exclusive of all taxes)
  </p>
      <p
        className="productdetail-qty"
        style={{
          color: parseInt(stock, 10) === 0 ? 'red' : parseInt(stock, 10) < 10 ? 'red' : 'green',
        }}
      >
        {parseInt(stock, 10) === 0 ? 'No stock' : `In stock: ${stock}`}
      </p>


   {/* Quantity Control */}
      <div className="d-flex  purity-weight">
        <div className="productdetail-qty1">
        <span className="productdetail-qty">Qty: </span> &nbsp;
        <Button variant="secondary" className="in-dec-button" onClick={handleDecrease}>
          -
        </Button> &nbsp; 
        <span className="mx-2">{quantity}</span> &nbsp; 
        <Button variant="secondary" className="in-dec-button" onClick={handleIncrease}>
          +
        </Button>
        </div>
        &nbsp; &nbsp; &nbsp; 
        
        <div className="d-flex align-items-center productdetail-weight">
        <nobr>
        <div >
        <span className="productdetail-para1">Weight: </span> &nbsp;
        <select
          className="ml-2 weightdrop12"
          style={{ maxWidth: "150px", appearance: "auto", marginTop: "0px" }}
          value={selectedWeight}
          onChange={handleWeightChange}
        >
          {Array.from(
            new Set(product.weight_price_list.map((option) => option.weight))
          ).map((weight, index) => (
            <option key={index} value={weight}>
              {weight}
            </option>
          ))}
        </select>
      </div>

        </nobr>
&nbsp;&nbsp;

        <nobr>
        <div >
        <span className="productdetail-para1">Purity: </span> &nbsp;
        <select
          className="ml-2 weightdrop12"
          style={{ maxWidth: "150px", marginTop: "0px" }}
          value={selectedPurity}
          onChange={handlePurityChange}
        >
          {filteredPurityOptions.map((option) => (
            <option key={option.id} value={option.purity}>
              {option.purity}
            </option>
          ))}
        </select>
      </div>
        </nobr>
        </div>
      </div>
    <br />
        <br />
        
        <Row>
          <Col>
            <p className="productdetails-detail">Metal</p>
            <p className="productdetails-detail12">{product.metal}</p>
          </Col>
          <Col>
            <p className="productdetails-detail">Purity</p>
            <p className="productdetails-detail12">{selectedPurity}</p>
          </Col>
          <Col>
            {/* <nobr><p className="productdetails-detail">Delivery Charges</p></nobr>
            <nobr>
         

              <p className="productdetails-detail12">
                
                <i 
                  className={product.delivery_charge !== null ? "bi bi-currency-rupee" : " "} 
                  style={{ fontSize: product.delivery_charge !== null ? "20px" : "25px" }}
                ></i>

                 
                 { console.log("line 528 "+product.delivery_charge)}
                  { product.delivery_charge === null ?   " FREE" :`${product.delivery_charge}` }
              </p>
            </nobr> */}
          </Col>
        </Row>
        <p
  className="productdetail-qty"
  
>
  10 Days Return For Each Product
</p>
        {/* Buy Now and Add to Cart Buttons */}
        <div className="productdetail-buybutton">
      {message && (
        <div className="message-popup">
          <FaShoppingCart className="cart-icon-addtocart" />
          <div className="message">{message}</div>
        </div>
      )}

{stock > 0 ? (
        <>
          <Button
            variant="primary"
            className="mt-3 buy-button"
            onClick={handleBuyNow}
          >
            Buy Now
          </Button>
          <Button
            variant="primary"
            className="mt-3 Addtocart-button"
            onClick={handleAddToCart}
          >
            Add to Cart
          </Button>
         
        </>
      ) : (
        <p style={{ color: "red" }}></p>
      )}
      {stock <= 0 && (
        <>
          <Button variant="primary" className="mt-3 buy-button" disabled>
            Buy Now
          </Button>
          <Button variant="primary" className="mt-3 Addtocart-button" disabled>
            Add to Cart
          </Button>
        </>
      )}
    </div>
        

        {/* Product Description */}
        <div style={{ marginTop: "85px" }}>
          <p className="mt-4 productdetail-head">Product Description</p>
          <p className="productdetail-para-detail">{product.description}</p>
        </div>

        <div className="price-breakup productdetail-para-detail">
      <p className="mt-4 productdetail-head">Metal Details</p>

      <div className="price-item">
        <span>Type:</span>
        <span className="price123">{selectedPurity} {product.metal}</span>
      </div>
      <div className="price-item">
        <span>Weight:</span>
        <span className="price123">{selectedWeight}</span>
      </div>
</div>
      
        
        {/* Price Breakup */}
        <div className="price-breakup productdetail-para-detail">
      <p className="mt-4 productdetail-head">Price Breakup</p>

      <div className="price-item">
        <span>{category}:</span>
        <span className="price123"> <i className="bi bi-currency-rupee"></i> {new Intl.NumberFormat("en-IN").format (metalrate)}</span>
      </div>

      <div className="price-item">
        <span>Making Charges:</span>
        <span className="price123"> <i className="bi bi-currency-rupee"></i> {new Intl.NumberFormat("en-IN").format(makingcharge)}</span>
      </div>

      <div className="price-item">
        <span>Wastage Charges[{wastagePercentage}%]:</span>
        <span className="price123"> <i className="bi bi-currency-rupee"></i> {new Intl.NumberFormat("en-IN").format(wastageCharges)}</span>
      </div>

      <div className="price-item">
        <span>Discount [{discountPercentage}%] :</span>
        <span className="price123"> <i className="bi bi-currency-rupee"></i>{new Intl.NumberFormat("en-IN").format(discountAmount12)}</span>
      </div>

      <div className="price-item">
        <span>Total:</span>
        <span className="price123"> <i className="bi bi-currency-rupee"></i> {new Intl.NumberFormat("en-IN").format(totalamount)}</span>
      </div>

      <div className="price-item">
        <span>GST [{gst}%]:</span>
        <span className="price123"> <i className="bi bi-currency-rupee"></i> {new Intl.NumberFormat("en-IN").format(gstAmount)}</span>
      </div>

      <div className="price-item">
        <span>Shipping charge:</span>
        <span className="price123"> <i className="bi bi-currency-rupee"></i>{new Intl.NumberFormat("en-IN").format(shipping)}</span>
      </div>

      <div className="price-item123">
        <span>Grand Total:</span>
        <span className="price1234"> <i className="bi bi-currency-rupee"></i>{new Intl.NumberFormat("en-IN").format(grandtotal1)}</span>
      </div>
    </div>
      </>
    ) : (
      <p>Loading product info...</p> // Placeholder while loading
    )}
  </Col>
</Row>
<h2 className="section-title">Recommended for you</h2>

      
      <div className="product-swiper" style={{marginLeft:"-20px"}}>
      <Swiper
      onSwiper={(swiper) => {
        console.log('Current Breakpoint:', swiper.currentBreakpoint);
        swiperRef.current = swiper;
      }}
  modules={[Autoplay,  Navigation]}
  navigation={{
    prevEl: '.custom-prev',
    nextEl: '.custom-next',
  }} // Attach custom buttons
  slidesPerView={5}
  spaceBetween={5}
  loop={recommended.length > 1}
  autoplay={{
    delay: 3000,
    disableOnInteraction: false,
  }}
  // pagination={{ clickable: true }}
  breakpoints={{
    320: { slidesPerView: 1 },
    375: { slidesPerView: 1.4 },
    480: { slidesPerView: 2 },
    768: { slidesPerView: 3, spaceBetween: 25 },
    1024: { slidesPerView: 4, spaceBetween: 30 },
  }}
>
      {/* Custom Navigation Buttons */}
      <button className="custom-prev">❮</button>
      <button className="custom-next">❯</button>
  {recommended?.map((item) => (
    <SwiperSlide key={item.product_id}>
      <div
        onClick={() => handleSubCategoryClick(item)}
        style={{ cursor: "pointer" }}
      >
        <div className="productdetail-product-card">
          <div className="productdetail-product-image-section">
            <img
              src={item.image}
              alt={item.product_name}
              className="product-image"
              loading="lazy"
            />
          </div>
          <div className="product-info-section">
            <h3 className="product-name">{item.product_name}</h3>
            <p className="product-price">
              <i className="bi bi-currency-rupee"></i>{" "}
              {new Intl.NumberFormat("en-IN").format(item.price)} <span className="product-discount">
             
              {item.discount !== "0" ? `[${item.discount} % Off]` : ""}
                {/* [{item.discount} % Off] */}
                </span>
            </p>
          </div>
        </div>
      </div>
    </SwiperSlide>
  ))}
</Swiper>

    </div>
    </Container>

    </>
  )}
    </div>
  );
};

export default ProductDetail;
