import React,{useEffect, useState} from "react";
import backgroundImage from '../Assets/background.png'; 
import PuffLoader from "react-spinners/PuffLoader";


const ReturnPolicy = () => {
  const [loading, setLoading] = useState(true); // Loading state
  useEffect(() => {
    // Simulate data fetching or delay for loader
    const timer = setTimeout(() => {
      setLoading(false); // Stop loading after 3 seconds
    }, 3000);

    return () => clearTimeout(timer); // Cleanup timeout
  }, []);
    
    useEffect(() => {
        window.scrollTo(0, 0);
      }, []);


  return (
    <div className='mainpage'>
       {loading ? (
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            height: "100vh",
          }}
        >
          <PuffLoader color="#D0C743" size={100} />
        </div>
      ) : (
        <>
        <div   style={{
          backgroundImage: `url(${backgroundImage})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          backgroundRepeat: "no-repeat",
          width: "100%",
          height:"200px",
          padding: "20px 0",
          color: "black",
          textAlign: "center",
          fontSize: "2rem",
          marginBottom: "20px",
        }}>
         <h1
       className="return-policy-title"
       
      >
        Return Policy
      </h1>
      </div>
    <div className="return-policy-container">
   

      <ul className="return-policy-list">
        <li>
          <p >1.Return Window: Returns are accepted within 10 days from the date of delivery.</p>
        </li>
        <li>
          <p>2.Required Documentation: Please provide a video of the packing process and the courier handover. Submit <br />
            your Government ID proof and one of the following bank documents:Bank statement,Passbook front page,Canceled chequeSend the required documentation via email and WhatsApp.
            </p >
          
        </li>
        <li>
          <p>3.Non-Returnable Items:</p>
          <ul>
            {/* <li>a.Gold Coins/Bars</li> */}
            <li>b.Silver Articles, Coins, and Bars</li>
            <li>c.Customized Orders</li>
            <li>d.Auspicous Products</li>
          </ul>
        </li>
        <li>
          <p>4.Orders Over ₹1 Lakh: Refunds are not possible for orders exceeding ₹1 lakh. Exchanges are available for such orders.</p>
        </li>
      </ul>
    </div>
    </>
      )}
    </div>
  );
};

export default ReturnPolicy;
