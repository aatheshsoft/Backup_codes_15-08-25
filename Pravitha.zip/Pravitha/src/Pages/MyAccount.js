import React, { useState,useEffect } from "react";
import { CgProfile } from "react-icons/cg";
import Logo2 from "../Assets/figma2.png";
import { FiEdit } from "react-icons/fi";
import { MdOutlineVerified } from "react-icons/md";
import icon from "../Assets/user-circle_svgrepo.com.png"
import { Modal, Button } from "react-bootstrap"
import { IoIosAddCircleOutline } from "react-icons/io";
import axios from 'axios';
import { useNavigate } from "react-router-dom";
import PuffLoader from "react-spinners/PuffLoader";

const MyAccount = () => {
  // State to keep track of the active tab
  const userID = localStorage.getItem('userID');
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("Orders");
  const [editType, setEditType] = useState(null); // Track what is being edited
  const [step, setStep] = useState("view"); // Track step (view, edit, otp)
  const [formType, setFormType] = useState("add"); // State to handle form display
  const [showModal, setShowModal] = useState(false);
  const [addresses, setAddresses] = useState([]);
  // const [selectedAddress, setSelectedAddress] = useState(null);
  const [newMobile, setNewMobile] = useState("");
  const [userInfo, setUserInfo] = useState(null);
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [newEmail, setNewEmail] = useState("");
  const [otp, setOtp] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [currentEmail, setCurrentEmail] = useState("");  // Empty string as initial value

  useEffect(() => {
    if (userID === null) {
      navigate('/signin');
    }
  }, [userID, navigate]);



  const [formData, setFormData] = useState({
    user_id: userID,
    name: '',
    address: '',
    city: '',
    pincode: '',
    state: '',
    landmark: '',
    label: '',
    phonenumber: ''
  });
  const [formErrors, setFormErrors] = useState({});

  // Function to validate form fields
  const validateForm = () => {
    const errors = {};
  
    // Validate name (only letters and spaces)
    if (!formData.name.trim()) {
      errors.name = "Name is required";
    } else if (!/^[a-zA-Z\s]+$/.test(formData.name)) {
      errors.name = "Name must contain only letters and spaces";
    }
  
    // Validate phone number (only numeric, 10 digits)
    if (!formData.phonenumber.trim()) {
      errors.phonenumber = "Phone number is required";
    } else if (!/^\d{10}$/.test(formData.phonenumber)) {
      errors.phonenumber = "Valid 10-digit phone number is required";
    }
  
    // Validate address
    if (!formData.address.trim()) {
      errors.address = "Address is required";
    }
  
    // Validate city
    if (!formData.city.trim()) {
      errors.city = "City is required";
    }
  
    // Validate state
    if (!formData.state.trim()) {
      errors.state = "State is required";
    }
  
    // Validate pincode (only numeric, 6 digits)
    if (!formData.pincode.trim()) {
      errors.pincode = "Pincode is required";
    } else if (!/^\d{6}$/.test(formData.pincode)) {
      errors.pincode = "Valid 6-digit pincode is required";
    }
  
    return errors;
  };

  // Function to handle form submit
  const handleFormSubmit = async (e) => {
    e.preventDefault();
    const errors = validateForm();
    setFormErrors(errors);
  
    if (Object.keys(errors).length === 0) {
      try {
        const apiUrl =
          formType === "add"
            ? "https://pravithajewels.com/customerapp/addresslistadd.php"
            : "https://pravithajewels.com/customerapp/addresslistupdate.php";
  
        const response = await axios.post(apiUrl, formData);

        console.log(formData);
        console.log("API Response:", response.data); // Log the full response
  
        // Check for success in the API response based on the 'head' object
        if (response.data.head && response.data.head.msg === "Success" && response.data.head.code === 200) {
          // alert("Address saved successfully!"); // Success alert
          setShowModal(false);
          window.location.reload(); 
        } else {
          alert("Failed to save the address. Please try again."); // Alert for non-success response
        }
      } catch (error) {
        console.error("Error:", error);
        alert("An error occurred while saving the address. Please try again later."); // Alert on error
      }
    } 
  };
  
  // Handle change in input fields
  const handleChange = (e) => {
    const { name, value } = e.target;
  
    // Validate individual fields during input
    if (name === "name" && !/^[a-zA-Z\s]*$/.test(value)) {
      return; // Prevent non-letter and non-space characters
    }
  
    if (name === "phonenumber" && !/^\d*$/.test(value)) {
      return; // Prevent non-numeric characters
    }
  
    if (name === "pincode" && !/^\d*$/.test(value)) {
      return; // Prevent non-numeric characters
    }
  
    setFormData((prevState) => ({ ...prevState, [name]: value }));
    setFormErrors({ ...formErrors, [name]: "" });

  };
  // Show modal and set form data for editing or adding
  const handleShowModal = (type, address = null) => {
    setFormType(type);
    setFormData(
      type === "edit" && address ? { ...address, user_id: userID } : {
        user_id: userID,
        name: '',
        address: '',
        city: '',
        pincode: '',
        state: '',
        landmark: '',
        label: '',
        phonenumber: ''
      }
    );
    setFormErrors({}); // Clear errors on opening modal
    setShowModal(true);
  };


  useEffect(() => {
    const fetchAddresses = async () => {
      try {
        const response = await axios.post(
          "https://pravithajewels.com/customerapp/addresslist.php",
          { user_id: userID }
        );

        if (response.data && response.data.body) {
          setAddresses(response.data.body);
        }
      } catch (error) {
        console.error("Error fetching addresses:", error);
      }
    };

    fetchAddresses();

    // Retrieve the selected address from localStorage when the component mounts
    const savedAddress = JSON.parse(localStorage.getItem("selectedAddress"));
    if (savedAddress) {
      setSelectedAddress(savedAddress); // Set the selected address from localStorage
    }
  }, []);

  // const handleAddressSelect = (address) => {
  //   // If the clicked address is already selected, unselect it
  //   if (selectedAddress?.address_id === address.address_id) {
  //     setSelectedAddress(null);
  //     localStorage.removeItem("selectedAddress"); // Remove from localStorage
  //   } else {
  //     setSelectedAddress(address); // Select the new address
  //     localStorage.setItem("selectedAddress", JSON.stringify(address)); // Save it in localStorage
  //   }
  // };
  const [selectedAddress, setSelectedAddress] = useState(
    JSON.parse(localStorage.getItem("selectedAddress")) || null
  );
  
  const handleAddressSelect = (address) => {
    if (selectedAddress?.address_id === address.address_id) {
      setSelectedAddress(null);
      localStorage.removeItem("selectedAddress"); // Remove from localStorage
    } else {
      setSelectedAddress(address);
      localStorage.setItem("selectedAddress", JSON.stringify(address)); // Save to localStorage
    }
  };
  
  // Auto-select the first address if available and none is selected
  useEffect(() => {
    if (!selectedAddress && addresses && addresses.length > 0) {
      const firstAddress = addresses[0];
      setSelectedAddress(firstAddress);
      localStorage.setItem("selectedAddress", JSON.stringify(firstAddress)); // Save to localStorage
    }
  }, [addresses]);





  // const handleFormSubmit = (e) => {
  //   e.preventDefault();
  //   // Add form submission logic here
  //   setShowModal(false); // Close modal on submit
  // };

  // const handleShowModal = (type) => {
  //   setFormType(type);
  //   setShowModal(true);
  // }

  const handleModalClose = () => {
    setShowModal(false);
    setStep("view");
    
  };
  
  const handleEditClick = (type) => {
    setEditType(type); // Set whether editing email or mobile
    setStep("edit"); // Move to the edit form step
    setShowModal(true);
  };

  const handleSendCodeClick = () => {
    setStep("otp"); // Move to the OTP step
  };

  const handleCancelClick = () => {
    setEditType(null);
    setStep("view"); // Reset to the default view
  };
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  

const HandleMobileEdit = async () =>{
  setLoading(true);
    try {

      console.log("newmail" + newEmail)
      const response = await axios.post(
        "https://pravithajewels.com/customerapp/forgot_request.php",
        {
          user_id: userID,
          mobile:newMobile
  
        }
      );
      if (response.data.head.code === 200) {
        alert("Mobile Number Edited successfully.");
        // setStep("password"); // Proceed to update password
        setShowModal(false);
        window.location.reload(); 
      } else {
        alert("Invalid Mobile Number");
      }
    } catch (error) {
      console.error(error);
      alert("Failed to verify Mobile Number.");
    }
    setLoading(false);
  };


  

  const handleSendVerificationCode = async () => {
    if (editType === "email" && (!newEmail || newEmail.length === 0)) {
      alert("Please enter a valid email.");
      return;
    }
    // if (editType === "mobile" && (!newMobile || newMobile.length === 0)) {
    //   alert("Please enter a valid mobile number.");
    //   return;
    // }

    setLoading(true);
    try {
      const response = await axios.post(
        "https://pravithajewels.com/customerapp/forgot_request.php",
        {
          user_id: userID,
          email: editType === "email" ? newEmail : undefined,
          // mobile: editType === "mobile" ? newMobile : undefined,
        }
      );
      console.log(response.data);
      if (response.data.head.code === 200) {
        setStep("otp");
      } else {
        alert("Failed to send verification code.");
      }
    } catch (error) {
      console.error(error);
      alert("An error occurred while sending the verification code.");
    }
    setLoading(false);
  };

  // Handle OTP verification
  const handleVerifyOtp = async () => {
    if (!otp || otp.length === 0) {
      alert("Please enter the OTP.");
      return;
    }

    setLoading(true);
    try {

      console.log("newmail" + newEmail)
      const response = await axios.post(
        "https://pravithajewels.com/customerapp/forgot_request.php",
        {
          user_id: userID,
          reset_code: otp,
          email:newEmail
  
        }
      );
      if (response.data.head.code === 200) {
        alert("OTP verified successfully.");
        setStep("password"); // Proceed to update password
        setShowModal(false);
        window.location.reload(); 
      } else {
        alert("Invalid OTP.");
      }
    } catch (error) {
      console.error(error);
      alert("Failed to verify OTP.");
    }
    setLoading(false);
  };


  const handleCancelOrder = (order) => {
    
  
    // Prepare the data to send in the request
    const { order_no, product_id, weight, purity, qty } = order;

    // Prepare the data to send in the request
    const data = {
      order_no: order_no,
      product_id: product_id,  
      weight: weight,           
      purity: purity,           
      qty: qty                  
    };
    console.log("data",data);
    // Make the POST request to the API
    axios.post('https://pravithajewels.com/customerapp/cancel_order.php', data)
      .then((response) => {
        console.log("Cancel Order response:", response.data);
        alert("Your Order Is Scucessfully Cancelled");
        window.location.reload();
      })
      .catch((error) => {
        console.error("Error cancelling order:", error);
        // Handle error (e.g., show an error message)
      });

  };










  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const response = await axios.post(
          "https://pravithajewels.com/customerapp/myaccount.php",
          {
            member_id: userID,
          }
        );
  
        console.log("API Response:", response.data); // Debugging API response
  
        if (response.data.head.code === 200) {
          setUserInfo(response.data.body.user[0]);
  
          // Directly set orders from the response
          setOrders(response.data.body.orders);
          console.log(response.data.body.orders);
        } else {
          console.error("Error fetching data:", response.data.head.msg);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setLoading(false);
      }
    };
  
    fetchUserData();
  }, [userID]);
  
  

  if (loading) return <div
  style={{
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    height: "100vh",
  }}
>
  <PuffLoader color="#D0C743" size={100} />
</div>;



  return (



    <div className="mainpage">
       {userID ? (         
       
      <div className="account-page">
        <p className="myaccount-title">My Account</p>
        <div className="account-container">
        <div className="user-info">
        <div className="profile-pic">
        <img
                      src={icon}
                      alt="Lord Balaji Silver Idol"
                      className="profile-pic-img"
                      loading="lazy"
                    />
        </div>
        <div className="user-details">
          <h3>{userInfo ? userInfo.name : "Loading..."}</h3>
          <p>{userInfo ? userInfo.email : "Loading..."}</p>
          <p>{userInfo ? userInfo.mobile : "Loading..."}</p>
        </div>
      </div>
          <div className="tab-container">
            {/* Tabs Section */}
            <div className="tabs">
              <button
                className={`tab ${activeTab === "Orders" ? "active" : ""}`}
                onClick={() => setActiveTab("Orders")}
              >
                Orders
              </button>
              <button
                className={`tab ${activeTab === "Address" ? "active" : ""}`}
                onClick={() => setActiveTab("Address")}
              >
                Address
              </button>
              <button
                className={`tab ${activeTab === "Settings" ? "active" : ""}`}
                onClick={() => setActiveTab("Settings")}
              >
                Settings
              </button>
            </div>

            {/* Conditionally render content based on active tab */}
            <div className="tab-content">
              {/* ------------------------order tab content start----------------------- */}
              {activeTab === "Orders" && (
  <div className="order-list">
    <h4>Recent Orders</h4>

    {/* Display message if no orders are found */}
    {orders && orders.length > 0 ? (
  <div className="orders">
    {orders.map((orderGroup, groupIndex) => (
      <div
        key={groupIndex}
        className={`order-group ${orderGroup.order_status?.order_status === "Processing" ? "border-processing" : ""}`}
      >
        {console.log("Order Status:", orderGroup.order_status)}

        {/* Order Status Container */}
        {orderGroup.order_status ? (
          <div className="orderstatus-container">
            <p className="orderstatus-container-p">
              Order Total: {new Intl.NumberFormat("en-IN").format(orderGroup.order_total) || "N/A"}
            </p>
            <p className="orderstatus-container-p">
              Order Status: {orderGroup.order_status || "N/A"}
            </p>
            <p className="orderstatus-container-p">
              Order Tracking: {orderGroup.order_note || " "}
            </p>
          </div>
        ) : (
          <p>No order status available</p>
        )} &nbsp;

        {/* Individual Products in the Order */}
        {Array.isArray(orderGroup.order_detail) && orderGroup.order_detail.length > 0 ? (
          orderGroup.order_detail.map((order, index) => (
            <div key={index} className="myaccount-order-item">
              <img
                src={order.image}
                alt={order.product_name}
                className="myaccount-product-image"
                loading="lazy"
              />
              <div className="myaccount-order-details">
                <div className="myaccount-order-proname-status">
                  <p className="myaccount-product-name">{order.product_name}</p>
                  <p
                    className={`myaccount-status ${
                      order.orderstatus === "0" && order.cancel === "0"
                        ? "Ordered"
                        : order.orderstatus === "1"
                        ? "Delivered"
                        : "Cancelled"
                    }`}
                  >
                    {order.orderstatus === "0" && order.cancel === "0"
                      ? "Ordered"
                      : order.orderstatus === "1"
                      ? "Delivered"
                      : "Cancelled"}
                  </p>
                </div>
                <div className="myaccount-product-info">
                  <p className="myaccount-product-code">
                    Order No:{" "}
                    <span style={{ color: "black" }}>
                      {order.order_id}-{order.order_no}
                    </span>
                  </p>
                  <p className="myaccount-order-date">
                    Order Date:{" "}
                    <span style={{ color: "black" }}>{order.date}</span>
                  </p>
                </div>
                <div className="myaccount-product-info  myaccount-productweight">
                  <p className="myaccount-product-code">
                    Weight:{" "}
                    <span style={{ color: "black" }}>
                      {order.weight}
                    </span>
                  </p>
                  <p className="myaccount-order-date">
                    Purity:{" "}
                    <span style={{ color: "black" }}>{order.purity}</span>
                  </p>
                </div>
                <div className="myaccount-price-qty">
                  <p className="myaccount-price">
                    <i className="bi bi-currency-rupee"></i>
                    {new Intl.NumberFormat("en-IN").format(order.price)}
                  </p>
                  <p className="myaccount-qty">
                    <span className="myaccount-quantity">Qty</span> &nbsp;
                    {order.qty}
                  </p>
                </div>
              </div>

              {/* Conditionally Render Cancel Order Button */}
              {order.orderstatus === "0" && order.cancel !== "1" && (
                <div className="myaccount-cancel-section">
                  <button
                    className="cancel-order-btn"
                    onClick={() => handleCancelOrder(order)}
                  >
                    Cancel Order
                  </button>
                  <p className="cancel-p">
                    Cancel within{" "}
                    <span className="cancel-time">48 hrs</span>
                  </p>
                </div>
              )}
            </div>
          ))
        ) : (
          <p>No order details available</p>
        )}
      </div>
    ))}
  </div>
) : (
  <p>No orders found</p>
)}



  </div>
              )}
              {/* ------------------------order tab content start----------------------- */}

              {/* ------------------------address tab content start----------------------- */}

              <>
      {/* Address section */}
      {activeTab === "Address" && (
       <div className="address-section">
       <div className="address-section-title">
         <h4>Saved Addresses</h4>
         <button
           className="add-address-button"
           style={{ float: "right" }}
           onClick={() => handleShowModal("add")}
         >
           <IoIosAddCircleOutline style={{ width: "20.25px", height: "20.25px", marginRight: "8px" }} /> Add 
         </button>
       </div>
       <div className="address-content">
         <div className="address-list">
           {addresses.map((address, index) => (
             <div key={address.address_id} className="address-item">
               {/* <input
                 type="checkbox"
                 id={`address${index}`}
                 className="address-checkbox"
                 checked={selectedAddress?.address_id === address.address_id}
                 onChange={() => handleAddressSelect(address)}
               /> */}
               <input
  type="checkbox"
  id={`address${index}`}
  className="address-checkbox"
  checked={selectedAddress?.address_id === address.address_id}
  onChange={() => handleAddressSelect(address)}
/>
               <div className="address-info">
                 <span className="address-name">{address.name}</span>
                 <label htmlFor={`address${index}`} className="address-label">
                   {address.address}, <br />
                   {address.phonenumber}, <br />
                   {address.landmark},
                   {/* {address.label}, <br /> */}
                   {address.city}, {address.state}, {address.pincode || "N/A"}
                 </label>
               </div>
               <button
                 className="edit-address-button"
                 onClick={() => handleShowModal("edit", address)}
               >
                 <FiEdit style={{ width: "17.25px", height: "17.25px" }} /> &nbsp;
                 Edit
               </button>
             </div>
           ))}
         </div>
       </div>

       {/* Modal for Add/Edit Address */}
       <Modal show={showModal} onHide={() => setShowModal(false)} centered>
         <Modal.Header closeButton>
           <Modal.Title>{formType === "add" ? "Add Address" : "Edit Address"}</Modal.Title>
         </Modal.Header>
         <Modal.Body>
           <form onSubmit={handleFormSubmit} className="address-form">
             <div className="form-group">
               <label htmlFor="name">Name</label>
               <input
                 type="text"
                 id="name"
                 name="name"
                 className="input-field"
                 value={formData.name}
                 onChange={handleChange}
               />
               
             </div>
             <div style={{marginLeft:"35%",color:"red",fontSize:"13px",marginTop:"-10px"}}>{formErrors.name && <p className="error-text">{formErrors.name}</p>}</div>
             <div className="form-group">
               <label htmlFor="phonenumber">Phone Number</label>
               <input
                 type="text"
                 id="phonenumber"
                 name="phonenumber"
                 className="input-field"
                 value={formData.phonenumber}
                 onChange={handleChange}
               />
               
             </div>
             <div style={{marginLeft:"35%",color:"red",fontSize:"13px",marginTop:"-10px"}}>{formErrors.phonenumber && <p className="error-text">{formErrors.phonenumber}</p>}</div>

             <div className="form-group">
               <label htmlFor="address">Address</label>
               <textarea
                 id="address"
                 name="address"
                 className="input-field address-box"
                 value={formData.address}
                 onChange={handleChange}
               />
             </div>
             <div style={{marginLeft:"35%",color:"red",fontSize:"13px",marginTop:"-10px"}}>{formErrors.address && <p className="error-text">{formErrors.address}</p>}</div>

             {/* <div className="form-group">
               <label htmlFor="label">Label</label>
               <input
                 type="text"
                 id="label"
                 name="label"
                 className="input-field"
                 value={formData.label}
                 onChange={handleChange}
               />
               {formErrors.label && <p className="error-text">{formErrors.label}</p>}
             </div> */}
            
             <div className="form-group">
               <label htmlFor="Landmark">Landmark</label>
               <input
                 type="text"
                 id="landmark"
                 name="landmark"
                 className="input-field"
                 value={formData.landmark}
                 onChange={handleChange}
               />
               
             </div>

             <div style={{marginLeft:"35%",color:"red",fontSize:"13px",marginTop:"-10px"}}>{formErrors.landmark && <p className="error-text">{formErrors.landmark}</p>}</div>

             <div className="form-group">
               <label htmlFor="city">City</label>
               <input
                 type="text"
                 id="city"
                 name="city"
                 className="input-field"
                 value={formData.city}
                 onChange={handleChange}
               />
               
             </div>
             <div style={{marginLeft:"35%",color:"red",fontSize:"13px",marginTop:"-10px"}}>{formErrors.city && <p className="error-text">{formErrors.city}</p>}</div>

             <div className="form-group">
               <label htmlFor="state">State</label>
               <input
                 type="text"
                 id="state"
                 name="state"
                 className="input-field"
                 value={formData.state}
                 onChange={handleChange}
               />
             </div>
             <div style={{marginLeft:"35%",color:"red",fontSize:"13px",marginTop:"-10px"}}>{formErrors.state && <p className="error-text">{formErrors.state}</p>}
             </div>

             <div className="form-group">
               <label htmlFor="pincode">Pincode</label>
               <input
                 type="text"
                 id="pincode"
                 name="pincode"
                 className="input-field"
                 value={formData.pincode}
                 onChange={handleChange}
               />
               
             </div>
             <div style={{marginLeft:"35%",color:"red",fontSize:"13px",marginTop:"-10px"}}>{formErrors.pincode && <p className="error-text">{formErrors.pincode}</p>}
             </div>
             <button type="submit" className="submit-button">Submit</button>
           </form>
         </Modal.Body>
       </Modal>
     </div>
      )}
    </>


              {/* ------------------------address tab content end----------------------- */}

              {/* ------------------------settings tab content start----------------------- */}

              <>
      {activeTab === "Settings" && (
      <div className="settings-section">
      {/* Email Section */}
      <div className="settings-item">
        <div className="settings-info">
          <span className="email-id">
            Email ID <br />
            <span className="email-text">{userInfo ? userInfo.email : "Loading..."}</span>
          </span>
          <span className="verified-tick">
            <MdOutlineVerified />
            <span className="verified-text">Verified</span>
          </span>
        </div>
        <button className="edit-button" onClick={() => handleEditClick("email")}>
          <FiEdit style={{ width: "17.25px", height: "17.25px" }} /> &nbsp; Edit
        </button>
      </div>
      <br />

      {/* Mobile Number Section */}
      <div className="settings-item">
        <div className="settings-info">
          <span className="mobile-number">
            Mobile Number <br />
            <span className="mobile-text">{userInfo ? userInfo.mobile : "Loading..."}</span>
          </span>
          <span className="verified-tick">
            <MdOutlineVerified />
            <span className="verified-text">Verified</span>
          </span>
        </div>
        <button className="edit-button" onClick={() => handleEditClick("mobile")}>
          <FiEdit style={{ width: "17.25px", height: "17.25px" }} /> &nbsp; Edit
        </button>
      </div>

      {/* Edit Modal */}
      <Modal show={showModal} onHide={handleModalClose} centered>
        <Modal.Header closeButton>
          <Modal.Title>{editType === "email" ? "Edit Email" : "Edit Mobile Number"}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {editType === "email" && step === "edit" ? (
            <div className="edit-form">
              <div className="settings-info">
                <span className="email-id">
                  Current Email <br />
                  <span className="email-text">{userInfo.email}</span>
                </span>
              </div>
              <div className="input-group">
                <label htmlFor="new-email" className="input-label">
                  New Email ID
                </label>
                <input
                  type="email"
                  id="new-email"
                  placeholder="Enter new email"
                  className="input-field"
                  value={newEmail}
                  onChange={(e) => setNewEmail(e.target.value)}
                />
              </div>
              <button
                className="send-code-button"
                onClick={handleSendVerificationCode}
                disabled={loading}
              >
                {loading ? "Sending..." : "Send Verification Code"}
              </button>
            </div>
          ) : editType === "email" && step === "otp" ? (
            <div className="otp-form">
              <h4>Enter OTP</h4>
              <div className="input-group">
                <label htmlFor="otp" className="input-label">
                  Verification Code
                </label>
                <input
                  type="text"
                  id="otp"
                  placeholder="Enter OTP"
                  className="input-field"
                  value={otp}
                  onChange={(e) => setOtp(e.target.value)}
                />
              </div>
              <button
                className="verify-button"
                onClick={handleVerifyOtp}
                disabled={loading}
              >
                {loading ? "Verifying..." : "Verify"}
              </button>
            </div>
          ) : editType === "mobile" && step === "edit" ? (
            <div className="edit-form">
              <div className="settings-info">
                <span className="email-id">
                   Current Mobile Number <br />
                  <span className="email-text">{userInfo.mobile}</span>
                </span>
              </div>
              <div className="input-group">
                <label htmlFor="new-mobile" className="input-label">
                  New Mobile Number
                </label>
                <input
                  type="tel"
                  id="new-mobile"
                  placeholder="Enter New Mobile Number"
                  className="input-field"
                  value={newMobile}
                  onChange={(e) => setNewMobile(e.target.value)}
                />
              </div>
              <button
                className="send-code-button"
                onClick={HandleMobileEdit}
                disabled={loading}
              >
                Submit
              </button>
            </div>
          ) : null}
          
        </Modal.Body>
      </Modal>
    </div>
      )}
    </>

              {/* ------------------------settings tab content end----------------------- */}
            </div>
          </div>
        </div>
      </div>
    
       ) : (
       null
    )}
    </div>
  );
};

export default MyAccount;
