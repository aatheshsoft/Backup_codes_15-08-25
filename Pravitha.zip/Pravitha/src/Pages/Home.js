import { useState, useEffect,useRef } from "react";
import ExampleCarouselImage from "../Assets/banner1.jpg";
import ExampleCarouselImage1 from "../Assets/banner3.jpg";
import ExampleCarouselImage2 from "../Assets/sub-banner2.jpg";
import ExampleCarouselImage3 from "../Assets/druthik-druthik-boat-1.jpg";
import { Carousel, Card, Button } from "react-bootstrap";
import { Row, Col } from 'react-bootstrap';
import Logo from "../Assets/figma1.png";
import Logo1 from "../Assets/figma1.png";
import Logo2 from "../Assets/figma2.png";
import Logo3 from "../Assets/figma3.png";
// import Logo4 from '../Assets/grocery.jpg'
import Logo5 from "../Assets/figma4.png";
import Logo6 from "../Assets/womencheppal.jpg";
import { Link } from "react-router-dom";
// import Scroll from "./Scroll";
import { Swiper, SwiperSlide } from 'swiper/react';
import { Navigation, Autoplay, Pagination  } from 'swiper/modules'; // Updated import
import 'swiper/css'; // Core Swiper styles
import 'swiper/css/navigation'; // Navigation styles
import 'swiper/css/autoplay';
import Whyus from "../Components/Whyus";
import Banner from "../Components/Banner";
import { useNavigate } from "react-router-dom";
import PuffLoader from "react-spinners/PuffLoader";




function Home() {

  const [index, setIndex] = useState(0);
  const [categories, setCategories] = useState([]);
  const [newArrivals, setNewArrivals] = useState([]);
  const [trendings, setTrendings] = useState([]);
  const navigate = useNavigate();
  const swiperRef = useRef(null);
  const [loading, setLoading] = useState(false); 


  useEffect(() => {
    const startAutoplay = () => {
      if (swiperRef.current && swiperRef.current.autoplay) {
        swiperRef.current.autoplay.stop(); // Stop any current autoplay
        swiperRef.current.autoplay.start(); // Force restart autoplay
      }
    };
  
    // Add a slight delay to ensure Swiper initializes fully
    const timer = setTimeout(startAutoplay, 100);
    return () => clearTimeout(timer);
  }, []);
  

  // Function to handle navigation
  const handleCategoryClick = (category) => {
    const { main_category_name, sub_category_name, main_category_id, sub_sub_category_id } = category;
  
    localStorage.setItem("selectedcategoryId", sub_sub_category_id);
    localStorage.setItem("sub_sub_category_id", "");
  
    console.log("Navigating with:");
    console.log("Main Category ID:", main_category_id);
    console.log("Sub Category ID (mapped from Sub Sub Category ID):", sub_sub_category_id);
  
    navigate(`/shopbycategory/${main_category_name}/${sub_category_name}`, {
      state: { 
        main_category_id, 
        sub_category_id: sub_sub_category_id // ✅ Passing sub_sub_category_id as sub_category_id
      }
    });
  };
  



  const handleSubCategoryClick = (trending) => {
    const { product_id } = trending;
    localStorage.setItem('selectedProductId1', 0);
    localStorage.setItem('selectedProductId2', 0);
    localStorage.setItem('selectedProductId3', 0);
    localStorage.setItem('selectedProductId4', 0);

    localStorage.setItem('selectedProductId', product_id);
    navigate(`/productdetail/${product_id}`);  // Navigate to Product Detail page with product_id
  };
  
  const handleNewArrivalsClick = (newArrivals) => {
    const { product_id,product_name } = newArrivals;
    localStorage.setItem('selectedProductId', 0);
    localStorage.setItem('selectedProductId1', product_id);
    localStorage.setItem('selectedProductId3', 0);
    localStorage.setItem('selectedProductId4', 0);

    localStorage.setItem('selectedProductId2', 0);

    navigate(`/productdetail/${product_name}`);  // Navigate to Product Detail page with product_id
  };
  


  const handleSelect = (selectedIndex) => {
    setIndex(selectedIndex);
  };

  useEffect(() => {
    // Fetch categories from API
    setLoading(true);

    fetch('https://pravithajewels.com/customerapp/home.php', {
      method: 'POST',
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.head.msg === 'Success') {
          setCategories(data.body.allsubcategory);
          localStorage.setItem("sub_sub_category_id",data.body.allsubcategory[0].sub_sub_category_id);
          localStorage.setItem("main_category_id",data.body.allsubcategory[0].main_category_id);
          console.log(localStorage.setItem("sub_sub_category_id",data.body.allsubcategory[0].sub_sub_category_id));
          setNewArrivals(data.body.new);
          setTrendings(data.body.trending);
        }
      })

      .catch((error) => console.error('Error fetching categories:', error));
      setLoading(false);
  }, []);
console.log(categories);

useEffect(() => {
  window.scrollTo(0, 0);
}, []);

useEffect(() => {
  if (swiperRef.current) {
    swiperRef.current.navigation.update(); // Update navigation status
    swiperRef.current.allowSlideNext = true; // Unlock next slide
    swiperRef.current.allowSlidePrev = true; // Unlock previous slide
    if (swiperRef.current.isLocked) {
      swiperRef.current.isLocked = false; // Ensure Swiper is unlocked
    }
  }
}, []);

/* ---------------------back navigation stopping code----------------------- */


useEffect(() => {
  // Prevent the back button by manipulating the browser history stack
  const handlePopState = (e) => {
    // You can perform your custom logic here (e.g., redirect to a specific page)
    navigate("/home"); // Ensure it stays on the home page when back is pressed
  };

  // Listen for popstate event which is triggered when the user clicks the back button
  window.addEventListener("popstate", handlePopState);

  // Add a new history entry so that the back button goes to your home page
  window.history.pushState(null, "", window.location.href);

  return () => {
    // Clean up event listener when the component is unmounted
    window.removeEventListener("popstate", handlePopState);
  };
}, [navigate]);


  return (
    <div className="mainpage">
      {loading ? (
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            height: "100vh",
          }}
        >
          <PuffLoader color="#D0C743" size={100} />
        </div>
      ) : (
      <>
      <Banner />
      {/* <Carousel activeIndex={index} onSelect={handleSelect} interval={2000}>
        <Carousel.Item>
          <img
            src={ExampleCarouselImage}
            alt="Banner 1"
            className="d-block w-100"
          />

          <Carousel.Caption>
            <h3>First slide label</h3>
            <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item>
          <img
            src={ExampleCarouselImage1}
            alt="Banner 1"
            className="d-block w-100"
          />
          <Carousel.Caption>
            <h3>Second slide label</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item>
          <img
            src={ExampleCarouselImage1}
            alt="Banner 1"
            className="d-block w-100"
          />
          <Carousel.Caption>
            <h3>Third slide label</h3>
            <p>
              Praesent commodo cursus magna, vel scelerisque nisl consectetur.
            </p>
          </Carousel.Caption>
        </Carousel.Item>
      </Carousel> */}
     

      {/* <div className="cardimg  custom-shadow">
        <Card style={{ width: "21rem" }} className="sub-banner  custom-shadow">
          <img
            src={ExampleCarouselImage2}
            alt="Banner 1"
            className="d-block w-100"
          />

          <Badge className="badge">
            Diwali <br></br> Offer{" "}
          </Badge>

          <Card.Body>
            <Card.Title> Trending Shoes</Card.Title>
            <Card.Text>Puma, Adidas & more</Card.Text>
            <Button variant="primary" className="homebtn">
              Shop Now
            </Button>
          </Card.Body>
        </Card>

        <Card style={{ width: "21rem" }} className="sub-banner custom-shadow">
          <img
            src={ExampleCarouselImage3}
            alt="Banner 1"
            className="d-block w-100"
            style={{ height: "190px" }}
          />
          <Card.Body>
            <Card.Title>boAT Headsets</Card.Title>
            <Card.Text style={{ color: "darkred" }}>
              Top Deals. Grab or Gone
            </Card.Text>
            <Button variant="primary" className="homebtn">
              Shop Now
            </Button>
          </Card.Body>
        </Card>

        <Card style={{ width: "21rem" }} className="sub-banner custom-shadow">
          <img
            src={ExampleCarouselImage2}
            alt="Banner 1"
            className="d-block w-100"
          />
          <Card.Body>
            <Card.Title>Trending Shoes</Card.Title>
            <Card.Text>Puma, Adidas & more</Card.Text>
            <Button variant="primary" className="homebtn">
              Shop Now
            </Button>
          </Card.Body>
        </Card>

        <Card style={{ width: "21rem" }} className="sub-banner custom-shadow">
          <img
            src={ExampleCarouselImage2}
            alt="Banner 1"
            className="d-block w-100"
          />
          <Card.Body>
            <Card.Title>Trending Shoes</Card.Title>
            <Card.Text>Puma, Adidas & more.</Card.Text>
            <Button className="homebtn">Shop Now</Button>
          </Card.Body>
        </Card>
      </div> */}

      {/*--------------------->  sub banner end <----------------------------*/}

      {/*---------------------> Shop Our category page start <----------------------------*/}

      <div className="newarr custom-shadow">
      <div>
        <h4 className="head">Shop our category</h4>
        <div className="underline"></div>
      </div>

      <div className="newarrival">
      
      
      <Swiper
        onSwiper={(swiper) => {
          console.log('Current Breakpoint:', swiper.currentBreakpoint);
          swiperRef.current = swiper; // Assign swiper instance
        }}
        modules={[Navigation, Autoplay]}
        spaceBetween={5}
        slidesPerView={4}
        loop={categories.length > 1}
        autoplay={{
          delay: 1000,
          disableOnInteraction: false,
        }}
        navigation={{
          prevEl: '.custom-prev',
          nextEl: '.custom-next',
        }} // Attach custom buttons
        breakpoints={{
          320: { slidesPerView: 1 },
          375: { slidesPerView: 1.4 },
          480: { slidesPerView: 2 },
          768: { slidesPerView: 3 },
          1024: { slidesPerView: 4 },
          1200: { slidesPerView: 4 },
          1400: { slidesPerView: 4 },
        }}
      >
        
      {/* Custom Navigation Buttons */}
      <button className="custom-prev">❮</button>
      <button className="custom-next">❯</button>
        {categories.map((category) => (
          <SwiperSlide key={category.sub_category_id}>
            <div
              className="sub-banner custom-shadow"
              onClick={() => handleCategoryClick(category)}
              style={{ cursor: 'pointer' }}
            >
              <Card>
                <Card.Img
                  variant="top"
                  src={category.image}
                  alt={category.sub_category_name}
                  className="img12"
                  loading="lazy"
                />
                <Card.Body className="text-center">
                  <Card.Title className="product-title-name">
                    {category.sub_category_name}
                  </Card.Title>
                </Card.Body>
              </Card>
            </div>
          </SwiperSlide>
        ))}
      </Swiper>




      </div>
    </div>


      {/*--------------------->  Shop Our category page end <----------------------------*/}

      {/*---------------------> New Arrival Page start <----------------------------*/}

      <div className="newarrivals custom-shadow">
      <div>
        <h4 className="head1" style={{ color: "white" }}>New Arrivals</h4>
        <div className="underline"></div>
      </div>

      <div className="newarrival123">
        <Swiper
           onSwiper={(swiper) => {
            console.log('Current Breakpoint:', swiper.currentBreakpoint);
            swiperRef.current = swiper;
          }}
          modules={[Navigation, Autoplay]}
          spaceBetween={10}
          slidesPerView={3}
          navigation={{
            prevEl: '.custom-prev',
            nextEl: '.custom-next',
          }} // Attach custom buttons
          autoplay={{ delay: 1000, disableOnInteraction: false }}
          loop={newArrivals.length > 1}
          playsinline
          breakpoints={{
            320: { slidesPerView: 1 }, // Mobile screens
            768: { slidesPerView: 2 }, // Tablets and above
            1024: { slidesPerView: 3},
          }}
        >
           {/* Custom Navigation Buttons */}
      <button className="custom-prev newarrival-naigation-button">❮</button>
      <button className="custom-next newarrival-naigation-button">❯</button>
          {newArrivals.map((newArrivals, index) => (
            <SwiperSlide key={newArrivals.product_id || index}>
              <Card className="sub-banner123 custom-shadow card-body-centered" style={{  position: 'relative' }} onClick={() => handleNewArrivalsClick(newArrivals)} >
                <div className="new-card-img">
                <img 
                  src={newArrivals.image}
                  alt={newArrivals.product_name}
                  loading="lazy"
                  className="d-block w-100 img12"
                  style={{ cursor: "pointer" }}
                  onError={(e) => { e.target.src = 'https://via.placeholder.com/150'; }}
                />
                </div>
                <Card.Body className="card-body-centered" style={{ textAlign: 'center' }}>
                  <p className="product-name1">{newArrivals.product_name}</p>
                  <Button className="centered-button">Explore Now</Button>
                </Card.Body>
              </Card>
            </SwiperSlide>
          ))}
        </Swiper>
      </div>
    </div>


     <div>
           <Whyus />
     </div>
     <div className="product-swiper">
      <h2 className="section-title-home">Shop our trending collections</h2>
      <div className="underline12"></div>
      <div className="newarrival">
      <Swiper
     onSwiper={(swiper) => {
      console.log('Current Breakpoint:', swiper.currentBreakpoint);
      swiperRef.current = swiper;
    }}
        modules={[Autoplay, Pagination, Navigation]}
        navigation={{
          prevEl: '.custom-prev',
          nextEl: '.custom-next',
        }} // Attach custom buttons
        slidesPerView={4}
        spaceBetween={5}
        loop={trendings.length > 1}
        playsinline
        autoplay={{
        delay: 1000,           // Delay in milliseconds for the auto swipe
        disableOnInteraction: false,  // Allows autoplay to continue after user interaction
      }}
        pagination={{ clickable: true }}
        breakpoints={{
          320: { slidesPerView: 1 },
          375: { slidesPerView: 1.4 },
          480: { slidesPerView: 2 },
          768: { slidesPerView: 3, spaceBetween: 25 },
          1024: { slidesPerView: 4, spaceBetween: 30 },
      }}
      
    >
          {/* Custom Navigation Buttons */}
          <button className="custom-prev">❮</button>
      <button className="custom-next">❯</button>
    {trendings.map((trending) => (
          <SwiperSlide key={trending.product_id}> 
            <div  key={trending.product_id}
            onClick={() => handleSubCategoryClick(trending)}
            style={{ cursor: "pointer" }}
            >
            <div className="productdetail-product-card">
              
              <div className="productdetail-product-image-section">
                <img
                  src={trending.image}
                  alt={trending.product_name}
                  className="product-image"
                  loading="lazy"
                />
              </div>
              <div className="product-info-section">
                <h3 className="product-name">{trending.product_name}</h3>
                <p className="product-price">
                <i class="bi bi-currency-rupee"></i>{new Intl.NumberFormat("en-IN").format(trending.price)}{' '}
                  <span className="product-discount">
                  {/* {console.log("line 430 "+trending.discount)} */}
                  {trending.discount !== "0" ? `[${trending.discount} % Off]` : ""}

                    {/* [{trending.discount} % Off] */}
                  </span>
                </p>
              </div>
            </div>
            </div>
          </SwiperSlide>
        ))}
      </Swiper>
      </div>
    </div>
      {/* <Scroll /> */}
      </>
      )}
    </div>
  );
}

export default Home;
 