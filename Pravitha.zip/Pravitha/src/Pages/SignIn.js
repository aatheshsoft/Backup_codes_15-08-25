import React, { useState } from 'react';
import { Form, Button } from 'react-bootstrap';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import axios from 'axios';
import Spinner from 'react-bootstrap/Spinner';

const SignInForm = () => {
  const [formData, setFormData] = useState({
    email: '', // Change username to email for API consistency
    password: '',
    captcha: ''
  });
  const [loading,setLoading] = useState(false)
  const [error, setError] = useState(null);
  const [isForgotPassword, setIsForgotPassword] = useState(false); // New state to toggle between sign-in and forgot password form
  const [successMessage, setSuccessMessage] = useState(null); // To display success message after email submission
  const navigate = useNavigate();
  const location = useLocation();

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmitSignIn = async (e) => {
    e.preventDefault();
    setError(null);
  
    try {
      const response = await axios.post('https://pravithajewels.com/customerapp/login.php', {
        email: formData.email,
        password: formData.password
      });
  
      if (response.data.head.code === 200) {
        console.log('Login successful');
        localStorage.setItem('userID', response.data.body.user_id);
        localStorage.setItem('Email', response.data.body.email);
        localStorage.setItem('username', response.data.body.name);
  
        const redirectTo = location.state?.redirectTo || '/';
        navigate(redirectTo);
      } else {
        setError(response.data.message || 'Login failed');
      }
    } catch (err) {
      setError('An error occurred. Please try again.');
      console.error(err);
    }
  };

  const handleSubmitForgotPassword = async (e) => {
    e.preventDefault();
    setSuccessMessage(null);
    setLoading(true);
    setError(null);

    try {
      const response = await axios.post('https://pravithajewels.com/customerapp/forgot_password.php', {
        email: formData.email
      });

      if (response.data.head.code === 200) {
        setSuccessMessage('Password reset link has been sent to your email.');
        // After 3 seconds, clear success message and return to sign-in form
        setTimeout(() => {
          setSuccessMessage(null);
          setIsForgotPassword(false);
        }, 3000);
      } else {
        setError(response.data.message || 'Failed to send password reset link.');
      }
    } catch (err) {
      setError('An error occurred. Please try again.');
      console.error(err);
    }finally{
      setLoading(false);
    }
  };

  return (
    <div className="signin-form-container">
      {!isForgotPassword ? (
        // Sign In Form
        <Form onSubmit={handleSubmitSignIn} className="p-4 border shadow">
          <h3 className="text-center">Sign In</h3>
          <hr />
          {error && <p className="text-danger text-center">{error}</p>}
          <Form.Group>
            <Form.Control
              type="text"
              name="email"
              placeholder="Email"
              value={formData.email}
              onChange={handleChange}
              required
            />
          </Form.Group>
          <Form.Group>
            <Form.Control
              type="password"
              name="password"
              placeholder="Password"
              value={formData.password}
              onChange={handleChange}
              required
            />
          </Form.Group>
          <p className="mt-3 ">
            <div className='forgot-button'><a href="#" onClick={() => setIsForgotPassword(true)} >Forgot Password?</a></div>
          
          </p>

          <Button type="submit" variant="warning" className="w-100 signinbutton">
            Sign In
          </Button>

          <p className="mt-3  text-center">
           
           <div > New user? <Link to="/signup">Sign Up</Link></div>
          </p>
        </Form>
      ) : (
        // Forgot Password Form
        <Form onSubmit={handleSubmitForgotPassword} className="p-4 border shadow">
          <h3 className="text-center">Reset Password</h3>
          <hr />
          {error && <p className="text-danger text-center">{error}</p>}
          {successMessage && <p className="text-success text-center">{successMessage}</p>}
          <Form.Group>
            <Form.Control
              type="email"
              name="email"
              placeholder="Enter your email"
              value={formData.email}
              onChange={handleChange}
              required
            />
          </Form.Group>
          <br/><br/>

          <Button type="submit" variant="warning" className="w-100">
          {loading ? (
    <Spinner animation="border" size="md" />
  ) : (
           <span>Submit</span> 
  )}
          </Button>

          <p className="mt-3 text-center">
            Remembered your password? <a href="#" onClick={() => setIsForgotPassword(false)}>Back to Sign In</a>
          </p>
        </Form>
      )}
    </div>
  );
};
export default SignInForm;