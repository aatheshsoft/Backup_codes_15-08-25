/* import React, { useState } from 'react';
import { Form, Button } from 'react-bootstrap';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';

const SignUpForm = () => {
  const [formData, setFormData] = useState({
    name: '',
    mobile: '',
    email: '',
    address: '',
    city: '',
    state: '',
    pincode: '',
    password: '',
    confirmPassword: '',
    captcha: ''
  });

  const [errors, setErrors] = useState({});
  const [successMessage, setSuccessMessage] = useState(null);
  const navigate = useNavigate();

  const handleNumericInput = (e) => {
    const value = e.target.value.replace(/\D/g, ''); // Remove non-numeric characters
    setFormData({ ...formData, [e.target.name]: value });
  };






  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const validateForm = () => {
    const newErrors = {};

     // Dynamic error messages for required fields
  Object.keys(formData).forEach((key) => {
    if (!formData[key]) {
      const fieldName = key
        .replace(/([A-Z])/g, " $1") // Convert camelCase to spaced words
        .replace(/^\w/, (c) => c.toUpperCase()); // Capitalize first letter
      newErrors[key] = `${fieldName} is required.`;
    }
  });

    // Validate email format
    const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (formData.email && !emailPattern.test(formData.email)) {
      newErrors.email = "Please enter a valid email address.";
    }

    // Validate password (at least 8 characters)
    if (formData.password && formData.password.length < 8) {
      newErrors.password = "Password must be at least 8 characters long.";
    }

    // Validate password match
    if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = "Passwords do not match.";
    }

    // Check captcha
    if (formData.captcha && !formData.captcha) {
      newErrors.captcha = "Captcha is required.";
    }

    // Validate mobile number (numeric only and length check)
    if (formData.mobile && !/^\d{10}$/.test(formData.mobile)) {
      newErrors.mobile = "Please enter a valid 10-digit mobile number.";
    }

    // Validate pincode (numeric only and length check)
    if (formData.pincode && !/^\d{6}$/.test(formData.pincode)) {
      newErrors.pincode = "Please enter a valid 6-digit pincode.";
    }

    // If any validation errors, return the error object
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0; // If no errors, return true
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSuccessMessage(null);

    if (!validateForm()) {
      return;
    }

    try {
      const response = await axios.post('https://pravithajewels.com/customerapp/register.php', {
        name: formData.name,
        phno: formData.mobile,
        email: formData.email,
        address: formData.address,
        city: formData.city,
        state: formData.state,
        pincode: formData.pincode,
        password: formData.password
      });
   console.log(response);
      if (response.data.head.code === 200) {
        setSuccessMessage("Registration successful! Redirecting to sign in...");
        setTimeout(() => navigate('/signin'), 2000);
      } else {
        setErrors({ global: response.data.message || "Registration failed." });
      }
    } catch (err) {
      setErrors({ global: "An error occurred. Please try again." });
      console.error(err);
    }
  };

  return (
    <div className="signup-form-container">
      <Form onSubmit={handleSubmit} className="p-4 border shadow">
        <h3 className="text-center">Sign Up</h3>
        <hr />
        {errors.global && <p className="text-danger text-center">{errors.global}</p>}
        {successMessage && <p className="text-success text-center">{successMessage}</p>}

        <Form.Group>
          <Form.Control
            type="text"
            name="name"
            placeholder="Name"
            value={formData.name}
            onChange={handleChange}
            isInvalid={!!errors.name}
          />
          <Form.Control.Feedback type="invalid">{errors.name}</Form.Control.Feedback>
        </Form.Group>

        <Form.Group>
          <Form.Control
            type="tel"
            name="mobile"
            placeholder="Mobile No"
            value={formData.mobile}
            onChange={handleNumericInput}
            isInvalid={!!errors.mobile}
          />
          <Form.Control.Feedback type="invalid">{errors.mobile}</Form.Control.Feedback>
        </Form.Group>

        <Form.Group>
          <Form.Control
            type="email"
            name="email"
            placeholder="Email ID"
            value={formData.email}
            onChange={handleChange}
            isInvalid={!!errors.email}
          />
          <Form.Control.Feedback type="invalid">{errors.email}</Form.Control.Feedback>
        </Form.Group>

        <Form.Group>
          <Form.Control
            type="text"
            name="address"
            placeholder="Address"
            value={formData.address}
            onChange={handleChange}
            isInvalid={!!errors.address}
          />
          <Form.Control.Feedback type="invalid">{errors.address}</Form.Control.Feedback>
        </Form.Group>

        <Form.Group>
          <Form.Control
            type="text"
            name="city"
            placeholder="City"
            value={formData.city}
            onChange={handleChange}
            isInvalid={!!errors.city}
          />
          <Form.Control.Feedback type="invalid">{errors.city}</Form.Control.Feedback>
        </Form.Group>

        <Form.Group>
          <Form.Control
            type="text"
            name="state"
            placeholder="State"
            value={formData.state}
            onChange={handleChange}
            isInvalid={!!errors.state}
          />
          <Form.Control.Feedback type="invalid">{errors.state}</Form.Control.Feedback>
        </Form.Group>

        <Form.Group>
          <Form.Control
            type="text"
            name="pincode"
            placeholder="Pincode"
            value={formData.pincode}
            onChange={handleNumericInput}            
            isInvalid={!!errors.pincode}
          />
          <Form.Control.Feedback type="invalid">{errors.pincode}</Form.Control.Feedback>
        </Form.Group>

        <Form.Group>
          <Form.Control
            type="password"
            name="password"
            placeholder="Password"
            value={formData.password}
            onChange={handleChange}
            isInvalid={!!errors.password}
          />
          <Form.Control.Feedback type="invalid">{errors.password}</Form.Control.Feedback>
        </Form.Group>

        <Form.Group>
          <Form.Control
            type="password"
            name="confirmPassword"
            placeholder="Confirm Password"
            value={formData.confirmPassword}
            onChange={handleChange}
            isInvalid={!!errors.confirmPassword}
          />
          <Form.Control.Feedback type="invalid">{errors.confirmPassword}</Form.Control.Feedback>
        </Form.Group>

        <Form.Group>
          <Form.Control
            type="text"
            name="captcha"
            placeholder="Captcha"
            value={formData.captcha}
            onChange={handleChange}
            isInvalid={!!errors.captcha}
          />
          <Form.Control.Feedback type="invalid">{errors.captcha}</Form.Control.Feedback>
        </Form.Group>

        <Button type="submit" variant="warning" className="w-100">
          Sign Up
        </Button>

        <p className="mt-3 text-center">
          Already have an account? <Link to="/signin">Sign In</Link>
        </p>
      </Form>
    </div>
  );
};

export default SignUpForm;
 */


import React, { useState } from 'react';
import { Form, Button } from 'react-bootstrap';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import ReCAPTCHA from 'react-google-recaptcha';

const SignUp = () => {
  const [formData, setFormData] = useState({
    name: '',
    mobile: '',
    email: '',
    address: '',
    city: '',
    state: '',
    pincode: '',
    password: '',
    confirmPassword: '',
  });
console.log("formData",formData);

  const [errors, setErrors] = useState({});
  const [successMessage, setSuccessMessage] = useState(null);
  const [captchaValue, setCaptchaValue] = useState(null);

  console.log('captchaValue',captchaValue);
  
  const navigate = useNavigate();

  // Handle numeric input fields
  const handleNumericInput = (e) => {
    const value = e.target.value.replace(/\D/g, '');
    setFormData({ ...formData, [e.target.name]: value });
  };

  // Handle input changes
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // Form validation
  const validateForm = () => {
    const newErrors = {};

    Object.keys(formData).forEach((key) => {
      if (!formData[key]) {
        const fieldName = key
          .replace(/([A-Z])/g, ' $1')
          .replace(/^\w/, (c) => c.toUpperCase());
        newErrors[key] = `${fieldName} is required.`;
      }
    });

    const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (formData.email && !emailPattern.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address.';
    }

    if (formData.password && formData.password.length < 8) {
      newErrors.password = 'Password must be at least 8 characters long.';
    }

    if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = 'Passwords do not match.';
    }

    if (!captchaValue) {
      newErrors.captcha = 'Captcha is required.';
    }

    if (formData.mobile && !/^\d{10}$/.test(formData.mobile)) {
      newErrors.mobile = 'Please enter a valid 10-digit mobile number.';
    }

    if (formData.pincode && !/^\d{6}$/.test(formData.pincode)) {
      newErrors.pincode = 'Please enter a valid 6-digit pincode.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    setSuccessMessage(null);
    setErrors({});

    if (!validateForm()) {
      return;
    }

    try {
      const response = await axios.post('https://pravithajewels.com/customerapp/register.php', {
        name: formData.name,
        phno: formData.mobile,
        email: formData.email,
        address: formData.address,
        city: formData.city,
        state: formData.state,
        pincode: formData.pincode,
        password: formData.password,
        recaptcha_token: captchaValue, 
      });

      if (response.data?.head?.code === 200) {
        setSuccessMessage('Registration successful! Redirecting to sign in...');
        setTimeout(() => navigate('/signin'), 2000);
      } else {
        const errorMsg = response.data?.head?.message || 'Registration failed.';
        setErrors({ global: errorMsg });
        console.error('API Error:', response.data);
      }
    } catch (err) {
      setErrors({ global: 'An error occurred. Please try again.' });
      console.error('Error:', err);
    }
  };

  // Captcha handler
  const handleCaptchaChange = (value) => {
    setCaptchaValue(value);
  };

  return (
    <div className="signup-form-container">
      <Form onSubmit={handleSubmit} className="p-4 border shadow">
        <h3 className="text-center">Sign Up</h3>
        <hr />
        {errors.global && <p className="text-danger text-center">{errors.global}</p>}
        {successMessage && <p className="text-success text-center">{successMessage}</p>}

        <Form.Group>
          <Form.Control
            type="text"
            name="name"
            placeholder="Name"
            value={formData.name}
            onChange={handleChange}
            isInvalid={!!errors.name}
          />
          <Form.Control.Feedback type="invalid">{errors.name}</Form.Control.Feedback>
        </Form.Group>

        <Form.Group>
          <Form.Control
            type="tel"
            name="mobile"
            placeholder="Mobile No"
            value={formData.mobile}
            onChange={handleNumericInput}
            isInvalid={!!errors.mobile}
          />
          <Form.Control.Feedback type="invalid">{errors.mobile}</Form.Control.Feedback>
        </Form.Group>

        <Form.Group>
          <Form.Control
            type="email"
            name="email"
            placeholder="Email ID"
            value={formData.email}
            onChange={handleChange}
            isInvalid={!!errors.email}
          />
          <Form.Control.Feedback type="invalid">{errors.email}</Form.Control.Feedback>
        </Form.Group>

        <Form.Group>
          <Form.Control
            type="text"
            name="address"
            placeholder="Address"
            value={formData.address}
            onChange={handleChange}
            isInvalid={!!errors.address}
          />
          <Form.Control.Feedback type="invalid">{errors.address}</Form.Control.Feedback>
        </Form.Group>

        <Form.Group>
          <Form.Control
            type="text"
            name="city"
            placeholder="City"
            value={formData.city}
            onChange={handleChange}
            isInvalid={!!errors.city}
          />
          <Form.Control.Feedback type="invalid">{errors.city}</Form.Control.Feedback>
        </Form.Group>

        <Form.Group>
          <Form.Control
            type="text"
            name="state"
            placeholder="State"
            value={formData.state}
            onChange={handleChange}
            isInvalid={!!errors.state}
          />
          <Form.Control.Feedback type="invalid">{errors.state}</Form.Control.Feedback>
        </Form.Group>

        <Form.Group>
          <Form.Control
            type="text"
            name="pincode"
            placeholder="Pincode"
            value={formData.pincode}
            onChange={handleNumericInput}
            isInvalid={!!errors.pincode}
          />
          <Form.Control.Feedback type="invalid">{errors.pincode}</Form.Control.Feedback>
        </Form.Group>

        <Form.Group>
          <Form.Control
            type="password"
            name="password"
            placeholder="Password"
            value={formData.password}
            onChange={handleChange}
            isInvalid={!!errors.password}
          />
          <Form.Control.Feedback type="invalid">{errors.password}</Form.Control.Feedback>
        </Form.Group>

        <Form.Group>
          <Form.Control
            type="password"
            name="confirmPassword"
            placeholder="Confirm Password"
            value={formData.confirmPassword}
            onChange={handleChange}
            isInvalid={!!errors.confirmPassword}
          />
          <Form.Control.Feedback type="invalid">{errors.confirmPassword}</Form.Control.Feedback>
        </Form.Group>

        <Form.Group>
          <div id="captcha" className="my-3">
            <ReCAPTCHA
              sitekey="6LesmIUqAAAAAGzAsSnEkontDV0bEh8tbvLperma"
              onChange={handleCaptchaChange}
            />
          </div>
          {errors.captcha && <p className="text-danger">{errors.captcha}</p>}
        </Form.Group>

        <Button type="submit" variant="warning" className="w-100">
          Sign Up
        </Button>

        <p className="mt-3 text-center">
          Already have an account? <Link to="/signin">Sign In</Link>
        </p>
      </Form>
    </div>
  );
};

export default SignUp;


