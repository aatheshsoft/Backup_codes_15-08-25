import React,{useEffect, useState} from 'react';
import backgroundImage from '../Assets/background.png'; 
import PuffLoader from "react-spinners/PuffLoader";




const CancellationPolicy = () => {
  const [loading, setLoading] = useState(true); // Loading state
  useEffect(() => {
    // Simulate data fetching or delay for loader
    const timer = setTimeout(() => {
      setLoading(false); // Stop loading after 3 seconds
    }, 3000);

    return () => clearTimeout(timer); // Cleanup timeout
  }, []);





useEffect(() => {
window.scrollTo(0, 0);
}, []);

  return (
    <div className='mainpage'>
       {loading ? (
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            height: "100vh",
          }}
        >
          <PuffLoader color="#D0C743" size={100} />
        </div>
      ) : (
        <>
        <div
      
      style={{
        backgroundImage: `url(${backgroundImage})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat',
        padding: '20px',
        color: '#333',
      }}
    >

      <h1 className="cancellation-policy-title">
        Cancellation Policy
      </h1>
</div>

<div className="cancellation-policy-container">
    
      <p>
        Pravitha Jewels believes in helping its customers as far as possible and has therefore adopted a liberal
        cancellation policy. Under this policy:
      </p>
      <ul>
        <li>
          <li>
            Cancellations will be considered only if the request is made within 2 days of placing the order.
            However, the cancellation request may not be entertained if the orders have been communicated to the
            vendors/merchants and they have initiated the process of shipping them.
          </li>
        
          <li>Pravitha Jewels does not accept cancellation requests for the following items like</li>
       <p className="indented">
        <ul >
            {/* <li >Gold Coins / Bars</li> */}
            <li >Silver Articles, Coins & Bars</li>
            <li >Customized Orders</li>
            <li >Make-to-Order & Special Products</li>
            </ul>
            </p>
        </li>
        <br />
          <p style={{marginLeft:"-30px"}}>
            However,Refund/replacement can be made if the customer establishes that the quality of the product delivered
            is not good.
          </p>
        <div className='cancellation-policy-point'>
        <li>
          <p>
            In case of receipt of damaged or defective items, please report the same to our Customer Service team
            within 2 days of receipt of the product. The request will be entertained once the merchant checks and
            determines the same at their end.
          </p>
        </li>
        <li>
          <p>
            In case you feel that the product received is not as shown on the site or as per your expectations, you
            must notify our customer service within 2 days of receiving the product. The team will take appropriate
            action based on your complaint.
          </p>
        </li>
        <li>
          <p>
            In case of complaints regarding products that come with a warranty from manufacturers, please refer the
            issue to them.
          </p>
        </li>
        {/* <li>
          <p>
            Refunds approved by Pravitha Jewels will take 6-8 days for the refund to be processed.
          </p>
        </li> */}
        <li>
          <p>
          Refund will be credited to customer account with in minimum 4 days to maximum 10 days after cancellation
          </p>
        </li>
        </div>
      </ul>
<br />
      <h2>Rights to Cancel Orders from Pravitha</h2>
      <ul>
        <li>Limited inventory of the product.</li>
        <li>Pricing or product information errors.</li>
        <li>Quality issues during inspection.</li>
        <li>Insufficient customer information or failed verification.</li>
        <li>Suspicious or fraudulent orders.</li>
        <li>Natural calamities or unforeseen circumstances.</li>
        <li>Serviceability issues.</li>
      </ul>
<br />
      <h2>Delivery Information</h2>
      <p>
        Pravitha Jewels offers FREE shipping above ₹50,000 on every order within India based on service
        availability. Your order will be shipped to you fully insured. We urge all customers to inspect the package
        for any damage or tampering before receiving or signing for receipt.
      </p>
      <p>Shipping Providers: BVC, Blue Dart</p>
      <p>
        For international buyers, orders are shipped and delivered through registered international courier companies
        and/or International Speed Post only. For domestic buyers, orders are shipped through registered domestic
        courier companies and/or Speed Post only.
      </p>
      <p>
        Orders are shipped within 0-7 days or as per the delivery date agreed at the time of order confirmation. Pravitha
        Jewels is not liable for any delay in delivery by the courier company or postal authorities and only guarantees to
        hand over the consignment to the courier company or postal authorities within the stipulated time frame.
      </p>
      <p>
        Delivery of all orders will be to the address provided by the buyer. Delivery will be confirmed via the registered
        email ID specified during registration. For any issues with delivery, please contact our helpdesk at
        info@pravithajewels.com.
      </p>
    </div>
    </>
      )}
    </div>
  
  )
}

export default CancellationPolicy