import React,{useEffect,useState} from "react";
import backgroundImage from '../Assets/background.png'; 
import PuffLoader from "react-spinners/PuffLoader";


const PrivacyPolicy = () => {
  const [loading, setLoading] = useState(true); // Loading state
  useEffect(() => {
    // Simulate data fetching or delay for loader
    const timer = setTimeout(() => {
      setLoading(false); // Stop loading after 3 seconds
    }, 3000);

    return () => clearTimeout(timer); // Cleanup timeout
  }, []);
    
    useEffect(() => {
        window.scrollTo(0, 0);
      }, []);


  return (
    <div className='mainpage'>
      {loading ? (
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            height: "100vh",
          }}
        >
          <PuffLoader color="#D0C743" size={100} />
        </div>
      ) : (
        <>
        <div   style={{
          backgroundImage: `url(${backgroundImage})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          backgroundRepeat: "no-repeat",
          width: "100%",
          height:"200px",
          padding: "20px 0",
          color: "black",
          textAlign: "center",
          fontSize: "2rem",
          marginBottom: "20px",
        }}>
         <h1
       className="return-policy-title"
       
      >
        Privacy Policy
      </h1>
      </div>
    <div className="return-policy-container">
   

      <ul className="return-policy-list">
        <li>
          <p > Welcome to Pravitha Jewels. We respect your privacy and are committed 
            to protecting your personal information. This Privacy Policy outlines how we collect, use, and safeguard your 
            information when you visit our website.</p>
        </li>
        {/* <li>
          <p>2.Required Documentation: Please provide a video of the packing process and the courier handover. Submit <br />
            your Government ID proof and one of the following bank documents:Bank statement,Passbook front page,Canceled chequeSend the required documentation via email and WhatsApp.
            </p >
          
        </li> */}
        <li>
          <p><strong>1.Information We Collect:</strong></p>
          <ul>
            <li><strong>a.Personal Information:</strong> When you make a purchase or create an account, we may collect personal information such as your name, email address, phone number, and shipping address.</li>
            <li><strong>b.Payment Information:</strong> For online transactions, we use Razorpay to process payments. We do not store your payment details on our servers. Razorpay handles all transaction information securely.</li>
            <li><strong>c.Usage Data:</strong> We may collect information on how you use our website, including your IP address, browser type, pages visited, and time spent on our site.</li>
           
          </ul>
        </li>
        <li>
          <p><strong>2.How We Use Your Information:</strong></p>
          <ul>
            <li><strong>a.Order Processing:</strong> To process and fulfill your orders, including sending order confirmations and shipping updates.</li>
            <li><strong>b.Customer Support:</strong> To respond to your inquiries and provide customer support.</li>
            <li><strong>c.Marketing:</strong> With your consent, we may send you promotional emails about new products, special offers, or other information we think you may find interesting.</li>
           
          </ul>
        </li>
        <li>
          <p><strong>3.Razorpay Transactions:</strong></p>
          <ul>
            <li><strong>a.Payment Security:</strong> Razorpay uses industry-standard encryption and security measures to protect your payment information during transactions.</li>
            <li><strong>b.Data Sharing:</strong> We share your personal and transaction details with Razorpay solely for the purpose of processing your payment. For more information on how Razorpay handles your data, please refer to Razorpay's privacy policy.</li>
            
           
          </ul>
        </li>
        <li>
          <p><strong>4. Data Security:</strong> We implement appropriate security measures to protect your personal information from unauthorized access, alteration, or disclosure. However, no method of transmission over the Internet or method of electronic storage is completely secure.</p>
          
        </li>
        <li>
          <p><strong>5. Third-Party Services:</strong> Our website may contain links to third-party services. This Privacy Policy does not apply to those services, and we are not responsible for their privacy practices. We encourage you to read the privacy policies of any third-party services you visit.</p>
          
        </li>
        <li>
          <p><strong>6.Your Rights:</strong>.</p>
          <ul>
            <li><strong>a.Access and Correction:</strong> You have the right to access and correct your personal information held by us.</li>
            <li><strong>b.Opt-Out:</strong> You can opt out of receiving marketing emails from us at any time by following the unsubscribe instructions in the emails.</li>
            
           
          </ul>
        </li>
        <li>
          <p><strong> Changes to This Privacy Policy:</strong> We may update this Privacy Policy from time to time. Any changes will be posted on this page with an updated revision date.

          
</p>
          
        </li>
        <li>
        <strong>Contact Us:</strong> If you have any questions or concerns about this Privacy Policy or our data practices, please contact us at <p href="mailto:info@pravithajewels.com">info@pravithajewels.com</p>
        </li>
       
      </ul>
    </div>
    </>
      )}
    </div>
  );
};

export default PrivacyPolicy;
