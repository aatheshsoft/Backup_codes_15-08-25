import React, { useState } from 'react';
import Logo2 from '../Assets/smartwatch.jpg'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {faIndianRupeeSign} from '@fortawesome/free-solid-svg-icons';



function Detailing() {
  const [showPaymentForm, setShowPaymentForm] = useState(false);
  const [showOrderHistory, setShowOrderHistory] = useState(false);

  const handleConfirmPayment = () => {
    setShowPaymentForm(true);
  };

  const handleConfirmOrder = () => {
    setShowOrderHistory(true);
  };
  return (
    <div className='mainpage2'>
      <div className='main123'>
        <div className='detail custom-shadow'>
          <div className="card-body">
            <h5 style={{ paddingBottom: "20px", fontWeight: "bold", textAlign: "center" }}>Delivery Address</h5>
            <form className="main-form full">
              <div className="row">
                <div className="col-12">
                  <div className="input-box form-group required">
                    <div className="row">
                      <label htmlFor="coupon-name" className="col-md-3 control-label">
                        First Name
                      </label>
                      <div className="col-md-5 form123">
                        <input
                          type="text"
                          className="form-control"
                          id="coupon-name"
                          required
                          placeholder="First Name"
                        />
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-12">
                  <div className="input-box form-group required">
                    <div className="row">
                      <label htmlFor="coupon-code" className="col-md-3 control-label">
                         Last Name
                      </label>
                      <div className="col-md-5 form123">
                        <input
                          type="text"
                          className="form-control"
                          id="coupon-code"
                          required
                          placeholder="Last Name"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="col-12">
                  <div className="input-box form-group required">
                    <div className="row">
                      <label htmlFor="start-date" className="col-md-3 control-label">
                        Mobile Number
                      </label>
                      <div className="col-md-5 form123">
                        <input
                          type="text"
                          className="form-control"
                          id="start-date"
                          required
                          placeholder="Mobile Number"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="col-12">
                  <div className="input-box form-group required">
                    <div className="row">
                      <label htmlFor="discount-type" className="col-md-3 control-label">
                        Alternate Number
                      </label>
                      <div className="col-md-5 form123">
                        <input
                          type="text"
                          className="form-control"
                          id="discount-type"
                          required
                          placeholder="Alternate Number"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="col-12">
                  <div className="input-box form-group required">
                    <div className="row">
                      <label htmlFor="end-date" className="col-md-3 control-label">
                        Email
                      </label>
                      <div className="col-md-5 form123">
                        <input
                          type="text"
                          className="form-control"
                          id="end-date"
                          required
                          placeholder="Email"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="col-12">
                  <div className="input-box form-group required">
                    <div className="row">
                      <label htmlFor="bank-details" className="col-md-3 control-label">
                        Delivery Address
                      </label>
                      <div className="col-md-5 form123">
                        <textarea
                          className="form-control"
                          id="bank-details"
                          required
                          placeholder="Delivery Address"
                        ></textarea>
                      </div>
                    </div>
                  </div>
                </div>

                

                <div className="col-12">
                  <div className="input-box form-group required">
                    <div className="row">
                      <label htmlFor="status-dropdown" className="col-md-3 control-label">
                        Delivery Time
                      </label>
                      <div className="col-md-5 form123">
                        <select className="form-control" id="status-dropdown" required>
                          <option value="">Time</option>
                          <option value="active">10.00AM to 12.00PM</option>
                          <option value="inactive">12.00PM to 3.00PM</option>
                          <option value="pending">3.00PM to 6.00PM</option>
                          <option value="expired">ANY</option>
                        </select>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-4 d-flex justify-content-end">
                  <button type="button" className="btn123" onClick={handleConfirmOrder}>Confirm</button>
                </div>
              </div>
            </form>
           
           <hr />

            {showOrderHistory && (
              <div>
                <h5 style={{ paddingBottom: "20px", fontWeight: "bold", textAlign: "center" }}>Order Summary</h5>
                
                {/* Display order history content here */}

                <div className='cartabc custom-shadow'>
        
                      <img src={Logo2} alt="Banner 1" className="d-block" style={{ height: "100px", width:'100px' }} />
                     <p style={{paddingLeft:"10px", fontSize:"16px"}}>Mi Xiaomi Smart Watch Band 8 Active 1.47"-Water Resistan....<span style={{fontSize:'12px',paddingLeft:"135px", fontWeight:'bold'}}>Delivery by Sat Jul 6 | Free </span><br></br>
            
                     <p style={{fontSize:'15px', color:"grey"}}> Black Strap, Free Size</p>
                    <p style={{fontSize:'15px', color:"grey"}}>seller: indian technologies</p>
                    <FontAwesomeIcon icon={faIndianRupeeSign} /> <span style={{fontWeight:"bold"}}>1199 only</span>
                      <span style={{fontSize:"12px", paddingLeft:"10px", color:'red', fontWeight:"bolder"}}>37% Offer</span>
                      </p>
                      <div className='price1'>
                             <h6 style={{color:"grey",paddingleftt:"20px"}}>Price Details</h6>
                             <p style={{paddingTop:"30px"}}>Price (1 item) <span style={{paddingLeft:"130px"}}><FontAwesomeIcon icon={faIndianRupeeSign} />1999</span></p>
                             <p>Discount<span style={{paddingLeft:"167px"}}><FontAwesomeIcon icon={faIndianRupeeSign} />1999</span></p>
                             <p>Delivery Charges<span style={{paddingLeft:"110px"}}><FontAwesomeIcon icon={faIndianRupeeSign} />1999</span></p>
                             <h6 style={{fontWeight:"bold"}}>Total Amount<span style={{paddingLeft:"130px"}}><FontAwesomeIcon icon={faIndianRupeeSign} />1999</span></h6>
                      </div>
                     </div>

                <div className="mt-4 d-flex justify-content-end">
                  <button type="button" className="btn123" onClick={handleConfirmPayment}>Confirm</button>
                </div>
              </div>
              
            )}
             <hr />
            {showPaymentForm && (
              <div>
                <h5 style={{ paddingBottom: "20px", fontWeight: "bold", textAlign: "center" }}>Payment Method</h5>
              
                <form className="main-form full">
                <div className="row">
                <div className="col-12">
                  <div className="input-box form-group required">
                    <div className="row">
                      <label htmlFor="coupon-name" className="col-md-3 control-label">
                        Card Number
                      </label>
                      <div className="col-md-5 form123">
                        <input
                          type="text"
                          className="form-control"
                          id="coupon-name"
                          required
                          placeholder="Card Number"
                        />
                      </div>
                    </div>
                  </div>
                  </div>
                </div>
                <div className="row">
                <div className="col-12">
                  <div className="input-box form-group required">
                    <div className="row">
                      <label htmlFor="coupon-name" className="col-md-3 control-label">
                        Cvv
                      </label>
                      <div className="col-md-5 form123">
                        <input
                          type="text"
                          className="form-control"
                          id="coupon-name"
                          required
                          placeholder="Enter Cvv"
                        />
                      </div>
                    </div>
                  </div>
                </div>
                </div>

                <div className="row">
                <div className="col-12">
                  <div className="input-box form-group required">
                    <div className="row">
                      <label htmlFor="coupon-name" className="col-md-3 control-label">
                        Name
                      </label>
                      <div className="col-md-5 form123">
                        <input
                          type="text"
                          className="form-control"
                          id="coupon-name"
                          required
                          placeholder="Card Holder Name"
                        />
                      </div>
                    </div>
                  </div>
                  </div>
                </div>

                
                <div className="row">
                    <div className="col-12">
                      <div className="input-box form-group required">
                        <div className="row">
                             <label htmlFor="card-type" className="col-md-3 control-label">
                                 Card Type
                            </label>
                          <div className="col-md-5 form123">
                             <select className="form-control" id="card-type" required>
                             <option value="">Select Card Type</option>
                              <option value="visa">Visa</option>
                                <option value="mastercard">MasterCard</option>
                                <option value="amex">American Express</option>
                                 <option value="discover">Discover</option>
                             </select>
                           </div>
                        </div>
                   </div>
                  </div>
                  </div>




                <h6 style={{ paddingBottom: "20px", fontWeight: "bold", textAlign: "center", marginTop:"25px" }} > (OR) </h6>

                <div className="row">
                <div className="col-12">
                  <div className="input-box form-group required">
                    <div className="row">
                      <label htmlFor="coupon-name" className="col-md-3 control-label">
                        UPI ID 
                      </label>
                      <div className="col-md-5 form123">
                        <input
                          type="text"
                          className="form-control"
                          id="coupon-name"
                          required
                          placeholder="Enter Your UPI ID"
                        />
                      </div>
                    </div>
                  </div>
                  </div>
                </div>


                <div className="mt-4 d-flex justify-content-end">
                  <button type="button" className="btn123" onClick={handleConfirmPayment}>Confirm Payment</button>
                </div>
                </form>
              </div>
            )}


          </div>

          
        </div>
      </div>
    </div>
  );
}

export default Detailing;
