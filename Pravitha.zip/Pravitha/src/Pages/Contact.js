import React,{useEffect, useState}  from 'react'
import backgroundImage from '../Assets/background.png'; 
import PuffLoader from "react-spinners/PuffLoader";




function Contact() {
  const [loading, setLoading] = useState(true); // Loading state
    useEffect(() => {
      // Simulate data fetching or delay for loader
      const timer = setTimeout(() => {
        setLoading(false); // Stop loading after 3 seconds
      }, 3000);
  
      return () => clearTimeout(timer); // Cleanup timeout
    }, []);
  
  useEffect(() => {
  window.scrollTo(0, 0);
  }, []);


  return (
    <div>
      {loading ? (
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            height: "100vh",
          }}
        >
          <PuffLoader color="#D0C743" size={100} />
        </div>
      ) : (
        <>
        <div
      
      style={{
        backgroundImage: `url(${backgroundImage})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat',
        padding: '20px',
        color: '#333',
      }}
    >

      <h1 className="cancellation-policy-title">
        Contact us
      </h1>
</div>
        <div id="contact" class="contact section">
        <div class="container section-title" data-aos="fade-up">
          
          {/* <h2 className="">Contact Info</h2> */}
          </div>
          <div class="row gy-4">
            <div class="col-lg-6">
              <div
                class="info-item d-flex flex-column justify-content-center align-items-center"
                data-aos="fade-up"
                data-aos-delay="200"
              >
                {/* <i class="bi bi-geo-alt sticon"></i> */}
               
                <p className='contact-text'>Pravitha Jewels <br />
                  99/4b Hoyasala Nagar  <br />
                  Horamavu  <br />
                  Bangalore - 560043  <br />
                  mail :  info@pravithajewels.com</p>
              </div>
            </div>

            {/* <div class="row gy-4 mt-1"> */}
            <div class="col-lg-4" data-aos="fade-up" data-aos-delay="300">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7774.586013107853!2d77.65622789629352!3d13.017003818249762!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae1127882d48e1%3A0x5fa9059938089bc0!2sHoysala%20Nagar%2C%20Horamavu%2C%20Bengaluru%2C%20Karnataka%20560016!5e0!3m2!1sen!2sin!4v1734421672964!5m2!1sen!2sin"
                frameborder="0"
                style={{ border: "0", width: "100%", height: "400px" }}
                allowfullscreen=""
                loading="lazy"
                referrerpolicy="no-referrer-when-downgrade"
                title="Google Map of Downtown conference center"
              ></iframe>
            </div>

            
          </div>

          </div>

         
        {/* </div> */}
        </>
      )}
      </div>
    
  )
}

export default Contact