import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { Card, Button, Breadcrumb } from 'react-bootstrap'; // Include Breadcrumb from react-bootstrap
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faShoppingCart, faStar as solidStar, faIndianRupeeSign } from '@fortawesome/free-solid-svg-icons';
import { faStar as regularStar, faHeart as regularHeart } from '@fortawesome/free-regular-svg-icons';
import { Offcanvas, ListGroup } from 'react-bootstrap';
import { BiSliderAlt } from "react-icons/bi";
import { FaAngleDown } from "react-icons/fa6";
import axios from 'axios';
import { Link } from 'react-router-dom';
import { CiFilter } from "react-icons/ci";
import StaticBanner from '../Components/StaticBanner';
import { useNavigate,useLocation } from 'react-router-dom';
import PuffLoader from "react-spinners/PuffLoader";

function Shop() {
  const navigate = useNavigate();
  // const { gold_id, main_category_id, sub_category_id, sub_gold_id, silver_id, sub_silver_id } = useParams();
  const { main_category_name, sub_silver_name } = useParams();
  console.log("Main Category Name:", main_category_name);
  console.log("Sub Silver Name:", sub_silver_name);
  const location = useLocation();
  const { main_category_id, sub_category_id } = location.state || {};

  const [visibleProducts, setVisibleProducts] = useState(8);
  const [visibleDropdown, setVisibleDropdown] = useState(null);
  const [priceRange, setPriceRange] = useState([1, 1000000]);
  const [products, setProducts] = useState([]);
  const [selectedOptions, setSelectedOptions] = useState('');
  const [filterValue, setFilterValue] = useState('');
  const [sortValue, setSortValue] = useState('');
  const [show, setShow] = useState(false);
  const [goldOpen, setGoldOpen] = useState(false);
  const [silverOpen, setSilverOpen] = useState(false);
  const [showOffcanvas, setShowOffcanvas] = useState(false);
  const handleShow = () => setShow(true);
  const handleClose = () => setShow(false);
  const [isOpen, setIsOpen] = useState(false);
  const [sideFilters, setSideFilters] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [title, setTitle] = useState("");
  const [subtitle, setSubTitle] = useState("");
  const[maintitle, setMainTitle] = useState("");
  const [openDropdowns, setOpenDropdowns] = useState({}); // Stores open states for each filter
  const [loading, setLoading] = useState(true); // Loading state
  const[mainid, setMainId] = useState();
  const[subid, setSubId] = useState()


  const toggleDropdown1 = (categoryName) => {
    setOpenDropdowns((prevState) => ({
      ...prevState,
      [categoryName]: !prevState[categoryName], // Toggle open state for the clicked category
    }));
  };
  
  




  
  const handleProductClick = (product_id) => {
    // Store the product_id in local storage
    localStorage.setItem('selectedProductId2', product_id);
    localStorage.setItem('selectedProductId1', 0);
    localStorage.setItem('selectedProductId', 0);
    localStorage.setItem('selectedProductId3', 0);
    localStorage.setItem('selectedProductId4', 0);



    // Navigate to the product detail page
    navigate(`/productdetail/${product_id}`);
};
 

useEffect(() => {
  setProducts([]);

  const fetchProducts = async () => {
    setLoading(true);
    // Generate a comma-separated list of selected sub-category IDs
    const selectedSubCategoryIds = Object.keys(selectedOptions)
      .flatMap(key => Object.keys(selectedOptions[key]).filter(subOption => selectedOptions[key][subOption]));

    // Combine sub_category_id with selected sub-category IDs
    const combinedStId = [sub_category_id, ...selectedSubCategoryIds].join(',');

    try {
      const response = await axios.post('https://pravithajewels.com/customerapp/product.php', {
        cid: main_category_id,
        st_id: combinedStId,
      });
      setLoading(false);

      if (response.data.head && response.data.head.code === 200) {
        setProducts(response.data.body.products);
        console.log(response.data.body.products)
        setSideFilters(response.data.body.sidefilter);
        setTitle(`${response.data.body.top_title.main_category_name}`);
        setSubTitle(response.data.body.top_title.sub_category_name)
        setMainTitle(response.data.body.top_title.sub_category_type_name);
        setMainId(response.data.body.top_title.main_category_id)
        setSubId(response.data.body.top_title.sub_category_id)

      } else {
        console.error('Failed to fetch products');
      }
    } catch (error) {
      console.error('Error fetching products:', error);
    }
  };

  if (main_category_id && sub_category_id) {
    fetchProducts();
  }
}, [main_category_id, sub_category_id, selectedOptions]);


// Function to handle "View More" / "View Less" toggle
const toggleViewMore = () => {
  if (visibleProducts === 8) {
    setVisibleProducts(products.length); // Show all products
  } else {
    setVisibleProducts(8); // Show only 8 products
  }
};




  const toggleGoldDropdown = () => {
    setGoldOpen(!goldOpen);
  };

  // Handle Silver dropdown toggle
  const toggleSilverDropdown = () => {
    setSilverOpen(!silverOpen);
  };
  const categories = ['Category 1', 'Category 2', 'Category 3'];
  
  const handleFilterChange = (e) => setFilterValue(e.target.value);

  
const handlePriceChange = (e) => {
  const newMax = Number(e.target.value); // Assuming you're only changing the max price here
  setPriceRange([priceRange[0], newMax]);
};

  const handleSortChange = (sortType) => {
    setSortValue(sortType);
    setIsOpen(false); // Close dropdown after selection
  };

  const toggleDropdown = (name) => {
    setVisibleDropdown((prev) => (prev === name ? null : name));
  };

  // Close dropdown if clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (!event.target.closest('.shop-main-dropdown')) {
        setVisibleDropdown(null);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // Handle checkbox state
 
  const handleCheckboxChange = (category, subType) => {
    setSelectedOptions(prevState => ({
      ...prevState,
      [category]: {
        ...prevState[category],
        [subType]: !prevState[category]?.[subType],
      },
    }));
  };


  const handleOptionClick = (optionLabel) => {
    setSelectedOptions(optionLabel);
    setVisibleDropdown(null); // Close dropdown after selection
  };
  const handleOffcanvasToggle = () => {
    setShowOffcanvas(!showOffcanvas);
  };

  useEffect(() => {
    const filtered = products.filter(
      (product) => product.price >= priceRange[0] && product.price <= priceRange[1]
    );

     // Sort by product_name
  if (sortValue === 'Ascending') {
    filtered.sort((a, b) => a.product_name.localeCompare(b.product_name));
  } else if (sortValue === 'Descending') {
    filtered.sort((a, b) => b.product_name.localeCompare(a.product_name));
  }

    setFilteredProducts(filtered);
  }, [products, priceRange, sortValue]);





  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  
  return (
    <>
    <div className='mainpage'>
      {/* Add Static Banner */}
      {/* <div className="static-banner">
        <img src={StaticBanner} alt="Static Banner" className="d-block w-100" style={{ height: "auto", objectFit: "cover" }} />
      </div> */}
      <StaticBanner/>
     <div className='shop-page-main'>
      {/* Add Breadcrumbs Below the Banner */}
      <Breadcrumb className="mt-3 breadcrumb" style={{ marginLeft: "20px" }}>
 
  <Breadcrumb.Item  style={{fontSize:"24", fontWeight:"400"}}><Link to="/">Home</Link> /<Link to ={`/silver/${mainid}`}>{title} </Link>  /<span style = {{color:"black",cursor:"default"}}>{subtitle} </span></Breadcrumb.Item>
        <Breadcrumb.Item active></Breadcrumb.Item>
      </Breadcrumb>
      
      <div>
        <p  className="productdetail-para" style={{marginLeft:"20px",fontSize:"36px",marginTop:"-15px"}}>{maintitle}</p>
      </div>

      
      <div className="filter-sort-container">
      {/* Filter Section (only visible on small screens) */}
      <div className="filter-container">
      <p onClick={handleShow} className="filter-container">Filters <BiSliderAlt/></p> {/* Corrected onClick */}
      
    </div>

      {/* Sort By Section */}
{products.length > 0 ? (<div
        className="sort-container"
        onMouseEnter={() => setIsOpen(true)}
        onMouseLeave={() => setIsOpen(false)}
        style={{ position: 'relative' }}
      >
        <div style={{ cursor: 'pointer', marginRight: '25px' }}>
          {sortValue || 'Sort By'}
          &nbsp; <FaAngleDown />
        </div>
        {isOpen && (
          <div
            className="dropdown-options"
            style={{
              position: 'absolute',
              background: 'white',
              border: '1px solid #ccc',
              boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
              zIndex: 1,
            }}
          >
            <div onClick={() => handleSortChange('Ascending')} style={{ padding: '8px', cursor: 'pointer',paddingLeft:'16px',paddingRight:'16px' }}>
              Ascending
            </div>
            <div onClick={() => handleSortChange('Descending')} style={{ padding: '8px', cursor: 'pointer',paddingLeft:'16px',paddingRight:'16px' }}>
              Descending
            </div>
          </div>
        )}
      </div>
      ):(
        ""
      )}
      


    </div>
  
      <hr />
      
      <div className='main123'>
      <div className='side custom-shadow'>
      {/* <h5 style={{ marginLeft: "20px", paddingTop: "25px" }} className="productdetail-para">
        Filters <CiFilter />
      </h5> */}
      
      

        {/* Other dropdown filters */}
        <p style={{ cursor: 'pointer',marginLeft:"20px" }} className="productdetail-para">
        Categories
      </p>
      {sideFilters.map((filter) => (
        <div key={filter.sub_category_id} className="shop-main-dropdown" style={{marginLeft:"30px" }}>
          <div className="dropdown dropmenu-para1">
            <div>
              {/* Dropdown Title */}
              <p
                className="shop-sub-dropdown dropmenu-para1"
                onClick={() => toggleDropdown(filter.sub_category_name)}
                style={{ cursor: 'pointer' }}
              >
                {filter.sub_category_name}
                <span
                  className={`caret ${visibleDropdown === filter.sub_category_name ? 'caret-rotate' : ''}`}
                ></span>
              </p>

              {/* Dropdown Content */}
              {visibleDropdown === filter.sub_category_name && (
                <div className="shop-sub-dropdown">
                  <ul>
                    {filter.sub_type.map((subType) => (
                      <li key={subType.sub_gold_id} style={{ cursor: 'pointer' }}>
                        <input
                          type="checkbox"
                          id={subType.sub_gold_id}
                          checked={sub_category_id === subType.sub_gold_id || selectedOptions[filter.sub_category_id]?.[subType.sub_gold_id] || false}
                          onClick={(e) => e.stopPropagation()} // Prevents dropdown from closing on checkbox click
                          onChange={() => handleCheckboxChange(filter.sub_category_id, subType.sub_gold_id)}
                          style={{ cursor: 'pointer' }}
                        />
                        <label
                          htmlFor={subType.sub_gold_id}
                          style={{ marginLeft: '5px', cursor: 'pointer' }}
                        >
                          {subType.sub_gold_name}
                        </label>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>
        </div>
      ))}






<hr />
<div className="range">
        <div className="price-range">
          <label htmlFor="priceRange" className="productdetail-para price-range12" >
            Price
          </label>
          <br />
          <span style={{ fontSize: "18px", marginLeft: "0px" }} className="productdetail-p price-filter"><i class="bi bi-currency-rupee"></i>{priceRange[1]}</span>
          <div className="slider-container">
            <span className="price-label"><span style={{fontSize:"22px"}}>₹</span>1</span>
            <input
              type="range"
              id="priceRange"
              min="1"
              max="1000000"
              step="100"
              value={priceRange[1]}
              onChange={handlePriceChange}
              className="slider"
            />
            <span className="price-label"><span style={{fontSize:"22px"}}>₹</span>1000000</span>
          </div>
        </div>
      </div>

    </div>
    { console.log(filteredProducts)}
        {/* Cards Display */}
        <div className="product-collection">
  <div className="product-grid">
    {loading ? (
      // Show loader when `loading` is true
      <p>.</p>
    ) : Array.isArray(filteredProducts) && filteredProducts.length > 0 ? (
      // Render products if `filteredProducts` is a non-empty array
      filteredProducts.slice(0, visibleProducts).map((product) => (
        <div
          className="product-card1"
          key={product.product_id}
          onClick={() => handleProductClick(product.product_id)}
          style={{ cursor: "pointer" }}
        >
          <div className="product-image1">
            <img
              src={product.image}
              alt={product.product_name}
              className="image1"
            />
          </div>
          <div className="product-info-section1">
            <nobr>
              <h3 className="shop-product-name12">{product.product_name}</h3>
            </nobr>
            <p className="product-price1">
  <i className="bi bi-currency-rupee"></i>
  {product.price
    ? new Intl.NumberFormat("en-IN").format(product.price)
    : "Price Unavailable"}{" "}
  {product.discount ? (
    <span className="product-discount1">
      {product.discount !== "0" ? `[${product.discount} % Off]` : ""}
    </span>
  ) : (
    <span className="product-discount1">No Discount</span>
  )}
</p>

          </div>
        </div>
      ))
    ) : (
      // Handle empty array or unexpected cases
      <p className="productdetail-para">No products found</p>
    )}
  </div>
</div>


     
    </div>
    </div>
    {filteredProducts && filteredProducts.length > 8 && (
  <p
    className="productdetail-para shop-viewmore"
    onClick={toggleViewMore}
    style={{ cursor: 'pointer' }}
  >
    {visibleProducts === 8 ? 'View More' : 'View Less'}
  </p>
)}
    </div>

                    {/* offcanvas categoies */ }
                    <Offcanvas show={show} onHide={handleClose} style={{ width: '270px' }}>
                    <Offcanvas.Header>
  <Offcanvas.Title>Filters</Offcanvas.Title>
  <button 
    onClick={handleClose} 
    style={{
      background: "#e3d948",
      color: "#000",
      border: "none",
      padding: "5px 10px",
      borderRadius: "8px",
      cursor: "pointer",
      fontSize: "1rem",
      marginLeft:"135px",
      paddingRight:"17px",
      paddingLeft:"17px"
    }}
  >
    Go
  </button>
</Offcanvas.Header>

  <Offcanvas.Body>
    <ul style={{ listStyleType: 'none', padding: 0 }} className="offcanvas-menu">
      {sideFilters.map((filter) => (
        <li key={filter.sub_category_id} style={{ marginBottom:"-10px" }}>
          {/* Mobile screen: Offcanvas dropdown */}
          <div
            onClick={() => toggleDropdown1(filter.sub_category_name)}
            style={{ cursor: 'pointer' }}
            className="offcanvas-dropdown-container"
          >
            {filter.sub_category_name}{' '}
            <span className="offcanvas-dropdown">
              {openDropdowns[filter.sub_category_name] ? '-' : '+'}
            </span>
          </div>
          {openDropdowns[filter.sub_category_name] && (
            <ul style={{ listStyleType: 'none', paddingLeft: '20px',marginTop:"-20px",marginBottom:"20px" }}>
             
              {filter.sub_type.map((subType) => (
                <li key={subType.sub_gold_id} style={{ cursor: 'pointer',marginBottom:"-30px" }}>
                  <input
                    type="checkbox"
                    // id={subType.sub_gold_id}
                    // checked={selectedOptions[filter.sub_category_id]?.[subType.sub_gold_id] || false}
                    onClick={(e) => e.stopPropagation()} // Prevents dropdown from closing on checkbox click
                    checked={selectedOptions[filter.sub_category_id]?.[subType.sub_gold_id] || false}
                    onChange={() => handleCheckboxChange(filter.sub_category_id, subType.sub_gold_id)}
                    style={{ cursor: 'pointer' }}
                  />
                  <label htmlFor={subType.sub_gold_id} style={{ marginLeft: '5px', cursor: 'pointer'}}>
                    {subType.sub_gold_name}
                  </label>
                </li>
              ))}
            </ul>
          )}
        </li>
      ))}
      <hr />

      <div className="content" style={{ width: "240px", marginLeft: "-10px" }}>
        <div className="price-range" >
          <label htmlFor="priceRange" className="productdetail-para" style={{ marginLeft: "-170px"}}>
            Price
          </label>
          <br />
          <span style={{ fontSize: "20px",marginTop: "-56px", marginLeft: "10px" }}> <span style={{fontSize:"14px"}}>₹</span>{priceRange[1]}</span>
          <div className="slider-container" style={{ marginTop: "-6px"}}>
            <span className="price-label"><span style={{fontSize:"14px"}}>₹</span>100</span>
            <input
              type="range"
              id="priceRange"
              min="100"
              max="10000000"
              step="100"
              value={priceRange[1]}
              onChange={handlePriceChange}
              className="slider"
              style={{width:"50%"}}
            />
            <span className="price-label"> <span style={{fontSize:"14px"}}>₹</span>1000000</span>
          </div>
        </div>
      </div>
    </ul>
  </Offcanvas.Body>
</Offcanvas>

      </>
  );
}

export default Shop;
