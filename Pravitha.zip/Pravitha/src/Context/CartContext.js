import React, { createContext, useState, useMemo, useEffect } from 'react';

// Create the context
const CartContext = createContext();

// Create a provider component
const CartProvider = ({ children }) => {
  const [cartItems, setCartItems] = useState(() => {
    // Load initial cart items from localStorage if available
    const savedCart = localStorage.getItem('cartItems');
    return savedCart ? JSON.parse(savedCart) : [];
  });

  // Function to add or update an item in the cart
  const addItemToCart = (item) => {
    setCartItems((prevItems) => {
      const existingItem = prevItems.find(
        (cartItem) =>
          cartItem.product_id === item.product_id &&
          cartItem.weight === item.weight &&
          cartItem.purity === item.purity // Ensure purity is checked
      );
  
      if (existingItem) {
        // Update quantity if item exists
        return prevItems.map((cartItem) =>
          cartItem.product_id === item.product_id &&
          cartItem.weight === item.weight &&
          cartItem.purity === item.purity // Ensure purity is matched
            ? { ...cartItem, quantity: cartItem.quantity + item.quantity } // Increment or decrement
            : cartItem
        );
      } else {
        // Add new item if it doesn't exist
        return [...prevItems, { ...item, quantity: item.quantity }];
      }
    });
  };
  
  
  
  const removeItemFromCart = (product_id, weight, purity) => {
    setCartItems((prevItems) =>
      prevItems.filter(
        (cartItem) => !(cartItem.product_id === product_id && cartItem.weight === weight && cartItem.purity === purity)
      )
    );
  };
  
  // Function to clear the cart
  const clearCart = () => {
    setCartItems([]); // Clears the cart state
    localStorage.removeItem('cartItems'); // Clear cart items from localStorage
  };

  // Save cart items to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('cartItems', JSON.stringify(cartItems));
  }, [cartItems]);

  // Calculate the total quantity of items in the cart
  const totalQuantity = useMemo(
    () => cartItems.reduce((total, item) => total + item.quantity, 0),
    [cartItems]
  );

  // Total count of unique items in the cart
  const cartCount = useMemo(() => cartItems.length, [cartItems]);

  return (
    <CartContext.Provider
      value={{
        cartItems,
        cartCount,
        clearCart,
        addItemToCart,
        removeItemFromCart,
        totalQuantity,
        setCartItems,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export { CartContext, CartProvider };
