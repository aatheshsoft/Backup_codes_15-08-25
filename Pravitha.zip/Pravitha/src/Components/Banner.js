import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

import axios from 'axios';
import './Banner.css'; // Import CSS for styling
import { Carousel } from 'react-bootstrap'; // Using React Bootstrap for the carousel
import Line from "../Assets/Line 4 (1).png"
import Shadowline from "../Assets/Line 3.png"

function Banner () {
  const [bannerImages, setBannerImages] = useState([]);
  const navigate = useNavigate();

  const handleExploreClick = () => {
    const sub_sub_category_id = localStorage.getItem("sub_sub_category_id");
    const main_category_id = localStorage.getItem("main_category_id");
     console.log(sub_sub_category_id);
     console.log(main_category_id);



    if (sub_sub_category_id && main_category_id) {
      // Navigate with query parameters
      navigate(`/shopbycategory/ ${sub_sub_category_id} /${main_category_id}`);
    } else {
      alert("Required category IDs are missing.");
    }
  };
  

  useEffect(() => {
    // Function to fetch data from the API
    const fetchBannerImages = async () => {
      try {
        const response = await axios.post('https://pravithajewels.com/customerapp/banner.php');
        if (response.data.head.code === 200) {
          setBannerImages(response.data.body.banner);
        } else {
          console.error("Failed to fetch banners");
        }
      } catch (error) {
        console.error("Error fetching banners:", error);
      }
    };

    fetchBannerImages();
  }, []);

  return (
    <div className="banner">
      <div className="banner-content">
        <div style={{marginTop:"58px"}}>
        <h1>Exquisite Silver Creations with</h1> 
        <h2>No Making & Wastage</h2>
        </div>
        <div className="line-img">
          {/* <div className="thick-line"></div>
          <div className="thin-line"></div> */}
        <img src={Line} style={{marginTop:"-108px"}} className='line-img' />
        </div>
        <p style={{marginTop:"-98px"}}>charges<span style={{color:"red"}}>*</span></p>
        
        <button className="explore-button"  onClick={handleExploreClick}>Explore creations</button>
      </div>
      <div className="banner-carousel">
        <Carousel interval={2000} pause={false}>
          {bannerImages.map((banner) => (
            <Carousel.Item key={banner.id}>
              <img
                className="d-block w-100 bannerimage"
                src={banner.image}
                alt={`Banner ${banner.id}`}
              />
            </Carousel.Item>
          ))}
        </Carousel>
      </div>
    </div>
  );
};

export default Banner;
