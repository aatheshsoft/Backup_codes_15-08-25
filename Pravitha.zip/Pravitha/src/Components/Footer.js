import React from 'react';
import { Link } from 'react-router-dom';
import './Footer.css'; // Optional: import CSS for styling
import { Row, Col } from 'react-bootstrap'; // Importing Row and Col from react-bootstrap

const Footer = () => {
  return (
    <footer id="footer" className="footer dark-background">
      <div className="container footer-top">
        <Row className="gy-4 container12"> {/* Use Row from react-bootstrap */}
          {/* Support Links */}
          <Col xs={4} sm={4} md={3}   className="footer-links footer-links12"> {/* Set column sizes for different screens */}
            <h4>Support</h4>
            <ul>
              {/* <li><a href="#">FAQ</a></li> */}
              <li><Link to = "/returnpolicy">Return Policy</Link></li>
              <li><Link to = "/cancellationpolicy">Cancellation / Refund Policy</Link></li>
              <li><Link to = "/privacypolicy">Privacy Policy</Link></li>
              <li><Link to = "/shippingpolicy">Shipping & Delivery</Link></li>

            </ul>
          </Col>

          {/* Company Links */}
          <Col xs={4} sm={4} md={3} className="footer-links  footer-links12">
            <h4>Company</h4>
            <ul>
              <li><Link to ='/whychoose'>Why Us</Link></li>
              <li><Link to="/contact">Contact</Link></li>
              <li><Link to ='/termsconditions'>Terms & Conditions</Link></li>
              {/* <li><a href="#">Careers</a></li> */}
            </ul>
          </Col>

          {/* Shop Links */}
          <Col xs={4} sm={4} md={3} className="footer-links footer-links12">
            <h4>Shop</h4>
            <ul>
              <li><Link to="/myaccount">My Account</Link></li>
              {/* <li><Link to="/">Check Out</Link></li> */}
              <li><Link to="/cart">Cart</Link></li>
            </ul>
          </Col>
        </Row>
      </div>
      
      <div className="container-sub copyright text-center mt-4">
        <p>© <span> 2024 Copyright</span> <strong className="px-1 sitename">Pravitha Jewels</strong> <span>All Rights Reserved</span></p>
      </div>
    </footer>
  );
};

export default Footer;
