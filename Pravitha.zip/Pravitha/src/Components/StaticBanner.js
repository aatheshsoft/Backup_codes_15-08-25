import React from "react";
import "./StaticBanner.css";
import centerImage from "../Assets/figma3.png";
import leftImage from "../Assets/figma4.png";
import rightImage from "../Assets/figma1.png";
import Line from "../Assets/Line 4 (1).png"


const StaticBanner = () => {
  return (
    <div className="Staticbanner-section">
      <div className="Staticbanner-content">
        <h1>Unique Silver Collections</h1>
        <p>From Deepam to Idols,</p>
        <h2>All at Unbeatable Value</h2>
        <img src={Line}  className='static-line-img' />
      </div>
      {/* <div className="line-img">
        
        
        </div> */}
      <div className=" Staticbanner-images">
      <img src={leftImage} className="side-image" alt="Left Idol" />
        <img src={centerImage} className="center-image" alt="Center Idol" />
        
        <img src={rightImage} className="side-image" alt="Right Idol" />
      </div>
    </div>
  );
};

export default StaticBanner;
