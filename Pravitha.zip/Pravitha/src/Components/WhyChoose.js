import React,{useEffect,useState} from 'react';
import './WhyChoose.css'; // Import the CSS file
import backgroundImage from '../Assets/background.png'; 
import deepamimage from '../Assets/vilakku.png';
import idolimage from '../Assets/figma2.png';
import plateimage from '../Assets/plate.png'
import PuffLoader from "react-spinners/PuffLoader";


const WhyChoose = () => {
  const [loading, setLoading] = useState(true); // Loading state

  useEffect(() => {
    // Simulate data fetching or delay for loader
    const timer = setTimeout(() => {
      setLoading(false); // Stop loading after 3 seconds
    }, 3000);

    return () => clearTimeout(timer); // Cleanup timeout
  }, []);


  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (

    <>
    {loading ? (
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            height: "100vh",
          }}
        >
          <PuffLoader color="#D0C743" size={100} />
        </div>
      ) : (
        <>
    <div
      
    style={{
      backgroundImage: `url(${backgroundImage})`,
      backgroundSize: 'cover',
      backgroundPosition: 'center',
      backgroundRepeat: 'no-repeat',
      padding: '20px',
      color: '#333',
      
    }}
  >

    <h1 className="cancellation-policy-title">
      Why Us
    </h1>
</div>


    <div className="why-choose-us">

    <div class="welcome">
  Welcome to
</div>
<div class="brand-name">
  Pravitha Jewels
</div>
<div class="content">
  Discover the timeless beauty and elegance of our handcrafted silver jewelry. At Pravitha Jewels, <br/>we believe that every piece of jewelry tells a story, and we are here to help you find the perfect piece to tell yours.
</div>

<br /><br /><br />
    <div className='ourcollection-section'>


     <h2>Our Collections</h2>
      <div className="underline"></div>
      <div className="choose-us-cards">
      <div className="card1">
      <img 
        src={deepamimage} 
        alt="Nagas Deepam" 
        className="card-image" 
        loading='lazy'
      />
      <h4>Deepam</h4>
      <p>
        Illuminate your home with our beautifully crafted  Deepam collection. 
        Each piece is designed to bring a touch of tradition and elegance to your space.
      </p>
    </div>
        <div className="card1">
        <img 
        src={idolimage} 
        alt="Nagas Deepam" 
        className="card-image" 
        loading='lazy'
      />
         
          <h4>Idols</h4>
          <p>
           Our Idols collection features intricately designed silver idols that are perfect for your 
          home altar or as a thoughtful gift for loved ones.
          </p>
        </div>
        <div className="card1">
        <img 
        src={plateimage} 
        alt="Nagas Deepam" 
        className="card-image" 
        loading='lazy'
      />
          <h4>Plates</h4>
          <p>
          We are committed to providing exceptional customer service and ensuring your satisfaction with every purchase
          </p>
        </div>
      </div>

      </div>

<br/><br/><br/>

      
      <h2>Why choose us?</h2>
      <div className="underline"></div>
      <div className="choose-us-cards">
        <div className="card1">
          <h3>01</h3>
          <h4>Quality<br /> Craftsmanship</h4>
          <p>
            Each piece of jewelry is meticulously crafted by skilled artisans using the finest silver.
          </p>
        </div>
        <div className="card1">
          <h3>02</h3>
          <h4>Unique<br /> Designs</h4>
          <p>
            Our collection features unique and exclusive designs that you won't find anywhere else.
          </p>
        </div>
        <div className="card1">
          <h3>03</h3>
          <h4>Customer<br /> Satisfaction</h4>
          <p>
            We are committed to providing exceptional customer service and ensuring your satisfaction with every purchase.
          </p>
        </div>
      </div>
    </div>
    </>
      )}
    </>
  );
};

export default WhyChoose;
