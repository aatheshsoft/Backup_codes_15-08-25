import React from 'react';
import './WhyChoose.css'; // Import the CSS file
import backgroundImage from '../Assets/background.png'; 
import deepamimage from '../Assets/vilakku.png';
import idolimage from '../Assets/figma2.png';
import plateimage from '../Assets/plate.png'


const WhyChoose = () => {
  return (
    <>
    


    <div className="why-choose-us">

    <h2>Why choose us?</h2>
      <div className="underline"></div>
      <div className="choose-us-cards">
        <div className="card1">
          <h3>01</h3>
          <h4>Quality<br /> Craftsmanship</h4>
          <p>
            Each piece of jewelry is meticulously crafted by skilled artisans using the finest silver.
          </p>
        </div>
        <div className="card1">
          <h3>02</h3>
          <h4>Unique<br /> Designs</h4>
          <p>
            Our collection features unique and exclusive designs that you won't find anywhere else.
          </p>
        </div>
        <div className="card1">
          <h3>03</h3>
          <h4>Customer<br /> Satisfaction</h4>
          <p>
            We are committed to providing exceptional customer service and ensuring your satisfaction with every purchase.
          </p>
        </div>
      </div>
    </div>
    </>
  );
};

export default WhyChoose;
