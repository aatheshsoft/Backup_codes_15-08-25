import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faShoppingCart } from "@fortawesome/free-solid-svg-icons";
import { Offcanvas } from "react-bootstrap";
import "./Header.css";
// import Mainlogo from "../Assets/manift-logo.png";
import axios from 'axios';
import Button from 'react-bootstrap/Button';
import myIcon from '../Assets/carticon.png';
import logo from '../Assets/jallikkutta-logo.png';

function Header() {
  const [cartCount, setCartCount] = useState(0);
  const [showOffcanvas, setShowOffcanvas] = useState(false);
  const [contactData, setContactData] = useState(null);
  const [priceListUrl, setPriceListUrl] = useState(""); // New state for price list URL
  // const [Mainlogo, setMainLogo] = useState("");
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
  
  useEffect(() => {
    const fetchContactData = async () => {
      try {
        const response = await axios.get(`${API_BASE_URL}content.php`
          // " https://manifriendstraders.com/customer_api/content.php"
        );
        const { body } = response.data;
        // setMainLogo(body.logo)
        setContactData(body.contact);
      } catch (error) {
        console.error("Error fetching the contact data", error);
      }
    };

    fetchContactData();
  }, []);

  useEffect(() => {
    // Retrieve cart count from local storage
    const count = parseInt(localStorage.getItem("cartCount")) || 0;
    setCartCount(count);

    // Optionally, listen for changes in local storage (if using multiple tabs)
    const handleStorageChange = () => {
      const count = parseInt(localStorage.getItem("cartCount")) || 0;
      setCartCount(count);
    };

    window.addEventListener('storage', handleStorageChange);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
    };
  }, []);

  const handleClose = () => setShowOffcanvas(false);
  const handleShow = () => setShowOffcanvas(true);

  const handleDownloadPriceList = async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}download_pricelist.php`,
        // 'https://manifriendstraders.com/customer_api/download_pricelist.php',
        {
          responseType: 'blob',
        }
      );

      const contentType = response.headers['content-type'];

      // Log content type
      console.log('Content-Type:', contentType);

      // Optional: Read text for debugging
      // const reader = new FileReader();
      // reader.onload = () => console.log('Response Text:', reader.result);
      // reader.readAsText(response.data);

      // Create a blob with correct MIME type for text/csv
      const blob = new Blob([response.data], { type: 'text/csv;charset=utf-8' });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', 'PriceList.pdf'); 
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(url);
      
    } catch (error) {
      console.error('Download failed:', error);
      alert('Failed to download price list. Please try again later.');
    }
  };

  return (
    <div className="nav-main">
      <div id="header" className="header sticky-top">
        <div className="topbar d-flex align-items-center">
          <div className="container d-flex justify-content-md-between">
            <div className="contact-info d-flex align-items-center">
              <i className="bi bi-envelope">
               <strong> <span>{contactData?.email || ""}</span></strong>
              </i>
              <i className="bi bi-phone">
              <strong><span>{contactData?.phonenumber || ""}</span></strong>
              </i>
            </div>
            <div className="social-links d-none d-md-flex align-items-center">
              <Link to="/" className="social">
                <i className="bi bi-facebook"></i>
              </Link>
              <Link to="/" className="social"><i className="bi bi-instagram"></i></Link>
              <Link to="/" className="social">
                <i className="bi bi-youtube"></i>
              </Link>
            </div>
          </div>
        </div>

        <div className="branding d-flex align-items-center">
          <div className="container position-relative d-flex align-items-center justify-content-between">
            <Link to="/" className="logo d-flex align-items-center me-auto">
              <div className="logo d-flex align-items-center me-auto">
                <img src={logo} alt="Logo" />
              </div>
            </Link>

            <nav id="navmenu" className="navmenu d-none d-xl-block">
              <ul>
                <li>
                  <Link to="/" className="nav-link">
                    Home
                  </Link>
                </li>
                <li>
                  <Link to="/quick" className="nav-link">
                    Quick Purchase
                  </Link>
                </li>
                <li>
                  <Link to="/about" className="nav-link">
                    About Us
                  </Link>
                </li>
                <li>
                  <Link to="/contact" className="nav-link">
                    Contact Us
                  </Link>
                </li>
              </ul>
            </nav>

            <Button className="cta-btn d-none d-sm-block blink" onClick={handleDownloadPriceList}>
              Download Price List
            </Button>
          </div>
          <div className="cart">
            <Link to="/cart">
            {/* style={{color:"#ff0500 "}} */}
              {/* <FontAwesomeIcon icon={faShoppingCart}  style={{color:"#fba338 "}}/> */}
              <img src={myIcon} alt="My Icon" style={{ width: 25, height: 25 }} />

              {cartCount > 0 && <span className="badge">{cartCount}</span>}
            </Link>
          </div>
          <i
            className="mobile-nav-toggle bi bi-list"
            onClick={handleShow}
          ></i>
        </div>
      </div>

      {/* Offcanvas Menu */}
      <Offcanvas show={showOffcanvas} onHide={handleClose} placement="start">
        <Offcanvas.Header closeButton>
          <Offcanvas.Title>
            <img src={logo} alt="Logo" style={{ width: "150px" }} />
          </Offcanvas.Title>
        </Offcanvas.Header>
        <Offcanvas.Body>
          <ul className="offcanvas-menu">
            <li>
              <Link to="/" className="nav-link" onClick={handleClose}>
                <i className="bi bi-house-fill officon"></i> Home
              </Link>
            </li>
            <hr />
            <li>
              <Link to="/about" className="nav-link" onClick={handleClose}>
                <i className="bi bi-journal-text officon"></i> About Us
              </Link>
            </li>
            <hr />
            <li>
              <Link to="/quick" className="nav-link" onClick={handleClose}>
                <i className="bi bi-bag-fill officon"></i> Quick Purchase
              </Link>
            </li>
            <hr />
            <li>
              <Link to="/contact" className="nav-link" onClick={handleClose}>
                <i className="bi bi-telephone-fill officon"></i> Contact Us
              </Link>
            </li>
             <hr />
                <Button className="cta-btn  d-sm-block " onClick={handleDownloadPriceList}>
              Download Price List
            </Button>
          </ul>
        </Offcanvas.Body>
      </Offcanvas>
    </div>
  );
}

export default Header;
