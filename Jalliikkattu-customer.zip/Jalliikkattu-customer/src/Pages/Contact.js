import React, { useEffect, useState } from 'react';
import axios from 'axios';
import "./Contact.css";
import Footer from "./Footer";
import Header from "./Header";
import { Parallax } from "react-parallax";
import image2 from "../Assets/page_bg.jpg";
import { Link } from "react-router-dom";
import CrackersLoader from './CrackersLoader';
import { useNavigate } from "react-router-dom";
import Spinner from "react-bootstrap/Spinner";
import Sticker from "./Sticker";


function Contact() {
  const [contactData, setContactData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isLoading, setIsLoading] = useState(true); // State to manage loading
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
  const navigate = useNavigate();

  useEffect(() => {
    const fetchContactData = async () => {
      try {
        const response = await axios.get(`${API_BASE_URL}content.php`
          // " https://manifriendstraders.com/customer_api/content.php"
        );
        const { body } = response.data;
        setContactData(body.contact);
      } catch (error) {
        setError("Error fetching contact data.");
        console.error("Error fetching the contact data", error);
      } finally {
        setLoading(false);
        setIsLoading(false);
      }
    };

    fetchContactData();
  }, []);

  if (isLoading) {
    return <CrackersLoader />; // Show the custom loader while fetching data
  }
  const handleSubmit = async (e) => {
   e.preventDefault(); // prevent actual form submission / page reload

  const formData = new FormData(e.target);
  
    // if (validateForm()) {
      setLoading(true);
  
      // Ensure coupon code is applied before submitting
      // if (!isCouponApplied) {
      //   setCouponCode(""); // Prevents an old or invalid coupon from being sent
      // }
  
      const orderData = {
        name: formData.get('name'),
        mobile: formData.get('mobile'),
        email: formData.get('email'),
        message: formData.get('message')
      };
  
      console.log("Enquiry message Before Sending:", orderData); // Debugging log
  /**/
      try {
        const response = await axios.post(`${API_BASE_URL}send_enquiry_mail.php`,
          // " https://manifriendstraders.com/customer_api/order.php",
          orderData
        );
        console.log("API Response:", response.data);
        alert("enquiry sent successfully!");
        e.target.reset();
        navigate("/contact");
  
        // Call handleOrderSuccess after successful order
        // handleOrderSuccess();
      } catch (error) {
        console.error("There was an error sent enquiry!", error);
      } finally {
        setLoading(false); // Hide loader
      }
      
    // }
  };

  return (
    <div className="main-homepage">
      <Header />
      <Parallax
        bgImage={image2}
        bgImageAlt="the cat"
        // strength={500}
        style={{ minHeight: "100px" }}
      >
        <div style={{ height: "230px" }}>
          <h1
            style={{
              color: "white",
              paddingTop: "100px",
              textAlign: "center",
            }}
          >
            Contact
          </h1>
          <p
            style={{
              display: "flex",
              justifyContent: "center",
              color: "white",
            }}
          >
             <Link to="/" style={{color:"white"}}>
             Home</Link> <i className="bi bi-chevron-right"></i> Contact Us
          </p>
        </div>
      </Parallax>

      <div id="contact" className="contact section">
        <h2 className='main-head'>Have Any Questions?</h2><br />
        <div className="container section-title" data-aos="fade-up">
          <h3 className='main-head1'>Contact Us</h3>
        </div>
        <div className="row gy-4">
          {loading ? (
            <p>Loading...</p>
          ) : error ? (
            <p>{error}</p>
          ) : (
            <>
              <div className="col-lg-4">
                <div
                  className="info-item info-item-1 d-flex flex-column justify-content-center align-items-center"
                  data-aos="fade-up"
                  data-aos-delay="200"
                >
                  <i className="bi bi-geo-alt sticon1"></i>
                  <h3>Address</h3>
                  <p style={{fontFamily: "var(--default-font)"}}>{contactData?.address}</p>
                </div>
              </div>

              <div className="col-lg-4 col-md-6">
                <div
                  className="info-item info-item-2 d-flex flex-column justify-content-center align-items-center"
                  data-aos="fade-up"
                  data-aos-delay="300"
                >
                  <i className="bi bi-telephone sticon1"></i>
                  <h3>Call Us</h3>
                  <p style={{fontFamily: "var(--default-font)"}}>{contactData?.phonenumber}</p>
                </div>
              </div>

              <div className="col-lg-4 col-md-6">
                <div
                  className="info-item info-item-3 d-flex flex-column justify-content-center align-items-center"
                  data-aos="fade-up"
                  data-aos-delay="400"
                >
                  <i className="bi bi-envelope sticon1"></i>
                  <h3>Email Us</h3>
                  <p style={{fontFamily: "var(--default-font)"}}>
                    <a
                      href="/cdn-cgi/l/email-protection"
                      className="__cf_email__"
                      data-cfemail="cea7a0a8a18eabb6afa3bea2abe0ada1a3"
                    >
                      {contactData?.email}
                    </a>
                  </p>
                </div>
              </div>
            </>
          )}
        </div>
        <Sticker /> 
<br />
        <div className="row gy-4 mt-1">
          <div className="col-lg-6" data-aos="fade-up" data-aos-delay="300">
          <iframe
                   src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d6691.667680450708!2d77.7857171!3d11.3994324!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ba967f13871ed8d%3A0x44a9330ef833ba22!2sJALLIKATTU%20CRACKERS!5e1!3m2!1sen!2sin!4v1751264307369!5m2!1sen!2sin"
                   frameBorder="0"
                  style={{ border: "0", width: "100%", height: "400px" }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title="The Jallikkattu Crackers"
               />

          </div>

          <div className="col-lg-6">
            <form
               onSubmit={handleSubmit}
              action="forms/contact.php"
              method="post"
              className="php-email-form"
              data-aos="fade-up"
              data-aos-delay="400"
            >
              <h3 >Contact Form</h3>
              <div className="row gy-4">
                
                <div className="col-md-6">
                  <input
                    type="text"
                    name="name"
                    className="form-control"
                    placeholder="Your Name"
                    required
                  />
                </div>

                <div className="col-md-6">
                   <input
                    type="text"
                    name="mobile"
                    className="form-control"
                    placeholder="Mobile"
                    required
                  />
                </div>

                <div className="col-md-12">
                 
                  <input
                    type="email"
                    name="email"
                    className="form-control"
                    placeholder="Your Email"
                    required
                  />
                </div>

                <div className="col-md-12">
                  <textarea
                    name="message"
                    className="form-control"
                    rows="6"
                    placeholder="Message"
                    required
                  ></textarea>
                </div>

                <div className="col-md-12 text-center">
                  <button type="submit">
                    {loading ? (
                      <Spinner animation="border" size="md" />
                    ) : (
                      "Send Message"
                    )}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
      <Footer />
      <div className="minifooter1">
      <div className="minimenu">
          
      <Link to="/">
            <div style={{display:"flex", flexDirection:"column",color:"white"}}>
          <i class="bi bi-house-door" style={{marginLeft:"12px",fontSize:"1.4rem"}}></i>
             Home
             </div>
             </Link>
         

             <Link to="/about">
          <div style={{display:"flex", flexDirection:"column",color:"white"}}>
          <i class="bi bi-journal-text officon" style={{marginLeft:"20px",fontSize:"1.4rem",color:"white"}}></i>
             About Us
             </div>
             </Link>
             
          
          <Link to="/quick">
          <div style={{display:"flex", flexDirection:"column",color:"white"}}>
          <i class="bi bi-bag" style={{marginLeft:"25px",fontSize:"1.4rem"}}></i>
             Quick Buy
             </div>
             </Link>
          
            
             
          <Link to="/contact">
          <div style={{display:"flex", flexDirection:"column",color:"white"}}>
          <i class="bi bi-telephone" style={{marginLeft:"12px",fontSize:"1.4rem"}}></i>
             Contact
             </div>
             </Link>
          
        </div>
      </div>
    </div>
  );
}

export default Contact;
