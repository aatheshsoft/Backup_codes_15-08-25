import React, { useEffect, useRef } from 'react';

const Animation = () => {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    let w, h;
    const rockets = [];
    const fireworks = [];
    const rocketLaunchRate = 0.05; // Lowered rocket launch rate

    const resizeCanvas = () => {
      w = canvas.width = window.innerWidth;
      h = canvas.height = window.innerHeight;
    };

    const updateWorld = () => {
      update();
      paint();
      if (window.innerWidth < 426) {
        setTimeout(() => requestAnimationFrame(updateWorld), 40); // Slow down for small screens
      } else {
        requestAnimationFrame(updateWorld);
      }
    };

    const update = () => {
      if (Math.random() < rocketLaunchRate) {
        rockets.push(new Rocket());
      }

      for (let i = 0; i < rockets.length; i++) {
        if (!rockets[i].move()) {
          createFirework(rockets[i].x, rockets[i].y);
          rockets.splice(i, 1);
          i--;
        }
      }

      const aliveFireworks = [];
      for (let i = 0; i < fireworks.length; i++) {
        if (fireworks[i].move()) {
          aliveFireworks.push(fireworks[i]);
        }
      }
      fireworks.length = 0;
      fireworks.push(...aliveFireworks);
    };

    const paint = () => {
      ctx.clearRect(0, 0, w, h);
      ctx.globalCompositeOperation = 'lighter';

      for (const rocket of rockets) {
        rocket.draw(ctx);
      }

      for (const firework of fireworks) {
        firework.draw(ctx);
      }
    };

    function Rocket() {
      this.x = Math.random() * (w - 200) + 100;
      this.y = h;
      this.vx = (Math.random() - 0.5) * 1.2;
      this.vy = -Math.random() * 4 - 3; // Reduced speed
      this.size = 7;
      this.trail = [];
      this.color = `rgb(${Math.random() * 255}, ${Math.random() * 255}, ${Math.random() * 255})`;
      this.blastHeight = Math.random() * (h / 2) + 120; // Increased explosion height slightly
    }

    Rocket.prototype = {
      move: function () {
        this.trail.push({ x: this.x, y: this.y });
        if (this.trail.length > 10) this.trail.shift();
        this.x += this.vx;
        this.y += this.vy;
        this.vy += 0.01; // Reduced gravity effect

        return this.y > this.blastHeight;
      },
      draw: function (c) {
        for (let i = 0; i < this.trail.length; i++) {
          const alpha = i / this.trail.length;
          c.fillStyle = `rgba(255, 165, 0, ${alpha})`;
          c.beginPath();
          c.arc(this.trail[i].x, this.trail[i].y, this.size * 0.4, 0, Math.PI * 2);
          c.fill();
        }

        c.fillStyle = this.color;
        c.beginPath();
        c.rect(this.x - this.size / 2, this.y, this.size, this.size * 2);
        c.fill();
      },
    };

    const createFirework = (x, y) => {
      const numParticles = Math.random() * 50 + 60; // Reduced particles slightly
      for (let i = 0; i < numParticles; i++) {
        fireworks.push(new Particle(x, y));
      }
    };

    function Particle(x, y) {
      this.x = x;
      this.y = y;
      this.vx = (Math.random() - 0.5) * 5; // Reduced explosion speed
      this.vy = (Math.random() - 0.5) * 5; // Reduced explosion speed
      this.alpha = 1;
      this.size = Math.random() * 3 + 2;
      this.color = `rgb(${Math.random() * 255}, ${Math.random() * 255}, ${Math.random() * 255})`;
    }

    Particle.prototype = {
      move: function () {
        this.x += this.vx;
        this.y += this.vy;
        this.alpha -= 0.01; // Slower fade-out
        return this.alpha > 0;
      },
      draw: function (c) {
        c.fillStyle = this.color;
        c.globalAlpha = this.alpha;
        c.beginPath();
        c.arc(this.x, this.y, this.size, 0, Math.PI * 2);
        c.fill();
      },
    };

    const init = () => {
      window.addEventListener('resize', resizeCanvas);
      resizeCanvas();
      requestAnimationFrame(updateWorld);
    };

    init();

    return () => {
      window.removeEventListener('resize', resizeCanvas);
    };
  }, []);

  return <canvas ref={canvasRef} style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '80%', zIndex: 1, pointerEvents: 'none' }} />;
};

export default Animation;